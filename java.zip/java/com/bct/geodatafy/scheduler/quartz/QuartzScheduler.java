package com.bct.geodatafy.scheduler.quartz;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.quartz.CalendarIntervalScheduleBuilder;
import org.quartz.CalendarIntervalTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.quartz.impl.StdSchedulerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.bct.geodatafy.job.DynamicJob;
import com.bct.geodatafy.job.GeodatafyJobExecutor;
import com.bct.geodatafy.scheduler.quartz.persistence.XMLJobPersister;
import com.bct.geodatafy.util.JsonUtil;
import com.bct.geodatafy.util.SchedulerUtil;

public class QuartzScheduler {
	static Logger logger = Logger.getLogger(QuartzScheduler.class);
	
	public static final String GROUP_NAME = "GeoDatafyGroup";
	
	public String addJob(JsonObject job) throws Exception{
		
		String jobName = job.get("jobName").getAsString();
		
		if (jobName == null || jobName.length() < 0) {
			logger.info("Job Name is null or empty");
			return "Null or Empty Job Name";
		}
			
		if(!SchedulerUtil.canAdd(job)){		
			logger.info(jobName + ": Not scheduling the job");
			return "Not Scheduled";
		}
		
		StdSchedulerFactory factory = Quartz.getFactory();
		Scheduler scheduler = factory.getScheduler();
		
		JobKey jobKey = new JobKey(jobName, GROUP_NAME);
		TriggerKey triggerKey = new TriggerKey(jobName + "Trigger", GROUP_NAME);
		
		if (scheduler.checkExists(jobKey) || scheduler.checkExists(triggerKey)){
			logger.info(jobName + ": Already Exists");
			return "Already Exists";				
		}
		
		return addJobToScheduler(job, jobKey, triggerKey);			
	}

	private String addJobToScheduler(JsonObject job, JobKey jobKey, TriggerKey triggerKey)
			throws ParseException, Exception, SchedulerException {
		
		String jobName = job.get("jobName").getAsString();
		
		JobDetail jobDetail = JobBuilder.newJob(GeodatafyJobExecutor.class).withIdentity(jobKey).build();
		
		//Just for info
		logger.info(jobName + ": Job data map before populating: " + jobDetail.getJobDataMap().toString());
		printJobDataMap(jobDetail);
		
		setJobDetails(jobDetail.getJobDataMap(), job);
		
		//Just for info
		logger.info(jobName + ": Job data map after populating: " + jobDetail.getJobDataMap().toString());
		printJobDataMap(jobDetail);
		
		CalendarIntervalTrigger trigger = getTrigger(triggerKey, job);
		logger.info(jobName + ": The trigger is: " + trigger );
		
		if(trigger == null){
			String msg = "Null Trigger"; 
			logger.info(msg);
			return msg;
		}		
		StdSchedulerFactory factory = Quartz.getFactory();
		Scheduler scheduler = factory.getScheduler();
		
		logger.info("Adding the persistence of the job for: " + jobName);
		XMLJobPersister.addJob(jobDetail, trigger);
		
		Date date = scheduler.scheduleJob(jobDetail, trigger);
		logger.info(jobName + ": After adding the scheduling details, the scheduler returned the date: " + date);
		
		return "Scheduled";
	}
	
	public String updateJob(JsonObject job) throws Exception {
		String jobName = job.get("jobName").getAsString();
		
		if (jobName == null || jobName.length() < 0) {
			logger.info("Job Name is null or empty");
			return "Null or Empty Job Name";
		}

		StdSchedulerFactory factory = Quartz.getFactory();
		Scheduler scheduler = factory.getScheduler();			
		JobKey jobKey = new JobKey(jobName, GROUP_NAME);
		
		
		if (!scheduler.checkExists(jobKey)){
			logger.info("Job does not exist in the scheduler. Instead of updating, creating the job.");
			TriggerKey triggerKey = new TriggerKey(jobName + "Trigger", GROUP_NAME);			
			return addJobToScheduler(job, jobKey, triggerKey);				
		}
		
		JobDetail jobDetail = scheduler.getJobDetail(jobKey);
		setJobDetails(jobDetail.getJobDataMap(), job);
		scheduler.deleteJob(jobKey);
		
		logger.info("Updating the persistence of the job for: " + jobName);
		XMLJobPersister.updateJob(jobDetail);
		
		String active = job.get("active").getAsString();
		if(active.equalsIgnoreCase("true")){
			TriggerKey triggerKey = new TriggerKey(jobName + "Trigger", GROUP_NAME);
			CalendarIntervalTrigger trigger = getTrigger(triggerKey, job);
			Date date = scheduler.scheduleJob(jobDetail, trigger);
			logger.info(jobName + ": After updating the scheduling details, the scheduler returned the date: " + date);
		}		
		return "Updated";
	}
	
	public String deleteJob(String jobName) throws Exception {
		if (jobName == null || jobName.length() < 0) {
			logger.info("Job Name is null or empty");
			return "Null or Empty Job Name";
		}
		StdSchedulerFactory factory = Quartz.getFactory();
		Scheduler scheduler = factory.getScheduler();			
		JobKey jobKey = new JobKey(jobName, GROUP_NAME);
		//TriggerKey triggerKey = new TriggerKey(jobName + "Trigger", GROUP_NAME);
		
		if (!scheduler.checkExists(jobKey)){
			logger.info("Job does not exist in the scheduler. Could not delete.");
			return "Job Does not exists";			
		}
		
		scheduler.deleteJob(jobKey);
		logger.info(jobName + ": Deleted from the scheduler");
		
		XMLJobPersister.deleteJob(jobName);

		return "Deleted";
	}

	private void printJobDataMap(JobDetail jobDetail) {
		JobDataMap jdm = jobDetail.getJobDataMap();
		String keys[] = jdm.getKeys();
		if(keys == null || keys.length <1){
			logger.info("No Keys in job data map");
		} else {
			for(String key: keys){
				logger.info("Key: " + key);
				logger.info("Value: " + jdm.get(key).toString());
			}
		}
	}
		
	private CalendarIntervalTrigger getTrigger(TriggerKey triggerKey, JsonObject job) throws ParseException {
		CalendarIntervalTrigger trigger = null;
		
		Date date = new Date(System.currentTimeMillis() + 10000);
		JsonElement  startDateTime = job.get("startDateTime");
		if(startDateTime != null){
			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			date = formatter.parse(startDateTime.getAsString());
		}					 			
				
		String duration = "";
		JsonElement  durationElement = job.get("duration");
		if(durationElement != null){
			duration = durationElement.getAsString();
		}
		
		int interval = -1;
		JsonElement  intervalElement = job.get("interval");
		if(intervalElement != null){
			interval = intervalElement.getAsInt();	
		}
		
		if (duration.toLowerCase().contains("second")) {
			
			trigger = TriggerBuilder.newTrigger().withIdentity(triggerKey).startAt(date)
					.withSchedule(CalendarIntervalScheduleBuilder.calendarIntervalSchedule().withIntervalInSeconds(interval))
					.build();
			logger.info("Created the trigger - " + trigger + " for second");
		}else if (duration.toLowerCase().contains("minute")) {
			trigger = TriggerBuilder.newTrigger().withIdentity(triggerKey).startAt(date)
					.withSchedule(CalendarIntervalScheduleBuilder.calendarIntervalSchedule().withIntervalInMinutes(interval))
					.build();
			logger.info("Created the trigger - " + trigger + " for minute");
		}else if (duration.toLowerCase().contains("hour")) {
			trigger = TriggerBuilder.newTrigger().withIdentity(triggerKey).startAt(date)
					.withSchedule(CalendarIntervalScheduleBuilder.calendarIntervalSchedule().withIntervalInHours(interval))
					.build();
			logger.info("Created the trigger - " + trigger + " for hour");
		}else if (duration.toLowerCase().contains("day")) {
			trigger = TriggerBuilder.newTrigger().withIdentity(triggerKey).startAt(date)
					.withSchedule(CalendarIntervalScheduleBuilder.calendarIntervalSchedule().withIntervalInDays(interval))
					.build();		
			logger.info("Created the trigger - " + trigger + " for day");
		}else if (duration.toLowerCase().contains("week")) {
			trigger = TriggerBuilder.newTrigger().withIdentity(triggerKey).startAt(date)
					.withSchedule(CalendarIntervalScheduleBuilder.calendarIntervalSchedule().withIntervalInWeeks(interval))
					.build();
			logger.info("Created the trigger - " + trigger + " for week");
		}else if (duration.toLowerCase().contains("month")) {
			trigger = TriggerBuilder.newTrigger().withIdentity(triggerKey).startAt(date)
					.withSchedule(CalendarIntervalScheduleBuilder.calendarIntervalSchedule().withIntervalInMonths(interval))
					.build();
			logger.info("Created the trigger - " + trigger + " for month");
		}else if (duration.toLowerCase().contains("year")) {
			trigger = TriggerBuilder.newTrigger().withIdentity(triggerKey).startAt(date)
					.withSchedule(CalendarIntervalScheduleBuilder.calendarIntervalSchedule().withIntervalInYears(interval))
					.build();
			logger.info("Created the trigger - " + trigger + " for year");
		}else{
			logger.info("The duraion does not have any of the defined values second, minute, hour, day, week, month, year.");
		}
		return trigger;
	}
		
	private void setJobDetails(JobDataMap jdm, JsonObject job)
	{
		//Can make it generic???
		//jdm.put("groupName", GROUP_NAME);
		
		JsonElement jobName = job.get("jobName");
		if(jobName != null){
			jdm.put("jobName", jobName.getAsString());
		}
		JsonElement jobType = job.get("jobType");
		if(jobType != null){
			jdm.put("jobType", jobType.getAsString());
		}
		JsonElement endPointURL = job.get("endPointURL");
		if(endPointURL != null){
			jdm.put("endPointURL", endPointURL.getAsString());
		}
		JsonElement startDateTime = job.get("startDateTime");					 			
		if(startDateTime != null){
			jdm.put("startDateTime", startDateTime.getAsString());
		}else{
			Date date = new Date(System.currentTimeMillis() + 10000);
			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			String dateString = formatter.format(date);
			jdm.put("startDateTime", dateString);
		}
		JsonElement interval = job.get("interval");
		if(interval != null){
			jdm.put("interval", interval.getAsString());
		}
		JsonElement duration = job.get("duration");
		if(duration != null){
			jdm.put("duration", duration.getAsString());
		}
		JsonElement active = job.get("active");
		if(active != null){
			jdm.put("active", active.getAsString());
		}		
		JsonElement scheduled = job.get("scheduled");
		if(scheduled != null){
			jdm.put("scheduled", scheduled.getAsString());
		}		
		JsonElement jobData = job.get("jobData");
		if(jobData != null){
			jdm.put("jobData", jobData.getAsString());
		}
	}
}
