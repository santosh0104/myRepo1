package com.bct.geodatafy.scheduler.quartz.persistence;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="job")
@XmlType(propOrder= {"name","group","description","jobClassName", "jobDataMap"})
@XmlAccessorType(XmlAccessType.PROPERTY)
public class Job {
	
	private String name;
	private String group;
	private String description;
	private String jobClassName;
	private JobDataMap jobDataMap;
	
	public Job() {	
		//Do nothing now
	}
	
	public Job(String name,String group,String desc,String jobClassName, JobDataMap jobDataMap) {
		this.name = name;
		this.group = group;
		this.description = desc;
		this.jobClassName = jobClassName;
		this.jobDataMap = jobDataMap;
	}
	
	@XmlElement(name="name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlElement(name="group")
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	
	@XmlElement(name="description")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@XmlElement(name="job-class")
	public String getJobClassName() {
		return jobClassName;
	}
	public void setJobClassName(String jobClassName) {
		this.jobClassName = jobClassName;
	}	
		
	@XmlElement(name="job-data-map")
	public JobDataMap getJobDataMap() {
		return jobDataMap;
	}
	public void setJobDataMap(JobDataMap jobDataMap) {
		this.jobDataMap = jobDataMap;
	}	
}
