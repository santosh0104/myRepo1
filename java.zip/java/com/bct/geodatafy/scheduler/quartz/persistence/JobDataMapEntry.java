package com.bct.geodatafy.scheduler.quartz.persistence;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "entry")
@XmlType(propOrder = { "jobDataMapKey", "jobDataMapValue" })
@XmlAccessorType(XmlAccessType.PROPERTY)
public class JobDataMapEntry {

	private String jobDataMapKey;
	private Object jobDataMapValue;

	@XmlElement(name = "key")
	public String getJobDataMapKey() {
		return jobDataMapKey;
	}
	public void setJobDataMapKey(String jobDataMapKey) {
		this.jobDataMapKey = jobDataMapKey;
	}

	@XmlElement(name = "value")
	public Object getJobDataMapValue() {
		return jobDataMapValue;
	}
	public void setJobDataMapValue(Object jobDataMapValue) {
		this.jobDataMapValue = jobDataMapValue;
	}
}
