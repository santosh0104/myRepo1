package com.bct.geodatafy.scheduler.quartz.persistence;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "calendar-interval")
@XmlType(propOrder = { "name", "group", "jobName", "jobGroup", "startTime", "repeatInterval", "repeatIntervalUnit" })
@XmlAccessorType(XmlAccessType.PROPERTY)
public class CalendarInterval {
	private String name;
	private String group;
	private String jobName;
	private String jobGroup;
	private String startTime;
	private int repeatInterval;
	private String repeatIntervalUnit;

	public CalendarInterval() {

	}

	@XmlElement(name = "name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	@XmlElement(name = "group")
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}

	@XmlElement(name = "job-name")
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	@XmlElement(name = "job-group")
	public String getJobGroup() {
		return jobGroup;
	}
	public void setJobGroup(String jobGroup) {
		this.jobGroup = jobGroup;
	}

	@XmlElement(name = "start-time")
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	@XmlElement(name = "repeat-interval")
	public int getRepeatInterval() {
		return repeatInterval;
	}
	public void setRepeatInterval(int repeatInterval) {
		this.repeatInterval = repeatInterval;
	}

	@XmlElement(name = "repeat-interval-unit")
	public String getRepeatIntervalUnit() {
		return repeatIntervalUnit;
	}
	public void setRepeatIntervalUnit(String repeatIntervalUnit) {
		this.repeatIntervalUnit = repeatIntervalUnit;
	}
}