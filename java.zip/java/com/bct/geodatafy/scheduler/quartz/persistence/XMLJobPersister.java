package com.bct.geodatafy.scheduler.quartz.persistence;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;
import org.quartz.CalendarIntervalTrigger;
import org.quartz.JobDetail;

import com.bct.geodatafy.scheduler.quartz.Quartz;
import com.bct.geodatafy.scheduler.quartz.QuartzScheduler;
import com.bct.geodatafy.util.EnvUtil;
import com.bct.geodatafy.util.SchedulerUtil;

public class XMLJobPersister {
	static Logger logger = Logger.getLogger(XMLJobPersister.class);
	private static File QUARTZ_CONFIG_FILE = null;
	
	static {		
			String configFileName = "/config/quartz/quartz-config.xml";
			//String programData  = System.getenv("GD_DATA_PATH");
			String programData = EnvUtil.getGDDataPath();
			if(programData != null && !programData.isEmpty()){
				configFileName = programData + configFileName;
			}
			QUARTZ_CONFIG_FILE = new File(configFileName);
	}
		
	public static void addJob(JobDetail jobDetail, CalendarIntervalTrigger trigger) throws Exception{
		
		if(jobDetail == null || trigger == null){
			logger.info("The input parameter JobDetail or CalendarIntervalTrigger is null. Not persisting. ");
		}
		org.quartz.JobDataMap jdm = jobDetail.getJobDataMap();
		String jobName = jdm.getString("jobName");
		
		if(!SchedulerUtil.canAdd(jdm)){		
			logger.info(jobName + ": Not persisting the job");
			return;
		}
		
		JobSchedulingData existingData = getExistingData();
		//This cannot be null - it will throw an exception
		ProcessingDirectives pd = existingData.getProcessingdirectives();
		if(pd == null){
			pd = new ProcessingDirectives();
			pd.setIgnoreDuplicates(true);
			pd.setOverwriteExistingData(false);			
		}
		//This cannot be null
		List<Schedule> schedules = existingData.getSchedules();			
		Schedule schedule = createSchedule(jdm);
		schedules.add(schedule);

		JobSchedulingData currentData = new JobSchedulingData();
		currentData.setProcessingdirectives(pd);
		currentData.setSchedules(schedules);
		
		writeData(currentData);
		logger.info("Added the " + jobName + " job details to the persistance.");
	}

	public static void updateJob(JobDetail jobDetail) throws Exception{
		org.quartz.JobDataMap jdm = jobDetail.getJobDataMap();
		String jobName = jdm.getString("jobName");
		
		if(!SchedulerUtil.canUpdate(jdm)){		
			logger.info(jobName + ": Not updating the job");
			return;
		}

		logger.info("Updating the JobDetail for the job: " + jobName);
		
		String active = jdm.getString("active");
		boolean update = true;
		
		if(active == null || active.equalsIgnoreCase("false")){
			update = false;
		}
					
		JobSchedulingData existingData = getExistingData();
		List<Schedule> schedules = existingData.getSchedules();
		
		for(int i = 0; i < schedules.size(); i++){
			if(schedules.get(i).getJob().getName().equals(jobName)){
				schedules.remove(i);
				logger.info("Found the schedule for the job: " + jobName + " and removing the same to update.");
				break;
			}
		}
		if(update){
			Schedule schedule = createSchedule(jdm);
			schedules.add(schedule);
			logger.info("Added the schedule for the job: " + jobName + " to update.");
		}
		existingData.setSchedules(schedules);
		writeData(existingData);
		
		logger.info("Updated the " + jobName + " job details to the persistance.");
	}

	public static void deleteJob(String jobName) throws Exception{		
		logger.info("Deleting the JobDetail for the job: " + jobName);			
		boolean exist = false;
		
		JobSchedulingData existingData = getExistingData();
		List<Schedule> schedules = existingData.getSchedules();		
		for(int i = 0; i < schedules.size(); i++){
			if(schedules.get(i).getJob().getName().equals(jobName)){
				schedules.remove(i);
				exist = true;
				logger.info("Found the schedule for the job: " + jobName + " and deleting the same.");
				break;
			}
		}
		if(exist){
			existingData.setSchedules(schedules);
			writeData(existingData);
			logger.info("Deleted the " + jobName + " job details from the persistance.");
		}
		else{
			logger.info("Could not find the schedule for the job: " + jobName + " to delete.");
		}
	}

	private static JobSchedulingData getExistingData() throws JAXBException {
		JAXBContext jaxbContext = JAXBContext.newInstance(JobSchedulingData.class);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		JobSchedulingData existingData = (JobSchedulingData) unmarshaller.unmarshal(QUARTZ_CONFIG_FILE);
		return existingData;
	}

	private static void writeData(JobSchedulingData currentData) throws FileNotFoundException, JAXBException {		
		JAXBContext jaxbContext = JAXBContext.newInstance(JobSchedulingData.class);		
		Marshaller marsheller = jaxbContext.createMarshaller();
		
		marsheller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		marsheller.setProperty(Marshaller.JAXB_SCHEMA_LOCATION,
				"http://www.quartz-scheduler.org/xml/JobSchedulingData 	http://www.quartz-scheduler.org/xml/job_scheduling_data_2_0.xsd");
		marsheller.setProperty("com.sun.xml.bind.xmlDeclaration", Boolean.FALSE);

		FileOutputStream fis = new FileOutputStream(QUARTZ_CONFIG_FILE);
		OutputStreamWriter osw = new OutputStreamWriter(fis);
		BufferedWriter bw = new BufferedWriter(osw);
		marsheller.marshal(currentData, bw);
	}


	private static Schedule createSchedule(org.quartz.JobDataMap jdm) {
		Job job = createJob(jdm);						
		Trigger trigger = createTrigger(jdm);

		Schedule schedule = new Schedule();
		schedule.setJob(job);
		schedule.setTrigger(trigger);
		return schedule;
	}

	private static Trigger createTrigger(org.quartz.JobDataMap jdm) {
		Trigger trigger = new Trigger();		
		CalendarInterval calendar = new CalendarInterval();		
		calendar.setJobName(jdm.getString("jobName"));
		calendar.setJobGroup(QuartzScheduler.GROUP_NAME);
		calendar.setName(jdm.getString("jobName") + "Trigger");
		calendar.setGroup(QuartzScheduler.GROUP_NAME);		
		calendar.setStartTime(jdm.getString("startDateTime"));
		calendar.setRepeatInterval(jdm.getIntFromString("interval"));
		calendar.setRepeatIntervalUnit(jdm.getString("duration").toUpperCase());
		trigger.setCalendar(calendar);
		return trigger;
	}

	private static Job createJob(org.quartz.JobDataMap jdm) {
		Job job = new Job();
		job.setName(jdm.getString("jobName"));
		job.setGroup(QuartzScheduler.GROUP_NAME);
		job.setDescription("job Description");
		job.setJobClassName("com.bct.geodatafy.job.GeodatafyJobExecutor");
		
		JobDataMap jobDataMap = new JobDataMap();	
		jobDataMap.setEntry(createJobDataEntries(jdm));
		
		job.setJobDataMap(jobDataMap);
		return job;
	}

	private static List<JobDataMapEntry> createJobDataEntries(org.quartz.JobDataMap jdm) {
		
		//Can make it generic???
		
		List<JobDataMapEntry> entries = new ArrayList<JobDataMapEntry>();
		
		String jobName = jdm.getString("jobName");
		if(jobName != null && jobName.length() > 0){
			JobDataMapEntry jobNameEntry = new JobDataMapEntry();
			jobNameEntry.setJobDataMapKey("jobName");
			jobNameEntry.setJobDataMapValue(jobName);
			entries.add(jobNameEntry);
		}

		String jobType = jdm.getString("jobType");
		if(jobType != null && jobType.length() > 0){
			JobDataMapEntry jobTypeEntry = new JobDataMapEntry();
			jobTypeEntry.setJobDataMapKey("jobType");
			jobTypeEntry.setJobDataMapValue(jobType);
			entries.add(jobTypeEntry);
		}

		String jobData = jdm.getString("jobData");
		if(jobData != null && jobData.length() > 0){
			JobDataMapEntry jobDataEntry = new JobDataMapEntry();
			jobDataEntry.setJobDataMapKey("jobData");
			jobDataEntry.setJobDataMapValue(jobData);
			entries.add(jobDataEntry);
		}
		
		String active = jdm.getString("active");
		if(active != null && active.length() > 0){
			JobDataMapEntry activeEntry = new JobDataMapEntry();
			activeEntry.setJobDataMapKey("active");
			activeEntry.setJobDataMapValue(active);
			entries.add(activeEntry);
		}		
		
		String scheduled = jdm.getString("scheduled");
		if(scheduled != null && scheduled.length() > 0){
			JobDataMapEntry scheduledEntry = new JobDataMapEntry();
			scheduledEntry.setJobDataMapKey("scheduled");
			scheduledEntry.setJobDataMapValue(scheduled);
			entries.add(scheduledEntry);
		}

		String endPointURL = jdm.getString("endPointURL");
		if(endPointURL != null && endPointURL.length() > 0){
			JobDataMapEntry endPointEntry = new JobDataMapEntry();
			endPointEntry.setJobDataMapKey("endPointURL");
			endPointEntry.setJobDataMapValue(endPointURL);
			entries.add(endPointEntry);
		}		
		return entries;
	}
	
	


}

