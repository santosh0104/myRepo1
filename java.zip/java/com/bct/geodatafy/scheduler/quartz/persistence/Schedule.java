package com.bct.geodatafy.scheduler.quartz.persistence;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="schedule")
public class Schedule {
	
	private Job job;
	private Trigger trigger;
	
	public Schedule() {
		job =  new Job();
		trigger = new Trigger();
	}

	public Job getJob() {
		return job;
	}	
	public void setJob(Job job) {
		this.job = job;
	}

	public Trigger getTrigger() {
		return trigger;
	}
	public void setTrigger(Trigger trigger) {
		this.trigger = trigger;
	}
}
