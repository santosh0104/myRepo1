package com.bct.geodatafy.scheduler.quartz.persistence;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "trigger")
public class Trigger {
	private CalendarInterval calendar;

	public Trigger() {
		calendar = new CalendarInterval();
	}
	
	@XmlElement(name = "calendar-interval")
	public void setCalendar(CalendarInterval calendar) {
		this.calendar = calendar;
	}
	public CalendarInterval getCalendar() {
		return calendar;
	}
}
