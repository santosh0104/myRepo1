/**
 * 
 */
/**
 * @author KS111138
 *
 */

@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.quartz-scheduler.org/xml/JobSchedulingData", 
xmlns = {@XmlNs(prefix = "", namespaceURI = "http://www.quartz-scheduler.org/xml/JobSchedulingData"), 
		 @XmlNs(prefix = "xsi", namespaceURI = "http://www.w3.org/2001/XMLSchema-instance")
		}, elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)

package com.bct.geodatafy.scheduler.quartz.persistence;

import javax.xml.bind.annotation.XmlNs;