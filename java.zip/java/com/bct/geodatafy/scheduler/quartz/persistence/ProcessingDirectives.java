package com.bct.geodatafy.scheduler.quartz.persistence;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "processing-directives")
@XmlType(propOrder= {"overwriteExistingData","ignoreDuplicates"})
@XmlAccessorType(XmlAccessType.PROPERTY)
public class ProcessingDirectives {

	private boolean overwriteExistingData;
	private boolean ignoreDuplicates;
		
	@XmlElement(name = "overwrite-existing-data")
	public boolean getOverwriteExistingData() {
		return overwriteExistingData;
	}
	public void setOverwriteExistingData(boolean overwriteExistingData) {
		this.overwriteExistingData = overwriteExistingData;
	}

	@XmlElement(name = "ignore-duplicates")
	public boolean getIgnoreDuplicates() {
		return ignoreDuplicates;
	}
	public void setIgnoreDuplicates(boolean ignoreDuplicates) {
		this.ignoreDuplicates = ignoreDuplicates;
	}
}
