package com.bct.geodatafy.scheduler.quartz.persistence;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "job-data-map")
public class JobDataMap {
	private List<JobDataMapEntry> entry;
	
	public JobDataMap() {
		entry = new ArrayList<JobDataMapEntry>();
	}
	
	@XmlElement(name = "entry")
	public List<JobDataMapEntry> getEntry() {
		return entry;
	}
	public void setEntry(List<JobDataMapEntry> entry) {
		this.entry = entry;
	}
}
