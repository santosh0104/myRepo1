package com.bct.geodatafy.scheduler.quartz.persistence;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "job-scheduling-data")
public class JobSchedulingData {
	
	private List<Schedule> schedules = new ArrayList<Schedule>();
	private ProcessingDirectives processingdirectives;
	
	public JobSchedulingData() {
		schedules = new ArrayList<Schedule>();
	}
	
	@XmlElement(name="schedule")
	public List<Schedule> getSchedules() {
		return schedules;
	}
	public void setSchedules(List<Schedule> schedules) {
		this.schedules = schedules;
	}

	@XmlElement(name="processing-directives")
	public ProcessingDirectives getProcessingdirectives() {
		return processingdirectives;
	}
	public void setProcessingdirectives(ProcessingDirectives processingdirectives) {
		this.processingdirectives = processingdirectives;
	}
	
	@XmlAttribute(name = "version")
	public String getVersion() {
		return "2.0";
	}
}
