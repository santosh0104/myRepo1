package com.bct.geodatafy.scheduler.quartz;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class QuartzListener implements ServletContextListener {

	public void contextInitialized(ServletContextEvent context){
		Quartz.invokeQuartz();
	}

	public void contextDestroyed(ServletContextEvent context) {

	}
}
