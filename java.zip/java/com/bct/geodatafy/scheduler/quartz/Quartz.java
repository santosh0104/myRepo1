package com.bct.geodatafy.scheduler.quartz;

import java.util.Properties;

import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.impl.StdSchedulerFactory;

import com.bct.geodatafy.util.EnvUtil;

public class Quartz {

	private static StdSchedulerFactory factory = null;
	//public static final String QUARTZ_PROPERTIES_FILE = "quartz.properties";

	public static StdSchedulerFactory getFactory() throws SchedulerException {
		if(factory == null){
			//factory = new StdSchedulerFactory(QUARTZ_PROPERTIES_FILE);	
			factory = new StdSchedulerFactory();
			String persistanceFileName = "/config/quartz/quartz-config.xml";
			//String programData  = System.getenv("GD_DATA_PATH");
			String programData = EnvUtil.getGDDataPath();
			if(programData != null && !programData.isEmpty()){
				persistanceFileName = programData + persistanceFileName;
			}
			Properties properties = new Properties();
			properties.put("org.quartz.scheduler.instanceName","GeodatafyJobScheduler");
			properties.put("org.quartz.threadPool.threadCount","3");
			properties.put("org.quartz.jobStore.class","org.quartz.simpl.RAMJobStore");
			properties.put("org.quartz.plugin.jobInitializer.class","org.quartz.plugins.xml.XMLSchedulingDataProcessorPlugin");
			properties.put("org.quartz.plugin.jobInitializer.fileNames", persistanceFileName);
			properties.put("org.quartz.plugin.jobInitializer.failOnFileNotFound",true);
			factory.initialize(properties);
		}		
		return factory;
	}
	
	public static void invokeQuartz() {
		try {
			StdSchedulerFactory factory = Quartz.getFactory();
			Scheduler scheduler = factory.getScheduler();
			scheduler.start();
		} catch (SchedulerException e) {
			e.printStackTrace();
		}
	}
}

