package com.bct.geodatafy.job;

import java.util.List;

public class GeodatafyJobType {
	private String name;
	private List<GeodatafyJobParameter> parameters;

	public GeodatafyJobType(){
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<GeodatafyJobParameter> getParameters() {
		return parameters;
	}

	public void setParameters(List<GeodatafyJobParameter> parameters) {
		this.parameters = parameters;
	}
}
