package com.bct.geodatafy.job.alert;

import java.util.List;
import java.util.Map;

public class AlertJobData {
	
	

	private String solrHost;
	private String solrPort;
	private String linkUrl;
	public String getLinkUrl() {
		return linkUrl;
	}

	public void setLinkUrlt(String linkUrl) {
		this.linkUrl = linkUrl;
	}

	private String solrCollectionName;	
	private String cartId;
	private String emailRecipients;
	private String LastExecutionTime;
	
	
	

	public String getCartId() {
		return cartId;
	}

	public void setCartId(String cartId) {
		this.cartId = cartId;
	}

	public String getEmailRecipients() {
		return emailRecipients;
	}

	public void setEmailRecipients(String emailRecipients) {
		this.emailRecipients = emailRecipients;
	}

	public String getLastExecutionTime() {
		return LastExecutionTime;
	}

	public void setLastExecutionTime(String lastExecutionTime) {
		LastExecutionTime = lastExecutionTime;
	}

	/**
	 * @return the solrHost
	 */
	public String getSolrHost() {
		return solrHost;
	}

	/**
	 * @param solrHost the solrHost to set
	 */
	public void setSolrHost(String solrHost) {
		this.solrHost = solrHost;
	}

	/**
	 * @return the solrPort
	 */
	public String getSolrPort() {
		return solrPort;
	}

	/**
	 * @param solrPort the solrPort to set
	 */
	public void setSolrPort(String solrPort) {
		this.solrPort = solrPort;
	}


	public String getSolrCollectionName() {
		return solrCollectionName;
	}

	public void setSolrCollectionName(String solrCollectionName) {
		this.solrCollectionName = solrCollectionName;
	}

	public AlertJobData(String cartId, String emailRecipient, String lastExecutionTime,  String solrHost, String solrPort, String linkUrl, String solrCollectionName){
	this.cartId = cartId;	
	this.emailRecipients = emailRecipient;
	this.solrHost = solrHost;
	this.solrPort = solrPort;
	this.linkUrl = linkUrl;
	this.solrCollectionName = solrCollectionName;
	this.LastExecutionTime = lastExecutionTime;	
	
}
}
