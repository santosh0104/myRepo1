package com.bct.geodatafy.job.alert;

import java.util.ArrayList;
import java.util.List;

import com.bct.geodatafy.cart.CartDetails;

public class AlertJob{
	
	public static final String SOL_DATA_TYPE = "jobRuns";
	
	public static final String JOB_RUNNING = "RUNNING";
	public static final String JOB_COMPLETED = "COMPLETED";
	public static final String JOB_ERROR = "ERROR";
	
	private String solrDocID;
	private String jobName;
	private String jobType;
	private String jobStatus;
	private String startTime;	
	private String endTime;
	private String logFileName;
	private String jobDataString;
	private String updatedDate;
	private boolean sendMail = false;
	
	private AlertJobData jobData;	
	private List<AlertJobStatistics> statistics;
	//private ArrayList<CartDetails> cartDetailsList;

	public String getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	public boolean isSendMail() {
		return sendMail;
	}
	public void setSendMail(boolean sendMail) {
		this.sendMail = sendMail;
	}



	
	/*public ArrayList<CartDetails> getCartDetailsList() {
		return cartDetailsList;
	}
	public void setCartDetailsList(ArrayList<CartDetails> cartDetailsList) {
		this.cartDetailsList = cartDetailsList;
	}*/
	public String getJobDataString() {
		return jobDataString;
	}
	public void setJobDataString(String jobDataString) {
		this.jobDataString = jobDataString;
	}
	public String getSolrDocID() {
		return solrDocID;
	}
	public void setSolrDocID(String solrDocID) {
		this.solrDocID = solrDocID;
	}
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getJobStatus() {
		return jobStatus;
	}
	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getLogFileName() {
		return logFileName;
	}
	public void setLogFileName(String logFileName) {
		this.logFileName = logFileName;
	}
	public AlertJobData getJobData() {
		return jobData;
	}
	public void setJobData(AlertJobData jobData) {
		this.jobData = jobData;
	}
	public List<AlertJobStatistics> getStatistics() {
		return statistics;
	}
	public void setStatistics(List<AlertJobStatistics> statistics) {
		this.statistics = statistics;
	}
	
	@Override
	public String toString() {
		return "AlertJob [solrDocID=" + solrDocID + ", jobName=" + jobName + ", jobType=" + jobType
				+ ", jobStatus=" + jobStatus + ", startTime=" + startTime + ", endTime=" + endTime + ", logFileName="
				+ logFileName + ", jobData=" + jobData + ", statistics=" + statistics + "]";
	}
}
