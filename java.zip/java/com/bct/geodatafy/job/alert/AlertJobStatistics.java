package com.bct.geodatafy.job.alert;

import java.util.ArrayList;
import java.util.List;

public class AlertJobStatistics {
	public String getDataType() {
		return dataType;
	}




	public void setDataType(String dataType) {
		this.dataType = dataType;
	}




	public void setTotal(int total) {
		this.total = total;
	}

	private String dataType;
	private int total;
	private int successful;
	private int skipped;
	private int failed;
	private int newlyIndexed;
	private int notIndexed;
	private int modified;
	private int unmodified;
	
	
	public int getModified() {
		return modified;
	}




	public void setModified(int modified) {
		this.modified = modified;
	}




	public int getUnmodified() {
		return unmodified;
	}




	public void setUnmodified(int unmodified) {
		this.unmodified = unmodified;
	}




	public int getNewlyIndexed() {
		return newlyIndexed;
	}




	public void setNewlyIndexed(int newlyIndexed) {
		this.newlyIndexed = newlyIndexed;
	}




	public int getNotIndexed() {
		return notIndexed;
	}




	public void setNotIndexed(int notIndexed) {
		this.notIndexed = notIndexed;
	}




	public AlertJobStatistics(String jobName){
		
		dataType = jobName;
		total = 0;
		successful = 0;
		skipped = 0;
		failed = 0;
		modified = 0;
		unmodified = 0;
	}



	
	public String getDataTypes() {
		return dataType;
	}

	public void setDataTypes(String dataType) {
		this.dataType = dataType;
		
	}

	public int getTotal() {
		return total;
	}

	public int getSuccessful() {
		return successful;
	}

	public void setSuccessful(int successful) {
		this.successful = successful;
	}

	public int getSkipped() {
		return skipped;
	}

	public void setSkipped(int skipped) {
		this.skipped = skipped;
	}

	public int getFailed() {
		return failed;
	}

	public void setFailed(int failed) {
		this.failed = failed;
	}	
}
