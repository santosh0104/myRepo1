package com.bct.geodatafy.job.document;

import java.util.ArrayList;
import java.util.List;

public class DocumentIndexJobStatistics {
	private String extension;
	private List<String> fileNames;
	private int total;
	private int successful;
	private int skipped;
	private int failed;
	
	public DocumentIndexJobStatistics(String extension){
		this.extension = extension;
		fileNames = new ArrayList<String>();
		total = fileNames.size();
		successful = 0;
		skipped = 0;
		failed = 0;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public List<String> getFileNames() {
		return fileNames;
	}

	public void setFileNames(List<String> fileNames) {
		this.fileNames = fileNames;
		total = fileNames.size();
	}

	public int getTotal() {
		return total;
	}

	public int getSuccessful() {
		return successful;
	}

	public void setSuccessful(int successful) {
		this.successful = successful;
	}

	public int getSkipped() {
		return skipped;
	}

	public void setSkipped(int skipped) {
		this.skipped = skipped;
	}

	public int getFailed() {
		return failed;
	}

	public void setFailed(int failed) {
		this.failed = failed;
	}	
}
