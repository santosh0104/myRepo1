package com.bct.geodatafy.job.document;

public class DocumentIndexJobProcessor {

	public DocumentIndexJobProcessor() {
		// TODO Auto-generated constructor stub
	}

}
