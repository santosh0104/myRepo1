package com.bct.geodatafy.job.document;

import java.util.List;
import java.util.Map;

public class DocumentIndexJobData {
	
	private String rootFolder;
	private boolean recurseFolder;
	private String solrHost;
	private String solrPort;
	private String solrCollectionName;
	private List<String> fileTypes;
	private boolean isWebAccess;
	private boolean isFileAccess;
		private String virtualPathName;
	private String onlyNew;
	private String projectName;
	
	public boolean isFileAccess() {
		return isFileAccess;
	}

	public void setFileAccess(boolean isFileAccess) {
		this.isFileAccess = isFileAccess;
	}


	
	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getOnlyNew() {
		return onlyNew;
	}

	public void setOnlyNew(String onlyNew) {
		this.onlyNew = onlyNew;
	}

	/**
	 * @return the isWebAccess
	 */
	public boolean isWebAccess() {
		return isWebAccess;
	}

	/**
	 * @param isWebAccess the isWebAccess to set
	 */
	public void setWebAccess(boolean isWebAccess) {
		this.isWebAccess = isWebAccess;
	}

	/**
	 * @return the virtualPathName
	 */
	public String getVirtualPathName() {
		return virtualPathName;
	}

	/**
	 * @param virtualPathName the virtualPathName to set
	 */
	public void setVirtualPathName(String virtualPathName) {
		this.virtualPathName = virtualPathName;
	}

	/**
	 * @return the solrHost
	 */
	public String getSolrHost() {
		return solrHost;
	}

	/**
	 * @param solrHost the solrHost to set
	 */
	public void setSolrHost(String solrHost) {
		this.solrHost = solrHost;
	}

	/**
	 * @return the solrPort
	 */
	public String getSolrPort() {
		return solrPort;
	}

	/**
	 * @param solrPort the solrPort to set
	 */
	public void setSolrPort(String solrPort) {
		this.solrPort = solrPort;
	}

	public String getRootFolder() {
		return rootFolder;
	}

	public void setRootFolder(String rootFolder) {
		this.rootFolder = rootFolder;
	}

	public boolean isRecurseFolder() {
		return recurseFolder;
	}

	public void setRecurseFolder(boolean recurseFolder) {
		this.recurseFolder = recurseFolder;
	}

	public String getSolrCollectionName() {
		return solrCollectionName;
	}

	public void setSolrCollectionName(String solrCollectionName) {
		this.solrCollectionName = solrCollectionName;
	}

	public List<String> getFileTypes() {
		return fileTypes;
	}

	public void setFileTypes(List<String> fileTypes) {
		this.fileTypes = fileTypes;
	}

	public DocumentIndexJobData(String rootFolder, boolean recurseFolder, List<String> fileTypes, 
			String solrHost, String solrPort, String solrCollectionName,
			boolean isWebAccess, String virtualPathName, String onlyNew, String projectName, boolean isFileAccess){
		this.rootFolder = rootFolder;
		this.recurseFolder = recurseFolder;
		this.solrHost = solrHost;
		this.solrPort = solrPort;
		this.solrCollectionName = solrCollectionName;
		this.fileTypes = fileTypes;		
		this.isWebAccess = isWebAccess;
		this.virtualPathName = virtualPathName;
		this.onlyNew = onlyNew;
		this.projectName = projectName;
		this.isFileAccess = isFileAccess;
	}
}
