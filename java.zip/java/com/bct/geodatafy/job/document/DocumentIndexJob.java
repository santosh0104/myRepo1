package com.bct.geodatafy.job.document;

import java.util.List;

public class DocumentIndexJob{
	
	public static final String SOL_DATA_TYPE = "jobRuns";
	
	public static final String JOB_RUNNING = "RUNNING";
	public static final String JOB_COMPLETED = "COMPLETED";
	public static final String JOB_ERROR = "ERROR";
	
	private String solrDocID;
	private String jobName;
	private String jobType;
	private String jobStatus;
	private String startTime;	
	private String endTime;
	private String logFileName;
	private String jobDataString;
	
	private DocumentIndexJobData jobData;	
	private List<DocumentIndexJobStatistics> statistics;

	
	public String getJobDataString() {
		return jobDataString;
	}
	public void setJobDataString(String jobDataString) {
		this.jobDataString = jobDataString;
	}
	public String getSolrDocID() {
		return solrDocID;
	}
	public void setSolrDocID(String solrDocID) {
		this.solrDocID = solrDocID;
	}
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getJobStatus() {
		return jobStatus;
	}
	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getLogFileName() {
		return logFileName;
	}
	public void setLogFileName(String logFileName) {
		this.logFileName = logFileName;
	}
	public DocumentIndexJobData getJobData() {
		return jobData;
	}
	public void setJobData(DocumentIndexJobData jobData) {
		this.jobData = jobData;
	}
	public List<DocumentIndexJobStatistics> getStatistics() {
		return statistics;
	}
	public void setStatistics(List<DocumentIndexJobStatistics> statistics) {
		this.statistics = statistics;
	}
	
	@Override
	public String toString() {
		return "DocumentIndexJob [solrDocID=" + solrDocID + ", jobName=" + jobName + ", jobType=" + jobType
				+ ", jobStatus=" + jobStatus + ", startTime=" + startTime + ", endTime=" + endTime + ", logFileName="
				+ logFileName + ", jobData=" + jobData + ", statistics=" + statistics + "]";
	}
}
