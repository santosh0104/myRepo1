package com.bct.geodatafy.job;

import java.util.Map;

public class GeodatafyJobParameter {
	private String name;
	private String type;
	private Map<String, String> optionalValues;
	
	public GeodatafyJobParameter(){
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Map<String, String> getOptionalValues() {
		return optionalValues;
	}

	public void setOptionalValues(Map<String, String> optionalValues) {
		this.optionalValues = optionalValues;
	}

}
