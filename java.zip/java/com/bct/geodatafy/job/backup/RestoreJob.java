package com.bct.geodatafy.job.backup;

import java.util.ArrayList;
import java.util.Date;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


public class RestoreJob{
	private String id;
	private String Name;
	private String datatype;
	private String backupRootFolder;
	private String collection;	
	private ArrayList<String> backupRetainedDetails;
	private String solrHost;
	private String solrPort;
	private String Last_Modified_DateTime;
	private String Last_Restored_DateTime;
	public String getLast_Restored_DateTime() {
		return Last_Restored_DateTime;
	}
	public void setLast_Restored_DateTime(String last_Restored_DateTime) {
		Last_Restored_DateTime = last_Restored_DateTime;
	}
	public String getRestoreStatus() {
		return restoreStatus;
	}
	public void setRestoreStatus(String restoreStatus) {
		this.restoreStatus = restoreStatus;
	}

	private String restoreStatus;
	
	
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		this.Name = name;
	}
	public String getDatatype() {
		return datatype;
	}
	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}
	public String getBackupRootFolder() {
		return backupRootFolder;
	}
	public void setBackupRootFolder(String backupRootFolder) {
		this.backupRootFolder = backupRootFolder;
	}
	public String getCollection() {
		return collection;
	}
	public void setCollection(String collection) {
		this.collection = collection;
	}
	public ArrayList<String> getBackupRetainedDetails() {
		return backupRetainedDetails;
	}
	public void setBackupRetainedDetails(ArrayList<String> backupRetainedDetails) {
		this.backupRetainedDetails = backupRetainedDetails;
	}
	public String getSolrHost() {
		return solrHost;
	}
	public void setSolrHost(String solrHost) {
		this.solrHost = solrHost;
	}
	public String getSolrPort() {
		return solrPort;
	}
	public void setSolrPort(String solrPort) {
		this.solrPort = solrPort;
	}
	public String getLast_Modified_DateTime() {
		return Last_Modified_DateTime;
	}
	public void setLast_Modified_DateTime(String last_Modified_DateTime) {
		Last_Modified_DateTime = last_Modified_DateTime;
	}
	
	@Override
	public String toString() {
		Gson gsonBuilder = new GsonBuilder().create();
		String jsonFromJavaArrayList = gsonBuilder.toJson(this);
		return jsonFromJavaArrayList;
		//return "RestoreJob [ID=" + id + ", Name=" + Name + ", datatype=" + datatype
				//+ ", backupRootFolder=" + backupRootFolder + ", collection=" + collection + "]";
	}
	
	

	
	}
