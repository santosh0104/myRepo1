package com.bct.geodatafy.job.backup;

import java.util.ArrayList;
import java.util.Date;


public class BackupActiveJob {
	private String id;
	private String name;
	private String datatype;
	private String backupFolder;
	private String collection;		
	private String backupDate;
	private String backupTime;
	private String bkupDateTime;
	private String restoreStatus;
	
	
	private String Last_Restored_DateTime;
	public String getLast_Restored_DateTime() {
		return Last_Restored_DateTime;
	}
	public void setLast_Restored_DateTime(String last_Restored_DateTime) {
		Last_Restored_DateTime = last_Restored_DateTime;
	}
	
	public String getRestoreStatus() {
		return restoreStatus;
	}
	public void setRestoreStatus(String restoreStatus) {
		this.restoreStatus = restoreStatus;
	}
	
	public String getBkupDateTime() {
		return bkupDateTime;
	}
	public void setBkupDateTime(String bkupDateTime) {
		this.bkupDateTime = bkupDateTime;
	}
	private String Last_Modified_DateTime;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDatatype() {
		return datatype;
	}
	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}
	public String getBackupFolder() {
		return backupFolder;
	}
	public void setBackupFolder(String backupFolder) {
		this.backupFolder = backupFolder;
	}
	public String getCollection() {
		return collection;
	}
	public void setCollection(String collection) {
		this.collection = collection;
	}
	public String getBackupDate() {
		return backupDate;
	}
	public void setBackupDate(String backupDate) {
		this.backupDate = backupDate;
	}
	public String getBackupTime() {
		return backupTime;
	}
	public void setBackupTime(String backupTime) {
		this.backupTime = backupTime;
	}
	public String getLast_Modified_DateTime() {
		return Last_Modified_DateTime;
	}
	public void setLast_Modified_DateTime(String last_Modified_DateTime) {
		Last_Modified_DateTime = last_Modified_DateTime;
	}
	
}
