package com.bct.geodatafy.job.backup;

import java.util.List;
import java.util.Map;

public class BackupJobData {
	
	private String backupFolder;

	private String solrHost;
	private String solrPort;
	private String solrCollectionName;	
	private int noOfBackupRetained;
	
	

	public int getNoOfBackupRetained() {
		return noOfBackupRetained;
	}

	public void setNoOfBackupRetained(int noOfBackupRetained) {
		this.noOfBackupRetained = noOfBackupRetained;
	}

	/**
	 * @return the solrHost
	 */
	public String getSolrHost() {
		return solrHost;
	}

	/**
	 * @param solrHost the solrHost to set
	 */
	public void setSolrHost(String solrHost) {
		this.solrHost = solrHost;
	}

	/**
	 * @return the solrPort
	 */
	public String getSolrPort() {
		return solrPort;
	}

	/**
	 * @param solrPort the solrPort to set
	 */
	public void setSolrPort(String solrPort) {
		this.solrPort = solrPort;
	}

	public String getBackupFolder() {
		return backupFolder;
	}

	public void setBackupFolder(String backupFolder) {
		this.backupFolder = backupFolder;
	}

	public String getSolrCollectionName() {
		return solrCollectionName;
	}

	public void setSolrCollectionName(String solrCollectionName) {
		this.solrCollectionName = solrCollectionName;
	}

	public BackupJobData(String backupFolder, String solrHost, String solrPort, String solrCollectionName, int noOfBackupRetained){
		this.backupFolder = backupFolder;		
		this.solrHost = solrHost;
		this.solrPort = solrPort;
		this.solrCollectionName = solrCollectionName;
		this.noOfBackupRetained = noOfBackupRetained;
		
	}
}
