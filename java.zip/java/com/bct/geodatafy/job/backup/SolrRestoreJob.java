package com.bct.geodatafy.job.backup;

import java.util.List;

public class SolrRestoreJob{
	
	public static final String SOL_DATA_TYPE = "jobRuns";
	
	public static final String JOB_RUNNING = "RUNNING";
	public static final String JOB_COMPLETED = "COMPLETED";
	public static final String JOB_ERROR = "ERROR";
	

	private String jobName;
	private String jobType;
	private String jobStatus;

	private String bkupRunsFolder;
	private String solrCollectionName;	
	private String solrHost;
	private String solrPort;
	private String backupName;
	
	public String getBackupName() {
		return backupName;
	}
	public void setBackupName(String backupName) {
		this.backupName = backupName;
	}


	
	public String getSolrHost() {
		return solrHost;
	}
	public void setSolrHost(String solrHost) {
		this.solrHost = solrHost;
	}
	public String getSolrPort() {
		return solrPort;
	}
	public void setSolrPort(String solrPort) {
		this.solrPort = solrPort;
	}
	public String getSolrCollectionName() {
		return solrCollectionName;
	}
	public void setSolrCollectionName(String solrCollectionName) {
		this.solrCollectionName = solrCollectionName;
	}
	public int getNoOfBackupRetained() {
		return noOfBackupRetained;
	}
	public void setNoOfBackupRetained(int noOfBackupRetained) {
		this.noOfBackupRetained = noOfBackupRetained;
	}

	private int noOfBackupRetained;
	
	public String getBkupRunsFolder() {
		return bkupRunsFolder;
	}
	public void setBkupRunsFolder(String bkupRunsFolder) {
		this.bkupRunsFolder = bkupRunsFolder;
	}

	private BackupJobData jobData;	
	private List<SolrBackupJobStatistics> statistics;

	
	
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getJobStatus() {
		return jobStatus;
	}
	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}
	
	public BackupJobData getJobData() {
		return jobData;
	}
	public void setJobData(BackupJobData jobData) {
		this.jobData = jobData;
	}
	public List<SolrBackupJobStatistics> getStatistics() {
		return statistics;
	}
	public void setStatistics(List<SolrBackupJobStatistics> statistics) {
		this.statistics = statistics;
	}
	
	/*	@Override
	public String toString() {
		return "SolrRestoreJob [solrDocID=" + solrDocID + ", jobName=" + jobName + ", jobType=" + jobType
				+ ", jobStatus=" + jobStatus + ", startTime=" + startTime + ", endTime=" + endTime + ", logFileName="
				+ logFileName + ", jobData=" + jobData + ", statistics=" + statistics + "]";
	}*/
}
