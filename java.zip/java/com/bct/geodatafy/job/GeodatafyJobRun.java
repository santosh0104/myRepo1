/**
 * 
 */
package com.bct.geodatafy.job;

/**
 * @author ks111138
 *
 */
public class GeodatafyJobRun {
	
	private String jobName;
	private String jobType;
	private String jobRunID;
	private String jobStatus;
	private String startTime;
	private String endTime;
	
	public GeodatafyJobRun(String jobName, String jobType, String jobRunID, String jobStatus, String startTime, String endTime) {
		super();
		this.jobName = jobName;
		this.jobType = jobType;
		this.jobRunID = jobRunID;
		this.jobStatus = jobStatus;
		this.startTime = startTime;
		this.endTime = endTime;
	}

	/**
	 * 
	 */
	public GeodatafyJobRun() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	/**
	 * @return the jobName
	 */
	public String getJobName() {
		return jobName;
	}

	/**
	 * @param jobName the jobName to set
	 */
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	/**
	 * @return the jobType
	 */
	public String getJobType() {
		return jobType;
	}

	/**
	 * @param jobType the jobType to set
	 */
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}

	/**
	 * @return the jobID
	 */
	public String getJobRunID() {
		return jobRunID;
	}

	/**
	 * @param jobID the jobID to set
	 */
	public void setJobRunID(String jobRunID) {
		this.jobRunID = jobRunID;
	}

	/**
	 * @return the jobStatus
	 */
	public String getJobStatus() {
		return jobStatus;
	}

	/**
	 * @param jobStatus the jobStatus to set
	 */
	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	/**
	 * @return the startTime
	 */
	public String getStartTime() {
		return startTime;
	}

	/**
	 * @param startTime the startTime to set
	 */
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	/**
	 * @return the endTime
	 */
	public String getEndTime() {
		return endTime;
	}

	/**
	 * @param endTime the endTime to set
	 */
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

}
