package com.bct.geodatafy.job.qc;

import java.util.ArrayList;
import java.util.List;

public class QCJobStatistics {
	private String project;
	private String datasource;
	private String dataSourceTypeName;
	private String datatype;	
	private int total;
	private int successful;
	private int skipped;
	private int failed;
	
	public String getDataSourceTypeName() {
		return dataSourceTypeName;
	}

	public void setDataSourceTypeName(String dataSourceTypeName) {
		this.dataSourceTypeName = dataSourceTypeName;
	}

	public QCJobStatistics(){
		total=0;
		successful = 0;
		skipped = 0;
		failed = 0;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getDatasource() {
		return datasource;
	}

	public void setDatasource(String datasource) {
		this.datasource = datasource;
	}

	public String getDatatype() {
		return datatype;
	}

	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getSuccessful() {
		return successful;
	}

	public void setSuccessful(int successful) {
		this.successful = successful;
	}

	public int getSkipped() {
		return skipped;
	}

	public void setSkipped(int skipped) {
		this.skipped = skipped;
	}

	public int getFailed() {
		return failed;
	}

	public void setFailed(int failed) {
		this.failed = failed;
	}

	
}
