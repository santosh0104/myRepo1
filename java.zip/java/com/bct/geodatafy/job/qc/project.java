package com.bct.geodatafy.job.qc;

import java.util.ArrayList;

public class project {
	private String id;
	private String Name;
	private String Geometry;
	private String DataSource;
	private String DataSourceTypeName;
	private String DataSourceTypeVersion;
	private String datatype;
	private String qcRuleSet;
	private ArrayList<String> projDataTypes;
	public ArrayList<String> getProjDataTypes() {
		return projDataTypes;
	}
	public void setProjDataTypes(ArrayList<String> projDataTypes) {
		this.projDataTypes = projDataTypes;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		this.Name = name;
	}
	public String getGeometry() {
		return Geometry;
	}
	public void setGeometry(String geometry) {
		this.Geometry = geometry;
	}
	public String getDataSource() {
		return DataSource;
	}
	public void setDataSource(String dataSource) {
		this.DataSource = dataSource;
	}
	public String getDataSourceTypeName() {
		return DataSourceTypeName;
	}
	public void setDataSourceTypeName(String dataSourceTypeName) {
		this.DataSourceTypeName = dataSourceTypeName;
	}
	public String getDataSourceTypeVersion() {
		return DataSourceTypeVersion;
	}
	public void setDataSourceTypeVersion(String dataSourceTypeVersion) {
		this.DataSourceTypeVersion = dataSourceTypeVersion;
	}
	public String getDatatype() {
		return datatype;
	}
	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}
	public String getQcRuleSet() {
		return qcRuleSet;
	}
	public void setQcRuleSet(String qcRuleSet) {
		this.qcRuleSet = qcRuleSet;
	}

}
