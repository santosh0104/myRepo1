package com.bct.geodatafy.job.qc;

import java.util.ArrayList;



public class QCJobData {	

	private String solrHost;
	private String solrPort;
	private boolean projectSet = false;
	private String projectSetName;
	
	public String getProjectSetName() {
		return projectSetName;
	}



	public void setProjectSetName(String projectSetName) {
		this.projectSetName = projectSetName;
	}



	public boolean isProjectSet() {
		return projectSet;
	}



	public void setProjectSet(boolean projectSet) {
		this.projectSet = projectSet;
	}



	private String projectCollectionName;
	private ArrayList<ProjectDSInput> projects;	
	private ArrayList<project> projectList;	
	
	
	public String getProjectCollectionName() {
		return projectCollectionName;
	}

	

	public void setProjectCollectionName(String projectCollectionName) {
		this.projectCollectionName = projectCollectionName;
	}


	public ArrayList<project> getProjectList() {
		return projectList;
	}

	public void setProjectList(ArrayList<project> projectList) {
		this.projectList = projectList;
	}

	public ArrayList<ProjectDSInput> getProjects() {
		return projects;
	}

	public void setProjects(ArrayList<ProjectDSInput> projects) {
		this.projects = projects;
	}

	/**
	 * @return the solrHost
	 */
	public String getSolrHost() {
		return solrHost;
	}

	/**
	 * @param solrHost the solrHost to set
	 */
	public void setSolrHost(String solrHost) {
		this.solrHost = solrHost;
	}

	/**
	 * @return the solrPort
	 */
	public String getSolrPort() {
		return solrPort;
	}

	/**
	 * @param solrPort the solrPort to set
	 */
	public void setSolrPort(String solrPort) {
		this.solrPort = solrPort;
	}


	
	public QCJobData(String solrHost, String solrPort ){
	
		this.solrHost = solrHost;
		this.solrPort = solrPort;
		
	}
}
