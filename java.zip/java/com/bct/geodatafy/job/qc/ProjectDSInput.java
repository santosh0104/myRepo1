package com.bct.geodatafy.job.qc;



public class ProjectDSInput {
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getDatasourcetypeName() {
		return datasourcetypeName;
	}
	public void setDatasourcetypeName(String datasourcetypeName) {
		this.datasourcetypeName = datasourcetypeName;
	}
	public String getDataSource() {
		return dataSource;
	}
	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
	
	public String getQcRuleSetName() {
		return qcRuleSetName;
	}
	public void setQcRuleSetName(String qcRuleSetName) {
		this.qcRuleSetName = qcRuleSetName;
	}

	private String project;
	private String dataSource;
	private String datasourcetypeName;
	private String qcRuleSetName;
	
}
