package com.bct.geodatafy.job.qc;

import java.util.List;

public class QCJob {
	public static final String SOL_DATA_TYPE = "jobRuns";
	
	public static final String JOB_RUNNING = "RUNNING";
	public static final String JOB_COMPLETED = "COMPLETED";
	public static final String JOB_ERROR = "ERROR";
	
	private String solrDocID;
	private String jobName;
	private String jobType;
	private String jobStatus;
	private String startTime;	
	private String endTime;
	private String logFileName;
	private String jobDataString;
	
	private QCJobData jobData;	
	public String getSolrDocID() {
		return solrDocID;
	}
	public void setSolrDocID(String solrDocID) {
		this.solrDocID = solrDocID;
	}
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getJobStatus() {
		return jobStatus;
	}
	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getLogFileName() {
		return logFileName;
	}
	public void setLogFileName(String logFileName) {
		this.logFileName = logFileName;
	}
	public String getJobDataString() {
		return jobDataString;
	}
	public void setJobDataString(String jobDataString) {
		this.jobDataString = jobDataString;
	}
	public QCJobData getJobData() {
		return jobData;
	}
	public void setJobData(QCJobData jobData) {
		this.jobData = jobData;
	}
	public List<QCJobStatistics> getStatistics() {
		return statistics;
	}
	public void setStatistics(List<QCJobStatistics> statistics) {
		this.statistics = statistics;
	}
	private List<QCJobStatistics> statistics;

}
