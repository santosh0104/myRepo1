package com.bct.geodatafy.job;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.apache.log4j.Logger;
import org.glassfish.jersey.client.ClientConfig;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;


public class GeodatafyJobExecutor implements Job{
	static Logger logger = Logger.getLogger(GeodatafyJobExecutor.class);

	public void execute(JobExecutionContext context) throws JobExecutionException {
		logger.info("In execute of GeodatafyJob. The execution context is " + context);
		System.out.println("In execute of GeodatafyJob. The execution context is " + context);		
		
		JobDetail jobDetail = context.getJobDetail();
		if(jobDetail == null){
			String msg = "JobDetail is null"; 
			logger.error(msg);
			throw new JobExecutionException(msg);
		}
		
		JobDataMap jdm = jobDetail.getJobDataMap();
		if(jdm == null){
			String msg = "JobDataMap is null"; 
			logger.error(msg);
			throw new JobExecutionException(msg);
		}
		
		//Just for info
		for (Map.Entry<String, Object> entry: jdm.entrySet()){
			String key = entry.getKey();
			Object value =  entry.getValue();
			logger.info("Parameter: " + key + " Value: " + value);
		}
		
		String endPointURL = jdm.getString("endPointURL");
		String jobName = jdm.getString("jobName");
		if(endPointURL== null || endPointURL.length() < 1){
			String msg = "endPointURL is not defined for the job: " + jobName;
			logger.error(msg);
			throw new JobExecutionException(msg);			
		}

		String jobType = jdm.getString("jobType"); 
		String jobData = jdm.getString("jobData");
		String instanceID = context.getFireInstanceId();
		Date time = context.getFireTime();
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		String fireTime = formatter.format(time);
		runJob(endPointURL, jobName, jobType, jobData, instanceID, fireTime);
	}

	public static void runJob(String endPointURL, String jobName, String jobType, String jobData, String instanceID,
			String fireTime) throws JobExecutionException {
		DynamicJob target = new DynamicJob();
		target.setJobName(jobName);
		target.setJobType(jobType);
		target.setJobData(jobData);
		target.setInstanceID(instanceID);
		target.setFireTime(fireTime);

		Gson gson = new Gson();
		String json = gson.toJson(target);
		
		logger.info("The input json to call " + endPointURL + " for the job - " + jobName + " is: " + json);
					
		try {
			URL url = new URL(endPointURL);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type", "application/json");
			
			OutputStream os = connection.getOutputStream();
			os.write(json.getBytes());
			os.flush();
			
			if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
				String msg = endPointURL + " returned a response code " + connection.getResponseCode() + " for the job: " + jobName;
				logger.error(msg);
				throw new JobExecutionException(msg);
			}else{
				BufferedReader br = new BufferedReader(new InputStreamReader((connection.getInputStream())));
				String output;
				logger.info("Output from calling the rest service:");
				logger.info("=====================================");
				while ((output = br.readLine()) != null) {
					logger.info(output);
				}
				logger.info("=====================================");
				br.close();
			}
			os.close();
			connection.disconnect();
		}
		catch(Exception e){
			throw new JobExecutionException(e);
		}
	}	
}
