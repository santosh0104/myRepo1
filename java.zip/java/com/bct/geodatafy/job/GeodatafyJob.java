/**
 * 
 */
package com.bct.geodatafy.job;

import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bct.geodatafy.util.JsonUtil;
import com.google.gson.Gson;

/**
 * @author ks111138
 *
 */
public class GeodatafyJob {
	
	static Logger logger = Logger.getLogger(GeodatafyJob.class); 
	
	private String id;
	private String jobType;
	private String jobName;
	private String jobDescription;
	private String logLevel;
	private String jobData;
	private boolean scheduled;
	private String scheduleStartTime;
	private int scheduleInterval;
	private int scheduleDuration;
	private boolean active;
	//private boolean deleted;
	private Date createdDate;
	private String createdBy;
	private Date lastModifiedDate;
	private String editedBy;
	private String endPointURL;
	private String jobCreateEndPointURL;
	private String jobRunsEndPointURL;
	private String jobLogEndPointURL;
	private String jobStatisticsEndPointURL;


	
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the jobType
	 */
	public String getJobType() {
		return jobType;
	}

	/**
	 * @param jobType the jobType to set
	 */
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}

	/**
	 * @return the jobName
	 */
	public String getJobName() {
		return jobName;
	}

	/**
	 * @param jobName the jobName to set
	 */
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	/**
	 * @return the jobDescription
	 */
	public String getJobDescription() {
		return jobDescription;
	}

	/**
	 * @param jobDescription the jobDescription to set
	 */
	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}

	/**
	 * @return the logLevel
	 */
	public String getLogLevel() {
		return logLevel;
	}

	/**
	 * @param logLevel the logLevel to set
	 */
	public void setLogLevel(String logLevel) {
		this.logLevel = logLevel;
	}

	/**
	 * @return the jobData
	 */
	public String getJobData() {
		return jobData;
	}

	/**
	 * @param jobData the jobData to set
	 */
	public void setJobData(String jobData) {
		this.jobData = jobData;
	}

	/**
	 * @return the scheduled
	 */
	public boolean isScheduled() {
		return scheduled;
	}

	/**
	 * @param scheduled the scheduled to set
	 */
	public void setScheduled(boolean scheduled) {
		this.scheduled = scheduled;
	}

	/**
	 * @return the scheduleStartTime
	 */
	public String getScheduleStartTime() {
		return scheduleStartTime;
	}

	/**
	 * @param scheduleStartTime the scheduleStartTime to set
	 */
	public void setScheduleStartTime(String scheduleStartTime) {
		this.scheduleStartTime = scheduleStartTime;
	}

	/**
	 * @return the scheduleInterval
	 */
	public int getScheduleInterval() {
		return scheduleInterval;
	}

	/**
	 * @param scheduleInterval the scheduleInterval to set
	 */
	public void setScheduleInterval(int scheduleInterval) {
		this.scheduleInterval = scheduleInterval;
	}

	/**
	 * @return the scheduleDuration
	 */
	public int getScheduleDuration() {
		return scheduleDuration;
	}

	/**
	 * @param scheduleDuration the scheduleDuration to set
	 */
	public void setScheduleDuration(int scheduleDuration) {
		this.scheduleDuration = scheduleDuration;
	}

	/**
	 * @return the active
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * @param active the active to set
	 */
	public void setActive(boolean active) {
		this.active = active;
	}

	/**
	 * @return the deleted
	 */
	//public boolean isDeleted() {
	//	return deleted;
	//}

	/**
	 * @param deleted the deleted to set
	 */
	//public void setDeleted(boolean deleted) {
	//	this.deleted = deleted;
	//}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the lasModifiedDate
	 */
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	/**
	 * @param lasModifiedDate the lasModifiedDate to set
	 */
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	/**
	 * @return the editedBy
	 */
	public String getEditedBy() {
		return editedBy;
	}

	/**
	 * @param editedBy the editedBy to set
	 */
	public void setEditedBy(String editedBy) {
		this.editedBy = editedBy;
	}

	/**
	 * @return the endPointURL
	 */
	public String getEndPointURL() {
		return endPointURL;
	}

	/**
	 * @param endPointURL the endPointURL to set
	 */
	public void setEndPointURL(String endPointURL) {
		this.endPointURL = endPointURL;
	}

	/**
	 * @return the jobCreateEndPointURL
	 */
	public String getJobCreateEndPointURL() {
		return jobCreateEndPointURL;
	}

	/**
	 * @param jobCreateEndPointURL the jobCreateEndPointURL to set
	 */
	public void setJobCreateEndPointURL(String jobCreateEndPointURL) {
		this.jobCreateEndPointURL = jobCreateEndPointURL;
	}

	/**
	 * @return the jobRunsEndPointURL
	 */
	public String getJobRunsEndPointURL() {
		return jobRunsEndPointURL;
	}

	/**
	 * @param jobRunsEndPointURL the jobRunsEndPointURL to set
	 */
	public void setJobRunsEndPointURL(String jobRunsEndPointURL) {
		this.jobRunsEndPointURL = jobRunsEndPointURL;
	}

	/**
	 * @return the jobLogEndPointURL
	 */
	public String getJobLogEndPointURL() {
		return jobLogEndPointURL;
	}

	/**
	 * @param jobLogEndPointURL the jobLogEndPointURL to set
	 */
	public void setJobLogEndPointURL(String jobLogEndPointURL) {
		this.jobLogEndPointURL = jobLogEndPointURL;
	}

	/**
	 * @return the jobStatisticsEndPointURL
	 */
	public String getJobStatisticsEndPointURL() {
		return jobStatisticsEndPointURL;
	}

	/**
	 * @param jobStatisticsEndPointURL the jobStatisticsEndPointURL to set
	 */
	public void setJobStatisticsEndPointURL(String jobStatisticsEndPointURL) {
		this.jobStatisticsEndPointURL = jobStatisticsEndPointURL;
	}

	/**
	 * 
	 */
	public GeodatafyJob() {
		// TODO Auto-generated constructor stub
	}

	public static GeodatafyJob getJobFromPayload(String payLoad) throws Exception {
		logger.info("Input payload is: " + payLoad);
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);	
		if(elementsMap == null || elementsMap.isEmpty()){
			String msg = "The input payload " + payLoad + " is not a correct json string";
			logger.error(msg);
			throw new Exception(msg);
		}
		
		logger.info("Number of elements in input json : " + elementsMap.size() + " ");		
		for (Map.Entry<String, String> entry: elementsMap.entrySet()){
			String key = entry.getKey();
			String value =  entry.getValue();				
			logger.info("Key: " + key + " Value: " + value);
		}	

		String jobName = elementsMap.get("jobName");
		if(jobName == null || jobName.length() < 1){
			String msg = "Job Name is Null or Empty in payload " + payLoad;
			logger.error(msg);
			throw new Exception(msg);			
		}

		String jobType = elementsMap.get("jobType");
		if(jobType == null || jobType.length() < 1){
			String msg = "Job Type is Null or Empty in payload " + payLoad;
			logger.error(msg);
			throw new Exception(msg);			
		}

		String jobData = elementsMap.get("jobData");
		if(jobData == null || jobData.length() < 1){
			String msg = "Job Data is Null or Empty in payload " + payLoad;
			logger.error(msg);
			throw new Exception(msg);			
		}

		Gson gson = new Gson();
		GeodatafyJob job = gson.fromJson(payLoad, GeodatafyJob.class);
		return job;
	}

	public String toString(){
	
		StringBuilder sb = new StringBuilder();
		sb.append("id: " + id);
		sb.append(", jobType: " + jobType);
		sb.append(", jobName: " + jobName);
		sb.append(", jobDescription: " + jobDescription);
		sb.append(", logLevel: " + logLevel);
		sb.append(", scheduled: " + scheduled);
		sb.append(", scheduleStartTime: " + scheduleStartTime);
		sb.append(", scheduleInterval: " + scheduleInterval);
		sb.append(", scheduleDuration: " + scheduleDuration);
		sb.append(", active: " + active);
		//sb.append(", deleted: " + deleted);
		sb.append(", createdDate: " + createdDate);
		sb.append(", createdBy: " + createdBy);
		sb.append(", lastModifiedDate: " + lastModifiedDate);
		sb.append(", editedBy: " + editedBy);
		sb.append(", endPointURL: " + endPointURL);
		sb.append(", jobCreateEndPointURL: " + jobCreateEndPointURL);
		sb.append(", jobRunsEndPointURL: " + jobRunsEndPointURL);
		sb.append(", jobLogEndPointURL: " + jobLogEndPointURL);
		sb.append(", jobStatisticsEndPointURL: " + jobStatisticsEndPointURL);
		return sb.toString();
	}
	
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		StringBuilder sb = new StringBuilder();
	    sb.append("{");
	    
	    sb.append("\"jobName\":\"" + "jobNameStr" + "\", ");
	    sb.append("\"jobType\":\"" + "jobTypeStr" + "\", ");
	    sb.append("\"jobData\":\"" + "jobDataStr" + "\"");
	    
	    sb.append("}");

		System.out.println(GeodatafyJob.getJobFromPayload(sb.toString()).toString());
	}
}
