package com.bct.geodatafy.job;

import java.util.List;
import java.util.Map;

public class GeodatafyJobTypes {
	
	private Map<String, String> names;

	public GeodatafyJobTypes(){
		
	}

	public Map<String, String> getParameters() {
		return names;
	}

	public void setParameters(Map<String, String> names) {
		this.names = names;
	}
}
