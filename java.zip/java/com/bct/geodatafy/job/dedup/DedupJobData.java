package com.bct.geodatafy.job.dedup;

import java.util.ArrayList;

import com.bct.geodatafy.job.qc.ProjectDSInput;




public class DedupJobData {	

	public String getQcRuleSetName() {
		return qcRuleSetName;
	}



	public void setQcRuleSetName(String qcRuleSetName) {
		this.qcRuleSetName = qcRuleSetName;
	}



	public String getPriority() {
		return priority;
	}



	public void setPriority(String priority) {
		this.priority = priority;
	}



	private String solrHost;
	private String solrPort;
	private String qcRuleSetName;
	private String priority;
	private String projectSetName;
	private String projectCollectionName;
	private ArrayList<ProjectDSInput> projects;	
	private ArrayList<String> ruleSetDatatypeList;	

	public String getProjectSetName() {
		return projectSetName;
	}



	public void setProjectSetName(String projectSetName) {
		this.projectSetName = projectSetName;
	}




	
	
	public ArrayList<String> getRuleSetDatatypeList() {
		return ruleSetDatatypeList;
	}



	public void setRuleSetDatatypeList(ArrayList<String> ruleSetDatatypeList) {
		this.ruleSetDatatypeList = ruleSetDatatypeList;
	}



	public String getProjectCollectionName() {
		return projectCollectionName;
	}

	

	public void setProjectCollectionName(String projectCollectionName) {
		this.projectCollectionName = projectCollectionName;
	}


	
	public ArrayList<ProjectDSInput> getProjects() {
		return projects;
	}

	public void setProjects(ArrayList<ProjectDSInput> projects) {
		this.projects = projects;
	}

	/**
	 * @return the solrHost
	 */
	public String getSolrHost() {
		return solrHost;
	}

	/**
	 * @param solrHost the solrHost to set
	 */
	public void setSolrHost(String solrHost) {
		this.solrHost = solrHost;
	}

	/**
	 * @return the solrPort
	 */
	public String getSolrPort() {
		return solrPort;
	}

	/**
	 * @param solrPort the solrPort to set
	 */
	public void setSolrPort(String solrPort) {
		this.solrPort = solrPort;
	}


	
	public DedupJobData(String solrHost, String solrPort ){
	
		this.solrHost = solrHost;
		this.solrPort = solrPort;
		
	}
}
