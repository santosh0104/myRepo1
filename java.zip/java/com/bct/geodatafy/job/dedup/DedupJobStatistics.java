package com.bct.geodatafy.job.dedup;



public class DedupJobStatistics {
	private String ruleSetName;
	private String datatype;	
	private long total;
	private long unique;
	private long match;	

	public DedupJobStatistics(){
		total=0;
		unique = 0;
		match = 0;
		
	}

	
	public String getRuleSetName() {
		return ruleSetName;
	}


	public void setRuleSetName(String ruleSetNam) {
		this.ruleSetName = ruleSetNam;
	}


	public long getUnique() {
		return unique;
	}


	public void setUnique(long unique) {
		this.unique = unique;
	}


	public long getMatch() {
		return match;
	}


	public void setMatch(long match) {
		this.match = match;
	}


	public String getDatatype() {
		return datatype;
	}

	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}

	public long getTotal() {
		return total;
	}

	public void setTotal(long total) {
		this.total = total;
	}

	
	
}
