package com.bct.geodatafy.job;

import java.io.Serializable;

import org.apache.log4j.Logger;


public class DynamicJob implements Serializable{
	static Logger logger = Logger.getLogger(DynamicJob.class);

	private String jobName;
	private String jobType;
	private String instanceID;
	private String fireTime;
	private String jobData;

	public DynamicJob() {
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;		
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public void setInstanceID(String instanceID) {
		this.instanceID = instanceID;		
	}
	public void setFireTime(String fireTime) {
		this.fireTime = fireTime;
	}
	public void setJobData(String jobData) {
		this.jobData = jobData;		
	}

	public String getJobName() {
		return jobName;		
	}
	public String getJobType() {
		return jobType;
	}
	public String getInstanceID() {
		return instanceID;		
	}
	public String getFireTime() {
		return fireTime;
	}
	public String getJobData() {
		return jobData;		
	}
}
