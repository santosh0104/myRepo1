package com.bct.geodatafy.job.openspirit;


//simple class like what would be a json object in an http request or response
// An OpenSpirit datasource
public class OpenSpiritDatasource {
	
	private String datasourceType;
	private String datasourceTypeVersion;
	private String name;
	/**
	 * @return the datasourceType
	 */
	public String getDatasourceType() {
		return datasourceType;
	}

	/**
	 * @param datasourceType the datasourceType to set
	 */
	public void setDatasourceType(String datasourceType) {
		this.datasourceType = datasourceType;
	}

	/**
	 * @return the datasourceTypeVersion
	 */
	public String getDatasourceTypeVersion() {
		return datasourceTypeVersion;
	}

	/**
	 * @param datasourceTypeVersion the datasourceTypeVersion to set
	 */
	public void setDatasourceTypeVersion(String datasourceTypeVersion) {
		this.datasourceTypeVersion = datasourceTypeVersion;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the supportsProjects
	 */
	public boolean isSupportsProjects() {
		return supportsProjects;
	}

	/**
	 * @param supportsProjects the supportsProjects to set
	 */
	public void setSupportsProjects(boolean supportsProjects) {
		this.supportsProjects = supportsProjects;
	}

	private boolean supportsProjects;
	
	public OpenSpiritDatasource(String datasourceType, String datasourceTypeVersion, String name, boolean supportsProjects){
		this.datasourceType = datasourceType;
		this.datasourceTypeVersion = datasourceTypeVersion;
		this.name = name;
		this.supportsProjects = supportsProjects;
	}
	
	public String toString(){
		return  name + " (" + datasourceType + " " + datasourceTypeVersion + ") projects:" +  supportsProjects;
	}

	public static void main(String[] args) {
	}
}
