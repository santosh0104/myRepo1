package com.bct.geodatafy.job.openspirit;

//simple class like what would be a json object in an http request or response
// A Scan data source may be either a project or ,for datastore types that don't support projects, a datasource
public class OpenSpiritScanDatasource {
	private String datasourceType;
	private String datasourceTypeVersion;
	private String datasourceName;
	private String projectName;

	public OpenSpiritScanDatasource() {
	}
	
	public OpenSpiritScanDatasource(String datasourceType, String datasourceTypeVersion, String datasourceName, String projectName) {
		this.datasourceType = datasourceType;
		this.datasourceTypeVersion = datasourceTypeVersion;
		this.datasourceName = datasourceName;
		this.projectName = projectName;
	}
	
	public OpenSpiritScanDatasource(String datasourceType, String datasourceTypeVersion, String datasourceName) {
		this(datasourceType, datasourceTypeVersion, datasourceName, null);
	}
	
	/**
	 * @return the datasourceType
	 */
	public String getDatasourceType() {
		return datasourceType;
	}

	/**
	 * @param datasourceType the datasourceType to set
	 */
	public void setDatasourceType(String datasourceType) {
		this.datasourceType = datasourceType;
	}

	/**
	 * @return the datasourceTypeVersion
	 */
	public String getDatasourceTypeVersion() {
		return datasourceTypeVersion;
	}

	/**
	 * @param datasourceTypeVersion the datasourceTypeVersion to set
	 */
	public void setDatasourceTypeVersion(String datasourceTypeVersion) {
		this.datasourceTypeVersion = datasourceTypeVersion;
	}

	/**
	 * @return the datasourceName
	 */
	public String getDatasourceName() {
		return datasourceName;
	}

	/**
	 * @param datasourceName the datasourceName to set
	 */
	public void setDatasourceName(String datasourceName) {
		this.datasourceName = datasourceName;
	}

	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String toString(){
		return  projectName + " (" + datasourceType + " " + datasourceTypeVersion + " - " +  datasourceName + ")";
	}

	public static void main(String[] args) {
	}
}
