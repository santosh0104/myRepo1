package com.bct.geodatafy.job.openspirit;

//simple class like what would be a json object in an http request or response
// An OpenSpirit ModelView
public class OpenSpiritModelView {
	public String name;
	public int version;
	public String modelName;
	public String modelVersion;
	
	public String toString(){
		return  name + " " + version;
	}

	public static void main(String[] args) {
	}
}
