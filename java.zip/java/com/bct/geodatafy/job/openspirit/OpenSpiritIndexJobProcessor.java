package com.bct.geodatafy.job.openspirit;

import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bct.geodatafy.util.EnvUtil;
import com.bct.geodatafy.util.JsonUtil;
import com.bct.geodatafy_osp_scan.SolrScanOutputPlugin;
import com.openspirit.BadArgumentsException;
import com.openspirit.InitializationException;
import com.openspirit.LicenseException;
import com.openspirit.NotFoundException;
import com.openspirit.OpenSpirit;
import com.openspirit.carto.CoordinateReferenceSystem;
import com.openspirit.data.DataSourceDefinition;
import com.openspirit.data.DataSourceTypeDefinition;
import com.openspirit.data.OspConnection;
import com.openspirit.data.ProjectDefinition;
import com.openspirit.data.QueryContext;
import com.openspirit.data.QueryScope;
import com.openspirit.metamodel.Model;
import com.openspirit.unit.Unit;
import com.tibco.openspirit.jobs.api.DataSource;
import com.tibco.openspirit.jobs.api.DataSourceFactory;
import com.tibco.openspirit.jobs.api.Job;
import com.tibco.openspirit.jobs.api.Job.LogLevel;
import com.tibco.openspirit.jobs.api.JobManager.LogFormat;
import com.tibco.openspirit.jobs.api.JobAlreadyExistsException;
import com.tibco.openspirit.jobs.api.JobException;
import com.tibco.openspirit.jobs.api.JobStatus;
import com.tibco.openspirit.scan.api.ScanJob;
import com.tibco.openspirit.scan.api.ScanJobManager;
import com.tibco.openspirit.scan.api.outputs.CustomOutputSettings;
import com.tibco.openspirit.scan.api.outputs.EnterpriseSearchIndexOutputSettings;
import com.tibco.openspirit.scan.api.outputs.OutputSettings;
import com.tibco.openspirit.scan.api.outputs.OutputSettingsFactory;
import com.tibco.openspirit.scan.api.rules.AllDataBoundingBoxRule;
import com.tibco.openspirit.scan.api.rules.ModifiedItemsRule;


public class OpenSpiritIndexJobProcessor {
	static Logger logger = Logger.getLogger(OpenSpiritIndexJobProcessor.class);
	//private static final String DIR = "C:\\svn\\geodatafy\\trunk\\java\\openspirit-scan-outputer\\GeodatafyScanOutputer";
	//private static final String LIB_DIR = DIR + "\\lib";
	private static final String SOLRSCAN_JAR = "ScanOutputer-1.0.jar";
	private static final String COMMONS_IO_JAR ="commons-io-2.5.jar";
	private static final String COMMONS_LOGGING_JAR = "commons-logging-1.2.jar";
	private static final String GSON_JAR = "gson-2.2.4.jar";
	private static final String HTTPCLIENT_JAR = "httpclient-4.4.1.jar";
	private static final String  HTTPCLIENTWIN_JAR = "httpclient-win-4.5.3.jar";
	private static final String HTTPCORE_JAR = "httpcore-4.4.1.jar";
	private static final String HTTPMIME_JAR = "httpmime-4.4.1.jar";
	private static final String NOGGIT_JAR ="noggit-0.6.jar";
	private static final String SLF4J_JAR = "slf4j-api-1.7.22.jar";
	private static final String SOLRJ_JAR = "solr-solrj-6.6.0.jar";	
	private static final String SEGY_JAR = "segy-1.0.0.jar ";	
	
	
	
	public static final String CONNECTION_NAME = "Geodatafy";
	public static final int WSG84_CODE = 4326;

	private final OpenSpirit openSpirit;
	private final ScanJobManager scanJobManager;

	private final CoordinateReferenceSystem  coordinateReferenceSystemWGS84;
	private final Unit meter;
	private final Unit milliSecond;
	private final Unit degreeAngle;
	
	private static OpenSpiritIndexJobProcessor instance = null;
	
	public static OpenSpiritIndexJobProcessor getInstance() throws InitializationException, LicenseException, NotFoundException {
		if(instance == null){
			instance = new OpenSpiritIndexJobProcessor(); 
		}
		return instance;
	}

	private OpenSpiritIndexJobProcessor() throws InitializationException, LicenseException, NotFoundException {
		openSpirit = com.openspirit.OpenSpiritFactory.createOpenSpirit();
		openSpirit.connect(CONNECTION_NAME);		
		scanJobManager = ScanJobManager.getInstance();
		coordinateReferenceSystemWGS84= openSpirit.getCoordinateService().findSystemByCode(WSG84_CODE);
		meter = openSpirit.getUnitService().getCatalog(null, null).getUnit("m");
		milliSecond = openSpirit.getUnitService().getCatalog(null, null).getUnit("ms");
		degreeAngle = openSpirit.getUnitService().getCatalog(null, null).getUnit("dega");
	}

	/**
	 * Returns list of Scan  ModelView objects
	 * @return List of Scan  ModelView objects
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws BadArgumentsException
	 * @throws NotFoundException
	 */
	public List<OpenSpiritModelView> getModelViews() throws ClassNotFoundException, SQLException, BadArgumentsException, NotFoundException  {
		 List<OpenSpiritModelView>  modelViews = new  ArrayList<OpenSpiritModelView> (); 
 	     String sql = "SELECT name, version, model_name, model_version FROM OSP_MODEL_VIEW where model_view_type='ScanJob' and is_deleted=0 and is_public=1";   
 	     long startTime = System.currentTimeMillis();
		 DataSourceTypeDefinition dataSourceType = openSpirit.getDataService().getDataSourceType("OSP Metadata Repository", null, null); 
		 long stopTime = System.currentTimeMillis();
		 logger.debug("Time taken for getting dataSourceType of OSP Metadata Repository: " + (stopTime-startTime)/1000.0 + "sec.");
		 DataSourceDefinition dataSource = dataSourceType.getDataSource("OpenSpirit Metadata"); 
		 startTime = System.currentTimeMillis();
	     Model model = openSpirit.getMetamodelService().getModel("OpenSpiritMetaModel", null); 	 
	     stopTime = System.currentTimeMillis();
	     logger.debug("Time taken for getting OpenSpiritMetaModel: " + (stopTime-startTime)/1000.0 + "sec.");
	     startTime = System.currentTimeMillis();
	     QueryContext context =  openSpirit.getDataService().getQueryFactory().createQueryContext(null, model, null, null, null); 
	     QueryScope scope =  openSpirit.getDataService().getQueryFactory().createQueryScope(dataSource);
	     OspConnection conn = openSpirit.getDataService().getOspConnection(scope, context);
         Statement stmt =  conn.createStatement();
         ResultSet rs=  stmt.executeQuery(sql);
	     while ( rs.next()) {
	    	 OpenSpiritModelView mv = new OpenSpiritModelView();
	    	 mv.name = rs.getString(1);
	    	 mv.version = rs.getInt(2);
	    	 mv.modelName = rs.getString(3);
	    	 mv.modelVersion = rs.getString(4);
	    	 modelViews.add(mv);
	     }
	     stopTime = System.currentTimeMillis();
		 logger.debug("Time taken for Execute Query for getModelView : " + (stopTime-startTime)/1000.0 + "sec.");
		    
		return modelViews;
	}
	
	/**
	 * Returns a list of OpenSpirit data sources that have 1 or more projects ( or don't support projects)
	 * @return List of Data source objects
	 */
	public List<OpenSpiritDatasource> getDatasources() {
		List<OpenSpiritDatasource> datasources = new ArrayList<OpenSpiritDatasource>();
		 long startTime = System.currentTimeMillis();
		DataSourceTypeDefinition[] dsTypes = openSpirit.getDataService().getDataSourceTypes();
		long  stopTime = System.currentTimeMillis();
		 logger.debug("Time taken for openSpirit.getDataService().getDataSourceTypes() in  getDatasources() method : " + (stopTime-startTime)/1000.0 + "sec.");
		 startTime = System.currentTimeMillis();
		for (DataSourceTypeDefinition dsType : dsTypes) {
			for (DataSourceDefinition datasource : dsType.getDataSources()) {
				if (datasource.getProjectNames().length >0 || !dsType.supportsProjects()) {
					OpenSpiritDatasource ds = new OpenSpiritDatasource(dsType.getName(), dsType.getVersion(), datasource.getName(), dsType.supportsProjects());
					datasources.add(ds);
				}
			}
		}
		stopTime = System.currentTimeMillis();
		 logger.debug("Time taken for creating OpenSpiritDatasource object List in  getDatasources() method : " + (stopTime-startTime)/1000.0 + "sec.");
		return datasources;
	}	

	/**
	 * Returns array of project names contained in specified data source
	 * @param datasource Datasource object
	 * @return Array of project names
	 * @throws NotFoundException
	 */
	public String[] getProjects(String datasourceName, String datasourceType, String datasourceTypeVersion) throws NotFoundException {
		long  startTime = System.currentTimeMillis();
		DataSourceDefinition ds = openSpirit.getDataService().getDataSourceType(datasourceType, datasourceTypeVersion, null).getDataSource(datasourceName);
		long  stopTime = System.currentTimeMillis();
		logger.debug("Time taken for openSpirit.getDataService().getDataSourceType for datasourceName : " + datasourceName + " datasourceType : " + datasourceType + " in  getProjects() method : " + (stopTime-startTime)/1000.0 + "sec.");
		return ds.getProjectNames();
	}
	/**
	 * Create a new Scan job with the parameters supplied and save it.  Call runJob afterwards in order to run it (but not immediately afterwards). 
	 * If the intent is to create and then immediately run the job then use createAndRunJob method.
	 * @param name Name of new job (must not already exist) 
	 * @param description Description of job - optional
	 * @param logLevel LogLevel of job 
	 * @param sources List of ScanDatasourecs that are to be scanned 
	 * @param modelViewName Name of ModelView to use 
	 * @param modelViewVersion Version  of ModelView to use 
	 * @param solrHost - Host name where Solr is running 
	 * @param solrPort - Port where Solr is running 
	 * @param solrCollection - Solr collection name to write to (use core name like data_shard1_replica1) 
	 * @param onlyModifiedData - If true then only new or data modified since last scan job will be scanned. This has no effect on initial job. 
	 * @throws BadArgumentsException
	 * @throws JobAlreadyExistsException
	 * @throws JobException
	 * @throws NotFoundException
	 * @throws InterruptedException
	 */
	public void createJob(String name, String description, Job.LogLevel logLevel, List<OpenSpiritScanDatasource> sources, String modelViewName, int modelViewVersion , String solrHost, 
			                 String solrPort, String solrCollection, boolean onlyModifiedData , String  webInfPath, String bulkData) throws BadArgumentsException, JobAlreadyExistsException, JobException, NotFoundException, InterruptedException {
		logger.info("Number of sources " + sources.size());
		ScanJob job = createScanJob(name, description, logLevel, sources, modelViewName, modelViewVersion, solrHost, solrPort, solrCollection, onlyModifiedData,  webInfPath, bulkData);
		long  startTime = System.currentTimeMillis();
		scanJobManager.saveJob(job);
		long  stopTime = System.currentTimeMillis();
		logger.debug("Time taken for saveJob for Job Nanme : " + name + " in  createJob() method : " + (stopTime-startTime)/1000.0 + "sec.");
		
		return;
	} 
	
	/**
	 * Create a new Scan job with the parameters supplied and then immediately run it.
	 * @param name Name of new job (must not already exist) 
	 * @param description Description of job - optional
	 * @param logLevel LogLevel of job 
	 * @param sources List of ScanDatasourecs that are to be scanned 
	 * @param modelViewName Name of ModelView to use 
	 * @param modelViewVersion Version  of ModelView to use 
	 * @param solrHost - Host name where Solr is running 
	 * @param solrPort - Port where Solr is running 
	 * @param solrCollection - Solr collection name to write to (use core name like data_shard1_replica1) 
	 * @param onlyModifiedData - If true then only new or data modified since last scan job will be scanned. This has no effect on initial job. 
	 * @throws BadArgumentsException
	 * @throws JobAlreadyExistsException
	 * @throws JobException
	 * @throws NotFoundException
	 * @throws InterruptedException
	 */
	public void createAndRunJob(String name, String description, Job.LogLevel logLevel, List<OpenSpiritScanDatasource> sources, String modelViewName, int modelViewVersion , String solrHost, 
			                 String solrPort, String solrCollection, boolean onlyModifiedData, String webInfPath, String bulkData ) throws BadArgumentsException, JobAlreadyExistsException, JobException, NotFoundException, InterruptedException {
		logger.info("Start of createAndRunJob " );
		logger.info("Number of sources " + sources.size());
		ScanJob job = createScanJob(name, description, logLevel, sources, modelViewName, modelViewVersion, solrHost, solrPort, solrCollection, onlyModifiedData, webInfPath, bulkData);
		logger.info("After createscanJob and before submitjob " );
		long  startTime = System.currentTimeMillis();
		scanJobManager.submitJob(job);
		long  stopTime = System.currentTimeMillis();
		logger.info("Time taken for submitJob for Job Nanme : " + name + " in  createAndRunJob() method : " + (stopTime-startTime)/1000.0 + "sec.");		
		logger.info("End of createAndRunJob " );
		return;
	}
	
	/**
	 * Update an existing job with the parameters supplied and save it for later execution. Supply null for any parameter that you don't wish to update.
	 * If the intent is to update and then immediately run the job then use updateAndRunJob method.
	 * @param name Name of existing job - required
	 * @param description Description of job - optional
	 * @param logLevel LogLevel of job - optional
	 * @param sources List of ScanDatasourecs that are to be scanned - optional 
	 * @param modelViewName Name of ModelView to use - optional (if supplied also supply modelViewVersion)
	 * @param modelViewVersion Version  of ModelView to use - optional (if supplied also supply modelViewName)
	 * @param solrHost - Host name where Solr is running - optional ( if supplied also supply solrPort and solrCollection)
	 * @param solrPort - Port where Solr is running - optional ( if supplied also supply solrHost and solrCollection)
	 * @param solrCollection - Solr collection name to write to ( use core name like data_shard1_replica1) - optional ( if supplied also supply solrHost and solrPort)
	 * @param onlyModifiedData - If true then only new or data modified since last scan job will be scanned. This has no effect on initial job. 
	 * @throws BadArgumentsException
	 * @throws JobAlreadyExistsException
	 * @throws JobException
	 * @throws NotFoundException
	 */
	public void updateJob(String name, String description, Job.LogLevel logLevel, List<OpenSpiritScanDatasource> sources, String modelViewName, Integer modelViewVersion, String solrHost, 
            String solrPort, String solrCollection , boolean onlyModifiedData, String  webInfPath, String bulkData) throws BadArgumentsException, JobAlreadyExistsException, JobException, NotFoundException {
		logger.info("Number of sources " + sources.size());
		ScanJob job = updateScanJob(name, description, logLevel, sources, modelViewName, modelViewVersion, solrHost, solrPort, solrCollection, onlyModifiedData, webInfPath, bulkData);
		long  startTime = System.currentTimeMillis();
		scanJobManager.saveJob(job, true); 
		long  stopTime = System.currentTimeMillis();
		logger.debug("Time taken for saveJob for Job Nanme : " + name + " in  updateJob() method : " + (stopTime-startTime)/1000.0 + "sec.");		
		
	}

	/**
	 * Update an existing job with the parameters supplied and then run it. Supply null for any parameter that you don't wish to update.
	 * @param name Name of existing job - required
	 * @param description Description of job - optional
	 * @param logLevel LogLevel of job - optional
	 * @param sources List of ScanDatasourecs that are to be scanned - optional 
	 * @param modelViewName Name of ModelView to use - optional (if supplied also supply modelViewVersion)
	 * @param modelViewVersion Version  of ModelView to use - optional (if supplied also supply modelViewName)
	 * @param solrHost - Host name where Solr is running - optional ( if supplied also supply solrPort and solrCollection)
	 * @param solrPort - Port where Solr is running - optional ( if supplied also supply solrHost and solrCollection)
	 * @param solrCollection - Solr collection name to write to ( use core name like data_shard1_replica1) - optional ( if supplied also supply solrHost and solrPort)
	 * @param onlyModifiedData - If true then only new or data modified since last scan job will be scanned. This has no effect on initial job. 
	 * @throws BadArgumentsException
	 * @throws JobAlreadyExistsException
	 * @throws JobException
	 * @throws NotFoundException
	 */
	public void updateAndRunJob(String name, String description, Job.LogLevel logLevel, List<OpenSpiritScanDatasource> sources, String modelViewName, Integer modelViewVersion, String solrHost, 
            String solrPort, String solrCollection , boolean onlyModifiedData, String  webInfPath, String bulkData) throws BadArgumentsException, JobAlreadyExistsException, JobException, NotFoundException {
		 logger.info("Start of  updateAndRunJob");
	    logger.info("Number of sources " + sources.size());
		ScanJob job = updateScanJob(name, description, logLevel, sources, modelViewName, modelViewVersion, solrHost, solrPort, solrCollection, onlyModifiedData, webInfPath, bulkData);
		long  startTime = System.currentTimeMillis();
	    scanJobManager.submitUpdateJob(job);
	    long  stopTime = System.currentTimeMillis();
		logger.debug("Time taken for submitUpdateJob for Job Nanme : " + name + " in  updateAndRunJob() method : " + (stopTime-startTime)/1000.0 + "sec.");		
		
	    logger.info("END of  updateAndRunJob");
	}
	
	/**
	 * Create a new Scan job with the parameters supplied.  Then it can be saved or submitted.
	 * @param name Name of new job (must not already exist) 
	 * @param description Description of job - optional
	 * @param logLevel LogLevel of job 
	 * @param sources List of ScanDatasourecs that are to be scanned 
	 * @param modelViewName Name of ModelView to use 
	 * @param modelViewVersion Version  of ModelView to use 
	 * @param solrHost - Host name where Solr is running 
	 * @param solrPort - Port where Solr is running 
	 * @param solrCollection - Solr collection name to write to (use core name like data_shard1_replica1) 
	 * @param onlyModifiedData - If true then only new or data modified since last scan job will be scanned. This has no effect on initial job. 
	 * @throws BadArgumentsException
	 * @throws JobAlreadyExistsException
	 * @throws JobException
	 * @throws NotFoundException
	 * @throws InterruptedException
	 */
	private ScanJob createScanJob(String name, String description, Job.LogLevel logLevel, List<OpenSpiritScanDatasource> sources, String modelViewName, int modelViewVersion , String solrHost, 
			                 String solrPort, String solrCollection, boolean onlyModifiedData, String webInfPath, String bulkData ) throws BadArgumentsException, JobAlreadyExistsException, JobException, NotFoundException, InterruptedException {
		List<DataSource> datasources = getOpenSpiritDataSources(sources);	
		long  startTime = System.currentTimeMillis();
		ScanJob job = scanJobManager.createScanJob(name, description, logLevel, datasources);
		long  stopTime = System.currentTimeMillis();
		logger.info("Time taken for createScanJob for Job Nanme : " + name + " in  createScanJob() method : " + (stopTime-startTime)/1000.0 + "sec.");		
		
		/*EnterpriseSearchIndexOutputSettings settings=  OutputSettingsFactory.create(EnterpriseSearchIndexOutputSettings.class);
		settings.setSolrServer(solrHost, solrPort);
		settings.setSolrCore(solrCollection);
		settings.setCoordinateReferenceSystem( coordinateReferenceSystemWGS84, degreeAngle, meter, milliSecond);	
		
		job.addOutput(settings);*/
		setOutput(job, solrHost, solrPort, solrCollection, webInfPath, bulkData);
		job.setModelView(modelViewName, modelViewVersion);
		// Default is to scan only new/updated items so if onlyModifiedData is false then add a rule to the job
		if ( !onlyModifiedData){
			ModifiedItemsRule rule= job.addRule(ModifiedItemsRule.class);
			rule.setScanAllItems(true);
		}
		//Add rule to calculate project bounding box
		AllDataBoundingBoxRule bbRule= job.addRule(AllDataBoundingBoxRule.class);
		bbRule.set(true);
		
		return job;
	} 
	
	private String getBulkOutputDir() {
		//String programDataDir =  System.getenv("GD_DATA_PATH");
		String programDataDir = EnvUtil.getGDDataPath();
		File imagedir = new File(programDataDir);
		String imageDirectoryPath = null;
		if(programDataDir != null && !programDataDir.isEmpty()){				
			String logDir = programDataDir + "\\openspirit\\bulkexport\\";
			imagedir = new File(logDir);
			if(imagedir == null || !imagedir.isDirectory()){ 
				imagedir.mkdir();
			}
			
		}
		try {
			imageDirectoryPath = imagedir.getCanonicalPath();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return imageDirectoryPath;

	}
	
	private java.util.Properties getOutputConfig(String solrHost, String solrPort, String solrCollection, String bulkData) {
		
    	java.util.Properties config = new java.util.Properties();
 		config.setProperty("SOLR_HOST",solrHost);
 		config.setProperty("SOLR_PORT",solrPort);
 		config.setProperty("SOLR_CORE_NAME",solrCollection);
 		config.setProperty("SCAN_BATCH_SIZE","500");
 		config.setProperty("ORGANIZE_BY_PROJECT","true");
 		if(bulkData!=null && bulkData.trim().length() > 0 ) {
 			config.setProperty("BULK_DIRECTORY",bulkData);
 		}
		logger.info("bulkData :"  + bulkData);

 		config.setProperty("IMAGE_FORMAT","png");	
 		return config;
	}
	
	private File[] getJarFiles(String webInfPath) {
		File[] jarFiles = new File[] { new File(webInfPath, SOLRSCAN_JAR),  new File(webInfPath,COMMONS_IO_JAR),  new File(webInfPath,COMMONS_LOGGING_JAR), new File(webInfPath,GSON_JAR), 
				 new File(webInfPath,HTTPCLIENT_JAR), new File(webInfPath,HTTPCLIENTWIN_JAR), new File(webInfPath,HTTPCORE_JAR),  new File(webInfPath,HTTPMIME_JAR),  new File(webInfPath,NOGGIT_JAR),  new File(webInfPath,SLF4J_JAR),  new File(webInfPath,SOLRJ_JAR), new File(webInfPath,SEGY_JAR)};
		return jarFiles;
	}
	
	/**
	 * This method will add our SolrScanOutputPlugin as an output
	 * to the scan job passed as the job argument.
	 * @param job the job that the custom output is to be added to
	 * @throws BadArgumentsException 
	 */
	public void setOutput(ScanJob job, String solrHost, String solrPort, String solrCollection, String webInfPath, String bulkData)  {
		
		logger.info("SetOutput host : " + solrHost);
		logger.info("SetOutput port : " + solrPort);
				
		// Set the properties that the SorlScanPlugin needs
		java.util.Properties config = getOutputConfig(solrHost,solrPort, solrCollection, bulkData);
		
		// The output plugin implementation classes must be contained in one or
		// more jar files. All jar files needed by the output plugin implementation
		// must be passed in the jarFiles argument to the createCustomOutputSettings
		// method. 
		File[] jarFiles = getJarFiles(webInfPath);
		//File[] jarFiles = new File[] { SOLRSCAN_JAR ,COMMONS_IO_JAR, COMMONS_LOGGING_JAR, GSON_JAR, 
			//	HTTPCLIENT_JAR, HTTPCORE_JAR, HTTPMIME_JAR, NOGGIT_JAR, SLF4J_JAR, SOLRJ_JAR};
		
		
		// The settings that describe a custom scan output plugin must define the jar files needed
		// by the output plugin and the class of the plugin. This will be used by the scan job
		// to create the output plugin using reflection in the batch scan job process when it is run.
		CustomOutputSettings settings =
				OutputSettingsFactory.createCustomOutputSettings(jarFiles, SolrScanOutputPlugin.class);
		
		// Add any configuration properties that will be needed by the output plugin to control
		// how and where the output is written to.
		settings.setConfiguration(config);
		
		// Finally add the output settings to the scan job. Scan jobs can actually have more
		// than one output if there is a need to write to more than one output type or destination,
		// however this is not common.
		job.addCustomOutput(settings);
		

	}

	
	/**
	 * Find an existing job based on its name and then update it with the parameters supplied.  Supply null for any parameter that you don't wish to update. It can then be saved or submitted. 
	 * @param name Name of existing job - required
	 * @param description Description of job - optional
	 * @param logLevel LogLevel of job - optional
	 * @param sources List of ScanDatasourecs that are to be scanned - optional 
	 * @param modelViewName Name of ModelView to use - optional (if supplied also supply modelViewVersion)
	 * @param modelViewVersion Version  of ModelView to use - optional (if supplied also supply modelViewName)
	 * @param solrHost - Host name where Solr is running - optional ( if supplied also supply solrPort and solrCollection)
	 * @param solrPort - Port where Solr is running - optional ( if supplied also supply solrHost and solrCollection)
	 * @param solrCollection - Solr collection name to write to ( use core name like data_shard1_replica1) - optional ( if supplied also supply solrHost and solrPort)
	 * @param onlyModifiedData - If true then only new or data modified since last scan job will be scanned. This has no effect on initial job. 
	 * @throws BadArgumentsException
	 * @throws JobAlreadyExistsException
	 * @throws JobException
	 * @throws NotFoundException
	 */
	private ScanJob updateScanJob(String name, String description, Job.LogLevel logLevel, List<OpenSpiritScanDatasource> sources, String modelViewName, Integer modelViewVersion, String solrHost, 
            String solrPort, String solrCollection , boolean onlyModifiedData, String webInfPath, String bulkData) throws BadArgumentsException, JobAlreadyExistsException, JobException, NotFoundException {
		 long  startTime = System.currentTimeMillis();
	     List <Job> jobs = scanJobManager.getJobs(name);
	     long  stopTime = System.currentTimeMillis();
		 logger.debug("Time taken for getJobs for Job Nanme : " + name + " in  updateScanJob() method : " + (stopTime-startTime)/1000.0 + "sec.");		
			
	     if ( jobs.size() == 0) throw new JobException(" Job named: " + name + " not found");
	     
	     
	     ScanJob job = (ScanJob) jobs.get(0);
	     logger.info("Job Name " + job.getName());
	     if (description != null  ) {
	    	 job.setDescription(description);
	     }
	     if (logLevel != null ) {
	    	 job.setLogLevel(logLevel);
	     }
	     if ( sources != null ) {
	    	 List<DataSource> datasources = getOpenSpiritDataSources(sources);
	    	 job.setSources(datasources);
	     }
	     if ( modelViewName != null && modelViewVersion != null) {
	    	 job.setModelView(modelViewName, modelViewVersion);
	     }
	     logger.info("Job Name " + job.getModelViewName() + " Version " + job.getModelViewVersion());
	     if ( solrHost != null && solrPort!=null && solrPort!= null){
	    	 
	    	 File[] jarFiles =  getJarFiles(webInfPath);
	    	
	    			    	 
	    	 CustomOutputSettings outputSettings =
	 				OutputSettingsFactory.createCustomOutputSettings(jarFiles, SolrScanOutputPlugin.class);	 		
	    	 
	    	 List <CustomOutputSettings> settings = job.getCustomOutputs();
	    	 logger.info("The Output Settings of job is " + settings + " and the size is " + settings.size());
	    	 
	    	 if(settings != null && settings.size() > 0){
	    		 
	    		 outputSettings = (CustomOutputSettings) job.getCustomOutputs().get(0);
	    		 job.removeCustomOutput(outputSettings);
	    	}
	    	 
	    	java.util.Properties config = getOutputConfig(solrHost,solrPort, solrCollection, bulkData);
	 		outputSettings.setConfiguration(config);
			
			// Finally add the output settings to the scan job. Scan jobs can actually have more
			// than one output if there is a need to write to more than one output type or destination,
			// however this is not common.
			job.addCustomOutput(outputSettings);
			 logger.info("The added Output Settings of job is " + job.getCustomOutputs() + " and the size is " + job.getCustomOutputs().size());
			
	    	
	     }
	     // Update the scanAllItems rule based on onlyModifiedData
	     ModifiedItemsRule rule = job.getRule(ModifiedItemsRule.class);
	     if (rule == null) {
	    	 rule= job.addRule(ModifiedItemsRule.class);
	     }
		if ( onlyModifiedData){			
			rule.setScanAllItems(false);
		}
		else {			
			rule.setScanAllItems(true);
		}
		AllDataBoundingBoxRule bbRule = job.getRule(AllDataBoundingBoxRule.class);
		 if (bbRule == null) {
			 bbRule= job.addRule(AllDataBoundingBoxRule.class);
	     }		
		bbRule.set(true);
	    return job;
	}
	
	/**
	 *  Get all job runs.  There could be 100's to 1000's of these
	 * @return List of JobStatus objects (Job Runs)
	 * @throws JobException
	 */
	public List<JobStatus> getJobRuns() throws JobException {	 
		try {
		long  startTime = System.currentTimeMillis();
		 List<JobStatus> jobRuns = scanJobManager.getAllJobStatus(null);		
		 long  stopTime = System.currentTimeMillis();
		 logger.debug("Time taken for getAllJobStatus  in  getJobRuns() method : " + (stopTime-startTime)/1000.0 + "sec.");		
		
		 return jobRuns;	
		} catch (JobException je) {
			je.printStackTrace();
			logger.error(je.getMessage(), je);
			return null;
		}
	}
	
	/**
	 * Returns html log for the specified Job run. If the job is currently running, the contents returned is a 
	 * snapshot of the job's log file at the instant the method is called.
	 * @param jobName Name of job
	 * @param jobRunId Id of desired job run
	 * @return html formated log 
	 * @throws JobException
	 */
	public String getJobRunLog(String jobName, String jobRunId) throws JobException {	
		long  startTime = System.currentTimeMillis();
		String  returnStr =  scanJobManager.getJobLog(jobName, jobRunId, LogFormat.HTML);	
		long  stopTime = System.currentTimeMillis();
		logger.debug("Time taken for getJobLog  in  getJobRunLog() method : " + (stopTime-startTime)/1000.0 + "sec.");		
		return returnStr;
	}

	
	/**
	 * Get summary statistics for a specified Job run. If the job is currently running there won't be any.
	 * @param jobName Name of job
	 * @param jobRunId Id of desired job run
	 * @return html formated statistics table 
	 * @throws JobException
	 */
	public String getJobRunStatistics(String jobName, String jobRunId) throws JobException {
		 long  startTime = System.currentTimeMillis();
		 String returnStr =  scanJobManager.getJobLog(jobName, jobRunId, LogFormat.HTML_SUMMARY);
		 long  stopTime = System.currentTimeMillis();
		 logger.debug("Time taken for getJobLog  in  getJobRunLog() method : " + (stopTime-startTime)/1000.0 + "sec.");		
		 return returnStr;
	}	
	
	


	
	/**
	 * Run the specified Job. Will launch separate process.  Call getJobStatus and getJobLog methods to view the status and progress of the job.
	 * @param name Name of  job to run
	 * @throws BadArgumentsException
	 * @throws JobException
	 */
	public void runJob(String name) throws BadArgumentsException, JobException  {
		long  startTime = System.currentTimeMillis();
		scanJobManager.submitJob(name);
		 long  stopTime = System.currentTimeMillis();
		 logger.debug("Time taken for submitJob for Job Name " + name + " in  runJob() method : " + (stopTime-startTime)/1000.0 + "sec.");	
	}
	
	/**
	 * Update an existing job with the parameters supplied. Supply null for any parameter that you don't wish to update.
	 * @param name Name of existing job - required
	 * @param description Description of job - optional
	 * @param logLevel LogLevel of job - optional
	 * @param sources List of ScanDatasourecs that are to be scanned - optional 
	 * @param modelViewName Name of ModelView to use - optional (if supplied also supply modelViewVersion)
	 * @param modelViewVersion Version  of ModelView to use - optional (if supplied also supply modelViewName)
	 * @param solrHost - Host name where Solr is running - optional ( if supplied also supply solrPort and solrCollection)
	 * @param solrPort - Port where Solr is running - optional ( if supplied also supply solrHost and solrCollection)
	 * @param solrCollection - Solr collection name to write to ( use core name like data_shard1_replica1) - optional ( if supplied also supply solrHost and solrPort)
	 * @throws BadArgumentsException
	 * @throws JobAlreadyExistsException
	 * @throws JobException
	 * @throws NotFoundException
	 */
/*	public void updateJob(String name, String description, Job.LogLevel logLevel, List<OpenSpiritScanDatasource> sources, String modelViewName, Integer modelViewVersion, String solrHost, 
            String solrPort, String solrCollection ) throws BadArgumentsException, JobAlreadyExistsException, JobException, NotFoundException {
	     List <Job> jobs = scanJobManager.getJobs(name);
	     logger.info("The lis of jobs returned is " + jobs + " and the size is " + jobs.size());
	     if(jobs == null || jobs.size() == 0) {
	    	 throw new JobException(" Job named: " + name + " not found");
	     }
	     else{
	    	 ScanJob job = (ScanJob) jobs.get(0);
	    	 if(description != null) {
	    		 job.setDescription(description);
	    	 }
	    	 if(logLevel != null) {
	    		 job.setLogLevel(logLevel);
	    	 }
	    	 if (sources != null) {
	    		 List<DataSource> datasources = getOpenSpiritDataSources(sources);
	    		 job.setSources(datasources);
	    	}
	    	 if(modelViewName != null && modelViewVersion != null) {
	    		 job.setModelView(modelViewName, modelViewVersion);
	    	}
	    	 if(solrHost != null && solrPort!=null && solrCollection!= null){
	    	     EnterpriseSearchIndexOutputSettings outputSettings=  OutputSettingsFactory.create(EnterpriseSearchIndexOutputSettings.class);
	    		 List <OutputSettings> settings = job.getOutputs();
	    	     logger.info("The Output Settings of job is " + settings + " and the size is " + settings.size());

	    	     if(settings != null && settings.size() > 0){
	    			 outputSettings = (EnterpriseSearchIndexOutputSettings) job.getOutputs().get(0);
	    			 job.removeOutput(outputSettings);
	    		 }
    			 outputSettings.setSolrServer(solrHost, solrPort);
    			 outputSettings.setSolrCore(solrCollection);
    			 job.addOutput(outputSettings);
	    	}
	    	 scanJobManager.saveJob(job, true);
	     }
	}*/

	
	/**
	 * Returns a list of scan jobs owned by the caller. The filter parameter can be used to limit 
	 * the jobs that are returned. If the filter is null, all scan jobs owned by the caller will 
	 * be returned. Otherwise, only jobs that contain the filter value anywhere in the name will be
	 * returned. The job objects will only have the name, description, type and createdDate attributes populated.
	 * @param filter Optional filter
	 * @return List of Jobs 
	 * @throws JobException
	 */
/*	public List<Job> getJobs(String filter) throws JobException {	 
		 List<Job> jobs = scanJobManager.getJobs(filter);		 
		 return jobs;		 
	}*/
	
	/**
	 * Given list of ScanDatasources return List of DataSources
	 * @param sources List of ScanDatasource objects
	 * @return List of DataSource objects
	 * @throws NotFoundException
	 * @throws BadArgumentsException
	 */
	private List<DataSource> getOpenSpiritDataSources (List<OpenSpiritScanDatasource> sources) throws NotFoundException, BadArgumentsException{
		List<DataSource> datasources = new ArrayList<DataSource>();
		for (OpenSpiritScanDatasource source: sources){
			if (source.getProjectName() == null){;
			 long  startTime = System.currentTimeMillis();
				DataSourceDefinition ds = openSpirit.getDataService().getDataSourceType(source.getDatasourceType(), source.getDatasourceTypeVersion(), null).getDataSource(source.getDatasourceName());
				 long  stopTime = System.currentTimeMillis();
				 logger.info("Time taken for openSpirit.getDataService().getDataSourceType for DatasourceType " + source.getDatasourceType() + " in  getOpenSpiritDataSources() method : " + (stopTime-startTime)/1000.0 + "sec.");	
				datasources.add(DataSourceFactory.createDataSource(ds) );
			}
			else {
				 long  startTime = System.currentTimeMillis();
				ProjectDefinition proj = openSpirit.getDataService().getDataSourceType(source.getDatasourceType(), source.getDatasourceTypeVersion(), null).
						                 getDataSource(source.getDatasourceName()).getProject(source.getProjectName());
				datasources.add(DataSourceFactory.createDataSource(proj) );
				 long  stopTime = System.currentTimeMillis();
				 logger.info("Time taken for openSpirit.getDataService().getDataSourceType for DatasourceType " + source.getDatasourceType() + " Project : " + source.getProjectName() +  " in  getOpenSpiritDataSources() method : " + (stopTime-startTime)/1000.0 + "sec.");	
				
			}		
		}
		return datasources;
	}

	public List<Job> getJobs() throws JobException {
		long  startTime = System.currentTimeMillis();
		List<Job> listOfJobs = scanJobManager.getJobs(null);
		long  stopTime = System.currentTimeMillis();
		 logger.debug("Time taken for getJobs : " + (stopTime-startTime)/1000.0 + "sec.");	
		return listOfJobs;
	}

	public boolean deleteJob(String name) throws JobException {
		long  startTime = System.currentTimeMillis();
		boolean deleteStatus = scanJobManager.deleteJob(name);
		long  stopTime = System.currentTimeMillis();
		logger.debug("Time taken for getJobs : " + (stopTime-startTime)/1000.0 + "sec.");	
		return deleteStatus;
	
		
	}

	public boolean jobExists(String name) throws JobException {	
		logger.info("Checking for the job if exists " + name);	
		long  startTime = System.currentTimeMillis();
		boolean response = scanJobManager.jobExists(name);
		long  stopTime = System.currentTimeMillis();
		logger.debug("Time taken for jobExists for job name " +  name + " in  jobExists() method : " + (stopTime-startTime)/1000.0 + "sec.");
		return response;
	}
}
