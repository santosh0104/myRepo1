package com.bct.geodatafy.job;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

public class GeodatafyJobLog {
	static Logger logger = Logger.getLogger(GeodatafyJobLog.class);
	
	public static final String DEBUG = "DEBUG";
	public static final String INFO = "INFO";
	public static final String WARN = "WARN";
	public static final String ERROR = "ERROR";
	
	private String fileName;
	private String logLevel;
	
	public GeodatafyJobLog(String logFileName, String logLevel){
		fileName = logFileName;
		this.logLevel = logLevel;
		try {
			File file = new File(logFileName);
			if(!file.exists()){			
				file.createNewFile();
			} 
		}catch (IOException e) {
			logger.error("Error creating log file: " + e.getMessage());
		}		
	}
	
	public void debug(String msg, String details){
		if(logLevel.equalsIgnoreCase(DEBUG)){
			StringBuilder sb = new StringBuilder();
			sb.append(getCurrentDateTime());
			sb.append(" DEBUG ");
			sb.append("(" + msg + ") ");
			if(details != null && details.length() > 0){
				sb.append("[" + details + "]");
			}
			log(sb.toString());
		}
	}
	
	public void info(String msg, String details){
		if(logLevel.equalsIgnoreCase(DEBUG) || logLevel.equalsIgnoreCase(INFO)){
			StringBuilder sb = new StringBuilder();
			sb.append(getCurrentDateTime());
			sb.append(" INFO ");
			sb.append("(" + msg + ") ");
			if(details != null && details.length() > 0){
				sb.append("[" + details + "]");
			}
			log(sb.toString());
		}
	}
	
	public void warn(String msg, String details){
		if(logLevel.equalsIgnoreCase(DEBUG) || logLevel.equalsIgnoreCase(INFO) || logLevel.equalsIgnoreCase(WARN)){
			StringBuilder sb = new StringBuilder();
			sb.append(getCurrentDateTime());
			sb.append(" WARN ");
			sb.append("(" + msg + ") ");
			if(details != null && details.length() > 0){
				sb.append("[" + details + "]");
			}
			log(sb.toString());
		}
	}
	
	public void error(String msg, String details){	
		StringBuilder sb = new StringBuilder();
		sb.append(getCurrentDateTime());
		sb.append(" ERROR ");
		sb.append("(" + msg + ") ");
		if(details != null && details.length() > 0){
			sb.append("[" + details + "]");
		}
		log(sb.toString());
	}
	
	public static String getCurrentDateTime(){
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		return formatter.format(new Date(System.currentTimeMillis()));
	}
	
	public static String getCurrentDateTime(long timeinMillis){
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		return formatter.format(new Date(timeinMillis));
	}
	
	
	private void log(String input){
		try{
			FileWriter writer = new FileWriter(fileName, true);
			writer.write(input);
			writer.write("\n");
			writer.close();
		}
		catch(Exception e){
			logger.error(e);
		}
	}
}
