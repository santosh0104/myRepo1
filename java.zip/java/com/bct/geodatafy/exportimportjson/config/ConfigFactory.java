package com.bct.geodatafy.exportimportjson.config;

import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bct.geodatafy.exportimportjson.config.CommandLineConfig.ActionType;
import com.bct.geodatafy.exportimportjson.config.SolrField.MatchType;



public class ConfigFactory {

  private static Logger         logger             = LoggerFactory.getLogger(ConfigFactory.class);
/*
  private static final String[] BLOCK_SIZE         = new String[] {"b", "blockSize"};
  private static final String[] SKIP_DOCS          = new String[] {"x", "skipCount"};
  private static final String[] COMMIT_DURING_WORK = new String[] {"c", "commitDuringImport"};
  private static final String[] SOLR_URL           = new String[] {"s", "solrUrl"};
  private static final String[] ACTION_TYPE        = new String[] {"a", "actionType"};
  private static final String[] OUTPUT             = new String[] {"o", "output"};
  private static final String[] DELETE_ALL         = new String[] {"d", "deleteAll"};
  private static final String[] FILTER_QUERY       = new String[] {"f", "filterQuery"};
  private static final String[] HELP               = new String[] {"h", "help"};
  private static final String[] DRY_RUN            = new String[] {"D", "dryRun"};
  private static final String[] UNIQUE_KEY         = new String[] {"k", "uniqueKey"};
  private static final String[] SKIP_FIELDS        = new String[] {"S", "skipFields"};
  private static final String[] INCLUDE_FIELDS     = new String[] {"i", "includeFields"};
  private static final String[] DATETIME_FORMAT    = new String[] {"F", "dateTimeFormat"};

*/
  /**
   * read parameters from args
   * 
   * @param args
   * @return Config
   * @throws ParseException
   */
  public static CommandLineConfig getConfig( String solrUrl, String skipFields, String includeFields , String file, String filterQuery, String uniqueKey,
		    Boolean deleteAll , Boolean dryRun, String actionType, String blockSize, String skipCount,
		    String commitAfter, String dateTimeFormat) throws Exception
  {
   // CommandLine cmd = parseCommandLine(args);
   

    if (actionType == null) {
      throw new Exception("actionType should be [" + String.join("|", ActionType.getNames()) + "]");
    }

    if (solrUrl == null) {
      throw new Exception("solrUrl missing");
    }

    CommandLineConfig c = new CommandLineConfig();
    c.setSolrUrl(solrUrl);
    c.setFileName(file);

    if (uniqueKey != null) {
      c.setUniqueKey(uniqueKey);
    }

    if (skipFields != null) {
      c.setSkipFieldSet(convertStringToSolrFieldSet(skipFields));
    }

    if (includeFields != null) {
      c.setIncludeFieldSet(convertStringToSolrFieldSet(includeFields));
    }

    for (ActionType o : ActionType.values()) {
      if (actionType.equalsIgnoreCase(o.toString())) {
        c.setActionType(o);
        break;
      }
    }
    if (c.getActionType() == null) {
      throw new Exception("actionType should be [" + String.join("|", ActionType.getNames()) + "]");
    }

    c.setFilterQuery(filterQuery);

    c.setDeleteAll(deleteAll);

    c.setDryRun(dryRun);
    if (skipCount != null) {
      c.setSkipCount(Long.valueOf(skipCount));
    }

    if (commitAfter != null) {
      c.setCommitAfter(Integer.valueOf(commitAfter));
    }

    if (blockSize != null) {
      c.setBlockSize(Integer.parseInt(blockSize));
    }

    if (dateTimeFormat != null) {
      c.setDateTimeFormat(dateTimeFormat);
    }

    logger.info("Current configuration " + c);

    return c;
  }

  /**
   * @param includeFields
   * @return
   */
  private static Set<SolrField> convertStringToSolrFieldSet(String includeFields)
  {
    return Pattern.compile(",")
                  .splitAsStream(includeFields)
                  .map(String::trim)
                  .filter(s -> !s.equals("*"))
                  .map(s ->
                    {
                      if (s.startsWith("*")) {
                        return new SolrField(s.substring(1), MatchType.ENDS_WITH);
                      } else if (s.endsWith("*")) {
                        return new SolrField(s.substring(0, s.length() - 1), MatchType.STARTS_WITH);
                      } else
                        return new SolrField(s, MatchType.EQUAL);
                    })
                  .collect(Collectors.toSet());
  }

  

}
