package com.bct.geodatafy.openspirit;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.WinHttpClients;
import org.apache.solr.client.solrj.impl.HttpSolrClient;

import com.openspirit.InitializationException;
import com.openspirit.LicenseException;
import com.openspirit.NotFoundException;
import com.openspirit.OpenSpirit;
import com.openspirit.OpenSpiritFactory;
import com.openspirit.data.DataSourceTypeDefinition;
import com.openspirit.metamodel.EntityDefinition;
import com.openspirit.metamodel.MetamodelService;
import com.openspirit.metamodel.Model;

/**
 * Discover the OpenSpirit data transfer capabilities and create and then write TransferCapabilityDoc objects to the Solr metadata collection
 * 
 * This assumes that these fields are already defined in theSolr metadata collection
 *  id as string
 *  datatype as string
 *  sourceDataSourceTypeName as string
 *  sourceDataSourceTypeVersion as string
 *  targetDataSourceTypeName as string
 *  targetDataSourceTypeVersion as string
 *  transferDatatype as string
 *  transferJobName as string
 *  createdDate as pdate
 *  active as boolean
 * 
 * @author Clay
 *
 */
public class TransferCapabilities {
	
	private OpenSpirit openSpirit;
	private Model openSpiritModel;
	private HttpSolrClient solrMetadataCollection;
	
	private static TransferCapabilities instance = null;
	
	public static TransferCapabilities getInstance(String solrHost, String solrPort) throws InitializationException, LicenseException, NotFoundException {
		if(instance == null){
			instance = new TransferCapabilities(solrHost, solrPort); 
		}
		return instance;
	}
	
	public TransferCapabilities(String solrHost, String solrPort) throws InitializationException, LicenseException, NotFoundException {			
		// connect to the OpenSpirit framework
		openSpirit = OpenSpiritFactory.createOpenSpirit();
		openSpirit.connect("Geodatafy");	
		openSpiritModel = openSpirit.getMetamodelService().getModel(MetamodelService.OPENSPIRIT_MODEL, null);  		
		String solrMetadataCollectionUrl = "http://" + solrHost + ":" + solrPort + "/solr/metadata";
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		solrMetadataCollection =   (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(solrMetadataCollectionUrl)).withHttpClient(httpClient).build();		
	}
	
	/**
	 *  Discover the OpenSpirit data transfer capabilities and create and then write TransferCapabilityDoc objects to the Solr metadata collection
	 * @throws Exception
	 */
	public void updateTransferCapabilities() throws Exception {
		List<TransferCapabilityDoc> capabilties = getOpenSpiritCapabilties();
		writeCapabilityDocs(capabilties );
		//System.out.println(capabilties.size() + " transferCap docs written.");
	}
	
	/**
	 * Write the TransferCapabilityDoc objects to the Solr metadata collection
	 * @param capabilties List of TransferCapabilityDoc objects
	 * @throws Exception
	 */
	public void writeCapabilityDocs( List<TransferCapabilityDoc> capabilties) throws Exception {	
		solrMetadataCollection.addBeans(capabilties, 1000) ;	
		solrMetadataCollection.commit();
	}
	
	/**
	 * Return a list of TransferCapabilityDoc objects that define what datatypes may be transfered between all OpenSpirit enabled data stores that are configured at this site
	 * @return List of TransferCapabilityDoc objects
	 * @throws Exception
	 */
	public List<TransferCapabilityDoc> getOpenSpiritCapabilties() throws Exception {
		List<TransferCapabilityDoc> capabilties= new ArrayList<TransferCapabilityDoc>();
		DataSourceTypeDefinition[] dsTypes =  openSpirit.getDataService().getDataSourceTypes();
		List<DataSourceTypeDefinition>  configuredDsTypes =  new ArrayList<DataSourceTypeDefinition> ();
		for (DataSourceTypeDefinition dsType : dsTypes ){
			if ( dsType.getDataSources().length > 0) {
				configuredDsTypes.add(dsType);
			}
		}
		for (DataSourceTypeDefinition source:  configuredDsTypes) {
			for (DataSourceTypeDefinition target:  configuredDsTypes) {
				 List<String> supportedEntities = getSupportedEntities ( source, target);
				 for ( String supportedEntity: supportedEntities) {
					 TransferCapabilityDoc doc = new TransferCapabilityDoc();
					 String datatype= getDatatype(supportedEntity);
					 if ( datatype != null) {
						 doc.id= "OpenSpirit_" + source.getName() + "_" + source.getVersion() + "_" + target.getName() + "_" + target.getVersion() + "_" + datatype;
						 doc.sourceDataSourceTypeName = source.getName();
						 doc.sourceDataSourceTypeVersion = source.getVersion();
						 doc.targetDataSourceTypeName = target.getName();
						 doc.targetDataSourceTypeVersion = target.getVersion();
						 doc.transferDatatype= datatype;
						 doc.transferJobName="OpenSpiritCopy";
						 doc.createdDate= new Date();
						 doc.active = true;
						 capabilties.add(doc);
					 }				
				 }
			}
		}
		return capabilties;
	}

	
	/**
	 * Given OpenSpirit entity name (e.g. EpiWell_Wellbore) return the corresponding Geodatafy datatype name
	 * @param supportedEntity  OpenSpirit entity name
	 * @return Geodatafy datatype (e.g "Well") or null if nor corresponding type
	 */
	private String getDatatype(String supportedEntity) {
		String datatype= null;
		switch (supportedEntity.toLowerCase()) {
			case "epiwell_wellbore" :
				datatype= "Well";
				break;
			case "epiwell_wellpick" :
				datatype= "Well Pick";
				break;
			case "epiwell_welllogtrace" :
				datatype= "Well Log";
				break;
			case "epiwell_wellvelocity" :
				datatype= "Checkshot";
				break;
			case "episeismic_poststack2d" :
				datatype= "Seismic 2d";
				break;
			case "episeismic_poststack3d" :
				datatype= "Seismic 3d";
				break;
			case "epiinterpretation_horizongrid1dsetproperty" :
				datatype= "Horizon- 2D Seismic";
				break;
			case "epiinterpretation_horizongrid2dproperty" :
				datatype= "Horizon";
				break;
			case "epiinterpretation_faultpolylineset" :
				datatype= "Fault";
				break;			
			default:
				break;
		}
		return datatype;
	}

	/**
	 * Return the names of OpenSpirit entities that may be read from specified source and written to specified target 
	 * @param source The DataSourceTypeDefinition of the source
	 * @param target The DataSourceTypeDefinition of the target
	 * @return List of entity names that may be transfered between source and target 
	 * @throws Exception
	 */
	private List<String> getSupportedEntities(DataSourceTypeDefinition source, DataSourceTypeDefinition target) throws Exception {
		List<String> readableEntities  = getReadableEntities(source);
		List<String> writeableEntities = getWritableEntities(target);
		List<String> supportedEntities = new ArrayList<String> ();
		for (String sourceEntity:readableEntities){
			if (writeableEntities.contains(sourceEntity) ){
				supportedEntities.add(sourceEntity);
			}
		}
		return supportedEntities;
	}
	
	/**
	 * Return the names of OpenSpirit entities that may be read from specified datasource type
	 * @param dsType The DataSourceTypeDefinition of the source
	 * @return List of entity names that may be read from source
	 */
	private List<String> getReadableEntities ( DataSourceTypeDefinition dsType){
		List<String> entityList = new ArrayList<String>();
		EntityDefinition[] entities = dsType.getDataSourceCapabilities().getEntities(openSpiritModel);
		for (EntityDefinition entity : entities){
			entityList.add( entity.getName());
		}
		return entityList;
	}
	
	/**
	 * Return the names of OpenSpirit entities that may be written to specified datasource type
	 * @param dsType The DataSourceTypeDefinition of the target
	 * @return List of entity names that may be written to target
	 */
	private List<String> getWritableEntities ( DataSourceTypeDefinition dsType) throws Exception{
		List<String> entityList = new ArrayList<String>();		
		EntityDefinition[] entities = dsType.getDataSourceCapabilities().getEntities(openSpiritModel);
		for (EntityDefinition entity : entities){
			if ( dsType.getDataSourceCapabilities().isInsertSupported(entity) ) {
				entityList.add( entity.getName());
			}
		}
		return entityList;
	}
	
	
	public static void main( String[] args )
	{
		if ( args.length != 2) {
			System.out.println("Usage:  TransferCapabilities solrHost solrPort");
			return;
		}
		try {
			TransferCapabilities cap = new TransferCapabilities(args[0], args[1]);
			cap.updateTransferCapabilities();			
		} catch (Exception e) {			
			e.printStackTrace();
		}		
	}	
}
