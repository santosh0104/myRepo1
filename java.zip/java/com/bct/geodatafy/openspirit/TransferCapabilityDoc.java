package com.bct.geodatafy.openspirit;

import java.util.Date;

import org.apache.solr.client.solrj.beans.Field;

/**
 * 
 *  A POJO representation of a Solr document that describes data transfer capability 
 * @author Clay
 *
 */
public class TransferCapabilityDoc {
	@Field public String id;
	@Field public String datatype = "transferCap";
	@Field public String sourceDataSourceTypeName;
	@Field public String sourceDataSourceTypeVersion;
	@Field public String targetDataSourceTypeName;
	@Field public String targetDataSourceTypeVersion;
	@Field public String transferDatatype;
	@Field public String transferJobName;
	@Field public Date createdDate;
	@Field public boolean active;
}