package com.bct.geodatafy.rest.service;


import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.bct.geodatafy.license.License;
import com.bct.geodatafy.license.LicenseFeature;
import com.bct.geodatafy.license.LicenseUtil;
import com.bct.geodatafy.util.EnvUtil;
import com.bct.geodatafy.util.JsonUtil;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

@Path("/license")
public class LicenseService {
	static Logger logger = Logger.getLogger(LicenseService.class);	

	@GET
	@Path("/verify/{feature}")
	public boolean verifyLicense(@PathParam("feature") String feature,  @Context HttpServletRequest request){
		boolean result = false;
		logger.info("In /license/verify service and verifyLicense method.");
		logger.info("Given feature is: " + feature);
		try{
			if(feature == null || feature.isEmpty()){
				logger.error("feature is not set. returning false.");
			}else if(feature.equalsIgnoreCase("All")){
				logger.info("Verifying license with all features");
				return LicenseUtil.verifyLicense(LicenseUtil.DEFAULT_LICENSE_FILE);				
			}
			logger.info("Verifying license with the feature: " + feature);
			String fileName = getLicenFileName();
			return LicenseUtil.verifyLicense(fileName, feature);
		}catch(Exception e){
			logger.error("Exception while verifying the license. Returning false. " + e.getMessage());
		}		
		return result;
	}
	
	@GET
	@Path("/getUserCount/{feature}")
	public int getUserCountForFeature(@PathParam("feature") String feature,  @Context HttpServletRequest request){
		int result = 0;
		logger.info("In /license/getFeatureUserCount service and getUserCountForFeature method.");
		logger.info("Given feature is: " + feature);
		try{
			if(feature == null || feature.isEmpty()){
				logger.error("feature is not set. returning false.");
			}
			logger.info("getUserCount for the feature: " + feature);
			String fileName = getLicenFileName();
			return LicenseUtil.getUserCountForFeature(fileName, feature);
		}catch(Exception e){
			logger.error("Exception while getUserCountForFeature. Returning 0. " + e.getMessage());
		}		
		return result;
	}
	
	@GET
	@Path("/details")	
	public String getLicenseDetails(){
		logger.info("In /license/details service and getLicenseDetails method.");
		String result = "";
		String fileName = getLicenFileName();
		try{
			License license = LicenseUtil.readLicense(fileName);
			Gson gson = new Gson();
			result = gson.toJson(license);		
		}catch(Exception e){
			logger.info("Exception while verifying the license. Returning false. " + e.getMessage());
		}
		return result;		
	}
	
	@POST
	@Path("/create")
	@Consumes(MediaType.APPLICATION_JSON)
	public void createLicense(String payLoad, @Context HttpServletRequest request) throws Exception{
		logger.info("In /license/create service and createLicense method.");
		logger.info("Input payload is: " + payLoad);
		
		Map<String, JsonElement> elementsMap = JsonUtil.getJsonElementMap(payLoad);
		JsonElement orgName = elementsMap.get("OrgName");
		if(orgName == null || orgName.getAsString().isEmpty()){
			String msg = "Organization name is null or empty.";
			throw new Exception(msg);
		}

		JsonElement macAddress = elementsMap.get("MACAddress");
		if(macAddress == null || macAddress.getAsString().isEmpty()){
			String msg = "MAC address is null or empty.";
			throw new Exception(msg);
		}

		JsonElement featuresElement = elementsMap.get("Features");
		if(featuresElement == null){
			String msg = "Features is null.";
			throw new Exception(msg);
		}

		JsonArray featuresArray = JsonUtil.convertToJsonArray(featuresElement); 
		if(featuresArray == null){
			String msg = "Features is null.";
			throw new Exception(msg);
		}
		
		List<LicenseFeature> features = new ArrayList<LicenseFeature>();
		
		for (JsonElement featureElement : featuresArray) {
			String name = featureElement.getAsJsonObject().get("Name").getAsString();
			String licenseExpDate = featureElement.getAsJsonObject().get("LicenseExpDate").getAsString();
			String mainExpDate = featureElement.getAsJsonObject().get("MaintExpDate").getAsString();
			String numUsers = featureElement.getAsJsonObject().get("NumberOfUsers").getAsString();
			LicenseFeature feature = new LicenseFeature();
			feature.setLicenseExpiryDate(LicenseUtil.FORMATTER.parse(licenseExpDate));
			feature.setMaintenanceExpiryDate(LicenseUtil.FORMATTER.parse(mainExpDate));
			feature.setName(name);
			feature.setNumberOfUsers(Integer.parseInt(numUsers));
			features.add(feature);
		}
		
		License license = new License();
		license.setOrgName(orgName.getAsString());
		license.setMachineAddress(macAddress.getAsString());
		license.setFeatures(features);
		logger.info("Call the LicenseUtil CreateLicenseFile Method from create service: " );
		LicenseUtil.createLicenseFile(license);
		logger.info("end if  create License service:" );
	}
	
	 public static void main(String arg[])
	    {
		 LicenseService lc = new LicenseService();
		 lc.getValidFeatures();
	    }
	 
	
	
	@GET
	@Path("/features/valid")	
	public String getValidFeatures(){
		logger.info("In /license/features/valid service and getValidFeatures method.");
		long startTime = System.currentTimeMillis();
		System.out.println("Starts : " + new Date());
		String result = "";
		String fileName = getLicenFileName();
		System.out.println("After get File : " + new Date());
		try{
			License license = LicenseUtil.readLicense(fileName);
			System.out.println("After get read License File : " + new Date());
			List<LicenseFeature> features = license.getFeatures();
			System.out.println("After get read License features : " + new Date());
			Map<String, Boolean> validFeatures = new HashMap<String, Boolean>();
			for(LicenseFeature feature : features){
				if(LicenseUtil.verifyLicense(fileName, feature.getName())){
					validFeatures.put(feature.getName(), true);	
				}else{
					validFeatures.put(feature.getName(), false);
				}
			}		
			System.out.println("After get verify License features : " + new Date());
			Gson gson = new Gson();
			result = gson.toJson(validFeatures);		
		}catch(Exception e){
			logger.info("Exception while verifying the license. Returning false. " + e.getMessage());
		}
		long endTime = System.currentTimeMillis();
		System.out.println("Total Time : "  +  String.valueOf(endTime-startTime));
		return result;		
	}

	private String getLicenFileName(){
		String fileName ="";
		//String programData = System.getenv("GD_DATA_PATH");
		String programData = EnvUtil.getGDDataPath();
		if(programData != null && !programData.isEmpty()){
			fileName = programData + "\\license\\LicenseKey";				
		}
		else{
			fileName = "C:\\ProgramData\\Geodatafy\\license\\LicenseKey";	
		}
		return fileName;		
	}
}