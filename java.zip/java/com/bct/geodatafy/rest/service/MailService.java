package com.bct.geodatafy.rest.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.InternetHeaders;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.servlet.http.HttpServletRequest;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;

import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.WinHttpClients;
import org.apache.log4j.Logger;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocumentList;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;


import com.bct.geodatafy.license.License;
import com.bct.geodatafy.license.LicenseFeature;
import com.bct.geodatafy.license.LicenseUtil;
import com.bct.geodatafy.mail.Mail;
import com.bct.geodatafy.mail.MailData;
import com.bct.geodatafy.util.GeoUtil;
import com.bct.geodatafy.util.JsonUtil;
import com.bct.geodatafy.util.SecurityUtil;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import org.apache.velocity.tools.generic.DateTool;
import org.codehaus.jettison.json.JSONObject;



@Path("/mail")
public class MailService {
	static Logger logger = Logger.getLogger(MailService.class);	
	public static String DEFAULT_LICENSE_FILE= "LicenseKey";
	
	@POST
	@Path("/test")
	public String  testMail(String payLoad
			, @Context HttpServletRequest request
			) throws Exception{
		boolean result = false;
		logger.info("In /mail/test service and mail test method.");		
		logger.info("Input payload is: " + payLoad);
		
		Map<String, JsonElement> elementsMap = JsonUtil.getJsonElementMap(payLoad);
		JsonElement smtpHost = elementsMap.get("smtpHost");
		if(smtpHost == null || smtpHost.getAsString().isEmpty()){
			String msg = "SMTP Host is null or empty.";
			return msg;
		}
		JsonElement smtpPort = elementsMap.get("smtpPort");
		if(smtpPort == null || smtpPort.getAsString().isEmpty()){
			String msg = "SMTP Port is null or empty.";
			return msg;
		}
		JsonElement smtpUsername = elementsMap.get("smtpUsername");
		boolean isAuth = true;
		if(smtpUsername == null || smtpUsername.getAsString().isEmpty()){
			String msg = "SMTP Username is null or empty.";
			//return msg;
			//throw new Exception(msg);
			isAuth = false;
		} 
		JsonElement smtpPassword = elementsMap.get("smtpPassword");
		if(smtpPassword == null || smtpPassword.getAsString().isEmpty()){
			String msg = " SMTP Password is null or empty.";
			//return msg;
			//throw new Exception(msg);
			isAuth = false;
		} 
		
		
		JsonElement mailFrom = elementsMap.get("mailFrom");
		if(mailFrom == null || mailFrom.getAsString().isEmpty()){
			String msg = "From Email Address is null or empty.";
			return msg;
		}
		
		JsonElement mailTo = elementsMap.get("mailTo");
		if(mailTo == null || mailTo.getAsString().isEmpty()){
			String msg = "Receipients Email Address is null or empty.";
			return msg;
		}
		
		
		try {						
	        Mail mail = new Mail();
	        mail.setSmtpHost(smtpHost.getAsString());
	        mail.setSmtpPort(smtpPort.getAsString());
	        mail.setAuthRequired(isAuth);
	        if(isAuth) {
	        mail.setSmtpUsername(smtpUsername.getAsString());
	        String encryptedPassword = smtpPassword.getAsString();
	        String smtpDecryptPassword = SecurityUtil.decrypt(encryptedPassword);
	        mail.setSmtpPassword(smtpDecryptPassword);
	        }
	        mail.setMailFrom(mailFrom.getAsString());
	        mail.setMailTo(mailFrom.getAsString());
	        String mailSubject = " Geodatafy Test Mail";
	        mail.setMailSubject(mailSubject);	
	        mail.setRegisteredUser(4);
	 	        
	        
	        String emailTo = mailTo.getAsString();
			logger.info(emailTo);
			String[] emails = emailTo.split(",");
			for (int j=0 ; j< emails.length; j++) {
				System.out.println(emails[j]);
				mail.setMailTo(emails[j]);
				sendEmail(mail);	
			}	
	        String msg = "Email verified successfully";
			return msg;
		} catch(Exception e) {
			e.printStackTrace();
			logger.error("Exception while sending mail returning false " , e);
			String msg=e.getMessage();
			return msg;
		}		
		
	}

	@POST
	@Path("/share")
	public String  mailShare(String payLoad
			, @Context HttpServletRequest request
			) throws Exception{
		boolean result = false;
		  logger.info("In /mail/share service and share method.");		
		  logger.info("Input payload is: " + payLoad);
		
		Map<String, JsonElement> elementsMap = JsonUtil.getJsonElementMap(payLoad);
		JsonElement smtpHost = elementsMap.get("smtpHost");
		if(smtpHost == null || smtpHost.getAsString().isEmpty()){
			String msg = "SMTP Host is null or empty.";
			return msg;
		}
		JsonElement smtpPort = elementsMap.get("smtpPort");
		if(smtpPort == null || smtpPort.getAsString().isEmpty()){
			String msg = "SMTP Port is null or empty.";
			return msg;
		}
		JsonElement smtpUsername = elementsMap.get("smtpUsername");
		boolean isAuth = true;
		if(smtpUsername == null || smtpUsername.getAsString().isEmpty()){
			String msg = "SMTP Username is null or empty.";
			isAuth = false;
			//return msg;	
			
		} else {
			isAuth = true;
		}
		JsonElement smtpPassword = elementsMap.get("smtpPassword");
		if(smtpPassword == null || smtpPassword.getAsString().isEmpty()){
			String msg = " SMTP Password is null or empty.";
			isAuth = false;
			//return msg;
			
		 
		}else {
			isAuth = true;
		}
		
		
		JsonElement mailFrom = elementsMap.get("mailFrom");
		if(mailFrom == null || mailFrom.getAsString().isEmpty()){
			String msg = "From Email Address is null or empty.";
			return msg;
		}
		JsonElement mailTo = elementsMap.get("mailTo");
		if(mailTo == null || mailTo.getAsString().isEmpty()){
			String msg = "To Email Address is null or empty.";
			return msg;
		}
		JsonElement cartName = elementsMap.get("cartName");
		if(cartName == null || cartName.getAsString().isEmpty()){
			String msg = "cartName is null or empty.";
			return msg;
		}	
		JsonElement name = elementsMap.get("name");
		if(name == null || name.getAsString().isEmpty()){
			String msg = "name is null or empty.";
			return msg;
		}	
		
		String userMessage = "";
		JsonElement message = elementsMap.get("message");
		if(message != null && !message.getAsString().isEmpty()){			
			userMessage = message.getAsString();			
		}	
		logger.debug("User Message " + userMessage);

		JsonElement linkURL = elementsMap.get("linkURL");
		if(linkURL == null || linkURL.getAsString().isEmpty()){
			String msg = "linkURL is null or empty.";
			return msg;
		}	
		logger.error("Link . " + linkURL);
		String solrHost = "localhost";
		if(elementsMap.get("solrHost") != null){
			solrHost = elementsMap.get("solrHost").getAsString();
		}else{
			logger.info("solr Host is not set. Assuming localhost");		
		}
		logger.info("solr host is set to: " + solrHost);

		String solrPort = "8983";
		if(elementsMap.get("solrPort") != null){
			solrPort = elementsMap.get("solrPort").getAsString();
		}else{
			logger.info("solr Port is not set. Assuming 8983");		
		}
		logger.info("solr Port is set to: " + solrPort);	
		/*JsonElement isRegUser = elementsMap.get("isRegUser");
		if(linkURL == null || linkURL.getAsString().isEmpty()){
			String msg = "RegisteredUser is null or empty.";
			return msg;
		}	
		int isRegisteredUser = isRegUser.getAsInt(); */
		try {						
	        Mail mail = new Mail();
	        mail.setSmtpHost(smtpHost.getAsString());
	        mail.setSmtpPort(smtpPort.getAsString());
	        mail.setAuthRequired(isAuth);
	        if(isAuth) {
	        mail.setSmtpUsername(smtpUsername.getAsString());
	        String encryptedPassword = smtpPassword.getAsString();
	        String smtpDecryptPassword = SecurityUtil.decrypt(encryptedPassword);
	        mail.setSmtpPassword(smtpDecryptPassword);
	        }

	        mail.setMailFrom(mailFrom.getAsString());
	       // mail.setMailTo(mailTo.getAsString());
	        String mailSubject = name.getAsString() + " shared " + cartName.getAsString() + " with you ";
	        mail.setMailSubject(mailSubject);	
	        
	        
	     //   mail.setRegisteredUser(isRegisteredUser);
	        Map < String, Object > model = new HashMap < String, Object > ();
	        model.put("name", name.getAsString());
	        model.put("url", linkURL.getAsString());
	        if(userMessage != null && !userMessage.isEmpty()){				
				model.put("message", userMessage);
				logger.debug("Setting the Message to model " + userMessage);
			}else{
				logger.debug("Not Setting the Message to model as it is empty.");
			}
	        
	        mail.setModel(model);	
	        logger.info("calling send mail beofre " + linkURL);
	        
	        String emailTo = mailTo.getAsString();
			logger.info(emailTo);
			String[] emails = emailTo.split(",");
			for (int j=0 ; j< emails.length; j++) {
				System.out.println(emails[j]);
				boolean userDetResult = getUserDetailsForShare(emails[j], mail, solrHost, solrPort);
				//mail.setAuthRequired(true);
				//mail.setMailTo("lakshmipathi.g@bahwancybertek.com");
				mail.setMailTo(emails[j]);
				sendEmail(mail);		
				
			}	
	        
	        logger.info(" send mail to  " + emailTo);
			String msg =  "Cart shared successfully";
			return msg;
		}catch(Exception e){
			logger.error("Exception while sending mail returning false ",  e);
			String msg=e.getMessage();
			return msg;
			
		}		
		
	}
	
	@POST
	@Path("/alert")
	public String  mailAlert(String payLoad
			, @Context HttpServletRequest request
			) throws Exception{
		
		  logger.info("In /mail/alert service and mail alert method.");		
		  logger.info("Input payload is: " + payLoad);
		
		Map<String, JsonElement> elementsMap = JsonUtil.getJsonElementMap(payLoad);
		JsonElement smtpHost = elementsMap.get("smtpHost");
		if(smtpHost == null || smtpHost.getAsString().isEmpty()){
			String msg = "SMTP Host is null or empty.";
			return msg;
		}
		JsonElement smtpPort = elementsMap.get("smtpPort");
		if(smtpPort == null || smtpPort.getAsString().isEmpty()){
			String msg = "SMTP Port is null or empty.";
			return msg;
		}
		JsonElement smtpUsername = elementsMap.get("smtpUsername");
		boolean isAuth = true;
		if(smtpUsername == null || smtpUsername.getAsString().isEmpty()){
			String msg = "SMTP Username is null or empty.";
			isAuth = false;
			//return msg;		
			
		}
		JsonElement smtpPassword = elementsMap.get("smtpPassword");
		if(smtpPassword == null || smtpPassword.getAsString().isEmpty()){
			String msg = " SMTP Password is null or empty.";
			isAuth = false;
			//return msg;
			
		
		}
		
		
		JsonElement mailFrom = elementsMap.get("mailFrom");
		if(mailFrom == null || mailFrom.getAsString().isEmpty()){
			String msg = "From Email Address is null or empty.";
			return msg;
			
		}
		JsonElement mailTo = elementsMap.get("mailTo");
		if(mailTo == null || mailTo.getAsString().isEmpty()){
			String msg = "To Email Address is null or empty.";
			return msg;
		}
		JsonElement cartName = elementsMap.get("cartName");
		if(cartName == null || cartName.getAsString().isEmpty()){
			String msg = "cartName is null or empty.";
			return msg;
		}	
		JsonElement name = elementsMap.get("name");
		if(name == null || name.getAsString().isEmpty()){
			String msg = "name is null or empty.";
			return msg;
		}	
		JsonElement linkURL = elementsMap.get("linkURL");
		if(linkURL == null || linkURL.getAsString().isEmpty()){
			String msg = "linkURL is null or empty.";
			return msg;
		}	
		JsonElement dataToList = elementsMap.get("data");
		if(dataToList == null || dataToList.getAsString().isEmpty()){
			String msg = "data is null or empty.";
			return msg;
		}	
		logger.error("Link . " + linkURL);
		JsonElement isRegUser = elementsMap.get("isRegUser");
		if(isRegUser == null || isRegUser.getAsString().isEmpty()){
			String msg = "RegisteredUser is null or empty.";
			return msg;
		}	
		int isRegisteredUser = isRegUser.getAsInt();
		List<MailData> runs = new ArrayList<MailData>();
		Gson gson = new Gson();
		String dataStr =  dataToList.getAsString();
		logger.info(dataStr);
		TypeToken<ArrayList<MailData>> token = new TypeToken<ArrayList<MailData>>() {};
		ArrayList<MailData> mailListObj = gson.fromJson(dataStr, token.getType());
		try {						
	        Mail mail = new Mail();
	        mail.setSmtpHost(smtpHost.getAsString());
	        mail.setSmtpPort(smtpPort.getAsString());
	        mail.setAuthRequired(isAuth);
	        if(isAuth) {
	        mail.setSmtpUsername(smtpUsername.getAsString());
	        String encryptedPassword = smtpPassword.getAsString();
	        String smtpDecryptPassword = SecurityUtil.decrypt(encryptedPassword);
	        mail.setSmtpPassword(smtpDecryptPassword);
	        }

	        mail.setMailFrom(mailFrom.getAsString());
	        mail.setMailTo(mailTo.getAsString());
	        String mailSubject = name.getAsString() + " shared " + cartName.getAsString() + " with you ";
	        mail.setMailSubject(mailSubject);	
	        mail.setRegisteredUser(isRegisteredUser);
	        Map < String, Object > model = new HashMap < String, Object > ();
	        model.put("name", name.getAsString());
	        model.put("url", linkURL.getAsString());
	        model.put("dataList", mailListObj);
	        mail.setModel(model);	
	        logger.info("calling send mail beofre " + linkURL);
	        sendEmail(mail);
	        logger.info(" send mail after " + linkURL);
			String msg =  "Cart Shared Successfully";
			return msg;
		}catch(Exception e){
			logger.error("Exception while sending mail returning false " , e);
			String msg=e.getMessage();
			return msg;
			
		}		
		
	}
	
	
	@POST
	
	@Path("/key")
	public String mailLicenseKey(String payLoad
			, @Context HttpServletRequest request
			) throws Exception{
		boolean result = false;
		logger.info("In /mail/key service and mailLicenseKey method.");		
		logger.info("Input payload is: " + payLoad);
		
		Map<String, JsonElement> elementsMap = JsonUtil.getJsonElementMap(payLoad);
		JsonElement smtpHost = elementsMap.get("smtpHost");
		if(smtpHost == null || smtpHost.getAsString().isEmpty()){
			String msg = "SMTP Host is null or empty.";
			return msg;
		}
		JsonElement smtpPort = elementsMap.get("smtpPort");
		if(smtpPort == null || smtpPort.getAsString().isEmpty()){
			String msg = "SMTP Port is null or empty.";
			return msg;
		}
		JsonElement smtpUsername = elementsMap.get("smtpUsername");
		boolean isAuth = true;
		if(smtpUsername == null || smtpUsername.getAsString().isEmpty()){
			String msg = "SMTP Username is null or empty.";
			//return msg;		
			isAuth = false;
		}
		JsonElement smtpPassword = elementsMap.get("smtpPassword");
		if(smtpPassword == null || smtpPassword.getAsString().isEmpty()){
			String msg = " SMTP Password is null or empty.";
			//return msg;
			isAuth = false;
		
		}
		
		
		JsonElement mailFrom = elementsMap.get("mailFrom");
		if(mailFrom == null || mailFrom.getAsString().isEmpty()){
			String msg = "From Email Address is null or empty.";
			return msg;
		}
		JsonElement mailTo = elementsMap.get("mailTo");
		if(mailTo == null || mailTo.getAsString().isEmpty()){
			String msg = "To Email Address is null or empty.";
			return msg;
		}
		JsonElement licenseId = elementsMap.get("licenseId");
		if(licenseId == null || licenseId.getAsString().isEmpty()){
			String msg = "LicenseId is null or empty.";
			return msg;
		}	
		JsonElement companyName = elementsMap.get("companyName");
		if(companyName == null || companyName.getAsString().isEmpty()){
			String msg = "CompanyName is null or empty.";
			return msg;
		}	
		
		JsonElement contactName = elementsMap.get("contactName");
		if(contactName == null || contactName.getAsString().isEmpty()){
			String msg = "ContactName is null or empty.";
			return msg;
		}	
		
				
		JsonElement macAddress = elementsMap.get("MACAddress");
		if(macAddress == null || macAddress.getAsString().isEmpty()){
			String msg = "MAC address is null or empty.";
			return msg;
		}

		JsonElement featuresElement = elementsMap.get("Features");
		if(featuresElement == null){
			String msg = "Features is null.";
			return msg;
		}

		JsonArray featuresArray = JsonUtil.convertToJsonArray(featuresElement); 
		if(featuresArray == null){
			String msg = "Features is null.";
			return msg;
		}
		
		List<LicenseFeature> features = new ArrayList<LicenseFeature>();
		
		for (JsonElement featureElement : featuresArray) {
			String name = featureElement.getAsJsonObject().get("Name").getAsString();
			String licenseExpDate = featureElement.getAsJsonObject().get("LicenseExpDate").getAsString();
			String mainExpDate = featureElement.getAsJsonObject().get("MaintExpDate").getAsString();
			String numUsers = featureElement.getAsJsonObject().get("NumberOfUsers").getAsString();
			boolean active = featureElement.getAsJsonObject().get("active").getAsBoolean();
			if(active) {
			LicenseFeature feature = new LicenseFeature();
			feature.setLicenseExpiryDate(LicenseUtil.FORMATTER.parse(licenseExpDate));
			feature.setMaintenanceExpiryDate(LicenseUtil.FORMATTER.parse(mainExpDate));
			feature.setName(name);
			feature.setNumberOfUsers(Integer.parseInt(numUsers));
			features.add(feature);
			}
		}
		
		License license = new License();
		license.setLicenseId(licenseId.getAsString());
		license.setOrgName(companyName.getAsString());
		license.setMachineAddress(macAddress.getAsString());
		license.setFeatures(features);		
		
		try {						
	        Mail mail = new Mail();
	        mail.setSmtpHost(smtpHost.getAsString());
	        mail.setSmtpPort(smtpPort.getAsString());
	        mail.setAuthRequired(isAuth);
	        if(isAuth) {
	        mail.setSmtpUsername(smtpUsername.getAsString());
	        mail.setSmtpPassword(smtpPassword.getAsString());
	        }
	        mail.setRegisteredUser(9);
	        String fileName = DEFAULT_LICENSE_FILE + "_" +  licenseId.getAsString();
	       
			logger.info(fileName);
			//String fileName = DEFAULT_LICENSE_FILE;	
			String programDataDir = System.getenv("ProgramData"); 
			if(programDataDir != null && !programDataDir.isEmpty()){				
				String logDir = programDataDir + "\\GeodatafyLicense\\License\\";
				fileName = logDir.concat(fileName);
				File dir = new File(fileName);
				if(dir == null || !dir.isFile()){ 
					String msg = "License File not found in the path " + dir.getCanonicalPath();					
					return msg;
				}
				 mail.setFileName(fileName);
				logger.info(fileName);
			}

	        mail.setMailFrom(mailFrom.getAsString());
	        mail.setMailTo(mailTo.getAsString());
	        String mailSubject =  " Geodatafy License" ;
	        mail.setMailSubject(mailSubject);	
	        logger.info("calling send mail beofre ");
	        Map < String, Object > model = new HashMap < String, Object > ();
	       /// model.put("name", name.getAsString());
	       // model.put("url", linkURL.getAsString());	        
	      
	        model.put("CompanyName", companyName.getAsString());
	        model.put("ContactName", contactName.getAsString());
	        model.put("MACAddress", macAddress.getAsString());
	        model.put("FeatureList", license.getFeatures());
	        mail.setModel(model);	
	        sendEmailWithAttachment(mail);
	        logger.info(" send mail after " );
			String msg =  "License Key sent in email Successfully";
			return msg;
		}catch(Exception e){
			logger.error("Exception while sending mail returning false " + e.getMessage());
			String msg=e.getMessage();
			return msg;			
		}				
	}
		
	private  MimeMessage createMimeMessage(Mail mail) throws Exception{
		
			Properties prop = new Properties();
			prop.put("mail.smtp.host", mail.getSmtpHost());
			prop.put("mail.from", mail.getMailFrom());
			Session session = null;
			  if (mail.isAuthRequired()) {
				  prop.put("mail.smtp.socketFactory.port", "465");		//sslport		 
				  prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

				  Authenticator auth = new Authenticator() {
						//override the getPasswordAuthentication method
						protected PasswordAuthentication getPasswordAuthentication() {
							return new PasswordAuthentication(mail.getSmtpUsername(), mail.getSmtpPassword());
						}
					};
				session = Session.getInstance(prop, auth);
                session.getProperties().put("mail.smtp.auth", "true");
			  } else {
				
				session = Session.getInstance(prop, null);
                session.getProperties().put("mail.smtp.auth", "false");
			  }
			
			  session.getProperties().put("mail.smtp.host", mail.getSmtpHost());
			  session.getProperties().put("mail.from", mail.getMailFrom());
			  session.getProperties().put("mail.smtp.port", mail.getSmtpPort());			  
			  session.setDebug(false);
		      MimeMessage message = new MimeMessage(session);		      
			return message;
		
	}
	
	private  String  getVelocityTemplateContent(Mail mail) {
		logger.info("getVelocityTemplateContent ---->  ");
		// velocity stuff		
		Properties p = new Properties();
		p.setProperty("resource.loader", "class");
		p.setProperty("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
		// Initialize velocity
		VelocityEngine ve = new VelocityEngine();
		ve.init(p);
		/* next, get the Template */
		Template t = null;
		logger.info("mail.getRegisteredUser() ---->  " + mail.getRegisteredUser());
		
		Map velModel = (HashMap) mail.getModel();
		
		if(mail.getRegisteredUser()==1) {
			if(velModel.get("message") == null || ((String)velModel.get("message")).isEmpty()){				
				t = ve.getTemplate("regusers-template-share.vm");
				logger.debug("getting the template without message. regusers-template-share.vm");
			}else{
				t = ve.getTemplate("regusers-template-share-message.vm");	
				logger.debug("getting the template with message. regusers-template-share-message.vm");
			}			
		} else if(mail.getRegisteredUser()==2) {
			if(velModel.get("message") == null || ((String)velModel.get("message")).isEmpty()){				
				 t = ve.getTemplate("unregusers-template-share.vm");
				 logger.debug("getting the template without message. unregusers-template-share.vm");
			}else{
				 t = ve.getTemplate("unregusers-template-share-message.vm");	
				 logger.debug("getting the template with message. unregusers-template-share-message.vm");
			}
		} else if(mail.getRegisteredUser()==3) {
			if(velModel.get("message") == null || ((String)velModel.get("message")).isEmpty()){				
				 t = ve.getTemplate("browseusers-template-share.vm");
				 logger.debug("getting the template without message. browseusers-template-share.vm");
			}else{
				t = ve.getTemplate("browseusers-template-share-message.vm");
				logger.debug("getting the template with message. browseusers-template-share-message.vm");
			}
		} else if(mail.getRegisteredUser()==5) {
			 t = ve.getTemplate("regusers-template-alert.vm");
		} else if(mail.getRegisteredUser()==6) {
			 t = ve.getTemplate("unregusers-template-alert.vm");
		} else if(mail.getRegisteredUser()==7) {
			 t = ve.getTemplate("browseusers-template-alert.vm");
		} else if(mail.getRegisteredUser()==9) {
			 t = ve.getTemplate("license-template-alert.vm");
		}
		/* create a context and add data */
		VelocityContext context = new VelocityContext();
		context.put("date", new DateTool());
		
		Set keys = velModel.keySet();
		for ( Object key: keys) {			
		    //String keyValue = (String) velModel.get(key);
		   // logger.info(" key " + key + "keyValue " +  keyValue);
		    if (key.toString().equals("dataList")) {
		    	ArrayList<MailData> keyValue = (ArrayList<MailData>) velModel.get(key);
		    	context.put(key.toString(), keyValue);
		    } else  if (key.toString().equals("FeatureList")) {
		    	ArrayList<LicenseFeature> keyValue = (ArrayList<LicenseFeature>) velModel.get(key);
		    	context.put(key.toString(), keyValue);
		    } else {
		    	String keyValue = (String) velModel.get(key);		    	
		    	context.put(key.toString(), keyValue);
		    	logger.debug("Put the key-value to the mail context. Key: " + key.toString() + " Value: " + keyValue);
		    }
		}	
		/* now render the template into a StringWriter */
		StringWriter out = new StringWriter();
		t.merge(context, out);
		String content = out.toString();
		logger.info("Mail content: " + content);
		return content;
	}

   public void sendEmail(Mail mail) throws Exception{
       MimeMessage mimeMessage = createMimeMessage(mail); 
       logger.info("In sendEmail");
       try {  
    	   
          	mimeMessage.addHeader("Content-type", "text/HTML; charset=UTF-8");
        	mimeMessage.addHeader("format", "flowed");
        	mimeMessage.addHeader("Content-Transfer-Encoding", "8bit"); 

	       	mimeMessage.setSubject(mail.getMailSubject());
	       	mimeMessage.setFrom(new InternetAddress(mail.getMailFrom()));	       		
	       	mimeMessage.addRecipients(Message.RecipientType.TO, InternetAddress.parse(mail.getMailTo()));
	       	if(mail.getRegisteredUser()==4) {
	       		mail.setMailContent("<h6>Your email has been verified Successfully!</h6>");
	       	} else if(mail.getRegisteredUser()==9) {
	       		mail.setMailContent("<h6>Please find the attachement for the Licensekey</h6>");
	       	} else {
	       		logger.debug("Calling the velocity template method.");
	       		mail.setMailContent(getVelocityTemplateContent(mail));
	       	}
	       	mimeMessage.setText(mail.getMailContent(), "UTF-8", "html");
	       	mimeMessage.setSentDate(new Date());	
	       	logger.info("Mail is ready: ");
        	
	       	Transport.send(mimeMessage);
	       	logger.info("Mail sent successfully ");
	       	
	      
           
       } catch (MessagingException me) {
    	   logger.error("Exception " , me);
           me.printStackTrace();
           throw me;
       } catch (Exception e) {
    	   logger.error("Exception " , e);
           e.printStackTrace();
           throw e;
       }
   }
       private void sendEmailWithAttachment(Mail mail) throws Exception{
           MimeMessage mimeMessage = createMimeMessage(mail); 
           logger.info("In sendEmailWithAttachment");
           try {  
        	   
              	mimeMessage.addHeader("Content-type", "text/HTML; charset=UTF-8");
            	mimeMessage.addHeader("format", "flowed");
            	mimeMessage.addHeader("Content-Transfer-Encoding", "8bit"); 

    	       	mimeMessage.setSubject(mail.getMailSubject());
    	       	mimeMessage.setFrom(new InternetAddress(mail.getMailFrom()));	       		
    	       	mimeMessage.addRecipients(Message.RecipientType.TO, InternetAddress.parse(mail.getMailTo()));
    	       	// Create the message body part
    	         BodyPart messageBodyPart = new MimeBodyPart();
    	         
    	    
    	    	mail.setMailContent(getVelocityTemplateContent(mail));
    	    
    	     //  	mimeMessage.setText(mail.getMailContent(), "UTF-8", "html");
    	       	mimeMessage.setSentDate(new Date());	
    	       	//logger.info("Mail is ready: ");

    	         // Fill the message
    	         messageBodyPart.setContent(mail.getMailContent(),  "text/html");
    	         
    	         // Create a multipart message for attachment
    	         Multipart multipart = new MimeMultipart();

    	         // Set text message part
    	         multipart.addBodyPart(messageBodyPart);

    	         // Second part is attachment
    	         messageBodyPart = new MimeBodyPart();
    	         String filename = mail.getFileName();
    	         
    	        
    	         DataSource source = new FileDataSource(filename);
    	         messageBodyPart.setDataHandler(new DataHandler(source));
    	         messageBodyPart.setFileName("LicenseKey");
    	         multipart.addBodyPart(messageBodyPart);

    	         // Send the complete message parts
    	         mimeMessage.setContent(multipart);

    	         // Send message
    	        // Transport.send(mimeMessage);
    	       //  logger.info("EMail Sent Successfully with attachment!!");
    	      
    	       	//mail.setMailContent("<h4>Please find the attached License Key</h4>");
    	       
    	       	//mimeMessage.setText(mail.getMailContent(), "UTF-8", "html");
    	       	mimeMessage.setSentDate(new Date());	
    	       	logger.info("Mail is ready: ");
            	
    	       	Transport.send(mimeMessage);
    	       	logger.info("Mail sent successfully ");
    	       	
    	      
               
           } catch (MessagingException me) {
        	   logger.error("Exception " , me);
               me.printStackTrace();
               throw me;
           } catch (Exception e) {
        	   logger.error("Exception " , e);
               e.printStackTrace();
               throw e;
           }
   }
       
       
       private boolean getUserDetailsForShare(String email, Mail mail, String solarHost, String solarPort) throws Exception{
   		
   		
   		try {
   			CloseableHttpClient httpClient = WinHttpClients.createDefault();
   			HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
   					"http://" + solarHost + ":" + solarPort + "/solr/" + "metadata")).withHttpClient(httpClient).build();
   			
   			

   			SolrQuery query = new SolrQuery();
   			query.setQuery("datatype:userRoles"); // main query
   			query.set("wt", "json");
   			query.setRows(2147483647);
   			String strEmailFilter =  "email:\"" + GeoUtil.escapeQueryParams(email) + "\"";
   			query.addFilterQuery(strEmailFilter);
   			System.out.println(query.toQueryString());
   			logger.info(query.toQueryString());
   			QueryResponse resp = client.query(query);
   			logger.info(" QueryResponse: " + resp.getResponse().toString());
   			System.out.println(" QueryResponse: " + resp.getResponse().toString());
   			SolrDocumentList docList = resp.getResults();		
   			logger.info(" QueryResponse for UserRoles : " + docList.getNumFound());
   			if (docList.getNumFound() > 0 ) {
   				mail.setRegisteredUser(1);
   				return true;
   			} else {
   				query = new SolrQuery();
   				query.setQuery("*:*"); // main query
   				query.set("wt", "json");
   				query.setRows(2147483647);
   				query.addFilterQuery("datatype:AppConfig");
   				System.out.println(query.toQueryString());
   				System.out.println(query.toQueryString());
   				resp = client.query(query);
   				logger.info(" QueryResponse to check browse access: " + resp.getResponse().toString());
   				System.out.println(" QueryResponse: " + resp.getResponse().toString());
   				docList = resp.getResults();		
   				logger.info(" QueryResponse for checking Browse Role: " + docList.getNumFound());		
   				
   				for (Map singleDoc : docList) {
   					JSONObject json = new JSONObject(singleDoc);
   					boolean isBrwseUser = (boolean) json.get("isBrowser");			
   					if(isBrwseUser) {
   						mail.setRegisteredUser(3); //browse user
   					} else {
   						mail.setRegisteredUser(2); //unregisteres user
   					}
   				}
   				
   			
   				return true;
   			}
   			
   			
   		} catch (Exception e) {
   			logger.error(e.getMessage());
   			logger.error("Exception during execution of Query for getUserDetails : " , e);
   			e.printStackTrace();		
   			throw new Exception(e.getMessage());
   			//return false;
   		} finally {

   		}		
   		
       }     
       
       
      
  
   
   public static void main(String args[]) throws Exception{
  	 
     /*  Mail mail = new Mail();
       mail.setMailFrom("lakshmipathi.g@bahwancybertek.com");
       //mail.setMailTo("nithya.m@bahwancybertek.com");
       mail.setMailTo("lakshmipathi.g@bahwancybertek.com");
       mail.setMailSubject("Lakshmi shared Default with you");
      

       Map < String, Object > model = new HashMap < String, Object > ();
       model.put("name", "Lakshmi");
       model.put("url", "http://petro.bahwancybertek.com");    
      
       mail.setModel(model);
       MailService mailService = new MailService(); 
       mailService.sendEmail(mail); */
	   
	   
	   MailService mailService = new MailService(); 
	   String s = " {" 
			+ "\"smtpHost\" : \"mail.bahwancybertek.com\","
			+ "\"smtpPort\" : \"587\","
			+ "\"smtpUsername\" : \"bctchn/va112300\","
			+ "\"cartName\" : \"new cart\","
			+ "\"name\" : \"K7\","
			+ "\"message\" : \"Sending for approval\","	
			+ "\"solrHost\" : \"192.168.0.166\","			
	   		+ "\"mailFrom\" : \"vaishaly.anbu@bahwancybertek.com\","	
			+   "\"mailTo\" : \"kesavan.srinivasan@bahwancybertek.com\","
	   		+ "\"linkURL\" : \"http://petro.bahwancybertek.com\""
			   
	   		+ "}";
	   
	   System.out.println(mailService.mailShare(s, null));
	  //System.out.println(mailService.testMail(s));
	   
	   
	 /* String str =  "{\"smtpHost\":\"mail.bahwancybertek.com\",\"smtpPort\":\"587\",\"smtpUsername\":\"bctchn/va112300\","
	  		+ "\"smtpPassword\":\"Isha@19951995\",\"mailFrom\":\"vaishaly.anbu@bahwancybertek.com\","
	  		+ "\"mailTo\":\"vaishaly.anbu@bahwancybertek.com\",\"licenseId\":\"bctvaishaly.anbu@bahwancybertek.com28082018112244\"}";
	   MailService mailService = new MailService(); 
	   logger.info(mailService.mailLicenseKey(str));*/
	 //  MailService mailService = new MailService(); 
	//   System.out.println(mailService.testMail(s));
	 /*  String str1 =  "{\"smtpHost\":\"mail.bahwancybertek.com\",\"smtpPort\":\"587\","
	   		+ "\"smtpUsername\":\"bctchn/va112300\",\"smtpPassword\":\"Isha@19951995\","
	   		+ " \"mailFrom\":\"vaishaly.anbu@bahwancybertek.com\","
	   		+ "\"mailTo\":\"lakshmipathi.g@bahwancybertek.com\",\"licenseId\":\"Bahwan cybertek Ltdlakshmipathi.g@bahwancybertek.com31082018053843\","
	   		+ "\"companyName\":\"bct\",\"contactName\":\"a@a.com\", \"MACAddress\":\"abc\",	"
	   		+ "\"Features\":[ "
	   		+ "{\"Name\":\"Geodatafy Core\",\"LicenseExpDate\":\"Aug/29/2018\",\"MaintExpDate\":\"Aug/31/2018\",\"NumberOfUsers\":5,\"active\":true}]}";
	   	
	   System.out.println(mailService.mailLicenseKey(str1)); */
       
   }
	
	
}