package com.bct.geodatafy.rest.service;


import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;
import org.codehaus.jettison.json.JSONObject;

import com.bct.geodatafy.job.GeodatafyJobLog;
import com.bct.geodatafy.job.backup.SolrRestoreJob;
import com.bct.geodatafy.rest.service.exception.GeodatafyInputException;
import com.bct.geodatafy.restore.RestoreUtil;
import com.bct.geodatafy.util.EnvUtil;
import com.bct.geodatafy.util.JsonUtil;



@Path("/jobs/restore")
public class RestoreService {
	static Logger logger = Logger.getLogger(RestoreService.class);
	public static final String JOB_TYPE = "SolrRestoreService";
	public static final int COMMIT_SIZE = 10;
	public static final String JOBS_COLLECTION = "jobs";
	
	
	@POST
	@Path("/list")
	@Consumes(MediaType.APPLICATION_JSON)
	public String getBackJobList(String payLoad
			, @Context HttpServletRequest request
			) throws Exception{		
		logger.info("In service: /jobs/restore/list and method: runSolrRestoreJob");		
		
		logger.info("Input payload is: " + payLoad);
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);	
		if(elementsMap == null || elementsMap.isEmpty()){
			String msg = "The input payload is not a expected json string";
			logger.error(msg);
			throw new GeodatafyInputException(msg);
			//return msg;
		}
		
		logger.info("Number of elements in input json : " + elementsMap.size() + " ");		
	
		
		String solrHost = "localhost";
		if(elementsMap.get("solrHost") != null){
			solrHost = elementsMap.get("solrHost");
		}else{
			logger.info("solr Host is not set. Assuming localhost");		
		}
		logger.info("solr host is set to: " + solrHost);

		String solrPort = "8983";
		if(elementsMap.get("solrPort") != null){
			solrPort = elementsMap.get("solrPort");
		}else{
			logger.info("solr Port is not set. Assuming 80");		
		}
		logger.info("solr Port is set to: " + solrPort);
		

		RestoreUtil restoreUtilObj = new RestoreUtil();
		String str = restoreUtilObj.getSolrBackupJobs(solrHost, solrPort);		

		return str;

		
	}
	
	
	@POST
	@Path("/start")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response  startSolrRestoreJobService(String payLoad
		//	, @Context HttpServletRequest request
			) throws Exception{		
		logger.info("In service: /jobs/restore/start and method: runSolrRestoreJob");		
		String returnMsg = null;
		RestoreUtil restoreUtilObj = new RestoreUtil();
		logger.info("Input payload is: " + payLoad);
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);	
		if(elementsMap == null || elementsMap.isEmpty()){
			returnMsg = "The input payload is not a expected json string";
			logger.error(returnMsg);
			throw new GeodatafyInputException(returnMsg);
			
		}
		
		logger.info("Number of elements in input json : " + elementsMap.size() + " ");		
					
		String solrHost = "localhost";
		if(elementsMap.get("solrHost") != null){
			solrHost = elementsMap.get("solrHost");
		}else{
			logger.info("solr Host is not set. Assuming localhost");		
		}
		logger.info("solr host is set to: " + solrHost);

		String solrPort = "8983";
		if(elementsMap.get("solrPort") != null){
			solrPort = elementsMap.get("solrPort");
		}else{
			logger.info("solr Port is not set. Assuming 80");		
		}
		logger.info("solr Port is set to: " + solrPort);	

		
		String  collectionName = elementsMap.get("collection");
		if(collectionName == null || collectionName.length() < 0){
			returnMsg = "The collectionName value is not available.";
			logger.error(returnMsg);
			throw new GeodatafyInputException(returnMsg);
			
		}
		
		logger.info("solr Collection Name is set to: " + collectionName);
		
		String  backupPath = elementsMap.get("backupFolder");
		if(backupPath == null || collectionName.length() < 0){
			returnMsg = "The bkupRunsFolder value is not available.";
			logger.error(returnMsg);
			throw new GeodatafyInputException(returnMsg);
			
		}	
		
		logger.info("solr bkupRunsFolder Name is set to: " + backupPath);
		String protocol =  "http";
		//String protocol = request.getScheme();
		if(protocol == null || protocol.isEmpty()){
			protocol = "http";
		}		
		
		returnMsg = restoreUtilObj.startSolrRestoreJobService( protocol, solrHost, solrPort);
		System.out.println(returnMsg);
		
		return Response.status(200).entity(returnMsg).build(); 
	}

	
	
	
	
	@POST
	@Path("/run")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response  runSolrRestoreJobService(String payLoad
			, @Context HttpServletRequest request
			) throws Exception{		
		logger.info("In service: /jobs/restore/run and method: runSolrRestoreJob");		
		String returnMsg = null;
		RestoreUtil restoreUtilObj = new RestoreUtil();
		logger.info("Input payload is: " + payLoad);
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);	
		if(elementsMap == null || elementsMap.isEmpty()){
			returnMsg = "The input payload is not a expected json string";
			logger.error(returnMsg);
			throw new GeodatafyInputException(returnMsg);
			//return returnMsg;
		}
		
		logger.info("Number of elements in input json : " + elementsMap.size() + " ");		
					
		String solrHost = "localhost";
		if(elementsMap.get("solrHost") != null){
			solrHost = elementsMap.get("solrHost");
		}else{
			logger.info("solr Host is not set. Assuming localhost");		
		}
		logger.info("solr host is set to: " + solrHost);

		String solrPort = "8983";
		if(elementsMap.get("solrPort") != null){
			solrPort = elementsMap.get("solrPort");
		}else{
			logger.info("solr Port is not set. Assuming 80");		
		}
		logger.info("solr Port is set to: " + solrPort);	

		
		String  collectionName = elementsMap.get("collection");
		if(collectionName == null || collectionName.length() < 0){
			returnMsg = "The collectionName value is not available.";
			logger.error(returnMsg);
			throw new GeodatafyInputException(returnMsg);
			//return returnMsg;
		}
		
		logger.info("Solr Collection Name is set to: " + collectionName);
		
		String  backupName = elementsMap.get("backupName");
		if(backupName == null || backupName.length() < 0){
			returnMsg = "The backupName value is not available.";
			logger.error(returnMsg);
			throw new GeodatafyInputException(returnMsg);
			//return returnMsg;
		}

		
		String  backupPath = elementsMap.get("backupFolder");
		if(backupPath == null || collectionName.length() < 0){
			returnMsg = "The bkupRunsFolder value is not available.";
			logger.error(returnMsg);
			throw new GeodatafyInputException(returnMsg);
			//return returnMsg;
		}
		
		
		logger.info("solr bkupRunsFolder Name is set to: " + backupPath);
		
		
				
		SolrRestoreJob restoreTask = new SolrRestoreJob();
		restoreTask.setBkupRunsFolder(backupPath);
		restoreTask.setSolrCollectionName(collectionName);
		restoreTask.setSolrHost(solrHost);;
		restoreTask.setSolrPort(solrPort);
		restoreTask.setBackupName(backupName);
		
		String solrDocID = "Restore" + "_" + Long.toString(System.currentTimeMillis());
		String logFileName = "logs\\" + solrDocID + ".log";
		
		//String programDataDir = System.getenv("GD_LOG_PATH"); 
		String programDataDir = EnvUtil.getGDLogPath();
		logger.info("GD Log Path dir received from environment variable GD_LOG_PATH is: " + programDataDir);
		
		if(programDataDir != null && !programDataDir.isEmpty()){				
				String logDir = programDataDir + "\\logs\\restore\\";
				logFileName = logDir + solrDocID + ".log";
		}		
		String logLevel = GeodatafyJobLog.INFO;			
		GeodatafyJobLog jobLogger = new GeodatafyJobLog(logFileName, logLevel);			
		jobLogger.info("Input Payload", payLoad);
		

		String protocol = request.getScheme();
		//String protocol =  "http";
		if(protocol == null || protocol.isEmpty()){
			protocol = "http";
		}		
		
		returnMsg = restoreUtilObj.runSolrRestoreJobService(restoreTask, jobLogger, protocol);
				
		return Response.status(200).entity(returnMsg).build(); 
	}
	
	public static void main(String args[]) throws Exception {
		RestoreService restoreObj = new RestoreService();
		//JSONObject json = new JSONObject();
		//json.put("solrHost","192.168.2.231");
		//json.put("solrPort","8983");
		//restoreObj.getBackJobList(json.toString()); 
	
		
		JSONObject json = new JSONObject();
		json.put("solrHost","192.168.2.231");
		json.put("solrPort","8983");
		json.put("solrCollectionName","metadata");
		json.put("backupFolder","D:\\BACKUP_SOLR\\192.168.2.231\\Lakshmi_Backup\\11012019_161023");		
		json.put("collection","data,gis,metadata");
		//json.put("bkupRunsFolder","D:\\BACKUP_SOLR\\192.168.2.231\\Data_Backup_job\\16112018_120423");		
		//System.out.println(restoreObj.getBackJobList(json.toString()));
		System.out.println(restoreObj.startSolrRestoreJobService(json.toString()));
		//RestoreUtil restoreObj = new RestoreUtil();	
	}
	

}
