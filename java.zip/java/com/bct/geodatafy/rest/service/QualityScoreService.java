package com.bct.geodatafy.rest.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.regex.Pattern;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.WinHttpClients;
import org.apache.log4j.Logger;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.codehaus.jettison.json.JSONObject;

import com.bct.geodatafy.util.GeoUtil;
import com.bct.geodatafy.qc.Constants;
import com.bct.geodatafy.qc.GenerateRule;
import com.bct.geodatafy.qc.GeodatafyField;
import com.bct.geodatafy.qc.SampleExpressionEvaluation;
import com.bct.geodatafy.util.JsonUtil;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@Path("/quality/score")
public class QualityScoreService {
	
	static Logger logger = Logger.getLogger(QualityScoreService.class);
	HttpSolrClient metadataHttpSolrClient;	

	@POST
	@Path("/")
	@Consumes(MediaType.APPLICATION_JSON)
	public String runScoreRecords(String payLoad) throws Exception{		
		logger.info("In service: /jobs/quality/score/ and method: runScoreRecords");	
		logger.info("Input payload is: " + payLoad);		
		
		Map<String, JsonElement> elementsMap = JsonUtil.getJsonElementMap(payLoad);
		
		JsonElement solrHost = elementsMap.get("solrHost");		
		if(solrHost == null || solrHost.getAsString().isEmpty()){
			String returnMSG = "solr Host is null or empty";
			logger.error(returnMSG + " Returning without doing anything.");
			throw new Exception(returnMSG);
			//return returnMSG;			
		}

		JsonElement solrPort = elementsMap.get("solrPort");		
		if(solrPort == null || solrPort.getAsString().isEmpty()){
			String returnMSG = "solr Port is null or empty";
			logger.error(returnMSG + " Returning without doing anything.");
			throw new Exception(returnMSG);
			//return returnMSG;			
		}
		
		JsonElement datatype = elementsMap.get("datatype");		
		if(datatype == null || datatype.getAsString().isEmpty()){
			String returnMSG = "datatype is null or empty";
			logger.error(returnMSG + " Returning without doing anything.");
			throw new Exception(returnMSG);
			//return returnMSG;			
		}

		JsonElement dataElement = elementsMap.get("data");		
		if(dataElement == null || !dataElement.isJsonArray() || dataElement.getAsJsonArray().size() < 1){
			String returnMSG = "data is null or empty";
			logger.error(returnMSG + " Returning without doing anything.");
			throw new Exception(returnMSG);
			//return returnMSG;			
		}

		String metadataURL = "http://" + solrHost.getAsString() + ":" + solrPort.getAsString() + "/solr/metadata"; 

		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		metadataHttpSolrClient =   (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(metadataURL)).withHttpClient(httpClient).build();
		
		System.out.println(metadataURL);
		System.out.println(metadataHttpSolrClient);
		
		String ruleSet = "";
		JsonElement ruleSetElement = elementsMap.get("qcRuleSet:");
		if(ruleSetElement == null || ruleSetElement.getAsString().isEmpty()){
			ruleSet = getDefaultRuleSet();
		}else{
			ruleSet = ruleSetElement.getAsString();
		}
		
		JsonArray dataArray = dataElement.getAsJsonArray();
		
		SolrDocumentList rulesJSON = getRulesforDatatype(ruleSet, datatype.getAsString());
		
		Map<String, GeodatafyField> ruleFieldsMap = new HashMap<String, GeodatafyField>();
		List<JSONObject> compositeRules = new ArrayList<JSONObject>();
		populateRules(rulesJSON, ruleFieldsMap, compositeRules);
		
		Map<String, HashMap<String, String>> compositeRuleFieldMaps = new HashMap<String, HashMap<String, String>>();
		Map<String, String> compositeRulePatterns =  new HashMap<String, String>();
		Set<String> compositeRuleFieldNames = new HashSet<String>();
		 
		getCompositeRulesExprAndFields(compositeRules, compositeRuleFieldMaps, compositeRulePatterns, compositeRuleFieldNames);

		for(JsonElement data : dataArray){
			List<String> qcDetails = new ArrayList<String>();
			double qcScore = 0.0;
			checkFieldRules(data, ruleFieldsMap, qcDetails);
			checkCompositeRules(data, compositeRules, compositeRulePatterns, compositeRuleFieldMaps, qcDetails);
			qcScore = calculateQCScore(data, qcDetails);
		}
		
		//System.out.println(dataArray);
		return dataArray.toString();
	}
	
	private String getDefaultRuleSet() throws Exception{

		String qcRuleSet = "";
		SolrQuery query = new SolrQuery();
		query.set("q","*:*" );
		query.addFilterQuery("datatype:\"qcRuleSet\"");
		query.addFilterQuery("default:true");
		query.set("wt","json");
		
		QueryResponse resp = metadataHttpSolrClient.query(query);
		int status = resp.getStatus();
		if(status == 0){
			SolrDocumentList ruleSets = resp.getResults();

			//Only one default rule set expected. 
			//If multiple rule sets are there, last value is taken
			for(SolrDocument ruleSet : ruleSets) {
				qcRuleSet = (String) ruleSet.getFieldValue("qcRuleSet");
			}
		}
		return qcRuleSet;
	}
	
	private SolrDocumentList getRulesforDatatype(String ruleSet, String datatype) throws Exception{
		SolrDocumentList rules = null;
		SolrQuery query = new SolrQuery();

		query.set("q","*:*" );
		query.addFilterQuery("qcRuleSet:\"" + GeoUtil.escapeQueryParams(ruleSet) + "\"");
		query.addFilterQuery("datatype:qcRule");
		query.addFilterQuery("qcEntity:\"" + datatype + "\"");
		query.set("wt","json");
		
		QueryResponse resp = metadataHttpSolrClient.query(query);
		int status = resp.getStatus();
		if (status == 0) {
			rules = resp.getResults();
		}
		return rules;
	}
	
	private static void populateRules(SolrDocumentList rulesJSON, Map<String, GeodatafyField> ruleFieldsMap, List<JSONObject> compositeRules) throws Exception{		
		for(Map rule : rulesJSON) {
			JSONObject json = new JSONObject(rule);
			
			if (json.has("compositeRules") && json.has("rules")){	
				compositeRules.add(json);			
			}
			else{
				if(json.has("qcField")) {
					GeodatafyField  fieldsObj = new GeodatafyField();
					
					String qcField = (String) json.get("qcField");					
					fieldsObj.setName(qcField);
					
					if(json.has("qcMandatory")) {
						fieldsObj.setMandatory((boolean) json.get("qcMandatory"));
					}
					if(json.has("qcPattern")) {
						fieldsObj.setPattern((String) json.get("qcPattern"));
					}
					if(json.has("qcMin")) {
						fieldsObj.setMin((Long) json.get("qcMin"));
					}
					if(json.has("qcMax")) {
						fieldsObj.setMax((Long) json.get("qcMax"));
					}
					if(json.has("qcMinDate")) {
						Date minDate = (Date) json.get("qcMinDate");
						fieldsObj.setMinDate(minDate);
					}
					if(json.has("qcMaxDate")) {
						Date maxDate  = (Date) json.get("qcMaxDate");
						fieldsObj.setMaxDate(maxDate);
					}
					if(json.has("qcType")) {						
						fieldsObj.setQcType((Long) json.get("qcType"));
					}
					ruleFieldsMap.put(qcField, fieldsObj);
				}			
			}
		}
	}
	
	
	private void getCompositeRulesExprAndFields(List<JSONObject> compositeRules, Map<String, HashMap<String, String>> compositeRuleFieldMaps, Map<String, String> compositeRulePatterns, Set<String> compositeRuleFieldNames) throws Exception {
		if(compositeRules != null && compositeRules.size() > 0){
			int j = 0;
			for(JSONObject json : compositeRules){
				String rules = (String) json.get("rules");
				String qcPattern = (String) json.get("qcPattern");
				String id = (String) json.get("id");
				
				HashMap<String, String> fieldMap = new HashMap<String, String>();
				JsonArray jsonArr = JsonUtil.convertToJsonArray(rules);
				for(int i = 0; i < jsonArr.size(); i++){
					JsonElement jsonObj = jsonArr.get(i);
					Map<String, String> elementsMap = JsonUtil.getJsonStringMap(jsonObj.toString());
					String elemlookUp = elementsMap.get("lookUp");
					boolean blookUp= new Boolean(elemlookUp);
					if(blookUp){
						String fieldName = elementsMap.get("field");
						String valfieldName = elementsMap.get("value");
						String solrType = elementsMap.get("solrType");
						
						fieldMap.put(fieldName, solrType);
						fieldMap.put(valfieldName, solrType);
						if(!compositeRuleFieldNames.contains(fieldName)){
							compositeRuleFieldNames.add(fieldName);
						}
						if(!compositeRuleFieldNames.contains(valfieldName)){
							compositeRuleFieldNames.add(valfieldName);
						}
					}else{
						String fieldName = elementsMap.get("field");
						String solrType = elementsMap.get("solrType");
						if(!compositeRuleFieldNames.contains(fieldName)){
							compositeRuleFieldNames.add(fieldName);
						}
						fieldMap.put(fieldName, solrType);
					}
				}
				String key = "Rule" + j++;
				compositeRuleFieldMaps.put(id, fieldMap);
				String ruleExpression = GenerateRule.buildRules(rules);
				compositeRulePatterns.put(id, ruleExpression);
			}
		}
	}

	private void checkFieldRules(JsonElement data, Map<String, GeodatafyField> ruleFieldsMap, List<String> qcDetails) throws Exception{
		JsonObject obj = data.getAsJsonObject();

		Set<Map.Entry<String, JsonElement>> entries = obj.entrySet();//will return members of the object
		
		for(Map.Entry<String, JsonElement> entry: entries){
			GeodatafyField field = ruleFieldsMap.get(entry.getKey());

			if(field != null){
				checkFieldRule(obj, field, qcDetails);
			}
		}
	}
	
	private void checkFieldRule(JsonObject obj, GeodatafyField ruleField, List<String> qcDetails) throws Exception{		
		JsonElement field = obj.get(ruleField.getName());
		if(ruleField.isMandatory()){
			if(field != null && !field.getAsString().isEmpty()){
				qcDetails.add("{\"field\":\""+ ruleField.getName() + "\", \"status\":\"passed\", \"rule\":\"mandatory\", \"reason\":\"exists\"}");
			}
			else{
				qcDetails.add("{\"field\":\""+ ruleField.getName() + "\", \"status\":\"failed\", \"rule\":\"mandatory\", \"reason\":\"does not exist\"}");
			}
		}
		
		//qcType is set for the pattern details and the min lenth and max length of pattern is assigned to min and max field 
		if(ruleField.getMin() != null && ruleField.getQcType() == null){
			if(field == null || field.getAsString().isEmpty()){
				qcDetails.add("{\"field\":\""+ ruleField.getName() + "\", \"status\":\"failed\", \"rule\":\"minField\", \"reason\":\"does not exist\"}");
			}else if(field.getAsLong() >= ruleField.getMin()){
				qcDetails.add("{\"field\":\""+ ruleField.getName() + "\", \"status\":\"passed\", \"rule\":\"minField\", \"reason\":\"greater than " + ruleField.getMin() + "\"}");
			}else{
				qcDetails.add("{\"field\":\""+ ruleField.getName() + "\", \"status\":\"failed\", \"rule\":\"minField\", \"reason\":\"is not greater than " + ruleField.getMin() + "\"}");
			}
		}
			
		if(ruleField.getMax() != null && ruleField.getQcType() == null){			
			if(field == null || field.getAsString().isEmpty()){
				qcDetails.add("{\"field\":\""+ ruleField.getName() + "\", \"status\":\"failed\", \"rule\":\"maxField\", \"reason\":\"does not exist\"}");
			}else if(field.getAsLong() <= ruleField.getMax()){
				qcDetails.add("{\"field\":\""+ ruleField.getName() + "\", \"status\":\"passed\", \"rule\":\"maxField\", \"reason\":\"lesser than " + ruleField.getMax() + "\"}");
			}else{
				qcDetails.add("{\"field\":\""+ ruleField.getName() + "\", \"status\":\"failed\", \"rule\":\"maxField\", \"reason\":\"is not lesser than " + ruleField.getMax() + "\"}");
			}
		}
		
		if(ruleField.getMinDate() != null){		
			if(field == null || field.getAsString().isEmpty()){
				qcDetails.add("{\"field\":\""+ ruleField.getName() + "\", \"status\":\"failed\", \"rule\":\"minDateField\", \"reason\":\"does not exist\"}");
			}
			else{
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
				format.setTimeZone(TimeZone.getTimeZone("UTC"));
				Date date = format.parse(field.getAsString());
				
				long minTime = ruleField.getMinDate().getTime();
				if(date.getTime() >= minTime){
					qcDetails.add("{\"field\":\""+ ruleField.getName() + "\", \"status\":\"passed\", \"rule\":\"minDateField\", \"reason\":\"greater than " + ruleField.getMinDate() + "\"}");
				}else{
					qcDetails.add("{\"field\":\""+ ruleField.getName() + "\", \"status\":\"failed\", \"rule\":\"minDateField\", \"reason\":\"is not greater than " + ruleField.getMinDate() + "\"}");
				}
			}
		}

		if(ruleField.getMaxDate() != null){
			if(field == null || field.getAsString().isEmpty()){
				qcDetails.add("{\"field\":\""+ ruleField.getName() + "\", \"status\":\"failed\", \"rule\":\"maxDateField\", \"reason\":\"does not exist\"}");
			}
			else{
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
				format.setTimeZone(TimeZone.getTimeZone("UTC"));
				Date date = format.parse(field.getAsString());
				
				long maxTime = ruleField.getMaxDate().getTime();
				if(date.getTime() <= maxTime){
					qcDetails.add("{\"field\":\""+ ruleField.getName() + "\", \"status\":\"passed\", \"rule\":\"maxDateField\", \"reason\":\"lesser than " + ruleField.getMaxDate() + "\"}");
				}else{
					qcDetails.add("{\"field\":\""+ ruleField.getName() + "\", \"status\":\"failed\", \"rule\":\"maxDateField\", \"reason\":\"is not lesser than " + ruleField.getMaxDate() + "\"}");
				}
			}
		}
				
		if(ruleField.getPattern() != null){
			if(field == null || field.getAsString().isEmpty()){
				qcDetails.add("{\"field\":\""+ ruleField.getName() + "\", \"status\":\"failed\", \"rule\":\"matchPattern\", \"reason\":\"does not exist\"}");
			}else{
				if(Pattern.matches(ruleField.getPattern(), field.getAsString())){
					qcDetails.add("{\"field\":\""+ ruleField.getName() + "\", \"status\":\"passed\", \"rule\":\"matchPattern\", \"reason\": \"" + field.getAsString() + " Matched pattern " + ruleField.getPattern() + "\"}");
				}else{
					qcDetails.add("{\"field\":\""+ ruleField.getName() + "\", \"status\":\"failed\", \"rule\":\"matchPattern\", \"reason\": \"" + field.getAsString() + " Did not match pattern " + ruleField.getPattern() + "\"}");
				}
			}
		}			
	}

	private void checkCompositeRules(JsonElement data, List<JSONObject> compositeRules, Map<String, String> compositeRulePatterns, Map<String, HashMap<String, String>> compositeRuleFieldMaps, List<String> qcDetails) throws Exception{
		JsonObject doc = data.getAsJsonObject();
		for(Map.Entry<String, String> entryRule : compositeRulePatterns.entrySet()){
			String ruleExpression = entryRule.getValue();
			HashMap<String, String> fieldMaps = compositeRuleFieldMaps.get(entryRule.getKey());
			HashMap<String,  Object> fieldObjects = new HashMap<String, Object>();
			for(Map.Entry<String, String> entry : fieldMaps.entrySet()){
				String fieldName = entry.getKey();
				JsonElement field = doc.get(fieldName);
				if(field != null && field.getAsString() != null && !field.getAsString().isEmpty()){
					if(entry.getValue().equalsIgnoreCase(Constants.STRING)){
						fieldObjects.put(entry.getKey().replace("-", "_"), field.getAsString());
					} else if(entry.getValue().equalsIgnoreCase(Constants.TINT)){
						fieldObjects.put(entry.getKey().replace("-", "_"), field.getAsInt());
					}else if(entry.getValue().equalsIgnoreCase(Constants.TLONG )){
						fieldObjects.put(entry.getKey().replace("-", "_"), field.getAsLong());
					} else if(entry.getValue().equalsIgnoreCase(Constants.TFLOAT)){
						fieldObjects.put(entry.getKey().replace("-", "_"), field.getAsFloat());
					} else if(entry.getValue().equalsIgnoreCase(Constants.TDOUBLE)){
						fieldObjects.put(entry.getKey().replace("-", "_"), field.getAsDouble());
					} else if(entry.getValue().equalsIgnoreCase(Constants.TDATE)){
						SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
						format.setTimeZone(TimeZone.getTimeZone("UTC"));
						Date date = format.parse(field.getAsString());
						
						fieldObjects.put(entry.getKey().replace("-", "_"), date.getTime());
					} else{
						fieldObjects.put(entry.getKey().replace("-", "_"), field.getAsString());
					}
				} else{
					fieldObjects.put(entry.getKey().replace("-", "_"), "''");
				}
			}
			boolean result  = SampleExpressionEvaluation.evaluateExpression(fieldObjects, ruleExpression);
			if(result){
				populateQCDetailsForCompositeRules(compositeRules, entryRule, qcDetails, "passed");
			} else{
				populateQCDetailsForCompositeRules(compositeRules, entryRule, qcDetails, "failed");
			}
		}
	}
	
	private void populateQCDetailsForCompositeRules(List<JSONObject> compositeRules, Map.Entry<String, String> entryRule, List<String> qcDetails, String result) throws Exception{
		if(compositeRules != null && compositeRules.size() > 0){
			for(JSONObject compositeRule : compositeRules){
				String id = (String) compositeRule.get("id");
				if(entryRule.getKey().equals(id)){
					String rules = (String) compositeRule.get("rules");				
					JsonArray jsonArr = JsonUtil.convertToJsonArray(rules);
					Set<String> fieldNames = new HashSet<String>();
					for(int k = 0; k < jsonArr.size(); k++) {
						JsonElement jsonObj = jsonArr.get(k);
						Map<String, String> elementsMap = JsonUtil.getJsonStringMap(jsonObj.toString());
						
						String fieldName = elementsMap.get("field");						
						fieldNames.add(fieldName);
						
						//String elemlookUp = elementsMap.get("lookUp");
						//if(elemlookUp != null && elemlookUp.equals("true")){
						//	String value = elementsMap.get("value");
						//	fieldNames.add(value);
						//}
					}
					
					String qcPattern = (String) compositeRule.get("qcPattern");
					for(String fieldName : fieldNames){
						JSONObject json = new JSONObject();
						json.put("field", fieldName);
						json.put("status", result);
						json.put("rule", qcPattern);
						if(result.equals("passed")){
							json.put("reason", "Matched the pattern: " + qcPattern);	
						}else{
							json.put("reason", "Did not match the pattern: " + qcPattern);
						}
						qcDetails.add(json.toString());
					}
				}
			}
		}
	}

	private double calculateQCScore(JsonElement doc, List<String> qcDetails) throws Exception{
		int total = qcDetails.size();
		if(total == 0){
			return 100.0;
		}
		
		int passed = 0;
		double score = 0.0;
		
		for(String json : qcDetails){			
			Map<String, String> elementsMap = JsonUtil.getJsonStringMap(json);
			String status = elementsMap.get("status");
			
			if(status != null && !status.isEmpty()){
				if(status.equals("passed")){
					passed++;
				}
			}
			else{
				String msg = "The status field is not available in qc details";
				throw new Exception(msg);
			}
		}
		
		score = 100 * ((double)passed)/total;
		
		Gson gson = new Gson();
		JsonParser jp = new JsonParser();
		JsonElement details = gson.toJsonTree(qcDetails);
		JsonElement scoreJson = gson.toJsonTree(score);
		doc.getAsJsonObject().remove("qcCheckDetails");
		doc.getAsJsonObject().remove("qcscore");

		doc.getAsJsonObject().add("qcCheckDetails", details);
		doc.getAsJsonObject().add("qcscore", scoreJson);

		/* If json array is required instead of string array for qc check details, we can use the below code.
		 
		JsonArray array = new JsonArray();
		for(String detail : qcDetails){
			JsonElement response = jp.parse(detail);	
			array.add(response);
		}
		
		doc.getAsJsonObject().add("qcCheckDetails", array);
		doc.getAsJsonObject().addProperty("qcscore", score);
		*/
		
		return score;		
	}

	
	public static void main(String[] args) throws Exception{
		String json = "{\"solrHost\":\"192.168.0.166\",\"solrPort\":8983,\"datatype\":\"Well\",\"data\":[{\"key\": \"Well 10005000001000Noble\",\"WellboreUWI\": \"5000001000\",\"WellboreName\": \"Well 1000\",\"Operator\": \"Noble\",\"Field\": \"FieldD\",\"DataSource\": \"Blend\",\"Project\": \"\",\"DataSourceTypeName\": \"Blend\",\"DataSourceTypeVersion\": \"1.0\",\"datatype\": \"Well\",\"id\": \"ProjectFakeDb_BlendWell 10005000001000Noble\",\"Geometry\": \"POINT(-97.53302853884233 34.127204444620205)\",\"qcscore\": 57.142857},{\"key\": \"Well 10005000001000Noble\",\"WellboreUWI\": \"5000001000\",\"WellboreName\": \"Well 1000\",\"Operator\": \"Noble\",\"Field\": \"FieldD\",\"TD\": 5541.819,\"DataSource\": \"Alend\",\"Project\": \"\",\"DataSourceTypeName\": \"Blend\",\"DataSourceTypeVersion\": \"1.0\",\"datatype\": \"Well\",\"id\": \"ProjectFakeDb_BlendWell 10005000001000Noble\",\"Geometry\": \"POINT(-97.53302853884233 34.127204444620205)\",\"qcscore\": 57.142857}]}";
		String result = new QualityScoreService().runScoreRecords(json);
		System.out.println(result);
	}
}
