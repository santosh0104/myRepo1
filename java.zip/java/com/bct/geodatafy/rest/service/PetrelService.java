package com.bct.geodatafy.rest.service;

import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.WinHttpClients;
import org.apache.log4j.Logger;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocumentList;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.bct.geodatafy.mail.Mail;
import com.bct.geodatafy.util.FileUtil;
import com.bct.geodatafy.util.JsonUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.apache.commons.io.FilenameUtils;

@Path("/petrel")
public class PetrelService {
	static Logger logger = Logger.getLogger(PetrelService.class);

	@POST
	@Path("/projects")
	@Consumes(MediaType.APPLICATION_JSON)
	public String getProjects(String payLoad) throws IOException {
		logger.info("In service: /petrel/projects and method: getProjects");
		logger.info("Input payload is: " + payLoad);

		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);

		if (elementsMap == null || elementsMap.isEmpty()) {
			String msg = "The input payload is not a expected json string";
			logger.info(msg);
			return msg;
		}

		String jobName = elementsMap.get("jobName");
		if (jobName == null || jobName.length() < 1) {
			String msg = "Job name is null or empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;
		}

		String root = elementsMap.get("rootFolder");
		logger.info("Root folder: " + root);

		if (!Files.isDirectory(Paths.get(root))) {
			String msg = "The root folder specified " + root + " is null or not a directory.";
			logger.error(msg);
			return null;
		}
		String strRecurse = elementsMap.get("recurseFolder");
		boolean recurse;
		if (strRecurse.equalsIgnoreCase("true")) {
			recurse = true;
		} else {
			recurse = false;
		}

		String solrHost = "localhost";
		if (elementsMap.get("solrHost") != null) {
			solrHost = elementsMap.get("solrHost");
		} else {
			logger.info("solr Host is not set. Assuming localhost");
		}
		logger.info("solr host is set to: " + solrHost);

		String solrPort = "80";
		if (elementsMap.get("solrPort") != null) {
			solrPort = elementsMap.get("solrPort");
		} else {
			logger.info("solr Port is not set. Assuming 80");
		}
		logger.info("solr Port is set to: " + solrPort);

		List<String> allFiles = new ArrayList<String>();
		List<String> extensions = new ArrayList<String>();
		extensions.add(".pet");

		if (recurse) {
			FileUtil.getFilesRecurWithMatchDir(root, extensions, "ptd", allFiles);
		} else {
			FileUtil.getFilesWithMatchDir(root, ".pet", "ptd", allFiles);
		}

		if (allFiles == null || allFiles.size() < 1) {
			logger.info("getFilesWithMatchDir rturns null ");
			return null;
		}

		String strQryByJobName = "jobName:\"" + jobName + "\"";
		logger.info("strQryByJobName    " + strQryByJobName);

		Map<String, Object> solrDocMap = getSolrPetrelProjects(strQryByJobName, solrHost, solrPort);

		List<Project> projectModelList = new ArrayList<Project>();
		List<String> idList = new ArrayList<String>();
		Project projectModel;
		for (String file : allFiles) {
			File selextedFile = new File(file);
			projectModel = new Project();
			String basename = FilenameUtils.getBaseName(selextedFile.getName());
			System.out.println("File basename ------> " + basename);
			logger.info("File basename ------>: " + basename);
			projectModel.setId(jobName + "_" + file);
			projectModel.setDataType("PetrelProject");
			projectModel.setProjectName(basename);
			projectModel.setProjectPath(file);
			Date currentDate = new Date(selextedFile.lastModified());
			// DateFormat df = new SimpleDateFormat("dd/mm/yyyy hh:mm:ss a");
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			df.setTimeZone(TimeZone.getTimeZone("UTC"));
			String lstMdf = df.format(currentDate);
			// df.format(currentDate);
			projectModel.setLastModified(lstMdf);
			projectModel.setJobName(jobName);

			if (solrDocMap.containsKey(projectModel.getId())) {
				projectModel.setStatus("Existing");
				JSONObject json = (JSONObject) solrDocMap.get(projectModel.getId());
				try {
					if (json.has("lastIndexed")) {
						projectModel.setLastIndexed(json.getString("lastIndexed"));
					}
					projectModel.setIndex(new Boolean(json.getString("index")).booleanValue());
				} catch (JSONException e) {
					logger.info("JSONException: on reading solr Job Collection " + e.getMessage());
					e.printStackTrace();
					return null;
				}

			} else {
				projectModel.setStatus("New");
				projectModel.setIndex(true);
			}
			projectModelList.add(projectModel);
			idList.add(projectModel.getId());
		}

		for (Map.Entry<String, Object> entry : solrDocMap.entrySet()) {
			if (idList.contains(entry.getKey())) {
				// do nothing
			} else {
				try {
					JSONObject json = (JSONObject) entry.getValue();
					projectModel = new Project();
					projectModel.setId(json.getString("id"));
					projectModel.setDataType("PetrelProject");
					projectModel.setProjectName(json.getString("projectName"));
					projectModel.setProjectPath(json.getString("projectPath"));
					projectModel.setLastModified(json.getString("lastModified"));
					if (json.has("lastIndexed")) {
						projectModel.setLastIndexed(json.getString("lastIndexed"));
					}
					projectModel.setJobName(json.getString("jobName"));
					projectModel.setIndex(((Boolean) json.get("index")).booleanValue());
		 			projectModel.setStatus("Deleted");
					projectModelList.add(projectModel);
				} catch (JSONException e) {
					logger.info("JSONException: on reading solr Job Collection " + e.getMessage());
					e.printStackTrace();
					return null;
				}

			}

		}

		Gson gsonBuilder = new GsonBuilder().create();
		String jsonFromJavaArrayList = gsonBuilder.toJson(projectModelList);
		System.out.println(jsonFromJavaArrayList);
		logger.info("Returned File List  ------>: " + jsonFromJavaArrayList);
		return jsonFromJavaArrayList;
	}

	private Map<String, Object> getSolrPetrelProjects(String jobName, String solarHost, String solarPort) {
		// Just for debug
		Map<String, Object> solrDocMap = new HashMap<String, Object>();

		try {
			CloseableHttpClient httpClient = WinHttpClients.createDefault();
			HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
					"http://" + solarHost + ":" + solarPort + "/solr/jobs")).withHttpClient(httpClient).build();

			SolrQuery query = new SolrQuery();

			query.setQuery("*:*"); // main query
			query.set("wt", "json");
			query.addFilterQuery(jobName, "datatype:PetrelProject");
			logger.info(query.toQueryString());
			QueryResponse resp = client.query(query);
			logger.info(" QueryResponse: " + resp.getResponse().toString());

			SolrDocumentList docList = resp.getResults();
			JSONObject returnResults = new JSONObject();

			for (Map singleDoc : docList) {
				String key = (String) (new JSONObject(singleDoc)).get("id");
				solrDocMap.put(key, new JSONObject(singleDoc));

			}
			returnResults.put("docs", solrDocMap);
			System.out.println(" Response 1 : " + returnResults.toString());
			logger.info(" Response from solr qry solrDocMap" + " : " + returnResults.toString());

		} catch (Exception e) {
			logger.info("Exception during execution of Solr Query for Petrel Job   ------>: " + e.getMessage());
			e.printStackTrace();
			return solrDocMap;
		} finally {

		}
		return solrDocMap;

	}
	
	
	
	@GET
	@Path("/checkPath")
	public Response checkPeterlExePath(@QueryParam("file") String filePath) {	
	
		logger.info("In service /petrel/checkPath and in method checkPeterlExePath.");
		 try
         {  
			 logger.info(" filePath : " + filePath);
         	if(filePath != null && !filePath.isEmpty()){	
         		 logger.info(" Inside if filePath : " + filePath);
         		
					File petrelExeFile = new File(filePath);
					logger.info("Petrel File  " + petrelExeFile.getCanonicalPath());
					if(petrelExeFile == null || !petrelExeFile.isFile()){
						logger.info("Petrel File Not Found " + petrelExeFile.getCanonicalPath());
						 throw new WebApplicationException("Petrel Exe file not found " + petrelExeFile.getCanonicalPath());
					} else {
					   return Response
				                .ok("true", MediaType.TEXT_PLAIN)				              
				                .build();
					}
				
         	} else {
         		 logger.info(" filePath is emtry  " );
         		throw new WebApplicationException("Petrel Exe File Path is empty ");
         	}             
           
         }
         catch (Exception e)
         {
             throw new WebApplicationException(e.getMessage());
         }
				
	}
	
	public static void main(String args[]) throws Exception {
		String filePath = "C:/Program Files/Schlumberger/Petrel 2017/";
		
		if(filePath != null && !filePath.isEmpty()){	
     		File dir = new File(filePath);			
			if(dir == null || !dir.isDirectory()){ 
				 System.out.println("Dir Not Exist");
			} else {
				File petrelExeFile = new File(filePath + "petrel.exe");
				if(petrelExeFile == null || !petrelExeFile.isFile()){
					 System.out.println("File not exist " + petrelExeFile.getCanonicalPath());
				} else {
					 System.out.println(" Pterl exe file exist");
				}
			}
     	} else {
     		 System.out.println("File Path is empty not exist");
     	}             
	}
	
	/*
	private String getPetrelExePath( String solarHost, String solarPort) throws Exception{
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
			"http://" + solarHost + ":" + solarPort + "/solr/" + "metadata")).withHttpClient(httpClient).build();
		String petrelPath = null;
		try {		
		
				SolrQuery query = new SolrQuery();
				query.setQuery("*:*"); // main query
				query.set("wt", "json");
				query.setRows(2147483647);
				query.addFilterQuery("datatype:AppConfig");
				System.out.println(query.toQueryString());				
				QueryResponse resp = client.query(query);
				logger.info("getPetrelExePath  QueryResponse: " + resp.getResponse().toString());
				SolrDocumentList docList = resp.getResults();		
				logger.info("getPetrelExePath QueryResponse for getting path of petrel exe: " + docList.getNumFound());		
				
				for (Map singleDoc : docList) {
					JSONObject json = new JSONObject(singleDoc);
					petrelPath = (String) json.get("petrelPath");					
				}	
				return petrelPath;
			
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error("Exception during execution of Solar Query for getUserDetails   ------>: " , e);
			e.printStackTrace();		
			throw new Exception(e.getMessage());
			//return false;
		} finally {
			client.close();
			httpClient.close();

		}		
	}
 */

	

}

class Project {

	String id;
	String datatype = "PetrelProject";
	String projectName;
	String projectPath;
	boolean index;
	String lastModified = "";
	String lastIndexed = "";
	String status = "";

	public boolean isIndex() {
		return index;
	}

	public void setIndex(boolean index) {
		this.index = index;
	}

	public String getDataType() {
		return datatype;
	}

	public void setDataType(String dataType) {
		this.datatype = dataType;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	String jobName;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getProjectPath() {
		return projectPath;
	}

	public void setProjectPath(String path) {
		this.projectPath = path;
	}

	public String getLastModified() {
		return lastModified;
	}

	public void setLastModified(String lastModifiedDate) {
		this.lastModified = lastModifiedDate;
	}

	public String getLastIndexed() {
		return lastIndexed;
	}

	public void setLastIndexed(String lastIndexedDate) {
		this.lastIndexed = lastIndexedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
