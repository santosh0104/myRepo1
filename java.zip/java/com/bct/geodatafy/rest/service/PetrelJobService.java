package com.bct.geodatafy.rest.service;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.WinHttpClients;
import org.apache.log4j.Logger;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocumentList;
import org.codehaus.jettison.json.JSONObject;
import com.bct.geodatafy.job.GeodatafyJobLog;
import com.bct.geodatafy.job.GeodatafyJobRun;
import com.bct.geodatafy.util.JsonUtil;
import com.google.gson.Gson;
import com.google.gson.JsonElement;

@Path("/jobs/petrel/indexer")
public class PetrelJobService {
	static Logger logger = Logger.getLogger(PetrelJobService.class);
	public static final String JOB_TYPE = "PetrelIndexer";
	public static final int COMMIT_SIZE = 10;

	@POST
	@Path("/create")
	@Consumes(MediaType.APPLICATION_JSON)
	public String createPetrelIndexJob(String payLoad, @Context HttpServletRequest request) throws Exception {
		logger.info("In service: /jobs/petrel/indexer/create and method: createPetrelIndexJob");

		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);

		String jobName = elementsMap.get("jobName");
		if (jobName == null || jobName.length() < 1) {
			String msg = "Job Name is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;
		}

		String jobData = elementsMap.get("jobData");
		if (jobData == null || jobData.length() < 1) {
			String msg = "Job Data is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;
		}

		logger.info("Creating the Petrel index job: " + jobName + " ");
		// Logic to create a job in solr
		return "Done";
	}

	@PUT
	@Path("/create")
	@Consumes(MediaType.APPLICATION_JSON)
	public String updatePetrelIndexJob(String payLoad, @Context HttpServletRequest request) throws Exception {
		logger.info("In service: PUT /jobs/petrel/indexer/create and method: updatePetrelIndexJob");

		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);

		String jobName = elementsMap.get("jobName");
		if (jobName == null || jobName.length() < 1) {
			String msg = "Job Name is null or empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;
		}

		String jobData = elementsMap.get("jobData");
		if (jobData == null || jobData.length() < 1) {
			String msg = "Job Data is null or empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;
		}

		logger.info("Updating the open petrel index job: " + jobName + " ");
		// Logic to update the job in solr
		return "Done";
	}

	@POST
	@Path("/run")
	@Consumes(MediaType.APPLICATION_JSON)
	public String runPetrelIndexJob(String payLoad, @Context HttpServletRequest request) throws Exception {
		logger.info("In service: /jobs/petrel/indexer/run and method: runPetrelIndexJob");

		logger.info("Input payload is: " + payLoad);
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);
		if (elementsMap == null || elementsMap.isEmpty()) {
			String msg = "The input payload is not a expected json string";
			logger.info(msg);
			return msg;
		}

		logger.info("Number of elements in input json : " + elementsMap.size() + " ");
		debug(elementsMap);

		String jobName = elementsMap.get("jobName");
		if (jobName == null || jobName.length() < 1) {
			String msg = "Job name is null or empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;
		}
		
		String jobType = elementsMap.get("jobType");
		if (jobType == null || jobType.length() < 1) {
			String msg = "Job jobType is null or empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;
		}


		String jobData = elementsMap.get("jobData");
		if (jobData == null || jobData.length() < 1) {
			String msg = "Job Data is null or empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;
		}

		logger.info("Starting the petrel index job: " + jobName + " ");

		String givenLogLevel = elementsMap.get("logLevel");
		String logLevel = GeodatafyJobLog.INFO;
		if (givenLogLevel != null && givenLogLevel.length() > 0) {
			logLevel = givenLogLevel;
		}

		Map<String, JsonElement> jdm = JsonUtil.getJsonElementMap(jobData);

		String solrCollectionName = "data";
		if (jdm.get("solrCollectionName") != null) {
			solrCollectionName = jdm.get("solrCollectionName").getAsString();
		} else {
			logger.info("solrCollectionName is not set. Assuming documents");
		}
		logger.info("solr Collection Name is set to: " + solrCollectionName);

		String solrHost = "localhost";
		if (jdm.get("solrHost") != null) {
			solrHost = jdm.get("solrHost").getAsString();
		} else {
			logger.info("solr Host is not set. Assuming localhost");
		}
		logger.info("solr host is set to: " + solrHost);

		String solrPort = "80";
		if (jdm.get("solrPort") != null) {
			solrPort = jdm.get("solrPort").getAsString();
		} else {
			logger.info("solr Port is not set. Assuming 80");
		}
		logger.info("solr Port is set to: " + solrPort);

		String onlyNew = "true";
		if (jdm.get("newAndModifiedOnly") != null) {
			onlyNew = jdm.get("newAndModifiedOnly").getAsString();
		} else {
			logger.info("newAndModifiedOnly is not set. Assuming newAndModifiedOnly as true");
		}
		logger.info("newAndModifiedOnly is set to: " + onlyNew);
		String petrelLicenseProfile = "Default";
		String petrelPath = "C:\\Program Files\\Schlumberger\\Petrel 2017\\petrel.exe";

		JSONObject jsonRestObj = getPetrelProfile(solrHost, solrPort, petrelLicenseProfile, petrelPath);
		petrelLicenseProfile = (String) jsonRestObj.get("petrelLicenseProfile");

		petrelPath = (String) jsonRestObj.get("petrelPath");

		String strPetrelJobToExecute = "\"" + petrelPath + "\"" + " /nosplashscreen /nodialogs -quiet -licensePackage  " + petrelLicenseProfile
				+ "  -exec \"Geodatafy.ScanManager,GeodatafyPetrelIndexer\" BeginScan -soption \"ScanManager=JobName=" + jobName
				+ "\" -soption \"ScanManager=SolrHost=" + solrHost + "\" -soption \"ScanManager=SolrPort=" + solrPort
				+ "\" -soption \"ScanManager=SolrCollection=" + solrCollectionName
				+ "\" -soption \"ScanManager=JobType=" + jobType
				+ "\" -soption \"ScanManager=LogLevel=" + givenLogLevel + "\" -soption \"ScanManager=OnlyNew=" + onlyNew
				+ "\"";

		logger.warn("Petrel EXE command to run " + strPetrelJobToExecute);
	
		try {
			
			Runtime rn = Runtime.getRuntime();
			logger.info("after getRuntime : ");
			Process p = rn.exec(strPetrelJobToExecute);
			logger.info("after Process exec : ");
			StreamGobbler errorGlobber = new StreamGobbler(p.getErrorStream(), "CMDTOOL-E");
			StreamGobbler outputGlobber = new StreamGobbler(p.getInputStream(), "CMDTOOL-O");
			logger.info("before Strean start to read : ");
			errorGlobber.start();
			outputGlobber.start();
			int exitVal = p.waitFor();
			logger.info("Process ExitValue: " + exitVal);
			if(exitVal==0) {
				return "Done";
			} else {
				String errMsg = "Issue in execution of exe file";
				return errMsg;
			
			}

		} catch (Exception e) {
			String errMsg = "Exeception during execution of exe file";
			logger.error(errMsg);
			logger.error("The Error is " + e.getMessage());
			e.printStackTrace();
			return errMsg;
		}

	}

	@GET
	@Path("/runs")
	@Produces(MediaType.APPLICATION_JSON)
	public String getAllPetrelIndexJobRuns() throws Exception {
		logger.info("In service: /jobs/petrel/indexer/runs and method: getAllPetrelIndexJobRuns");

		// Query solr to get all the job runs and return as json
		// Use the same JobRun object
		List<GeodatafyJobRun> runs = new ArrayList<GeodatafyJobRun>();
		Gson gson = new Gson();
		gson.toJson(runs);
		return "";
	}

	@POST
	@Path("/runs/get/statistics")
	@Consumes(MediaType.APPLICATION_JSON)
	public String getPetrelIndexJobStatistics(String payLoad) throws Exception {
		logger.info("In service: /jobs/Petrel/indexer/runs/get/statistics and method: getPetrelIndexJobStatistics");
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);
		elementsMap.get("jobName");
		elementsMap.get("jobID");

		// Create a html content with the statistics
		return "";
	}

	@POST
	@Path("/runs/get/log")
	public String getPetrelIndexJobLog(String payLoad) throws Exception {
		logger.info("In service: /jobs/Petrel/indexer/runs/get/log and method: getPetrelIndexJobLog");

		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);
		elementsMap.get("jobName");
		elementsMap.get("jobID");

		// Create a html content with the log file
		return "";
	}

	private JSONObject getPetrelProfile(String solarHost, String solarPort, String petrelLicenseProfile,
			String petrelPath) {

		try {
			CloseableHttpClient httpClient = WinHttpClients.createDefault();
			HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
					"http://" + solarHost + ":" + solarPort + "/solr/metadata")).withHttpClient(httpClient).build();
			SolrQuery query = new SolrQuery();
			query.set("q", "*:*");
			query.set("wt", "json");
			query.set("fq", "datatype:AppConfig");
			QueryResponse resp = client.query(query);
			System.out.println(" Response: " + resp.getResponse().toString());
			logger.info(" get petrelProfile Query Response: " + resp.getResponse().toString());

			SolrDocumentList docList = resp.getResults();
			// JSONObject returnResults = new JSONObject();
			JSONObject generalObj = null;
			for (Map singleDoc : docList) {
				generalObj = new JSONObject(singleDoc);
				petrelLicenseProfile = (String) generalObj.get("petrelLicenseProfile");
				petrelPath = (String) generalObj.get("petrelPath");
			}
			System.out.println(" petrelLicenseProfile : " + petrelLicenseProfile);
			System.out.println(" petrelPath : " + petrelPath);
			logger.info(" petrelLicenseProfile: " + petrelLicenseProfile);
			logger.info(" petrelPath: " + petrelPath);

			return generalObj;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {

		}

	}


	private void debug(Map<String, String> elementsMap) {
		// Just for debug
		for (Map.Entry<String, String> entry : elementsMap.entrySet()) {
			String key = entry.getKey();
			String value = entry.getValue();
			logger.info("Key: " + key + " Value: " + value);
		}
	}

	public static void main(String[] args) throws Exception {
		String filePath = "C://cmdTes.bat";
		File fileP = new File(filePath);
		try {
			String path = "cmd /c start C://cmdTes.bat";
			String abc = "rundll32 url.dll,FileProtocolHandler ";

			// Process p = Runtime.getRuntime().exec(abc + fileP.getCanonicalPath());
			Runtime rn = Runtime.getRuntime();
			Process p = rn.exec(fileP.getCanonicalPath());
			StreamGobbler errorGlobber = new StreamGobbler(p.getErrorStream(), "CMDTOOL-E");
			StreamGobbler outputGlobber = new StreamGobbler(p.getInputStream(), "CMDTOOL-O");
			errorGlobber.start();
			outputGlobber.start();
			// p.waitFor();

			InputStream in = p.getInputStream();
			ByteArrayOutputStream baos = new ByteArrayOutputStream();

			int c = -1;
			while ((c = in.read()) != -1) {
				baos.write(c);
			}

			String response = new String(baos.toByteArray());
			System.out.println("Response From Exe : " + response);

		} catch (Exception e) {
			logger.error("Exeception occured during execution of exe file");
			e.printStackTrace();
		}
		String solrHost = "192.168.5.92";
		String solrPort = "8983";
		String jobName = "petrelJopb";
		String solrCollectionName = null;
		String onlyNew = "true";
		String givenLogLevel = "INFO";

		String petrelLicenseProfile = "Default";
		String petrelPath = "C:\\Program Files\\Schlumberger\\Petrel 2017\\petrel.exe";
		JSONObject jsonRestObj = new PetrelJobService().getPetrelProfile(solrHost, solrPort, petrelLicenseProfile,
				petrelPath);
		petrelLicenseProfile = (String) jsonRestObj.get("petrelLicenseProfile");
		System.out.println(" petrelLicenseProfile ***** -----> " + petrelLicenseProfile);
		petrelPath = (String) jsonRestObj.get("petrelPath");
		System.out.println(" petrelPath *** -----> " + petrelPath);

		String strPetrelJobToExecute = "\"" + petrelPath + "\"" + " -licensePackage  " + petrelLicenseProfile
				+ "  -exec \"Geodatafy.ScanManager,SolrIndexer\" BeginScan -soption \"ScanManager=JobName=" + jobName
				+ "\" -soption \"ScanManager=SolrHost=" + solrHost + "\" -soption \"ScanManager=SolrPort=" + solrPort
				+ "\" -soption \"ScanManager=SolrCollection=" + solrCollectionName
				+ "\" -soption \"ScanManager=LogLevel=" + givenLogLevel + "\" -soption \"ScanManager=OnlyNew=" + onlyNew
				+ "\"";

		System.out.println(" strPetrelJobToExecute -----> " + strPetrelJobToExecute);
	}
}

class StreamGobbler extends Thread {
	InputStream is;
	String type;
	static Logger logger = Logger.getLogger(StreamGobbler.class);

	StreamGobbler(InputStream is, String type) {
		logger.info("reader constructor");
		this.is = is;
		this.type = type;
	}

	public void run() {
		InputStreamReader isr = null;
		BufferedReader br = null;
		try {
			logger.info("run inside");
			isr = new InputStreamReader(is);
			br = new BufferedReader(isr);
			String line = null;
			while ((line = br.readLine()) != null) {
				logger.info(type + ">" + line);
				System.out.println(type + ">" + line);
			}
			 isr.close();
			 br.close();
		} catch (Exception ioe) {
			ioe.printStackTrace();
		} finally {

		}
	}
}
