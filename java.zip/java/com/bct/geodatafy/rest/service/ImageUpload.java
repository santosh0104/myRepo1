package com.bct.geodatafy.rest.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.FileNameMap;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.activation.MimetypesFileTypeMap;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

@Path("/upload")
public class ImageUpload {
	static Logger logger = Logger.getLogger(LicenseService.class);	
	
	@GET
	@Path("/downloadFile")
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	public Response downloadFile(String fileName) {
		File file = new File(fileName);
	    return Response.ok(file, MediaType.APPLICATION_OCTET_STREAM)
	        .header("Content-Disposition", "attachment; filename=\"" + file.getName() + "\"")
	        .build();
	}

	
	@POST
	@Path("/file")
	
	public byte[] getFile(String filePath) throws Exception{ 
		//Input payload contains all the job and job data details
		
		byte[] fileContent = null;
		
		try {
			
			// create file object
			File file = new File(filePath);
			System.out.println(file.getAbsolutePath());
			System.out.println(file.toURL());
			// initialize a byte array of size of the file
			fileContent = new byte[(int) file.length()];
			FileInputStream inputStream = null;
			try {
			// create an input stream pointing to the file
			inputStream = new FileInputStream(file);
			// read the contents of file into byte array
			inputStream.read(fileContent);
			} catch (IOException e) {
			throw new IOException("Unable to convert file to byte array. " + e.getMessage());
			} finally {
			// close input stream
			if (inputStream != null) {
			inputStream.close();
			}
			}
			File file1 = new File(filePath);
            java.nio.file.Path path = Paths.get(filePath);
            byte[] data = Files.readAllBytes(file1.toPath());
            
			return data;

			
		
		} catch (Exception e) {
			String errMsg = "Exception during execution of download the file";
			logger.error(errMsg);
			logger.error("The Error is " + e.getMessage());
			e.printStackTrace();
			return null;
		}

		
		
	}
	
	public static void main(String[] args) throws Exception {
		ImageUpload im = new ImageUpload();
		System.out.println(im.getFile("\\\\192.168.5.92\\vaish\\good2\\Dinesh.pdf"));
		System.out.println(im.getFile("D:\\A&R\\test.txt"));
		String filePath = "//192.168.5.92/vaish/good2/Dinesh.pdf";
		 String fileName = filePath.substring(filePath.lastIndexOf("/")+1);
		 MimetypesFileTypeMap mimetypesFileTypeMap=new MimetypesFileTypeMap();
		 System.out.println( mimetypesFileTypeMap.getContentType(fileName));
		// URL url1 = new URL("file://192.168.2.231/AutoBuild/StaticContents/solr/server/contexts/solr-jetty-context.xml");
		 URL url1 = new URL("file:///D:/Nithya/clay/177044018600.las");
	File file = new File(url1.getPath());	 
// File file = new File("//192.168.2.231/AutoBuild/StaticContents/solr/server/contexts/solr-jetty-context.xml");
		 String url = file.getAbsolutePath();
		 FileNameMap fileNameMap = URLConnection.getFileNameMap();
		 String mime = fileNameMap.getContentTypeFor(file.toURI().toString());
		 System.out.println(mime);

	}

	@POST
	@Path("/image")
	@Consumes({MediaType.MULTIPART_FORM_DATA})
	public Response uploadImageFile(  @FormDataParam("file") InputStream fileInputStream,
	                                @FormDataParam("file") FormDataContentDisposition fileMetaData) throws Exception
	{
	    String UPLOAD_PATH = "";
	    //String programDataDir = System.getenv("ProgramFiles"); 
	    WindowsService w = new WindowsService();
	    String strGDInsPath = w.getGDInstallationPath();
		logger.info("ProgramFiles dir received from environment variable ProgramFiles is: " + strGDInsPath);
		
		if(strGDInsPath != null && !strGDInsPath.isEmpty()){				
				UPLOAD_PATH = strGDInsPath + "\\assets\\images\\";
		} else {
			logger.error("Error while getting Geodatafy installation path : " );
			 throw new WebApplicationException("Error while getting Geodatafy installation path. Please try again !!");
		}
		logger.info("Image Upload Path is: " + UPLOAD_PATH);

	    try
	    {
	        int read = 0;
	        byte[] bytes = new byte[1024];
	 
	        OutputStream out = new FileOutputStream(new File(UPLOAD_PATH + fileMetaData.getFileName()));
	        while ((read = fileInputStream.read(bytes)) != -1)
	        {
	            out.write(bytes, 0, read);
	        }
	        out.flush();
	        out.close();
	    } catch (IOException e)
	    {
	    	
	    	logger.error("Error while uploading file : " + e.getMessage());
	        throw new WebApplicationException("Error while uploading file. Please try again !!");
	    }
	    return Response.ok("Data uploaded successfully !!").build();
	}
	
	
	
}
