package com.bct.geodatafy.rest.service;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.bct.geodatafy.util.EnvUtil;
import com.bct.geodatafy.util.FileUtil;
import com.bct.geodatafy.util.JsonUtil;
import com.bct.geodatafy.util.RestUtil;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

//import com.bct.geodatafy.theme.ThemeDao;

@Path("/theme")
public class ThemeService {
	static Logger logger = Logger.getLogger(ThemeService.class);
	static final String GEODATAY_CSS = "geodatafy";
	

	@POST
	@Path("/set")
	@Consumes(MediaType.APPLICATION_JSON)
	public String set(String payLoad) throws Exception{				
		
		logger.info("The input payload is: " + payLoad);
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);		
		if(elementsMap == null || elementsMap.isEmpty()){
			String msg = "The input payload is not a expected json string";
			logger.info(msg);
			return msg;
		}
		
		logger.info("Number of elements in input json : " + elementsMap.size() + " ");		
		
		String solrURL = elementsMap.get("solrUrl");	
		String cssFileName = elementsMap.get("cssFileName");
		//String htmlFileName = elementsMap.get("htmlFileName");
		//String cssPath = elementsMap.get("cssPath");
		logger.info("Given Parameters: solrUrl: " + solrURL + "and cssFileName: " + cssFileName);
		
		String result = RestUtil.getURLResponse(solrURL);		
		logger.info("Called the URL for theme " + solrURL);
		logger.info("The result from solr query for themes : " + result);						
						
		JsonArray elements = JsonUtil.getDocElementsArray(result);
		
		if(elements == null){
			String msg = "No doc element returned from solr for the given theme name.";
			logger.info(msg + "Returning...");
			return msg;
		}
		
		for (JsonElement jsonElement : elements) {
			logger.debug("The theme JSON element is " + jsonElement.getAsJsonObject());
			JsonObject docObj = jsonElement.getAsJsonObject();
			
			JsonElement themeName = docObj.get("name");
			JsonElement themeID = docObj.get("id");
			JsonElement themeDatatype = docObj.get("datatype");
			JsonElement themeDetails = docObj.get("theme");
			logger.debug("Theme name is " + themeName);
			logger.debug("Theme datatype is " + themeDatatype);
			logger.debug("Theme id is " + themeID);
			logger.debug("Theme detail string is " + themeDetails.getAsString());
			
			JsonArray themeArray = JsonUtil.convertToJsonArray(themeDetails.getAsString());
			if(themeArray != null){
				String cssString = getCSSFileContents(themeArray);
				String cssPath = "config\\themecss"; 
				//String programData = System.getenv("GD_DATA_PATH");
				String programData = EnvUtil.getGDDataPath();
				if(programData != null && !programData.isEmpty()){
					cssPath = 	programData + File.separator + cssPath;
				}				   
				FileUtil.writeToCSSFile(cssString, cssPath, cssFileName);
				FileUtil.writeToCSSFile(cssString, cssPath, GEODATAY_CSS);
			}
			else{
				String msg = "Theme theme detail is null"; 
				logger.info(msg + "Returning...");
				return msg;
			}
		}					
		//FileUtil.updateHtmlFile(htmlFileName,cssFileName);
		return "Success";
	}
	
	
	private String getCSSFileContents(JsonArray cssElements){
		StringBuilder sb = new StringBuilder();
		if(cssElements != null){
			sb = new StringBuilder();
			for (JsonElement cssElement : cssElements) {
				logger.debug("Theme element is " + cssElement);
				JsonObject css = cssElement.getAsJsonObject();				
				String cssColor = css.get("color").getAsString();
				String cssProperty = css.get("property").getAsString();
				String cssClassName = css.get("classname").getAsString();
				sb.append("." + cssClassName + "\n\r{\n\r" + cssProperty + ":" + cssColor + "\n\r}\r\n");												
			}				
			logger.debug("The file contents are: \n" + sb.toString());
			logger.info("Read the theme details and created the file contents.");
		}
		return sb.toString();
	}
}
