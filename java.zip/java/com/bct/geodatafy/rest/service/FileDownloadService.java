package com.bct.geodatafy.rest.service;


import java.io.File;
import java.io.IOException;
import java.net.FileNameMap;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

import javax.activation.MimetypesFileTypeMap;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;


import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;



@Path("/download")
public class FileDownloadService
{
	static Logger logger = Logger.getLogger(FileDownloadService.class);	
    @GET
    @Path("/getFile")
    public Response downloadFile(@QueryParam("file") String filePath)
    
    {
    	logger.error("File Path : " + filePath);
        StreamingOutput fileStream =  new StreamingOutput()
        {
            @Override
            public void write(java.io.OutputStream output) throws IOException, WebApplicationException
            {
                try
                {
                	String fileUNCPath = filePath;
                	if (filePath.startsWith("file://")) {
                		// do nothing
                	} else {
                		if (filePath.startsWith("file:/")) {
                			fileUNCPath = fileUNCPath.replace("file:/", "file:///");
                		}
                	}
                	
                	URL url1 = new URL(fileUNCPath.replace("%", "%25").replace("+", "%2B").replace("#", "%23"));
                	File file = new File(URLDecoder.decode(url1.getPath(), "UTF-8"));
                   
                    byte[] data = Files.readAllBytes(file.toPath());
                    output.write(data);
                    output.flush();
                }
                catch (Exception e)
                {
                	logger.error("Exception in getFile " , e);
                    throw new WebApplicationException("File Not Found !!");
                }
            }
        };
       String fileName = filePath.substring(filePath.lastIndexOf("/")+1);
        String attach = "inline; filename = " + fileName;
      
       
	//	FileNameMap fileNameMap = URLConnection.getFileNameMap();
		//String mime = fileNameMap.getContentTypeFor(filePath);
        MimetypesFileTypeMap fileTypeMap = new MimetypesFileTypeMap();
        String mime = fileTypeMap.getContentType(filePath);
		//String mime = getContentTypeByFileName(filePath);
        return Response
                .ok(fileStream,mime)
                .header("content-disposition",attach)
                .build();
    }
    
   
    	private   String encodeURLStr(String str) {
		try {
		//str = URIUtil.encodeQuery(str).replace("&", "%26").replace("+", "%2B");
		str = URLEncoder.encode(str.replace("+", "%2B").replace("&", "%26"), "UTF-8").replace("+", "%20");
		//str = URLEncoder..encode(str, "UTF-8").replace("+", "%20");
	} catch(Exception e) {
		return null;
	}
	return str;
	
}

    
    public static void main(String args[]) throws Exception{
    	FileDownloadService f = new FileDownloadService();
    	try {
    		String str = "file:/D:/A&R/a+b/test+=test.txt";
    	 URL url1 = new URL(str.replace("%", "%25").replace("+", "%2B"));
    		File file = new File(URLDecoder.decode(url1.getFile(),"UTF-8").replace("%2B", "+"));
     	//File file = new File("D:\\New folder\\doctest # Copy.txt");
    		 System.out.println(f.encodeURLStr("file:///D:/A&R/a+b/test+= test.txt").replace("%2B", "+"));
        System.out.println(URLDecoder.decode(url1.getFile(),"UTF-8"));
         byte[] data = Files.readAllBytes(file.toPath());
         System.out.println("****");
    	} catch(Exception e ) {
    		e.printStackTrace();
    	}
    	
    	    			
    }
		
}