package com.bct.geodatafy.rest.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.util.TimeZone;
import javax.servlet.http.HttpServletRequest;

import javax.ws.rs.Consumes;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;


import org.apache.http.client.ClientProtocolException;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.WinHttpClients;
import org.apache.log4j.Logger;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.bct.geodatafy.cart.AlertExecution;
import com.bct.geodatafy.cart.AlertMessage;
import com.bct.geodatafy.cart.Cart;
import com.bct.geodatafy.cart.CartAlertJob;
import com.bct.geodatafy.cart.CartDetails;
import com.bct.geodatafy.job.GeodatafyJobLog;
import com.bct.geodatafy.job.alert.AlertJob;
import com.bct.geodatafy.job.alert.AlertJobData;
import com.bct.geodatafy.job.alert.AlertJobStatistics;
import com.bct.geodatafy.job.document.DocumentIndexJob;
import com.bct.geodatafy.job.qc.project;
import com.bct.geodatafy.mail.Mail;
import com.bct.geodatafy.mail.MailData;
import com.bct.geodatafy.util.EnvUtil;
import com.bct.geodatafy.util.GeoUtil;
import com.bct.geodatafy.util.JsonUtil;
import com.bct.geodatafy.util.SecurityUtil;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;

/**
 * 
 * @author LG111891
 *  
 */

@Path("/jobs/cart/alert")
public class AlertJobService {
	static Logger logger = Logger.getLogger(AlertJobService.class);
	public static final String JOB_TYPE = "AlertJobService";
	public static final int COMMIT_SIZE = 10;
	public static final String JOBS_COLLECTION = "jobs";	
	 
	@POST
	@Path("/run")
	@Consumes(MediaType.APPLICATION_JSON)
	public String runAlertJob(String payLoad
			, @Context HttpServletRequest request
			) throws Exception{		
		logger.info("In service: /jobs/cart/alert and method: runAlertJob");	
		String retMsg = null;
		
		System.out.println("Input payload is: " + payLoad);
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);	
		if(elementsMap == null || elementsMap.isEmpty()){
			retMsg = "The input payload is not a expected json string";
			logger.error(retMsg);
			return retMsg;
		}
		
		logger.info("Number of elements in input json : " + elementsMap.size() + " ");		
	
				
		String jobName = elementsMap.get("jobName");
		if(jobName == null || jobName.length() < 1){
			retMsg = "Job name is null or empty";
			logger.error(retMsg + " Returning without doing anything.");
			return retMsg;			
		}
		
		String jobType = elementsMap.get("jobType");
		if(jobType == null || jobType.length() < 1){
			retMsg = "Job Type is null or empty";
			logger.error(retMsg + " Returning without doing anything.");
			return retMsg;			
		}
		
		String jobData = elementsMap.get("jobData");
		if(jobData == null || jobData.length() < 1){
			retMsg = "Job Data is null or empty";
			logger.error(retMsg + " Returning without doing anything.");
			return retMsg;			
		}

		logger.info("Starting the Alert Job job: " + jobName + " ");
		AlertJob indexJob = new AlertJob();
		indexJob.setJobName(jobName);
		indexJob.setJobType(jobType);
		
		String solrDocID = jobName + "_" + Long.toString(System.currentTimeMillis());
		indexJob.setSolrDocID(solrDocID);
		String logFileName = "logs\\" + solrDocID + ".log";
		
		//String programDataDir = System.getenv("GD_LOG_PATH");
		String programDataDir = EnvUtil.getGDLogPath();
		logger.info("ProgramData dir received from environment variable ProgramData is: " + programDataDir);
		
		if(programDataDir != null && !programDataDir.isEmpty()){				
				String logDir = programDataDir + "\\logs\\indexers\\custom\\" + jobType + "\\";
				logFileName = logDir + solrDocID + ".log";				
				File dir = new File(logDir);
				if(dir == null || !dir.isDirectory()){ 
					dir.mkdir();
				}
		}

		String givenLogLevel = elementsMap.get("logLevel");
		String logLevel = GeodatafyJobLog.INFO;
		if(givenLogLevel != null && givenLogLevel.length() > 0){
			logLevel = givenLogLevel;	
		}
		
		GeodatafyJobLog jobLogger = new GeodatafyJobLog(logFileName, logLevel);
		indexJob.setLogFileName(logFileName);
		
		jobLogger.info("Input Payload", payLoad);
		jobLogger.info("Job Data from Input", jobData);

		AlertJobData indexJobData = constructJobData(jobData);
		
		indexJob.setJobDataString(jobData);
		indexJob.setJobData(indexJobData);
		indexJob.setJobStatus(DocumentIndexJob.JOB_RUNNING);
		long startTime = System.currentTimeMillis();
		indexJob.setStartTime(GeodatafyJobLog.getCurrentDateTime(startTime));		
		indexJob.setEndTime("");	
		
		String protocol = null;
		if(protocol == null || protocol.isEmpty()){
			protocol = "http";
		}			

		String baseSolrURL = protocol + "://" + indexJobData.getSolrHost() + ":" + indexJobData.getSolrPort()+ "/solr";
		try {
			executeAndSendAlert(startTime, indexJob, baseSolrURL, jobLogger);			
			logger.info("Uploading the job run data after Alert Execution." + indexJob.getJobStatus());
			uploadJobRunData(baseSolrURL, indexJob, jobLogger);
		} catch(Exception e) {
				String msg = e.getMessage();
				logger.error("Exception during scheduling the Alert for the cart   ", e);
				indexJob.setJobStatus(DocumentIndexJob.JOB_ERROR);
				indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
				return msg;
		}		
		
		return "Alert scheduled successfully";
	}
	
	private void executeAndSendAlert(long jobStartTime, AlertJob indexJob, String baseSolrURL, GeodatafyJobLog jobLogger) {
		try {
			jobLogger.info("Getting the Cart Details of the Alert  ", "");
			ArrayList<CartDetails> cartDetailsList = getCartDetailsOfAlert(indexJob, jobLogger);
			List<AlertJobStatistics> statistics = getJobStatistics(cartDetailsList, 0, 	indexJob,  jobLogger);
			indexJob.setStatistics(statistics);
			Cart cart = null;
			if(cartDetailsList != null && cartDetailsList.size()>0) {
				jobLogger.info("Number of DataTypes in the Cart  ", " " + cartDetailsList.size());
				logger.info("Uploading the job run data before Alert Execution.");
				jobLogger.info("Uploading the job run data before Alert Execution. ", "");				
				uploadJobRunData(baseSolrURL, indexJob, jobLogger);								
				jobLogger.info("Getting the Cart Object  ", "");
				cart = getCart(indexJob, jobLogger );
				if (cart!= null) {
					jobLogger.info("Preparing to check any Cart Items Modified ", " " );
					ArrayList<AlertExecution> alertExecutionList = CheckForModification(jobStartTime, indexJob, cartDetailsList, cart, jobLogger);									
				} else {
					logger.error("Exception during querying Cart for the Alert");
					jobLogger.info("Exception during querying Cart for the Alert ", "");
					indexJob.setJobStatus(DocumentIndexJob.JOB_ERROR);
					indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
						
				}
			} else {
				logger.error("Exception during getting CartDetails for the Alert");
				jobLogger.info("Exception during getting CartDetails for the Alert ", "");
				indexJob.setJobStatus(DocumentIndexJob.JOB_ERROR);
				indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
					
			}
		} catch(Exception e) {
			logger.error("Exception during execution of ExecuteAndSendAlert mehod   ------>: " ,  e);
			jobLogger.info("Exception during execution of ExecuteAndSendAlert mehod  ", "");
			indexJob.setJobStatus(DocumentIndexJob.JOB_ERROR);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());	
			jobLogger.info("Exception occuered ", e.getMessage());
			e.printStackTrace();			
		}
		
	}
	
	
	public static void main(String args[]) throws Exception {
	}
	
	private Cart getCart(AlertJob indexJob, GeodatafyJobLog jobLogger)  throws Exception {		
		
		Cart cartObj = new Cart();
		AlertJobData alertJobData = indexJob.getJobData();
		try {
			CloseableHttpClient httpClient = WinHttpClients.createDefault();
			HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
					"http://" + alertJobData.getSolrHost() + ":" + alertJobData.getSolrPort() + "/solr/" + "cart")).withHttpClient(httpClient).build();

			SolrQuery query = new SolrQuery();
			query.setQuery("*:*"); // main query
			query.set("wt", "json");
			query.setRows(2147483647);			
			String strQryByAlertId = "id:" + alertJobData.getCartId();
			logger.info("strQryBy ----> " +   strQryByAlertId);			
			//query.setParam("fl", "id,last_indexed_datetime");
			query.addFilterQuery(strQryByAlertId, "datatype:dataCart");
			logger.info(query.toQueryString());			
			QueryResponse resp = client.query(query);
			logger.info(" QueryResponse: " + resp.getResponse().toString());			
			SolrDocumentList docList = resp.getResults();
					
			for (Map singleDoc : docList) {
				JSONObject json = new JSONObject(singleDoc);
				cartObj.setId((String) json.get("id"));
				cartObj.setCartName((String) json.get("cartName"));
				cartObj.setCreatedDate((Date) json.get("createdDate"));
				cartObj.setActive((boolean) json.get("active"));
				cartObj.setUserName((String) json.get("userName"));				
			}		
			
		} catch (Exception e) {
			logger.error("Exception during execution of Solar Query for getCart   ------>: " ,  e);
			indexJob.setJobStatus(DocumentIndexJob.JOB_ERROR);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
			indexJob.getStatistics().get(0).setFailed(indexJob.getStatistics().get(0).getFailed() +1);			
			e.printStackTrace();
			throw e;			
		} finally {

		}				
		return cartObj;

	}
	
	

	
	private ArrayList<CartDetails> getCartDetailsOfAlert(AlertJob indexJob, GeodatafyJobLog jobLogger)  throws Exception {		
		
		ArrayList<CartDetails> cartDetailsObjList = new ArrayList<CartDetails>();
		AlertJobData alertJobData = indexJob.getJobData();
		try {
			CloseableHttpClient httpClient = WinHttpClients.createDefault();
			HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
					"http://" + alertJobData.getSolrHost() + ":" + alertJobData.getSolrPort() + "/solr/" + "cart")).withHttpClient(httpClient).build();
			SolrQuery query = new SolrQuery();
			query.setQuery("*:*"); // main query
			query.set("wt", "json");
			query.setRows(2147483647);					
			String strQryByAlertId = "cartId:" + alertJobData.getCartId();
			logger.info(" strQryBy: " + strQryByAlertId);			
			query.addFilterQuery(strQryByAlertId, "datatype:dataCartDetails");
			logger.info(query.toQueryString());
			QueryResponse resp = client.query(query);
			logger.info(" QueryResponse: " + resp.getResponse().toString());		
			SolrDocumentList docList = resp.getResults();
			
			for (Map singleDoc : docList) {
				CartDetails cartDetailsObj = new CartDetails();
				JSONObject json = new JSONObject(singleDoc);
				logger.info(json.toString());
				String key = (String) json.get("id");	
				String cartDataType = (String) json.get("cartDatatype");
				ArrayList<String> getDataTypeDetList = getURLAndDisplayName( alertJobData.getSolrHost() ,  alertJobData.getSolrPort(), cartDataType );
				if(json.has("selectedValues")) {
					cartDetailsObj.setId(key);
					cartDetailsObj.setCartId((String) json.get("cartId"));
					cartDetailsObj.setDatatype((String) json.get("datatype"));
					cartDetailsObj.setColumnName((String) json.get("columnName"));
					cartDetailsObj.setCartDatatype((String) json.get("cartDatatype"));
					cartDetailsObj.setDisplayName(getDataTypeDetList.get(0));//fromQc
					boolean isFromQc = (boolean) json.get("fromQc");					
					if (isFromQc) {
						cartDetailsObj.setDisplayName(getDataTypeDetList.get(0) +  " (Sent from QC)");//fromQc
					} 
					
					cartDetailsObj.setFromQc((boolean) json.get("fromQc"));
					cartDetailsObj.setCartCollectionUrl(getDataTypeDetList.get(1));	
					cartDetailsObj.setCartSelection((String) json.get("cartSelection"));
					
					ArrayList<String> selectedValuesStr = (ArrayList<String>)json.get("selectedValues");
					cartDetailsObj.setSelectedValues(selectedValuesStr);
					cartDetailsObjList.add(cartDetailsObj);
					
				}
				if(json.has("selectedCriteria")) {
					cartDetailsObj.setId(key);
					cartDetailsObj.setCartId((String) json.get("cartId"));
					cartDetailsObj.setDatatype((String) json.get("datatype"));
					cartDetailsObj.setColumnName((String) json.get("columnName"));
					cartDetailsObj.setCartDatatype((String) json.get("cartDatatype"));
					cartDetailsObj.setFromQc((boolean) json.get("fromQc"));
					cartDetailsObj.setDisplayName(getDataTypeDetList.get(0));//fromQc
					boolean isFromQc = (boolean) json.get("fromQc");					
					if (isFromQc) {
						cartDetailsObj.setDisplayName(getDataTypeDetList.get(0) +  " (Sent from QC)");//fromQc
					} 
					cartDetailsObj.setCartCollectionUrl(getDataTypeDetList.get(1));		
					cartDetailsObj.setCartSelection((String) json.get("cartSelection"));
					ArrayList<String> selectedCriteriaStr = (ArrayList<String>)json.get("selectedCriteria");
					cartDetailsObj.setSelectedCriteria(selectedCriteriaStr);
					cartDetailsObj.setMainCriteriaQry(getMainCriteriaQry(selectedCriteriaStr));
					cartDetailsObjList.add(cartDetailsObj);
					
				}				
				
			}
			
			client.close();
			httpClient.close();
		} catch (Exception e) {
			logger.info(" Exception : " + e.getMessage());
			logger.error("Exception during execution of Solar Query for getCartDetailsOfAlert   ------>: " , e);
			e.printStackTrace();
			indexJob.setJobStatus(DocumentIndexJob.JOB_ERROR);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
			indexJob.getStatistics().get(0).setFailed(indexJob.getStatistics().get(0).getFailed() +1);
			//return null;
			throw e;
		} finally {			

		}		
		
		return cartDetailsObjList;

	}
	
	
private ArrayList<String> getURLAndDisplayName(String solarHost, String solarPort, String datatype) throws Exception {		
		
		
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
				"http://" + solarHost + ":" + solarPort + "/solr/metadata" )).withHttpClient(httpClient).build();
		ArrayList<project> projList = new ArrayList<project>();
		try {
			
			SolrQuery query = new SolrQuery();
	
			query.setQuery("*:*"); // main query
			query.set("wt", "json");
			query.setRows(2147483647);
			query.addFilterQuery("datatype:datatype");
			String fqry = "name:\"" + GeoUtil.escapeQueryParams(datatype) + "\"";
			query.addFilterQuery(fqry);
							
						
			QueryResponse resp = client.query(query);
			logger.info("getProjectCollection  QueryResponse: " + resp.getResponse().toString());
			
			SolrDocumentList docList = resp.getResults();
			logger.info(" getProjectCollection QueryResponse Num : " + docList.getNumFound());
			ArrayList<String> retList = new ArrayList<String>();
			if (docList.getNumFound() > 0 ) {			
				
					SolrDocumentList docs = resp.getResults();
					String solrCoreUrl =  null;
					for(SolrDocument doc : docs) {
						
						String datatypeName = (String) doc.getFieldValue("displayName");
						solrCoreUrl = (String) doc.getFieldValue("solrCoreUrl");
						retList.add(datatypeName);
						retList.add(solrCoreUrl);
						//solrCoreUrl = solrCoreUrl.substring(solrCoreUrl.lastIndexOf("/")+1);
						
					}	
					return retList;
			} else {
				throw new Exception("Exception in getting SolrCoreURl and DisplayName of Datatype");
			}
				
			
				
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error(e.getStackTrace().toString());
			logger.info("Exception during execution of Solar Query for getURLAndDisplayName   ------>: " ,  e);
			e.printStackTrace();
			throw new Exception(e.getMessage());
			//return null;
		} finally {
			client.close();
			httpClient.close();
		}	
				
		//return null;
	
	}


	
	private String getMainCriteriaQry(ArrayList<String> selectedCriteria) throws Exception {
		 StringBuffer strMainQryBuf = new StringBuffer();
		try {
		 for (String list : selectedCriteria) {			 
			 JSONObject json = new JSONObject(list);
			 logger.info(json);
			 JSONObject aoiFilterObj = (JSONObject)json.get("aoiFilter");
			 
			 String gementryStr = null;
			 if(aoiFilterObj!=null && !aoiFilterObj.isNull("xmin")) {
				 System.out.println(aoiFilterObj);
				 Double strXmin = (Double) aoiFilterObj.get("xmin");
				 Double strYmin = (Double) aoiFilterObj.get("ymin");
				 Double strXmax = (Double) aoiFilterObj.get("xmax");
				 Double strYmax = (Double) aoiFilterObj.get("ymax");			 
				 System.out.println(strXmin.doubleValue());			 
				 gementryStr = "(Geometry:[" + strYmin  + "," + strXmin + " TO "  + strYmax + "," + strXmax + "])";
			 }
			 
			 
			 String textFiler = (String)json.get("textFilter");
			 
			 JSONArray additionalFiler = (JSONArray) json.get("additionalFilter");
			 StringBuffer strBuf = new StringBuffer();
			 if(additionalFiler.length() > 0 ) {
				 strBuf.append("( ");
				 for(int i=0; i < additionalFiler.length(); i++ ) {
					 String filterStr = (String) additionalFiler.get(i);
					 if (i== additionalFiler.length()-1) {
						 strBuf.append(filterStr).append(")");					 
					 } else {
						 strBuf.append(filterStr).append(" && ");
					 }
				 }
			 }
			 System.out.println(strBuf.toString());			
			 
			 if(textFiler == null || textFiler.isEmpty()) {				 
			 } else {
				 strMainQryBuf.append("(").append(textFiler).append(")");
			 }
			 if(gementryStr != null  && gementryStr.length() > 0) {	
				 if(strMainQryBuf.toString()!= null && strMainQryBuf.toString().length() > 0 ) {
					 strMainQryBuf.append(" && ").append(gementryStr);
										 
				 } else {
					 strMainQryBuf.append(gementryStr);
				 }
			 } 
			 if(strBuf.toString().length() > 0) {	
				 if(strMainQryBuf.toString().length() > 0 ) {
					 strMainQryBuf.append(" && ").append(strBuf.toString());										 
				 }	else {
					 strMainQryBuf.append(strBuf.toString()); 
				 }
			 } 
			 
			 System.out.println(strMainQryBuf.toString());		
		
			 return strMainQryBuf.toString();	
		 }
		} catch (Exception e) {
			logger.info(" Exception : " + e.getMessage());
			logger.error("Exception during parsing selected Criteria   ------>: " , e);
			throw e;
		}		 
		 return strMainQryBuf.toString();	
	}
	
	private void sendMailForIndexed(AlertJob indexJob, String lastAlertQueryTime,  GeodatafyJobLog jobLogger, ArrayList<AlertExecution> alertExecutionList) throws Exception{
		try {
			jobLogger.info("Preparing to Send Mail for the changed Cart Itmes  ", "");
			logger.info("************************************ MAil send");
			logger.info(indexJob.getJobData().getLastExecutionTime());
			logger.info(indexJob.getUpdatedDate());
			Cart cart = getCart(indexJob, jobLogger );
		//	SendAlertEmail(AlertExecutionList);
			MailService mailService = new MailService();
			Mail mail = getEmailServerDetails(indexJob.getJobData().getSolrHost(), indexJob.getJobData().getSolrPort());
			System.out.println(mail.getMailFrom());
			 String mailSubject =  cart.getCartName() + " Alert from Geodatafy";
			 	mail.setMailSubject(mailSubject);
			    Map < String, Object > model = new HashMap < String, Object > ();
		        model.put("cartname", cart.getCartName());
		        model.put("lastModifiedDate", lastAlertQueryTime);
		        model.put("updatedDate", indexJob.getUpdatedDate());    
		        ArrayList<MailData> mailListObj = new ArrayList<MailData>();
		        logger.info("alertExecutionList Obj " + alertExecutionList.size());
		        for(int k=0; k< alertExecutionList.size();k++ ) {
		        	 MailData maildata = new MailData();
		        	 AlertExecution alertExec = alertExecutionList.get(k);	
		        	 String linkURL = indexJob.getJobData().getLinkUrl()  + alertExec.getAlertId();
		        	 model.put("url", linkURL);
		        	 int cnt = alertExec.getSelectedValues().size();	
		        	 if (cnt > 0 ) {
		        		 maildata.setDataType(alertExec.getDisplayName());
		        		 maildata.setCount(Integer.valueOf(cnt).toString());
		        		 mailListObj.add(maildata);
		        	 }
		        	 
		        }
		        logger.info("MailList Obj " + mailListObj.size());
		        model.put("dataList", mailListObj);
		        mail.setModel(model);
		        List<AlertJobStatistics> statistics = getJobStatistics(mailListObj,  indexJob, jobLogger);
				indexJob.setStatistics(statistics);		    
			String emailTo = indexJob.getJobData().getEmailRecipients();
			logger.info(emailTo);
			String[] emails = emailTo.split(",");
			for (int j=0 ; j< emails.length; j++) {
				System.out.println(emails[j]);
				boolean result = getUserDetails(emails[j], mail, indexJob.getJobData().getSolrHost(), indexJob.getJobData().getSolrPort());
				mail.setMailTo(emails[j]);
				mailService.sendEmail(mail);		
				
			}	
			jobLogger.info("Mail Sent to the Receipients ", "");
			indexJob.setJobStatus(DocumentIndexJob.JOB_COMPLETED);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());			
		} catch(Exception e ) {
			
			logger.info(" Exception : " + e.getMessage());
			logger.error("Exception during executing send Mail   ------>: " , e);
			e.printStackTrace();
			indexJob.setJobStatus(DocumentIndexJob.JOB_ERROR);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
			 throw e;			
		}
		
	}
	
	private ArrayList<AlertExecution> CheckForModification(long jobStartTime, AlertJob indexJob, ArrayList<CartDetails> cartDetailsList, Cart cart, GeodatafyJobLog jobLogger) throws Exception {
		
		AlertJobData alertJobData = indexJob.getJobData();
		ArrayList<AlertExecution> alertExecutionList = new ArrayList<AlertExecution>();
		ArrayList<String> chnagedListFinal = new ArrayList<String>();
		String lastAlertQueryTime = null;
		boolean isExceptionOccured = true;
		try {
			isExceptionOccured = getIndexedFilesForAlert( chnagedListFinal , alertExecutionList ,  cartDetailsList,  indexJob,  jobLogger);
			ArrayList<AlertExecution> copyAlertExecutionList = new ArrayList<AlertExecution>(alertExecutionList);
			
			ArrayList<AlertExecution> alertExecListSave = new ArrayList<AlertExecution>();
			for(AlertExecution alertExecObj : copyAlertExecutionList) {
				AlertExecution alertExec = new AlertExecution();
				
				alertExec.setAlertId(alertExecObj.getAlertId());
				alertExec.setCartId(alertExecObj.getCartId());
				alertExec.setId(alertExecObj.getId());
				alertExec.setColumnName(alertExecObj.getColumnName());
				alertExec.setCartDatatype(alertExecObj.getCartDatatype());				
				alertExec.setFromQc(alertExecObj.isFromQc());				
				alertExec.setCartSelection(alertExecObj.getCartSelection());
				alertExec.setSelectedValues(alertExecObj.getSelectedValues());
				alertExec.setDatatype(alertExecObj.getDatatype());	
				alertExecListSave.add(alertExec);
			}
			Gson gson = new Gson();			
			String json = gson.toJson(alertExecListSave, new TypeToken<List<AlertExecution>>() {}.getType());
			logger.info(json);
			String baseUrl = "http://" + alertJobData.getSolrHost() + ":" + alertJobData.getSolrPort() + "/solr/"; 
			logger.info(baseUrl);
			boolean result = false;
			if (alertExecutionList!= null &&  alertExecutionList.size() > 0) {
				jobLogger.info(" Inserting the Alert Execution document into cart   ", " " + alertExecutionList.size());
				 result = uploadData(baseUrl, "cart",  json);
				 if(result) {
						AlertMessage alertMessage = new AlertMessage();
						AlertExecution alertExecution = alertExecutionList.get(0);
						long timenow = new Date().getTime();
						String id = alertExecution.getAlertId()  + "_" + timenow;
						alertMessage.setId(id);
						String strDate = ZonedDateTime.now(ZoneOffset.UTC).toString();
						alertMessage.setCreatedDate(strDate);
						alertMessage.setDatatype("dataCartMessage");
						alertMessage.setMessageStatus("unread");
						alertMessage.setMessageType("alert");
						alertMessage.setMsgDocumentId(alertExecution.getAlertId());
						ArrayList<AlertMessage> alertMessageList = new ArrayList<AlertMessage>();
						alertMessageList.add(alertMessage);
					Gson gsonforMessage = new Gson();			
					
					String jsonforMessage = gson.toJson(alertMessageList, new TypeToken<List<AlertMessage>>() {}.getType());
					logger.info(json);
					jobLogger.info(" Inserting the Alert message document for the cart   ", " " + jsonforMessage);
					uploadData(baseUrl, "cart",  jsonforMessage);
				}
				 
			} else {
				jobLogger.info(" No Files are modified and hence alert execution and message documents are not created   ", " " );
				result = true;
				
			}
			
	  	    ZonedDateTime now = ZonedDateTime.now(ZoneOffset.UTC);
		    CartAlertJob cartAlertJob = null;
		    if(result) {
		    	logger.info(" indexJob name   --------> " + indexJob.getJobName());
		    	cartAlertJob = getAlertJob(alertJobData.getSolrHost(),  alertJobData.getSolrPort(),  indexJob.getJobName(),  alertJobData.getSolrCollectionName());	
		    	
		    	 LocalDateTime localDateTime = LocalDateTime.ofInstant(new Date(jobStartTime).toInstant(), ZoneId.systemDefault());
				 ZonedDateTime utc = ZonedDateTime.of(localDateTime, ZoneOffset.UTC);			
				
				String lastExecutionTime =utc.toString();
		    	DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.sss'Z'");
		    	df.setTimeZone(TimeZone.getTimeZone("UTC"));
		       	cartAlertJob.setStartDateTime(getFormatedUTCTime(cartAlertJob.getStartDateTime()));
		    	cartAlertJob.setCreatedDate(getFormatedUTCTime(cartAlertJob.getCreatedDate()));
		    	cartAlertJob.setLasModifiedDate(now.toString());
		    	String strJobData = cartAlertJob.getJobData();
		    	AlertJobData alertJB = gson.fromJson(strJobData, AlertJobData.class);
		    	lastAlertQueryTime = alertJB.getLastExecutionTime();
		    	alertJB.setLastExecutionTime(lastExecutionTime);
		    	String strUpdJobData = gson.toJson(alertJB, new TypeToken<AlertJobData>() {}.getType());
		    	cartAlertJob.setJobData(strUpdJobData);
		    	json = gson.toJson(cartAlertJob, new TypeToken<CartAlertJob>() {}.getType());
		    	json = "[" + json + "]";
		    	jobLogger.info(" Updating the Job Definition - Job Data for the Last Execution time to ", "" + lastExecutionTime);
		    	boolean resultUpdateDate = uploadData(baseUrl, "jobs", json);
		    	if(resultUpdateDate) {
		    		indexJob.setUpdatedDate(lastExecutionTime);
		    	}
		    } else {
		    	
		    }
		} catch (Exception e) {
			logger.error("Exception during execution of Solar query in checkModification method: " , e);
			jobLogger.info(" Exception during execution of Solar query in checkModification method ", "" );
			e.printStackTrace();	
			indexJob.setJobStatus(DocumentIndexJob.JOB_ERROR);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
			logger.error(e.getMessage());
			 throw e;
		}
		
		
		if(chnagedListFinal.size() > 0) {
			jobLogger.info("Dataset updated in the cart preparing to send email", "" );
			sendMailForIndexed( indexJob, lastAlertQueryTime, jobLogger,  alertExecutionList) ;
			jobLogger.info("DataTypes Indexed after Alert Last Execution Time . Send mail completed successfully", "" );
		} else {
			jobLogger.info(" No DataTypes files indexed since Alert's Last Execution Time . Mail Not send", "" );
		}
		logger.info("AlertExecutionList size returned  " + alertExecutionList.size());
		if(isExceptionOccured) {
			indexJob.setJobStatus(DocumentIndexJob.JOB_COMPLETED);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());	
			
		} else {
			indexJob.setJobStatus(DocumentIndexJob.JOB_ERROR);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
		}
		
		return alertExecutionList;
		
	}
	
	private boolean getIndexedFilesForAlert( ArrayList<String> chnagedListFinal , ArrayList<AlertExecution> alertExecutionList ,  ArrayList<CartDetails> cartDetailsList,  AlertJob indexJob, GeodatafyJobLog jobLogger) throws Exception {
		AlertJobData alertJobData = indexJob.getJobData();
		boolean result = true;
		ArrayList<CartDetails> listOfCart = cartDetailsList;
		//logger.error("alertJobData.getLastExecutionTime()   --------> " + alertJobData.getLastExecutionTime());
		logger.info("listOfCart.size()   --------> " +listOfCart.size());
		
		CartAlertJob cartAlertJobObj = getAlertJob(alertJobData.getSolrHost(),  alertJobData.getSolrPort(),  indexJob.getJobName(),  alertJobData.getSolrCollectionName());
		cartAlertJobObj.getJobData();
		String strJobDataObj = cartAlertJobObj.getJobData();
    	//logger.info(strJobDataObj);
    	Gson gson = new Gson();
    	AlertJobData alertJB = gson.fromJson(strJobDataObj, AlertJobData.class);
    	//logger.info(alertJB.getLastExecutionTime());
    	
    	Long timeNow = new Date().getTime();
		String alertId = indexJob.getJobName() + "_" + timeNow;
		for(int i=0; i < listOfCart.size(); i++ ) {
			//logger.info("Loop   --------> " + i );
			try {
				CartDetails cartDetObj = listOfCart.get(i);
			
				String strCollection = cartDetObj.getCartCollectionUrl().substring(cartDetObj.getCartCollectionUrl().lastIndexOf("/")+1);
				logger.info("strCollection   --------> " +strCollection);
				
				String cartSelectionStr = cartDetObj.getCartSelection();
						
				if(cartSelectionStr !=null && cartSelectionStr.equalsIgnoreCase("rowselection")) {
					jobLogger.info("Checking the Cart details rows selection  for changed files" + " in " + strCollection + "  since last execution time at: ",   alertJB.getLastExecutionTime());
					ArrayList<String> selList = cartDetObj.getSelectedValues();	
					if(selList !=null && selList.size() > 0) {
						//logger.info("getSelectedValues   --------> " +selList.size());		
						ArrayList<String> idList = new ArrayList<String>();
						int partitionSize = 1000;
						List<List<String>> batchList = new ArrayList<>();
						for (int b=0; b<selList.size(); b += partitionSize) {
							batchList.add(selList.subList(b, Math.min(b + partitionSize, selList.size())));
						}
						StringBuffer strSplitList = new StringBuffer();
					    for (List<String> list : batchList) {
					    	//System.out.println("***********************");
					    	strSplitList = new StringBuffer();
					    	strSplitList.append("id: ( ");
					        for(int j=0; j < list.size(); j++) {
					        	if(j!= list.size()-1) {
					        		strSplitList.append("\"").append(selList.get(j)).append("\" OR ");
								} else {
									strSplitList.append("\"").append(selList.get(j)).append("\" )" );
								}
					        	
					        }
					        idList.add(strSplitList.toString().replace("\\", "\\\\"));
					       
					    }
					    logger.info("Partitioned list    --------> " +idList.size());
					    ArrayList<String> chnagedList = new ArrayList<String>();
					    for(int m =0; m < idList.size(); m++) {
							String idqry = idList.get(m);
							 logger.info(" List  " + m + " " + idqry);
							
							String strFilterByLastIndexed = null;
							strFilterByLastIndexed = "Last_Modified_DateTime:[" + alertJB.getLastExecutionTime() + " TO *]";						
							
							JSONObject json = new JSONObject();
							JSONObject paramjson = new JSONObject();	
								
							json.put("q", idqry );
							json.put("fq", strFilterByLastIndexed);
							json.put("indent", "on");
							json.put("rows", "2147483647");
							json.put("wt", "json");
							paramjson.put("params", json);
							logger.info(paramjson.toString());
							jobLogger.info("Query Param for  " + strCollection + " :   "  + paramjson.toString() , " ");
							getDocument(paramjson.toString(),strCollection, chnagedList, indexJob, jobLogger );
							if( chnagedList.size() > 0) {
								chnagedListFinal.addAll(chnagedList);
							}
						
					    }
						
						logger.info(indexJob.getJobName());
						timeNow = new Date().getTime();
						if( chnagedList.size() > 0) {
							AlertExecution alertExecObj = new AlertExecution();
							alertExecObj.setAlertId(alertId);
							alertExecObj.setCartId(cartDetObj.getCartId());
							alertExecObj.setId(indexJob.getJobName() + "_" + timeNow);
							alertExecObj.setColumnName(cartDetObj.getColumnName());
							alertExecObj.setCartDatatype(cartDetObj.getCartDatatype());		
							alertExecObj.setDisplayName(cartDetObj.getDisplayName());
							alertExecObj.setFromQc(cartDetObj.getFromQc());
							//alertExecObj.setCartCollectionUrl(cartDetObj.getCartCollectionUrl());
							alertExecObj.setCartSelection(cartDetObj.getCartSelection());
							alertExecObj.setSelectedValues(chnagedList);
							alertExecObj.setDatatype("dataCartAlertExecution");
							alertExecutionList.add(alertExecObj);	
							
						}
						logger.info(indexJob.getJobName());
						//logger.info("***********************************");
					}
				 } else if(cartDetObj.getCartSelection().equalsIgnoreCase("criteriaselection")) {
					 jobLogger.info("Checking the cart details criteria query for changed files" + " in " + strCollection + " since last execution time at: ",   alertJB.getLastExecutionTime());
					String mainQryStr = cartDetObj.getMainCriteriaQry();	
					logger.info("getMainCriteriaQry   --------> " + mainQryStr);	
					String strFilterByLastIndexed = null;
					strFilterByLastIndexed = "Last_Modified_DateTime:[" + alertJB.getLastExecutionTime() + " TO *]";
				
					JSONObject json = new JSONObject();
					JSONObject paramjson = new JSONObject();	
						
					json.put("q", mainQryStr );
					json.put("fq", strFilterByLastIndexed);
					json.put("indent", "on");
					json.put("rows", "2147483647");
					json.put("wt", "json");
					paramjson.put("params", json);
					logger.error(paramjson.toString());
					jobLogger.info("Query Param for   " + strCollection + "  :   "  + paramjson.toString() , " ");
					 ArrayList<String> chnagedList = new ArrayList<String>();
					getDocument(paramjson.toString(),strCollection, chnagedList, indexJob, jobLogger );
					if( chnagedList.size() > 0) {
						chnagedListFinal.addAll(chnagedList);
					}
					logger.info(indexJob.getJobName());
					 timeNow = new Date().getTime();
					 if( chnagedList.size() > 0) {
						AlertExecution alertExecObj = new AlertExecution();
						alertExecObj.setAlertId(alertId);
						alertExecObj.setCartId(cartDetObj.getCartId());
						alertExecObj.setId(indexJob.getJobName() + "_" + timeNow);
						alertExecObj.setColumnName(cartDetObj.getColumnName());
						alertExecObj.setCartDatatype(cartDetObj.getCartDatatype());	
						alertExecObj.setDisplayName(cartDetObj.getDisplayName());
						alertExecObj.setFromQc(cartDetObj.getFromQc());
						//alertExecObj.setCartCollectionUrl(cartDetObj.getCartCollectionUrl());
						alertExecObj.setCartSelection("rowselection");
						alertExecObj.setSelectedValues(chnagedList);
						alertExecObj.setDatatype("dataCartAlertExecution");
						alertExecutionList.add(alertExecObj);	
					 }
					
					
				}
	         			
			} catch (Exception e) {
				logger.info("Exception during execution of Solar Query for getting Modified files  ------>: " , e);
				e.printStackTrace();	
				jobLogger.info("Exception during execution of Solar Query for getting Modified files  ",  " " + e.getMessage());
				indexJob.setJobStatus(DocumentIndexJob.JOB_ERROR);
				indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
				
				result = false;
			} finally {
		
			}		
			logger.info(" END Loop   --------> " + i );
		}	
		logger.info(" AlertExecution Count   --------> " + alertExecutionList.size() );
		logger.info(" changedListFinal Count   --------> " + chnagedListFinal.size() );
		jobLogger.info("No of files modified since last execution time of Alert ",  " " + chnagedListFinal.size());
		jobLogger.info(" Return result of the search query ",  " " + result);
		return result;
		
	}
	
	
	
	
	private CartAlertJob getAlertJob(String solarHost, String solarPort, String alertId, String strCollectionName) throws Exception {		
		
		CartAlertJob cartAlertJobObj = null;
		try {
			CloseableHttpClient httpClient = WinHttpClients.createDefault();
			HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
					"http://" + solarHost + ":" + solarPort + "/solr/" + strCollectionName)).withHttpClient(httpClient).build();

			SolrQuery query = new SolrQuery();

			query.setQuery("*:*"); // main query
			query.set("wt", "json");
			query.setRows(2147483647);
		
			
			String strQryByAlertId = "id:" + alertId;
			logger.info("strQryBy for getAlertJob ----> " +   strQryByAlertId);
			query.addFilterQuery(strQryByAlertId, "datatype:jobDefinition");
			//logger.info(query.toQueryString());			
			QueryResponse resp = client.query(query);
			logger.info("Job Def  QueryResponse: " + resp.getResponse().toString());
			
			SolrDocumentList docList = resp.getResults();
			logger.info(" QueryResponse Num : " + docList.getNumFound());
			if (docList.getNumFound() > 0 ) {			
				for (Map singleDoc : docList) {
					CartDetails cartDetailsObj = new CartDetails();
					JSONObject json = new JSONObject(singleDoc);				
					//logger.info(" JSON String : " + json.toString());
					Gson gson = new Gson();			
					cartAlertJobObj = gson.fromJson(json.toString(), CartAlertJob.class);
					//logger.info(" Job Def Job Data: " + cartAlertJobObj.getJobData());
					
				}				
			} else {
				String msg="Job Definition for the Alert not Found  " + alertId;
				logger.error(msg);
				throw new Exception(msg);
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error(e.getStackTrace().toString());
			logger.info("Exception during execution of Solar Query for getAlertJob   ------>: " ,  e);
			e.printStackTrace();
			throw new Exception(e.getMessage());
			//return null;
		} finally {

		}	
				
		return cartAlertJobObj;

	}


	private String getFormatedUTCTime(String strDate) throws Exception{
		
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.sss'Z'");
		df.setTimeZone(TimeZone.getTimeZone("UTC"));	
		  ZonedDateTime zdt = ZonedDateTime.now(ZoneOffset.UTC);
		DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
		Date dateObj=null;
		try {
			dateObj = (Date)formatter.parse(strDate);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		String retStrDate = df.format(new Date(dateObj.getTime())).toString();
		return retStrDate;
	}
	
	
private boolean getUserDetails(String email, Mail mail, String solarHost, String solarPort) throws Exception{
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
			"http://" + solarHost + ":" + solarPort + "/solr/" + "metadata")).withHttpClient(httpClient).build();
		
		try {
			
			SolrQuery query = new SolrQuery();
			query.setQuery("datatype:userRoles"); // main query
			query.set("wt", "json");
			query.setRows(2147483647);
			String strEmailFilter =  "email:\"" + GeoUtil.escapeQueryParams(email) + "\"";
			query.addFilterQuery(strEmailFilter);
			System.out.println(query.toQueryString());
			logger.info("getUserDetails query String " + query.toQueryString());
			QueryResponse resp = client.query(query);
			logger.info(" getUserDetails QueryResponse: " + resp.getResponse().toString());
			System.out.println(" QueryResponse: " + resp.getResponse().toString());
			SolrDocumentList docList = resp.getResults();		
			logger.info(" getUserDetails QueryResponse for UserRomes : " + docList.getNumFound());
			if (docList.getNumFound() > 0 ) {
				mail.setRegisteredUser(5);
				return true;
			} else {
				query = new SolrQuery();
				query.setQuery("*:*"); // main query
				query.set("wt", "json");
				query.setRows(2147483647);
				query.addFilterQuery("datatype:AppConfig");
				System.out.println(query.toQueryString());
				System.out.println(query.toQueryString());
				resp = client.query(query);
				logger.info("getUserDetails  QueryResponse: " + resp.getResponse().toString());
				//System.out.println("getUserDetails QueryResponse: " + resp.getResponse().toString());
				docList = resp.getResults();		
				logger.info("getUserDetails QueryResponse for checking Browse Role: " + docList.getNumFound());		
				
				for (Map singleDoc : docList) {
					JSONObject json = new JSONObject(singleDoc);
					boolean isBrwseUser = (boolean) json.get("isBrowser");			
					if(isBrwseUser) {
						mail.setRegisteredUser(7); //browse user
					} else {
						mail.setRegisteredUser(6); //unregisteres user
					}
				}
				
				return true;
			}			
			
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error("Exception during execution of Solar Query for getUserDetails   ------>: " , e);
			e.printStackTrace();		
			throw new Exception(e.getMessage());
			//return false;
		} finally {
			client.close();
			httpClient.close();

		}		
				
	}
	



	private Mail getEmailServerDetails(String solarHost, String solarPort) throws Exception {
		Mail mail = new Mail();
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
				"http://" + solarHost + ":" + solarPort + "/solr/" + "metadata")).withHttpClient(httpClient).build();
		try {
			
			SolrQuery query = new SolrQuery();
			query.setQuery("*:*"); // main query
			query.set("wt", "json");
			query.setRows(2147483647);
			query.addFilterQuery("datatype:mailService");
			System.out.println(query.toQueryString());
			System.out.println(query.toQueryString());
			QueryResponse resp = client.query(query);
			logger.info("getEmailServerDetails QueryResponse: " + resp.getResponse().toString());
			
			SolrDocumentList docList = resp.getResults();		
			logger.info(" getEmailServerDetails QueryResponse records found: " + docList.getNumFound());
			for (Map singleDoc : docList) {
					JSONObject json = new JSONObject(singleDoc);
					mail.setSmtpHost((String) json.get("smtpHost"));
			        mail.setSmtpPort(((Long)json.get("smtpPort")).toString());
			        if(json.has("smtpUsername") && json.has("smtpPassword")) {
			        	 mail.setAuthRequired(true);		       
					     mail.setSmtpUsername((String) json.get("smtpUsername"));
					     String encryptedPassword = (String) json.get("smtpPassword");
					        String smtpDecryptPassword = SecurityUtil.decrypt(encryptedPassword);
					        mail.setSmtpPassword(smtpDecryptPassword);
					    
			        } else {
			        	mail.setAuthRequired(false);
			        }			       
			        mail.setMailFrom((String) json.get("mailFrom"));	
			}			
			
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error("Exception during execution of Solar Query for getEmailServerDetails   ------>: ", e);
			e.printStackTrace();	
			throw new Exception(e.getMessage());
			//return null;
		} finally {
			client.close();
			httpClient.close();
		}		
		return mail;
	}
	

	private List<AlertJobStatistics> getJobStatistics(ArrayList<MailData> mailList, AlertJob indexJob,  GeodatafyJobLog jobLogger) throws IOException {
		List<AlertJobStatistics> statistics = indexJob.getStatistics();
		
		for(int j=0; j< statistics.size(); j++) {
			AlertJobStatistics statistic = statistics.get(j);
			for(int i=0 ; i <mailList.size(); i++ ) {
				MailData mailData =mailList.get(i);
				String datatypeChngStr = mailData.getDataType();
				if(datatypeChngStr.equalsIgnoreCase(statistic.getDataType()) ) {		
					//jobLogger.info(statistic.getDataType() , " ---> datatypeChngStr  " +  datatypeChngStr);
					statistic.setModified(Integer.parseInt(mailData.getCount()));
					//jobLogger.info(statistic.getModified() + " ", " ---> Modified   total :   " +   statistic.getTotal() );
				
					//if(!statistic.getTotal().equalsIgnoreCase("NA")) {
						int unmodified = statistic.getTotal() - statistic.getModified();
						//jobLogger.info(statistic.getDataType() , " ---> unmodified  " +  unmodified);
						statistic.setUnmodified(unmodified);
					//} else {
						
					//}			
				}
			}		
		}
		
		
		return statistics;
	}
	
	private List<AlertJobStatistics> getJobStatistics(ArrayList<CartDetails> cartDetails, int modified, AlertJob indexJob,  GeodatafyJobLog jobLogger) throws Exception {
		List<AlertJobStatistics> statistics = new ArrayList<AlertJobStatistics>();		
		
		for(int i=0 ; i <cartDetails.size(); i++ ) {
			CartDetails cartDetailsObj =cartDetails.get(i);
			AlertJobStatistics statistic = new AlertJobStatistics(cartDetailsObj.getDisplayName());	
			statistic.setDataTypes(cartDetailsObj.getDisplayName());
			if (cartDetailsObj.getCartSelection().equalsIgnoreCase("rowselection")) {
				int rowSelectCnt = cartDetailsObj.getSelectedValues().size();
				statistic.setTotal(rowSelectCnt);
				statistic.setModified(modified);
				int unmodified = rowSelectCnt - modified;
				statistic.setUnmodified(unmodified);
			} else {
				//int rowSelectCnt = cartDetailsObj.getSelectedValues().size();
				String mainQryStr = cartDetailsObj.getMainCriteriaQry();	
				JSONObject json = new JSONObject();
				JSONObject paramjson = new JSONObject();						
				json.put("q", mainQryStr );
				json.put("indent", "on");
				json.put("rows", "2147483647");
				json.put("wt", "json");
				paramjson.put("params", json);
				logger.error(paramjson.toString());
				String strCollection = cartDetailsObj.getCartCollectionUrl().substring(cartDetailsObj.getCartCollectionUrl().lastIndexOf("/")+1);
				logger.info("strCollection   --------> " +strCollection);
				ArrayList<String> list = new ArrayList<String>();
				getDocument(paramjson.toString(),strCollection, list, indexJob, jobLogger );
				int total = list.size();
				if( total > 0) {
					statistic.setTotal(total);
				} 
				statistic.setModified(modified);
				int unmodified = total - modified;
				statistic.setUnmodified(unmodified);
			}
				statistics.add(statistic);
		}

		
		return statistics;
	}




	
	

	private AlertJobData constructJobData(String jobData) throws Exception
		{
			Map<String, JsonElement> jdm = JsonUtil.getJsonElementMap(jobData);
			
			JsonElement alertIdElement = jdm.get("cartId");
			if(alertIdElement == null || alertIdElement.getAsString().length() < 0){
				String msg = "The Cart Id  is not available.";
				throw new Exception(msg);
			}				
			String cartId = alertIdElement.getAsString();
			logger.info("The Cart Id is : " + cartId);
			
			JsonElement emailToElement = jdm.get("emailRecipients");
			if(emailToElement == null || emailToElement.getAsString().length() < 0){
				String msg = "The EmailTo  is not available.";
				throw new Exception(msg);
			}				
			String emailRecipient = emailToElement.getAsString();
			logger.info("The EmailRecipient is : " + emailRecipient);
			
			JsonElement lastModifiedDateElement = jdm.get("LastExecutionTime");
			if(lastModifiedDateElement == null || lastModifiedDateElement.getAsString().length() < 0){
				String msg = "The lastModifiedDate  is not available.";
				throw new Exception(msg);
			}				
			String LastExecutionTime = lastModifiedDateElement.getAsString();
			logger.info("The LastModifiedDate is : " + LastExecutionTime);
			
			JsonElement linkUrlElement = jdm.get("linkUrl");
			if(linkUrlElement == null || linkUrlElement.getAsString().length() < 0){
				String msg = "The LinkUrl  is not available.";
				throw new Exception(msg);
			}		
			
			String solrCollectionName = "jobs";
			if(jdm.get("SolrCollectionName") != null){
				solrCollectionName = jdm.get("SolrCollectionName").getAsString();
			}else{
				logger.info("solrCollectionName is not set. Assuming cart");		
			}
			logger.info("solr Collection Name is set to: " + solrCollectionName);
			
			String solrHost = "localhost";
			if(jdm.get("solrHost") != null){
				solrHost = jdm.get("solrHost").getAsString();
			}else{
				logger.info("solr Host is not set. Assuming localhost");		
			}
			logger.info("solr host is set to: " + solrHost);

			String solrPort = "8983";
			if(jdm.get("solrPort") != null){
				solrPort = jdm.get("solrPort").getAsString();
			}else{
				logger.info("solr Port is not set. Assuming 8983");		
			}
			logger.info("solr Port is set to: " + solrPort);	
			
			String linkUrl = "";
			if(jdm.get("linkUrl") != null){
				linkUrl = jdm.get("linkUrl").getAsString();
			}else{
				logger.info("IIS Port is not set. Assuming 80");		
			}
			logger.info("solr Port is set to: " + linkUrl);	
			
			
			return new AlertJobData(cartId, emailRecipient, LastExecutionTime,  solrHost, solrPort, linkUrlElement.getAsString(), solrCollectionName);
		}
		
	

	private void uploadJobRunData(String baseSolrURL, AlertJob indexJob, GeodatafyJobLog jobLogger) throws Exception {
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		
		HttpPost post = new HttpPost(baseSolrURL + "/" + JOBS_COLLECTION + "/update/json?wt=json&commitWithin=1&overwrite=true");
		
		try {
			String content = getDocContents(indexJob, jobLogger);
			content = "{\"add\": { \"doc\": " + content + "}}";
			StringEntity entity  = new StringEntity(content, "UTF-8");
			entity.setContentType("application/json");
			post.setEntity(entity);

			jobLogger.info("Adding the Alert job run data to solr", content);
	    	logger.info("Adding the Alert job run data to solr " + content);
	    	CloseableHttpResponse response = httpClient.execute(post);
			jobLogger.info("Added the Alert job run data to solr and the response ", response.toString());
			logger.info("Added the Alert job run data to solr and the response is: " + response.toString());
	    	
		} catch (ClientProtocolException e) {			
			logger.error(e.getMessage());
			logger.error("IOException ", e);
			jobLogger.error("ClientProtocolException", e.getMessage());
			throw new Exception(e.getMessage());
		} catch (IOException e) {
			logger.error(e.getMessage());
			logger.error("IOException ", e);
			
			jobLogger.error("IOException", e.getMessage());
			throw new Exception(e.getMessage());
		}	 
	}
	
	
	private boolean getDocument(String content, String strCollection, ArrayList<String> changedList	, AlertJob indexJob, GeodatafyJobLog jobLogger
			) throws Exception{
			boolean retStatus = true;
			try {	
			CloseableHttpClient httpClient = WinHttpClients.createDefault();			
			AlertJobData indexJobData = indexJob.getJobData();
			String baseSolrURL =  "http://" + indexJobData.getSolrHost() + ":" + indexJobData.getSolrPort()+ "/solr";
			HttpPost post = new HttpPost(baseSolrURL + "/" + strCollection + "/select");			
			StringEntity entity  = new StringEntity(content);
	
				post.addHeader("content-type", "application/json");
				entity.setContentType("application/json");	
				post.setEntity(entity);				
		    	CloseableHttpResponse response = httpClient.execute(post);				
				//System.out.println(" getModifiedDocument from solr response is: " + response.toString());
				logger.info(" getModifiedDocument response is: " + response.getEntity().getContent());
				StringBuffer strBuffer = new StringBuffer();
				 BufferedReader rd = new BufferedReader(new InputStreamReader(
		                    response.getEntity().getContent()));
		            String line = "";
		            while ((line = rd.readLine()) != null) {
		            	strBuffer.append(line);
		            }
		            logger.info(strBuffer.toString());
		            JSONObject json = new JSONObject(strBuffer.toString());
		            
		            if (json.has("response")) {
		            	JSONObject jsonObj = json.getJSONObject("response");
		            	int numFound = (int) jsonObj.get("numFound");
		            	logger.info("\"Number of Files/Data Modified for alert execution :      " +numFound);
		            	jobLogger.error("Number of Files/Data Modified for alert execution : " + numFound, " ");
		            	if(numFound > 0) {
		            		JSONArray jsonArrObj = jsonObj.getJSONArray("docs");
		            		for(int arrCnt=0; arrCnt < jsonArrObj.length(); arrCnt++ ) {
		            			JSONObject jsonResObj = jsonArrObj.getJSONObject(arrCnt);		            					
		            			String idStr = (String)jsonResObj.get("id");
		            			changedList.add(idStr);
		            			
		            		}
		            	}
		            	
		            } else {
		            	throw new Exception("Exception in post request for getting the updated indexed file");
		            }		            
		            return retStatus;
		    	
			} catch (ClientProtocolException e) {			
				e.printStackTrace();
				retStatus=false;
				logger.error("ClientProtocolException ", e);
				logger.error(e.getStackTrace().toString());
				jobLogger.error("ClientProtocolException", e.getMessage());
				throw new Exception(e.getMessage());
			} catch (IOException e) {
				e.printStackTrace();
				retStatus=false;
				logger.error("IOException ", e);				
				jobLogger.error("IOException", e.getMessage());
				throw new Exception(e.getMessage());
			}	 
		}
	
	private boolean uploadData(String baseSolrURL, String collection, String content
			//, GeodatafyJobLog jobLogger
			) throws Exception {
		
		logger.info(baseSolrURL  + collection + "/update/json?wt=json&commitWithin=1&overwrite=true");
		System.out.println("http://" +"192.168.1.80" + ":" + "8983" + "/solr" + "/" + collection + "/update/json?wt=json&commitWithin=1000&overwrite=true");
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		HttpPost post = new HttpPost(baseSolrURL  + collection + "/update/json?wt=json&commitWithin=1&overwrite=true");
	
		try {
			StringEntity entity  = new StringEntity(content, "UTF-8");
			entity.setContentType("application/json");
			post.setEntity(entity);
	    	logger.info("Adding the job run data to solr " + content);
	    	CloseableHttpResponse response = httpClient.execute(post);
	    	logger.info("Added the Alert Excution data to solr and the response is: " + response.toString());
	    	return true;
	    	
		} catch (ClientProtocolException e) {			
			logger.error("ClientProtocolException ", e);				
			throw new Exception(e.getMessage());
		} catch (IOException e) {
			logger.error("IOException ", e);				
			throw new Exception(e.getMessage());			
		}	
	}

	
	private String getDocContents(AlertJob indexJob,  GeodatafyJobLog jobLogger){
	    StringBuilder sb = new StringBuilder();
	    sb.append("{");
	    sb.append("\"id\":\"" + indexJob.getSolrDocID() + "\", ");
	    sb.append("\"datatype\":\"" + AlertJob.SOL_DATA_TYPE + "\", ");
	    sb.append("\"jobRunID\":\"" + indexJob.getSolrDocID() + "\", ");
	    sb.append("\"jobName\":\"" + indexJob.getJobName() + "\", ");	    
	    sb.append("\"jobType\":\"" + indexJob.getJobType() + "\", ");
	    sb.append("\"jobStatus\":\"" + indexJob.getJobStatus() + "\", ");
	    sb.append("\"startTime\":\"" + indexJob.getStartTime() + "\", ");
	    sb.append("\"endTime\":\"" + indexJob.getEndTime() + "\", ");
	    sb.append("\"logFileName\":\"" + indexJob.getLogFileName().replace("\\", "\\\\\\\\") + "\", ");
	    String jobData = indexJob.getJobDataString();
	    jobData = jobData.replace("\\", "\\\\");
	    jobData = jobData.replace("\"", "\\\"");
	    sb.append("\"jobData\":\"" + jobData + "\"");       
	
	    if(indexJob.getStatistics() != null && indexJob.getStatistics().size() > 0){
	    	AlertJobStatistics jobStatisticsobj =  indexJob.getStatistics().get(0);
	    	if(!jobStatisticsobj.getDataType().trim().isEmpty()) {
	    	StringBuilder stat = new StringBuilder();
	    	stat.append("[");
	    	for(int i = 0; i < indexJob.getStatistics().size(); i++){
	    		AlertJobStatistics jobStatistics = indexJob.getStatistics().get(i);
	    		stat.append("\"{");
	    		stat.append("\\\"Datatype\\\":\\\"" + jobStatistics.getDataType());
	    		stat.append("\\\", \\\"total\\\":" + jobStatistics.getTotal());	  
	    		stat.append(", \\\"Modified\\\":" + jobStatistics.getModified());
	    		stat.append(", \\\"Unmodified\\\":"+ jobStatistics.getUnmodified() );
	    		if(i == (indexJob.getStatistics().size() - 1)){
	    			stat.append("}\"");
	    		}else{
	    			stat.append("}\",");
	    		}	    		
	    	}
	    	stat.append("]");
	    	logger.info("The job Statistics is: " + stat.toString());
	    	sb.append(",\"jobStatistics\":" + stat.toString());
	    }
	    }
    	sb.append("}");
    	
		return sb.toString();
	}

}
