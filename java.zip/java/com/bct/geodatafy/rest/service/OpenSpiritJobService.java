package com.bct.geodatafy.rest.service;

import java.io.File;
import java.net.URL;
import java.net.URLDecoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;




import org.apache.log4j.Logger;

import com.bct.geodatafy.job.GeodatafyJobRun;
import com.bct.geodatafy.job.openspirit.OpenSpiritIndexJobProcessor;
import com.bct.geodatafy.job.openspirit.OpenSpiritScanDatasource;
import com.bct.geodatafy.util.JsonUtil;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.tibco.openspirit.jobs.api.Job.LogLevel;
import com.tibco.openspirit.jobs.api.JobStatus;


@Path("/jobs/openspirit/indexer")
public class OpenSpiritJobService {
	static Logger logger = Logger.getLogger(OpenSpiritJobService.class);
	public static final String JOB_TYPE = "OpenSpiritIndexer";
	
	
	@GET
	@Path("/runs")	
	@Produces(MediaType.APPLICATION_JSON)
	public String getAllOpenSpiritIndexJobRuns() throws Exception{		
		logger.info("In service: /jobs/openspirit/indexer/runs and method: getAllOpenSpiritIndexJobRuns");		
		try {
		List<JobStatus> status = OpenSpiritIndexJobProcessor.getInstance().getJobRuns();
		
		if(status == null || status.size() < 1){
			return "{ \"jobStatus\":\"UNKNOWN\"}";
		}
		List<GeodatafyJobRun> runs = new ArrayList<GeodatafyJobRun>();
		for(JobStatus stat: status){
			
			GeodatafyJobRun run = new GeodatafyJobRun(stat.getJobName(), JOB_TYPE, stat.getJobRunId(), stat.getStatus().toString(), getFormatedUTCTime(stat.getStartTime()), getFormatedUTCTime(stat.getEndTime()));
			runs.add(run);
		}
		
		Gson gson = new Gson();		
		return gson.toJson(runs); 
		} catch(Exception e) {
			logger.error("Exception in getting runs " + e);
			return "{ \"jobStatus\":\"UNKNOWN\"}";
		}
	}
	
	@GET
	@Path("/exists/{jobName}")	
	public boolean checkOpenSpiritIndexJobExists(@PathParam("jobName") String jobName) throws Exception{		
		logger.info("In service: /jobs/openspirit/indexer/exists/{jobName} and method: checkOpenSpiritIndexJobExists");
		logger.info("The input job name is " + jobName);
		boolean response = OpenSpiritIndexJobProcessor.getInstance().jobExists(jobName);
		logger.info("The input job exists is " + response);
		return response;
	}
	
	@DELETE
	@Path("/delete/{jobName}")	
	public boolean deleteOpenSpiritIndexJobExists(@PathParam("jobName") String jobName) throws Exception{		
		logger.info("In service: /jobs/openspirit/indexer/delete/{jobName} and method: deleteOpenSpiritIndexJobExists");
		logger.info("The input job name is " + jobName);
		return OpenSpiritIndexJobProcessor.getInstance().deleteJob(jobName);
	}

	@POST
	@Path("/runs/get/statistics")
	@Consumes(MediaType.APPLICATION_JSON)
	public String getOpenSpiritIndexJobStatistics(String payLoad) throws Exception{		
		logger.info("In service: /jobs/openspirit/indexer/runs/get/statistics and method: getOpenSpiritIndexJobStatistics");
		Map<String, String> elementsMap = checkAndGetPayloadElements(payLoad);		
		checkJobNameAndJobRunID(elementsMap);

		//Return the html as it is
		return OpenSpiritIndexJobProcessor.getInstance().getJobRunStatistics(elementsMap.get("jobName"), elementsMap.get("jobRunID"));
	}

	@POST
	@Path("/runs/get/log")	
	public String getOpenSpiritIndexJobLog(String payLoad) throws Exception{		
		logger.info("In service: /jobs/openspirit/indexer/runs/get/log and method: getOpenSpiritIndexJobLog");
		Map<String, String> elementsMap = checkAndGetPayloadElements(payLoad);		
		checkJobNameAndJobRunID(elementsMap);
		//Return the html as it is
		return OpenSpiritIndexJobProcessor.getInstance().getJobRunLog(elementsMap.get("jobName"), elementsMap.get("jobRunID"));
	}
	
	@POST
	@Path("/create")
	@Consumes(MediaType.APPLICATION_JSON)
	public String createOpenSpiritIndexJob(String payLoad, @Context HttpServletRequest request) throws Exception{		
		logger.info("In service: /jobs/openspirit/indexer/create and method: createOpenSpiritIndexJob");		
		
		Map<String, String> elementsMap = this.checkAndGetPayloadElements(payLoad);
				
		String jobName = elementsMap.get("jobName");
		if(jobName == null || jobName.length() < 1){
			String msg = "Job Name is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}

		String jobData = elementsMap.get("jobData");
		if(jobData == null || jobData.length() < 1){
			String msg = "Job Data is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}

		logger.info("Starting the open spirit index job: " + jobName + " ");
		URL r = this.getClass().getResource("/");
		String decoded = URLDecoder.decode(r.getFile(), "UTF-8");

		if (decoded.startsWith("/")) {
		    // path "C:/Program Files/Tomcat 6.0/webapps/myapp/WEB-INF/classes/"
		    decoded = decoded.replaceFirst("/", "");
		}
		File f1 = new File(decoded + "../lib/");
		logger.info(" Lib Path   :  " + f1.getAbsolutePath());
		manageJob(elementsMap, false, false, f1.getAbsolutePath());				
		return "Done";
	}

	@POST
	@Path("/createandrun")
	@Consumes(MediaType.APPLICATION_JSON)
	public String createAndRunOpenSpiritIndexJob(String payLoad
			, @Context HttpServletRequest request
			) throws Exception{		
		logger.info("In service: /jobs/openspirit/indexer/createandrun and method: createAndRunOpenSpiritIndexJob");		
		
		Map<String, String> elementsMap = this.checkAndGetPayloadElements(payLoad);
				
		String jobName = elementsMap.get("jobName");
		if(jobName == null || jobName.length() < 1){
			String msg = "Job Name is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}

		String jobData = elementsMap.get("jobData");
		if(jobData == null || jobData.length() < 1){
			String msg = "Job Data is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}

		logger.info("Starting the open spirit index job: " + jobName + " ");
		
		URL r = this.getClass().getResource("/");
		String decoded = URLDecoder.decode(r.getFile(), "UTF-8");

		if (decoded.startsWith("/")) {
		    // path "C:/Program Files/Tomcat 6.0/webapps/myapp/WEB-INF/classes/"
		    decoded = decoded.replaceFirst("/", "");
		}
		File f1 = new File(decoded + "../lib/");
		logger.info(" Lib Path   :  " + f1.getAbsolutePath());
		manageJob(elementsMap, false, true, f1.getAbsolutePath());				
		return "Done";
	}
	

	@PUT
	@Path("/create")
	@Consumes(MediaType.APPLICATION_JSON)
	public String updateOpenSpiritIndexJob(String payLoad, @Context HttpServletRequest request) throws Exception{		
		logger.info("In service: PUT /jobs/openspirit/indexer/create and method: updateOpenSpiritIndexJob");		
		
		Map<String, String> elementsMap = this.checkAndGetPayloadElements(payLoad);
				
		String jobName = elementsMap.get("jobName");
		if(jobName == null || jobName.length() < 1){
			String msg = "Job Name is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}

		String jobData = elementsMap.get("jobData");
		if(jobData == null || jobData.length() < 1){
			String msg = "Job Data is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}

		logger.info("Updating the open spirit index job: " + jobName + " ");
		URL r = this.getClass().getResource("/");
		String decoded = URLDecoder.decode(r.getFile(), "UTF-8");

		if (decoded.startsWith("/")) {
		    // path "C:/Program Files/Tomcat 6.0/webapps/myapp/WEB-INF/classes/"
		    decoded = decoded.replaceFirst("/", "");
		}
		File f1 = new File(decoded + "../lib/");
		logger.info(" Lib Path   :  " + f1.getAbsolutePath());
		manageJob(elementsMap, true, false, f1.getAbsolutePath());				
		return "Done";
	}

	@PUT
	@Path("/createandrun")
	@Consumes(MediaType.APPLICATION_JSON)
	public String updateAndRunOpenSpiritIndexJob(String payLoad, @Context HttpServletRequest request) throws Exception{		
		logger.info("In service: PUT /jobs/openspirit/indexer/createandrun and method: updateAndRunOpenSpiritIndexJob");		
		
		Map<String, String> elementsMap = this.checkAndGetPayloadElements(payLoad);
				
		String jobName = elementsMap.get("jobName");
		if(jobName == null || jobName.length() < 1){
			String msg = "Job Name is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}

		String jobData = elementsMap.get("jobData");
		if(jobData == null || jobData.length() < 1){
			String msg = "Job Data is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}

		logger.info("Updating the open spirit index job: " + jobName + " ");
		URL r = this.getClass().getResource("/");
		String decoded = URLDecoder.decode(r.getFile(), "UTF-8");

		if (decoded.startsWith("/")) {
		    // path "C:/Program Files/Tomcat 6.0/webapps/myapp/WEB-INF/classes/"
		    decoded = decoded.replaceFirst("/", "");
		}
		File f1 = new File(decoded + "../lib/");
		logger.info(" Lib Path   :  " + f1.getAbsolutePath());
		manageJob(elementsMap, true, true, f1.getAbsolutePath());				
			
		return "Done";
	}

	private void manageJob(Map<String, String> elementsMap, boolean update, boolean run, String webInfPath) throws Exception {
		String jobName = elementsMap.get("jobName");
		if(jobName == null || jobName.length() < 0){
			String msg = "The job Name is not available from input.";
			logger.error(msg);
			throw new Exception(msg);
		}				
				
		String jobDescription = elementsMap.get("jobDescription");
		if(jobDescription == null || jobDescription.length() < 0){
			jobDescription = jobName;
		}				

		String logLevel = elementsMap.get("logLevel");
		LogLevel logLevelObj = LogLevel.INFO;
		if(logLevel.equalsIgnoreCase("debug")) {
			logLevelObj = LogLevel.DEBUG;
		} else if(logLevel.equalsIgnoreCase("error")) {
			logLevelObj = LogLevel.ERROR;
		} if(logLevel.equalsIgnoreCase("warn")) {
			logLevelObj = LogLevel.WARN;
		} else {
			logLevelObj = LogLevel.INFO;
		}
		
		if(logLevel != null && logLevel.length() < 0){
			logLevelObj = LogLevel.valueOf(logLevel);	
		}
		
/*		String scheduledStr = elementsMap.get("scheduled");
		boolean run = false;
		if(scheduledStr != null && scheduledStr.length() < 0){
			if(scheduledStr == "false"){
				run=true;
			}
		}*/
		
		String jobData = elementsMap.get("jobData");
		if(jobName == null || jobName.length() < 0){
			String msg = "The job data is not available from input.";
			logger.error(msg);
			throw new Exception(msg);
		}
		
		Map<String, JsonElement> jdm = JsonUtil.getJsonElementMap(jobData);
		
		JsonElement modelViewName = jdm.get("modelViewName");
		if(modelViewName == null || modelViewName.getAsString().length() < 0){
			String msg = "The Model View Name is not available from job data for job " + jobName;
			logger.error(msg);
			throw new Exception(msg);
		}				

		JsonElement modelViewVer = jdm.get("modelViewVersion");
		int modelViewVersion = -1;
		if(modelViewVer == null || modelViewVer.getAsString().length() < 0){
			String msg = "The Model View version is not available from job data for job " + jobName;
			logger.error(msg);
			throw new Exception(msg);
		}	else{
			modelViewVersion = Integer.parseInt(modelViewVer.getAsString());
		}

		JsonElement solrHost = jdm.get("solrHost");
		if(solrHost == null || solrHost.getAsString().length() < 0){
			String msg = "The solr Host is not available from job data for job " + jobName;
			logger.error(msg);
			throw new Exception(msg);
		}				

		JsonElement solrPort = jdm.get("solrPort");
		if(solrPort == null || solrPort.getAsString().length() < 0){
			String msg = "The solr Port is not available from job data for job " + jobName;
			logger.error(msg);
			throw new Exception(msg);
		}				

		JsonElement solrCollectionName = jdm.get("solrCollectionName");
		if(solrCollectionName == null || solrCollectionName.getAsString().length() < 0){
			String msg = "The solr Collection name is not available from job data for job " + jobName;
			logger.error(msg);
			throw new Exception(msg);
		}	
		JsonElement jeBulkData = jdm.get("bulkData");
		String bulkData = "";
		if(jeBulkData == null || jeBulkData.getAsString().length() < 0){
			//String msg = "Bulk data folder is not available from job data for job " + jobName;
			//logger.error(msg);
			//throw new Exception(msg);
		} else {	
			 bulkData = jeBulkData.getAsString();
		}
	//	logger.error("bulkData : "  + bulkData);
		String imageDirectoryPath = null;	  
		if(bulkData != null && !bulkData.isEmpty() && bulkData.trim().length() > 0 ){				
			File imagedir = new File(bulkData);
			if(imagedir == null || !imagedir.isDirectory()){ 
				imagedir.mkdir();
			}
			try {
				imageDirectoryPath = imagedir.getCanonicalPath();
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Error in getting BulkData Path", e);
				
			}
			
		}
		
		JsonElement modified = jdm.get("newAndModifiedOnly");
		boolean newAndModifiedOnly = true;
		if(modified != null){
			newAndModifiedOnly = modified.getAsBoolean();	
		}

		JsonElement dataSources = jdm.get("dataSources");
		List<OpenSpiritScanDatasource> sources = new ArrayList<OpenSpiritScanDatasource>();
		if(dataSources == null){
			String msg = "The Data Sources is not available from job data for job " + jobName;
			logger.error(msg);
			throw new Exception(msg);
		}else{
			JsonArray dataSourcesArray = JsonUtil.convertToJsonArray(dataSources);
			for (JsonElement jsonElement : dataSourcesArray) {
				JsonObject dataSource = jsonElement.getAsJsonObject();
				String datasourceType = dataSource.get("dataSourceType").getAsString();
				String datasourceTypeVersion = dataSource.get("dataSourceTypeVersion").getAsString();
				String datasourceName = dataSource.get("dataSourceName").getAsString();
				JsonElement project = dataSource.get("projectName");
				OpenSpiritScanDatasource scanDatasource;
				if(project != null  && project.getAsString().length() > 0){
					String projectName = project.getAsString();
					scanDatasource = new OpenSpiritScanDatasource(datasourceType, datasourceTypeVersion, datasourceName, projectName);
				}else{
					scanDatasource = new OpenSpiritScanDatasource(datasourceType, datasourceTypeVersion, datasourceName);
				}
				logger.info("Adding the data source " + scanDatasource.toString());
				sources.add(scanDatasource);	
			}
		}
				
		if(update && run){
			logger.info("update && run  calling updateAndRunJob" );
			OpenSpiritIndexJobProcessor.getInstance().updateAndRunJob(jobName, jobDescription, logLevelObj,
					sources, modelViewName.getAsString(), modelViewVersion,
					solrHost.getAsString(), solrPort.getAsString(), solrCollectionName.getAsString(), newAndModifiedOnly, webInfPath,imageDirectoryPath);
		}else if (update && !run){
			logger.info("update && !run  calling updateJob" );
			OpenSpiritIndexJobProcessor.getInstance().updateJob(jobName, jobDescription, logLevelObj,
					sources, modelViewName.getAsString(), modelViewVersion,
					solrHost.getAsString(), solrPort.getAsString(), solrCollectionName.getAsString(), newAndModifiedOnly, webInfPath, imageDirectoryPath);
		}else if(!update && run){
			logger.info("!update && run  calling createAndRunJob" );
			OpenSpiritIndexJobProcessor.getInstance().createAndRunJob(jobName, jobDescription, logLevelObj,
					sources, modelViewName.getAsString(), modelViewVersion,
					solrHost.getAsString(), solrPort.getAsString(), solrCollectionName.getAsString(), newAndModifiedOnly, webInfPath, imageDirectoryPath);
		}else if (!update && !run){
			logger.info("!update && !run  calling createJob" );
			OpenSpiritIndexJobProcessor.getInstance().createJob(jobName, jobDescription, logLevelObj,
					sources, modelViewName.getAsString(), modelViewVersion,
					solrHost.getAsString(), solrPort.getAsString(), solrCollectionName.getAsString(), newAndModifiedOnly, webInfPath, imageDirectoryPath);
		}
	}

	@POST
	@Path("/run")
	@Consumes(MediaType.APPLICATION_JSON)
	public String runOpenSpiritIndexJob(String payLoad, @Context HttpServletRequest request) throws Exception{		
		logger.info("In service: /jobs/openspirit/indexer/run and method: runOpenSpiritIndexJob");		
		
		Map<String, String> elementsMap = this.checkAndGetPayloadElements(payLoad);
		
		String jobName = elementsMap.get("jobName");
		if(jobName == null || jobName.length() < 1){
			String msg = "Job Name is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}

		logger.info("Starting the open spirit index job: " + jobName + " ");
		OpenSpiritIndexJobProcessor.getInstance().runJob(jobName);				
		return "Done";
	}
	
	private Map<String, String> checkAndGetPayloadElements(String payLoad) throws Exception {
		logger.info("Input payload is: " + payLoad);
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);	
		if(elementsMap == null || elementsMap.isEmpty()){
			String msg = "The input payload is not a expected json string";
			logger.error(msg);
			throw new Exception(msg);
		}
		
		logger.info("Number of elements in input json : " + elementsMap.size() + " ");		
		debug(elementsMap);
		return elementsMap;
	}

	private void checkJobNameAndJobRunID(Map<String, String> elementsMap) throws Exception{
		String jobName = elementsMap.get("jobName");
		if(jobName == null || jobName.length() < 1){
			String msg = "Job Name is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			throw new Exception(msg);
		}
		
		String jobRunID = elementsMap.get("jobRunID");
		if(jobRunID == null || jobRunID.length() < 1){
			String msg = "Job run id is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			throw new Exception(msg);
		}
	}
	
	private void debug(Map<String, String> elementsMap) {
		//Just for debug		
		for (Map.Entry<String, String> entry: elementsMap.entrySet()){
			String key = entry.getKey();
			String value =  entry.getValue();				
			logger.info("Key: " + key + " Value: " + value);
		}
	}
	
	private String getFormatedUTCTime(String strDate) throws Exception{		
		if (strDate == null || strDate.length() <=0 ) { 
			return null;
		}
		
		Date dateObj=null;
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa");
		try {
			dateObj = (Date)formatter.parse(strDate);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
			
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.sss'Z'");
		df.setTimeZone(TimeZone.getTimeZone("UTC"));				
		String retStrDate = df.format(new Date(dateObj.getTime())).toString();
		
		return retStrDate;
	}
	
	/*
	
	private String getFormatedUTCTime(String strDate) throws Exception{
		
		//DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");	  
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.sss'Z'");
		DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss aa");
		if (strDate == null || strDate.length() <=0 ) { 
			return null;
		}
		Date dateObj=null;
		try {
			dateObj = (Date)formatter.parse(strDate);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		String retStrDate = df.format(new Date(dateObj.getTime())).toString();
		return retStrDate;
	} */


}
