package com.bct.geodatafy.rest.service;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import org.apache.log4j.Logger;

import com.bct.geodatafy.util.EnvUtil;


@Path("/getWindowsService")
public class WindowsService {
	static Logger logger = Logger.getLogger(WindowsService.class);
	
	@POST
	@Path("/userName")
	@Consumes(MediaType.APPLICATION_JSON)
	public String getServiceUserName() throws Exception{ 
		//Input payload contains all the job and job data details
		logger.info("In service /getWindowsService/userName and in method WindowsService.");
		//logger.info("Input payload is: " + payLoad);
		//JsonObject jobObject = getJsonObject(payLoad);
		String strGDPath = getGDInstallationPath();
		strGDPath = strGDPath.substring(0, strGDPath.lastIndexOf("\\"));
		String nssmPath= strGDPath + "\\nssm-2.24\\win64\\nssm.exe";
		
		String strToExecute = "\"" + nssmPath + "\"" + " get \"Geodatafy\" ObjectName";
		logger.info(" get Service User Name command to run " + strToExecute);
		
		try {
			
			Runtime rn = Runtime.getRuntime();
			logger.info("after getRuntime : ");
			Process p = rn.exec(strToExecute);
			logger.info("after Process exec : ");
			BufferedReader stdInput = new BufferedReader(new 
				     InputStreamReader(p.getInputStream()));

				BufferedReader stdError = new BufferedReader(new 
				     InputStreamReader(p.getErrorStream()));

				// read the output from the command
				System.out.println("Here is the standard output of the command:\n");
				String str = null;
				StringBuffer strBuffer = new StringBuffer(); 
				while ((str = stdInput.readLine()) != null) {
				    System.out.println(str);
				    strBuffer.append(str);
				    
				}
				String s = null;
				// read any errors from the attempted command
				logger.info("Here is the standard error of the command (if any):\n");
				while ((s = stdError.readLine()) != null) {
				    logger.info(s);
				}
			//StreamGobbler errorGlobber = new StreamGobbler(p.getErrorStream(), "CMDTOOL-E");
			//StreamGobbler outputGlobber = new StreamGobbler(p.getInputStream(), "CMDTOOL-O");
			logger.info("before Strean start to read : ");
			//errorGlobber.start();
			//outputGlobber.start();
			int exitVal = p.waitFor();
			 logger.info("Process ExitValue: " + exitVal);
			if(exitVal==0) {
				 logger.info("Before Return " + strBuffer.toString());
				return strBuffer.toString();
			} else {
				String errMsg = "Issue in execution of getting windows service username ";
				return errMsg;
			
			}

		} catch (Exception e) {
			String errMsg = "Exception during execution of getting windows service username";
			logger.error(errMsg);
			logger.error("The Error is " + e.getMessage());
			e.printStackTrace();
			return errMsg;
		}

		
		
	}
	
	@POST
	@Path("/programDataPath")
	@Consumes(MediaType.APPLICATION_JSON)
	public String getProgramDataPath() throws Exception{ 
		//Input payload contains all the job and job data details
		logger.info("In service /getWindowsService/userName and in method WindowsService.");
		String programDataDir =  EnvUtil.getGDDataPath();;
		return programDataDir;		
		
	}
	
	
	
	
	
	
	
	
	@POST
	@Path("/restart")
	@Consumes(MediaType.APPLICATION_JSON)
	public String restartService() throws Exception{ 
		//Input payload contains all the job and job data details
		logger.info("In service /restartService and in method WindowsService.");
		//logger.info("Input payload is: " + payLoad);
		//JsonObject jobObject = getJsonObject(payLoad);
		//String nssmPath="C:\\Program Files\\Geodatafy\\nssm-2.24\\win64\\nssm.exe";
		
		String strGDPath = getGDInstallationPath();
		strGDPath = strGDPath.substring(0, strGDPath.lastIndexOf("\\"));
		String nssmPath= strGDPath + "\\nssm-2.24\\win64\\nssm.exe";
		
		
		
		
		//String strToExecute = "\"" + nssmPath + "\"" + " get \"Geodatafy\" ObjectName";
		String strToExecute = "\"" + nssmPath + "\"" + " restart \"Geodatafy\" ";
		logger.info("Service rstart EXE command to run " + strToExecute);
		
		try {
			
			Runtime rn = Runtime.getRuntime();
			logger.info("after getRuntime : ");
			Process p = rn.exec(strToExecute);
			logger.info("after Process exec : ");
			BufferedReader stdInput = new BufferedReader(new 
				     InputStreamReader(p.getInputStream()));

				BufferedReader stdError = new BufferedReader(new 
				     InputStreamReader(p.getErrorStream()));

				// read the output from the command
				System.out.println("Here is the standard output of the command:\n");
				String str = null;
				StringBuffer strBuffer = new StringBuffer(); 
				while ((str = stdInput.readLine()) != null) {
				    System.out.println(str);
				    strBuffer.append(str);
				    
				}
				String s = null;
				// read any errors from the attempted command
				logger.info("Here is the standard error of the command (if any):\n");
				while ((s = stdError.readLine()) != null) {
				    System.out.println(s);
				}
			//StreamGobbler errorGlobber = new StreamGobbler(p.getErrorStream(), "CMDTOOL-E");
			//StreamGobbler outputGlobber = new StreamGobbler(p.getInputStream(), "CMDTOOL-O");
			logger.info("before Strean start to read : ");
			//errorGlobber.start();
			//outputGlobber.start();
			int exitVal = p.waitFor();
			logger.info("service restart Process ExitValue: " + exitVal);
			if(exitVal==0) {
				 logger.info("Before Return " + strBuffer.toString());
				return strBuffer.toString();
			} else {
				String errMsg = "Issue in execution of getting windows service username ";
				return errMsg;
			
			}

		} catch (Exception e) {
			String errMsg = "Exception occurred during execution of getting windows service username";
			logger.error(errMsg);
			logger.error("The Error is " + e.getMessage());
			e.printStackTrace();
			return errMsg;
		}

		
		
	}
	public String getGDInstallationPath() {
		try {
			
			 Runtime rn = Runtime.getRuntime();
			 String sysdir = System.getenv("WINDIR") + "\\system32\\inetsrv";

			String strCommand = sysdir + "\\appcmd.exe list app \"Geodatafy/\" /text:[path='/'].physicalPath";
			
			 Process p = rn.exec("cmd /c " + strCommand);
			
			 BufferedReader stdInput = new BufferedReader(new 
				     InputStreamReader(p.getInputStream()));

				BufferedReader stdError = new BufferedReader(new 
				     InputStreamReader(p.getErrorStream()));

				// read the output from the command
				System.out.println("Here is the standard output of the command:\n");
				String str = null;
				StringBuffer strBuffer = new StringBuffer(); 
				while ((str = stdInput.readLine()) != null) {
				    System.out.println(str);
				    strBuffer.append(str);
				    
				}
				String s = null;
				// read any errors from the attempted command
				System.out.println("Here is the standard error of the command (if any):\n");
				while ((s = stdError.readLine()) != null) {
				    System.out.println(s);
				}
			//StreamGobbler errorGlobber = new StreamGobbler(p.getErrorStream(), "CMDTOOL-E");
			//StreamGobbler outputGlobber = new StreamGobbler(p.getInputStream(), "CMDTOOL-O");
			logger.info("before Strean start to read : ");
			//errorGlobber.start();
			//outputGlobber.start();
			int exitVal = p.waitFor();
			 System.out.println("Process ExitValue: " + exitVal);
			if(exitVal==0) {
				 System.out.println("Before Return " + strBuffer.toString());
				return strBuffer.toString();
			} else {
				String errMsg = "Issue in execution of getting windows service username ";
				//return errMsg;
				return null;
			
			}

		} catch(Exception e) {
			e.printStackTrace();
			return null;
		}
		
	}
	public static void main(String args[]) throws Exception {
		WindowsService w = new WindowsService();
		//String strGDPath = w.getServiceUserName();
		w.getGDInstallationPath();
		//strGDPath = strGDPath.substring(0, strGDPath.lastIndexOf("\\"));

		System.out.println("$$$$$$$$$" );
		/*String pgStr = System.getenv("ProgramFiles");
		System.out.println(pgStr);
		//String strOutput = w.getServiceUserName();
		//Runtime.getRuntime().exec("cmd /c \"runas /savecred /user:theDomain\\administrator yourCommand\"");
		String path = "cmd /c  start C://Users//lg111891//Desktop//Build.bat";
		String nssmPath= pgStr + "\\Geodatafy\\nssm-2.24\\win64\\nssm.exe";
		
		String strToExecute = "\"" + nssmPath + "\"" + " restart \"Geodatafy\" ";
		try {
			// Runtime.getRuntime().exec("runas /profile /user:Administrator \"cmd.exe \"");
			 Runtime rn = Runtime.getRuntime();
			// Process p = Runtime.getRuntime().exec("powershell -command \"Get-ItemProperty HKLM:\\Software\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* | Select-Object DisplayName, DisplayVersion, Publisher, InstallDate | Format-Table �AutoSize\"");
			 
			 Process p = Runtime.getRuntime().exec("powershell -command \"Get-ItemProperty HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* | Select-Object DisplayName, InstallLocation, DisplayVersion, Publisher, InstallDate | Format-Table �AutoSize\"");
			// Process p = rn.exec("cmd /c  start java -jar d:\\import-export.jar -s http://192.168.2.231/solr/metadata -a export -o /tmp/metadata.json");
			// Process p = Runtime.getRuntime().exec("powershell.exe Start-Process notepad.exe -verb RunAs");
			 BufferedReader stdInput = new BufferedReader(new 
				     InputStreamReader(p.getInputStream()));

				BufferedReader stdError = new BufferedReader(new 
				     InputStreamReader(p.getErrorStream()));

				// read the output from the command
				System.out.println("Here is the standard output of the command:\n");
				String str = null;
				StringBuffer strBuffer = new StringBuffer(); 
				while ((str = stdInput.readLine()) != null) {
				    System.out.println(str);
				    strBuffer.append(str);
				    
				}
				String s = null;
				// read any errors from the attempted command
				System.out.println("Here is the standard error of the command (if any):\n");
				while ((s = stdError.readLine()) != null) {
				    System.out.println(s);
				}
			StreamGobbler errorGlobber = new StreamGobbler(p.getErrorStream(), "CMDTOOL-E");
			StreamGobbler outputGlobber = new StreamGobbler(p.getInputStream(), "CMDTOOL-O");
			logger.info("before Strean start to read : ");
			errorGlobber.start();
			outputGlobber.start();
			int exitVal = p.waitFor();
			 System.out.println("Process ExitValue: " + exitVal);
			if(exitVal==0) {
				 System.out.println("Before Return " + strBuffer.toString());
				//return strBuffer.toString();
			} else {
				String errMsg = "Issue in execution of getting windows service username ";
				//return errMsg;
			
			}

		} catch(Exception e) {
			e.printStackTrace();
		}*/
		System.out.println("*************");
		//System.out.println(strOutput);
	}
	
	
	
	



}


