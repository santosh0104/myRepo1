package com.bct.geodatafy.rest.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
//import java.nio.file.Files;
//import java.nio.file.Paths;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.FileEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.WinHttpClients;
import org.apache.log4j.Logger;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.client.solrj.util.ClientUtils;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.SolrInputDocument;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;







import com.bct.geodatafy.las.LasFile;
import com.bct.geodatafy.las.LasUnitUtil;
import com.bct.geodatafy.las.LasWell;

import com.bct.geodatafy.job.GeodatafyJobLog;
import com.bct.geodatafy.job.GeodatafyJobRun;
import com.bct.geodatafy.job.document.DocumentIndexJob;
import com.bct.geodatafy.job.document.DocumentIndexJobData;
import com.bct.geodatafy.job.document.DocumentIndexJobStatistics;
import com.bct.geodatafy.job.qc.project;
import com.bct.geodatafy.util.EnvUtil;
import com.bct.geodatafy.util.FileUtil;
import com.bct.geodatafy.util.JsonUtil;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;


@Path("/jobs/document/indexer")
public class DocumentJobService {
	static Logger logger = Logger.getLogger(DocumentJobService.class);
	public static final String JOB_TYPE = "DocumentIndexer";
	public static final int COMMIT_SIZE = 10;
	public static final String JOBS_COLLECTION = "jobs";
	private static final String DS_TYPENAME="Document";
	private static final String DS_TYPEVERSION="1";
    private static final int CONSTANT_64K = 64 * 1024;

	//private static final String DATASOURCE="Document";
	
	
	@POST
	@Path("/create")
	@Consumes(MediaType.APPLICATION_JSON)
	public String createDocumentIndexJob(String payLoad, @Context HttpServletRequest request) throws Exception{		
		logger.info("In service: /jobs/document/indexer/create and method: createDocumentIndexJob");		
		
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);
				
		String jobName = elementsMap.get("jobName");
		if(jobName == null || jobName.length() < 1){
			String msg = "Job Name is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}

		String jobData = elementsMap.get("jobData");
		if(jobData == null || jobData.length() < 1){
			String msg = "Job Data is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}

		logger.info("Creating the document index job: " + jobName + " ");
		//Logic to create a job in solr						
		return "Done";
	}

	@PUT
	@Path("/create")
	@Consumes(MediaType.APPLICATION_JSON)
	public String updateDocumentIndexJob(String payLoad, @Context HttpServletRequest request) throws Exception{		
		logger.info("In service: PUT /jobs/document/indexer/create and method: updateDocumentIndexJob");		
		
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);
				
		String jobName = elementsMap.get("jobName");
		if(jobName == null || jobName.length() < 1){
			String msg = "Job Name is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}

		String jobData = elementsMap.get("jobData");
		if(jobData == null || jobData.length() < 1){
			String msg = "Job Data is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}

		logger.info("Updating the open document index job: " + jobName + " ");
		//Logic to update the job in solr				
		return "Done";
	}
	
	@POST
	@Path("/run")
	@Consumes(MediaType.APPLICATION_JSON)
	public String runDocumentIndexJob(String payLoad
			, @Context HttpServletRequest request
			) throws Exception{		
		logger.info("In service: /jobs/document/indexer/run and method: runDocumentIndexJob");		
		
		logger.info("Input payload is: " + payLoad);
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);	
		if(elementsMap == null || elementsMap.isEmpty()){
			String msg = "The input payload is not a expected json string";
			logger.info(msg);
			return msg;
		}
		
		logger.info("Number of elements in input json : " + elementsMap.size() + " ");		
		debug(elementsMap);		
				
		String jobName = elementsMap.get("jobName");
		if(jobName == null || jobName.length() < 1){
			String msg = "Job Name is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}
		
		String jobType = elementsMap.get("jobType");
		if(jobType == null || jobType.length() < 1){
			String msg = "Job Type is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}
		
		String jobData = elementsMap.get("jobData");
		if(jobData == null || jobData.length() < 1){
			String msg = "Job Data is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}

		logger.info("Starting the document index job: " + jobName + " ");
		DocumentIndexJob indexJob = new DocumentIndexJob();
		indexJob.setJobName(jobName);
		indexJob.setJobType(jobType);
		
		String solrDocID = jobName + "_" + Long.toString(System.currentTimeMillis());
		indexJob.setSolrDocID(solrDocID);
		String logFileName = "logs\\" + solrDocID + ".log";
		
		//String programDataDir = System.getenv("GD_LOG_PATH");
		//String programDataDir = EnvUtil.getGDLogPath();
		String programDataDir = EnvUtil.getGDLogPath();
		logger.info("ProgramData dir received from environment variable ProgramData is: " + programDataDir);
		
		if(programDataDir != null && !programDataDir.isEmpty()){				
				String logDir = programDataDir + "\\logs\\indexers\\document\\";
				logFileName = logDir + solrDocID + ".log";
		}

		String givenLogLevel = elementsMap.get("logLevel");
		String logLevel = GeodatafyJobLog.INFO;
		if(givenLogLevel != null && givenLogLevel.length() > 0){
			logLevel = givenLogLevel;	
		}
		
		GeodatafyJobLog jobLogger = new GeodatafyJobLog(logFileName, logLevel);
		indexJob.setLogFileName(logFileName);
		
		jobLogger.debug("Input Payload", payLoad);
		jobLogger.debug("Job Data from Input", jobData);

		DocumentIndexJobData indexJobData = constructJobData(jobData);
		indexJob.setJobDataString(jobData);
		indexJob.setJobData(indexJobData);
		indexJob.setJobStatus(DocumentIndexJob.JOB_RUNNING);
		indexJob.setStartTime(GeodatafyJobLog.getCurrentDateTime());		
		indexJob.setEndTime("");		

		String protocol = request.getScheme();
		//String protocol = null;
		if(protocol == null || protocol.isEmpty()){
			protocol = "http";
		}			

		String baseSolrURL = protocol + "://" + indexJobData.getSolrHost() + ":" + indexJobData.getSolrPort()+ "/solr";

		List<DocumentIndexJobStatistics> statistics = getJobStatistics(indexJobData, jobLogger);
		indexJob.setStatistics(statistics);
		if(statistics == null){
			indexJob.setJobStatus(DocumentIndexJob.JOB_ERROR);	
			uploadJobRunData(baseSolrURL, indexJob, jobLogger);
		}else if(statistics.size() == 0){
			jobLogger.info("No files", "Given directory does not have any matching files to index");
			indexJob.setJobStatus(DocumentIndexJob.JOB_COMPLETED);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());	
			uploadJobRunData(baseSolrURL, indexJob, jobLogger);
		}else{
			logger.info("Uploading the job run data before indexing.");
			uploadJobRunData(baseSolrURL, indexJob, jobLogger);
			indexFiles(baseSolrURL, indexJob, jobLogger);
			logger.info("Uploading the job run data after indexing.");	
			uploadJobRunData(baseSolrURL, indexJob, jobLogger);			
		}
		return "Done";
	}
	
	@POST
	@Path("/runs")	
	@Produces(MediaType.APPLICATION_JSON)
	public String getAllDocumentIndexJobRuns() throws Exception{		
		logger.info("In service: /jobs/document/indexer/runs and method: getAllDocumentIndexJobRuns");				

		//Query solr to get all the job runs and return as json
		//Use the same JobRun object
		List<GeodatafyJobRun> runs = new ArrayList<GeodatafyJobRun>();
		Gson gson = new Gson();
		gson.toJson(runs);
		return "";
	}

	@POST
	@Path("/runs/get/statistics")
	@Consumes(MediaType.APPLICATION_JSON)
	public String getDocumentIndexJobStatistics(String payLoad) throws Exception{		
		logger.info("In service: /jobs/document/indexer/runs/get/statistics and method: getDocumentIndexJobStatistics");
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);
		elementsMap.get("jobName");
		elementsMap.get("jobID");
		
		//Create a html content with the statistics
		return "";
	}

	@POST
	@Path("/runs/get/log")	
	public String getDocumentIndexJobLog(String payLoad) throws Exception{		
		logger.info("In service: /jobs/document/indexer/runs/get/log and method: getDocumentIndexJobLog");
		
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);
		elementsMap.get("jobName");
		elementsMap.get("jobID");
		
		//Create a html content with the log file
		return "";
	}

	

	private void indexFiles(String baseSolrURL, DocumentIndexJob indexJob, GeodatafyJobLog jobLogger) {
		String solrUrl = baseSolrURL + "/" + indexJob.getJobData().getSolrCollectionName();	
		logger.info("The solr url to call for the collection upload " + solrUrl);
		List<DocumentIndexJobStatistics> statistics = indexJob.getStatistics();
		
		boolean isWebAccess = indexJob.getJobData().isWebAccess(); 
		boolean isFileAccess = indexJob.getJobData().isFileAccess();
		String rootFolder = indexJob.getJobData().getRootFolder();
		
		String virtualPath = "";
		if(isWebAccess){
			//virtualPath = "http://" + indexJob.getJobData().getSolrHost() + ":" + 
				//	indexJob.getJobData().getSolrPort() + "/" + indexJob.getJobData().getVirtualPathName();
			virtualPath = "/" + indexJob.getJobData().getVirtualPathName();
			logger.info("The virtual path base is: " + virtualPath);
		}
		
		ZonedDateTime now = ZonedDateTime.now(ZoneOffset.UTC);
		String Last_Indexed_DateTime = now.toString();
		
		for (DocumentIndexJobStatistics statistic: statistics){						
			List<String> fileNames =  statistic.getFileNames();
			
			int total = fileNames.size();
			int processed = 0;
			int failed = 0;				

			for (int k = 0; k < total; k++){
				String fileName = fileNames.get(k);
				File file = new File(fileName);
				try{
					CloseableHttpClient httpClient = WinHttpClients.createDefault();
					logger.info("FileName: " + fileName);
					jobLogger.info("Processing file.", fileName);
					
					 LocalDateTime localDateTime = LocalDateTime.ofInstant(new Date(file.lastModified()).toInstant(), ZoneId.systemDefault());
					 ZonedDateTime utc = ZonedDateTime.of(localDateTime, ZoneOffset.UTC);
				
					String LastModified_DateTime = utc.toString();
					jobLogger.info("Processing file LastModified DateTime.", LastModified_DateTime);
					String docId = encodeURLStr(fileName);								
					logger.info("The docId is: " + docId);

					//String param = "literal.Last_Indexed_DateTimeNow=" + Last_Indexed_DateTime + "&literal.id=" + docId + "&literal.datatype=document&commit=false&overwrite=true";
					String param = "literal.Last_Indexed_DateTime=" + Last_Indexed_DateTime +  "&literal.Last_Modified_DateTime=" + LastModified_DateTime + "&literal.id=" + docId + "&literal.datatype=Document&commit=false&overwrite=true&lowernames=false";
					
					if(k + 1 == (total) || (((k + 1) % COMMIT_SIZE) == 0)){
						//param = "literal.Last_Indexed_DateTime=" + Last_Indexed_DateTime + "&literal.id=" + docId +  "&literal.datatype=document&commit=true&overwrite=true";
						param = "literal.Last_Indexed_DateTime=" + Last_Indexed_DateTime +  "&literal.Last_Modified_DateTime=" + LastModified_DateTime +  "&literal.id=" + docId +  "&literal.datatype=Document&commit=true&lowernames=false&overwrite=true";
					}
					logger.info("The param is: " + param);
					
					if(isWebAccess){
						logger.info("The  file name is: " + fileName);
						logger.info("The rootFolder is: " + rootFolder);
						File dir = new File(rootFolder);
						logger.info("The rootFolder is: " + dir.getCanonicalPath());
						String virtualFileName = fileName.replace(dir.getCanonicalPath(), "");
						logger.info("The virtual file name is: " + virtualFileName);
						if(virtualFileName.startsWith("\\")){
							virtualFileName = virtualPath + virtualFileName;								
						}
						else{
							virtualFileName = virtualPath + "\\" + virtualFileName;
						}								
						virtualFileName = virtualFileName.replace("\\", "/").replace("%", "%25").replace("#", "%23");
						//virtualFileName = virtualFileName.replace(" ", "%20");

						param = param + "&literal.url=" + encodeURLStr(virtualFileName);
						logger.info("The virtual file name is: " + encodeURLStr(virtualFileName));
					}		
					if(isFileAccess){
						String UNCFileName = file.toURI().toString();
						param = param + "&literal.url=" + UNCFileName.replace("&", "%2526").replace("+", "%252B").replace("%23", "%2523");
						//param = param + "&literal.url=" + encodeURLStr(UNCFileName.replace("#", "%23").replace("&", "%26").replace("+", "%2B"));
						logger.info("The UNC File Path is: " + UNCFileName);
						logger.info("The UNC File Path is: " + encodeURLStr(UNCFileName));
					}		

					String projectName = indexJob.getJobData().getProjectName();
		
					
					
					param = param + "&literal.DataSourceTypeName=" + DS_TYPENAME;
					param = param + "&literal.DataSourceTypeVersion=" + DS_TYPEVERSION;
					param = param + "&literal.DataSource=" + encodeURLStr(indexJob.getJobName());
					param = param + "&literal.Project=" + encodeURLStr(projectName);
				
					//param = ClientUtils.escapeQueryChars(param);
					//param = encodeURLStr(param);
					String fileExtn = FileUtil.getExtensionOfFile(fileName);
					logger.info("fileExtn is: " + fileExtn);
					String lasFileContentStr = null;
					if(fileExtn.equalsIgnoreCase(".las")) {
						logger.info("Inside if las");
						try {
							LasFile lasFile = new LasFile(fileName, false);
							List<String> logNames=  lasFile.getLogNames();
							
							LasWell well = lasFile.getWell();
							String wellCommonName = well.getCommonName();
							
							param = param + "&literal.WellboreName=" + encodeURLStr(well.getName());
							
							String wellUWI = well.getUWI();
							if(wellUWI!=null && wellUWI.length() > 0 ) {
								param = param + "&literal.WellboreUWI=" + encodeURLStr(wellUWI);
							} else {
								param = param + "&literal.WellboreUWI=" + encodeURLStr(well.getAPI());
							}
							if(logNames!=null  && logNames.size() > 0 ) {
								param = param + "&literal.Logs=" + String.join(",", lasFile.getLogNames());;
							}	
							
							String topStr =   null;
							String bottomStr = null;
							// if top and bottom are in feet we want to convert to meters
							if ( lasFile.getStepUnit().equals("ft")){
								topStr =     Float.toString( LasUnitUtil.convertFeetToMeters( lasFile.getStrt() ) );
								bottomStr =  Float.toString( LasUnitUtil.convertFeetToMeters( lasFile.getStop() ) );
							}
							else {
								topStr =   Float.toString( lasFile.getStrt() );
								bottomStr =  Float.toString( lasFile.getStop() );
							}			
							
							param = param + "&literal.Top=" + topStr;
							param = param + "&literal.Bottom=" + bottomStr;
							if(well.getLastModified()!=null ) {
								param = param + "&literal.Last_Modified_DateTime=" + getFormatedUTCTime(well.getLastModified().toString());
							}
							param = param + "&literal.Content-Type=" + "text/las";
							lasFileContentStr = lasFile.getTextHeader();
							
							
						} catch (Exception e) {
							logger.error("Exception during reading LAS file", e);
							e.printStackTrace();
						}
						
					} 

					String postRequest = solrUrl + "/update/extract?" + param;
					
					logger.info("The post request string is: " + postRequest);
					//jobLogger.info("The post request string", postRequest);
					HttpPost post = new HttpPost(postRequest);
		
					if(fileExtn.equalsIgnoreCase(".las")) {						
						StringEntity entity =  new StringEntity(lasFileContentStr);
						post.setEntity(entity);	
							
					} else {
						FileEntity entity =  new FileEntity(new File(fileName));
						post.setEntity(entity);
					}
					 
					//entity.setContentType("application/octet-stream");
					
					
			    	CloseableHttpResponse response = httpClient.execute(post);
			    	logger.info("The response to add/update is: " + response.toString());
			    	if(response.getStatusLine().getStatusCode() == HttpURLConnection.HTTP_OK){
			    		jobLogger.info("Processed successfully.", fileName);
			    		processed++;
			    	}else{
			    		jobLogger.warn("Processing failed.", fileName);
			    		StringBuffer strBuffer = new StringBuffer();
						 BufferedReader rd = new BufferedReader(new InputStreamReader(
				                    response.getEntity().getContent()));
				            String line = "";
				            while ((line = rd.readLine()) != null) {
				            	strBuffer.append(line);
				            }
				            logger.info(strBuffer.toString());
			    		jobLogger.warn("Processing failed response .", strBuffer.toString());
			    		failed++;
			    	}
				}
				catch(Exception e){
					logger.error(e.getMessage());
					logger.error(e.getStackTrace().toString());
					jobLogger.error("Processing failed for", fileName);
					jobLogger.error("IO Exception while processing " + fileName, e.getStackTrace().toString());
					
					failed++;					
				}
			}
			statistic.setSuccessful(processed);
			statistic.setFailed(failed);
			statistic.setSkipped(total-processed-failed);
		}
		boolean isProjectUpdated =  updateProject( baseSolrURL,  indexJob,  jobLogger);
		if(isProjectUpdated) {
			indexJob.setJobStatus(DocumentIndexJob.JOB_COMPLETED);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
		} else {
			indexJob.setJobStatus(DocumentIndexJob.JOB_ERROR);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
		}
			
	}
	private  String encodeURLStr(String str) {
			try {
			//str = URIUtil.encodeQuery(str).replace("&", "%26");
			//str = URIUtil.encodeQuery(str).replace("&", "%26").replace("+", "%2B");
			str = URLEncoder.encode(str.replace("+", "%2B"), "UTF-8").replace("+", "%20");
			
		} catch(Exception e) {
			return null;
		}
		return str;
		
	}
	private boolean updateProject(String baseSolrURL, DocumentIndexJob indexJob, GeodatafyJobLog jobLogger) {	
		
		boolean result = false;
		try {
			DocumentIndexJobData indexJobData = indexJob.getJobData();
			jobLogger.info("Updating the Project Document", indexJobData.getProjectName());
			String projCollection = getProjectCollection(indexJobData.getSolrHost(), indexJobData.getSolrPort());
			String defaultRuleSet = getDefaultRuleSet(indexJobData.getSolrHost(), indexJobData.getSolrPort());
			System.out.println("Collection for Project  :  " + projCollection);
			String solrUrl = baseSolrURL + "/" + projCollection;	
			logger.info("solrUrl  :  " + solrUrl);
			//String solrMetadataCollectionUrl = "http://" + host + ":" + port + "/solr/metadata";
			CloseableHttpClient httpClient = WinHttpClients.createDefault();
			HttpPost post = new HttpPost(solrUrl + "/update/json?wt=json&commitWithin=1&overwrite=true");
			//CloseableHttpClient httpClient = WinHttpClients.createDefault();
			/*HttpSolrClient m_solrDataCollection =   (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(solrUrl)).withHttpClient(httpClient).build();
					SolrInputDocument projDoc = new SolrInputDocument();
					
					String id = indexJobData.getRootFolder();
					projDoc.addField("id", id);
					projDoc.addField("Name", indexJobData.getProjectName());
					projDoc.addField("DataSource", DATASOURCE);
					projDoc.addField("DataSourceTypeName", DS_TYPENAME);
					projDoc.addField("DataSourceTypeVersion", DS_TYPEVERSION);
					projDoc.addField("datatype", "Project");
					projDoc.addField("ProjectPath", id);
					LocalDateTime localDateTime = LocalDateTime.ofInstant(new Date().toInstant(), ZoneId.systemDefault());
					ZonedDateTime utc = ZonedDateTime.of(localDateTime, ZoneOffset.UTC);				
					String Last_Indexed_DateTime = utc.toString();					
					projDoc.addField("Last_Indexed_DateTime", Last_Indexed_DateTime);						
					logger.info(projDoc.toString());					
					m_solrDataCollection.add(projDoc);	
					m_solrDataCollection.commit(); */
			JSONObject projDoc = new JSONObject();
			
			String id = indexJobData.getRootFolder();
			projDoc.put("id", id);
			projDoc.put("Project", indexJobData.getProjectName());
			projDoc.put("DataSource", indexJob.getJobName());
			projDoc.put("DataSourceTypeName", DS_TYPENAME);
			projDoc.put("DataSourceTypeVersion", DS_TYPEVERSION);
			projDoc.put("datatype", "Project");
			projDoc.put("qcRuleSet", defaultRuleSet);
			projDoc.put("ProjectPath", id);
			LocalDateTime localDateTime = LocalDateTime.ofInstant(new Date().toInstant(), ZoneId.systemDefault());
			ZonedDateTime utc = ZonedDateTime.of(localDateTime, ZoneOffset.UTC);				
			String Last_Indexed_DateTime = utc.toString();					
			projDoc.put("Last_Indexed_DateTime", Last_Indexed_DateTime);						
			logger.info(projDoc.toString());	
			jobLogger.info(projDoc.toString(), "");
				StringEntity entity  = new StringEntity("["+projDoc.toString()+"]", "UTF-8");
				entity.setContentType("application/json");
				post.setEntity(entity);
		    	//logger.warn("Adding the job run data to solr " + content);
		    	CloseableHttpResponse response = httpClient.execute(post);
		    	logger.info("Added the Project Document to solr and the response is: " + response.toString());
		    	jobLogger.info("Added the Project Document to solr and the response is: " , response.toString());
		    	
				StringBuffer strBuffer = new StringBuffer();
				 BufferedReader rd = new BufferedReader(new InputStreamReader(
		                    response.getEntity().getContent()));
		            String line = "";
		            while ((line = rd.readLine()) != null) {
		            	strBuffer.append(line);
		            }
		            logger.info(strBuffer.toString());
		            JSONObject json = new JSONObject(strBuffer.toString());
		            
		            if (json.has("responseHeader")) {
		            	JSONObject jsonObj = json.getJSONObject("responseHeader");
		            	
		            	if((int)jsonObj.get("status") ==0 ) {
		            		logger.info("Successfully updated the project doc :      " + jsonObj.get("status"));
		            		jobLogger.info("Successfully updated the project doc :      " , "");
		            		return true;
		            	}  else {
			            	throw new Exception("Exception in post request for updating project file");
			            }		
		            
		            	
		            } else {
		            	throw new Exception("Exception in post request for updating project file");
		            }	

		} catch (Exception e ) {	
			logger.error("  Status: FAILED");
			logger.error(e.getMessage(), e);	
			jobLogger.error("  Status: FAILED", "");
			jobLogger.error(e.getMessage(), "");	
			e.printStackTrace();
			result =  false;
		}	
		finally {
			
		}
		
		return result;
	}
	
	
private String getProjectCollection(String solarHost, String solarPort) throws Exception {		
		
		
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
				"http://" + solarHost + ":" + solarPort + "/solr/metadata" )).withHttpClient(httpClient).build();
		ArrayList<project> projList = new ArrayList<project>();
		try {
			
			SolrQuery query = new SolrQuery();
	
			query.setQuery("*:*"); // main query
			query.set("wt", "json");
			query.setRows(2147483647);
			query.addFilterQuery("datatype:datatype");
			query.addFilterQuery("name:Project");
							
						
			QueryResponse resp = client.query(query);
			logger.info("getProjectCollection  QueryResponse: " + resp.getResponse().toString());
			
			SolrDocumentList docList = resp.getResults();
			logger.info(" getProjectCollection QueryResponse Num : " + docList.getNumFound());
			if (docList.getNumFound() > 0 ) {			
				
					SolrDocumentList docs = resp.getResults();
					String solrCoreUrl =  null;
					for(SolrDocument doc : docs) {
						
						String datatypeName = (String) doc.getFieldValue("name");
						solrCoreUrl = (String) doc.getFieldValue("solrCoreUrl");
						solrCoreUrl = solrCoreUrl.substring(solrCoreUrl.lastIndexOf("/")+1);
						
					}	
					return solrCoreUrl;
			} else {
				throw new Exception();
			}
				
			
				
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error(e.getStackTrace().toString());
			logger.error("Exception during execution of Solar Query for getProjectCollection   ------>: " , e);
			e.printStackTrace();
			throw new Exception(e.getMessage());
			//return null;
		} finally {
			client.close();
			httpClient.close();
		}	
				
		//return null;
	
	}


private String getDefaultRuleSet(String solarHost, String solarPort) throws Exception {		
	
	
	CloseableHttpClient httpClient = WinHttpClients.createDefault();
	HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
			"http://" + solarHost + ":" + solarPort + "/solr/metadata" )).withHttpClient(httpClient).build();
	ArrayList<project> projList = new ArrayList<project>();
	try {
		
		SolrQuery query = new SolrQuery();

		query.setQuery("*:*"); // main query
		query.set("wt", "json");
		query.setRows(2147483647);
		query.addFilterQuery("datatype:qcRuleSet");
		query.addFilterQuery("default:true");
						
					
		QueryResponse resp = client.query(query);
		logger.info("getDefaultRuleSet  QueryResponse: " + resp.getResponse().toString());
		
		SolrDocumentList docList = resp.getResults();
		logger.info(" getDefaultRuleSet QueryResponse Num : " + docList.getNumFound());
		if (docList.getNumFound() > 0 ) {			
			
				SolrDocumentList docs = resp.getResults();
				String defRuleSet =  null;
				for(SolrDocument doc : docs) {
					
					defRuleSet = (String) doc.getFieldValue("qcRuleSet");
					
					
				}	
				return defRuleSet;
		} else {
			throw new Exception();
		}
			
		
			
	} catch (Exception e) {
		logger.error(e.getMessage());
		logger.error(e.getStackTrace().toString());
		logger.error("Exception during execution of Solar Query for getDefaultRuleSet   ------>: " , e);
		e.printStackTrace();
		throw new Exception(e.getMessage());
		//return null;
	} finally {
		client.close();
		httpClient.close();
	}	
			
	//return null;

}




	private List<DocumentIndexJobStatistics> getJobStatistics(DocumentIndexJobData indexJobData, GeodatafyJobLog jobLogger) throws IOException {
		
		List<DocumentIndexJobStatistics> statistics = new ArrayList<DocumentIndexJobStatistics>();
		String root = indexJobData.getRootFolder();
		logger.info("Root folder: " + root);
		jobLogger.info("Root folder", root);
		if (!Files.isDirectory(Paths.get(root))) {
			String msg = "The root folder specified " + root + " is null or not a directory.";
			logger.error(msg);
			jobLogger.error("Root folder error." , msg);
			return null;
		}

		List<String> extensions = indexJobData.getFileTypes();		
		if (extensions == null || extensions.size() < 1) {
			String msg = "There are no extensions specified.";
			logger.warn("Extensions: " + extensions);
			jobLogger.warn("Extensions ", "Extensions is null or empty.");
			return statistics;
		}

		boolean recurse = indexJobData.isRecurseFolder();
		List<String> allFiles = new ArrayList<String>();

		if(recurse){
			FileUtil.getFilesRecursively(root, extensions, allFiles);
		}else{
			FileUtil.getFiles(root, extensions, allFiles);
		}	

		if (allFiles == null || allFiles.size() < 1) {
			return statistics;
		}
		File dir = new File(root);
		logger.info("Looking for files indexed already in the Directory : " + dir.getCanonicalPath());
		Map<String, Object> solrDocMap = getIndexedDocsFromSolr(indexJobData.getSolrHost(), indexJobData.getSolrPort(), dir.getCanonicalPath(), indexJobData.getSolrCollectionName());
		for(String extension: extensions){
			List<String> extensionFiles = new ArrayList<String>();
			if(indexJobData.getOnlyNew().equalsIgnoreCase("false")) {
				extensionFiles = getFileNames(allFiles, extension);
			} else {
				extensionFiles = getFileNames(allFiles, extension,solrDocMap);
			}
			 
			if(extensionFiles == null || extensionFiles.isEmpty()){
				jobLogger.info("Extension " + extension + " has no files", "");
				logger.info("Extension: " + extension + " has no files.");
				continue;
			}
			DocumentIndexJobStatistics statistic = new DocumentIndexJobStatistics(extension);
			statistic.setFileNames(extensionFiles);
			statistics.add(statistic);			
			StringBuilder fileLog = new StringBuilder();
			for(String file: extensionFiles){
				fileLog.append(file);
				fileLog.append(", ");
			}
			jobLogger.debug("Extension: " + extension, "File Names: " + fileLog.substring(0, fileLog.lastIndexOf(",") - 1));
			logger.info("Extension is: " + extension + " and the file Names are: " + fileLog.substring(0, fileLog.lastIndexOf(",")));
		}
		return statistics;
	}

	private List<String> getFileNames(List<String> files, String extension) throws IOException {
		List<String> fileNames = new ArrayList<String>();
		
		for(String file: files){
			System.out.println(file);
			if(extension.equalsIgnoreCase(FileUtil.getExtensionOfFile(file))){
				fileNames.add(file);
			}
		}
		return fileNames;
	}
	
	private Map<String, Object>  getIndexedDocsFromSolr(String solarHost, String solarPort, String root, String strCollectionName) {
		
		Map<String, Object> solrDocMap = new HashMap<String, Object>();
		try {
			CloseableHttpClient httpClient = WinHttpClients.createDefault();
			HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
					"http://" + solarHost + ":" + solarPort + "/solr/" + strCollectionName)).withHttpClient(httpClient).build();

			SolrQuery query = new SolrQuery();

			query.setQuery("*:*"); // main query
			query.set("wt", "json");
			query.setRows(2147483647);
			String rootRep = root.replace("\\", "\\\\");
			String rootRepColon = rootRep.replace(":", "\\:");
			String rootRepSpace = rootRepColon.replace(" ", "\\ ");
			
			String strQryBy = "id:" + rootRepSpace + "*";
			logger.info("strQryBy ----> " +   strQryBy);
			System.out.println(" strQryBy: " + strQryBy);
			query.setParam("fl", "id,Last_Indexed_DateTime");
			query.addFilterQuery(strQryBy, "datatype:Document");
			System.out.println(query.toQueryString());
			logger.info(query.toQueryString());
			QueryResponse resp = client.query(query);
			System.out.println(" QueryResponse: " + resp.getResponse().toString());
			logger.info(" QueryResponse: " + resp.getResponse().toString());
			SolrDocumentList docList = resp.getResults();
			JSONObject returnResults = new JSONObject();
			
			for (Map singleDoc : docList) {
				JSONObject json = new JSONObject(singleDoc);
				String key = (String) json.get("id");
				Date lastIndexedOn = (Date) json.get("Last_Indexed_DateTime");
				//logger.info(" key: " + key);
				solrDocMap.put(key, lastIndexedOn);

			}
			returnResults.put("docs", solrDocMap);
			
		} catch (Exception e) {
			logger.info("Exception during execution of Solar Query for getIndexedSolrDocs   ------>: " ,  e);
			e.printStackTrace();			
			return solrDocMap;
		} finally {

		}		
		return solrDocMap;

	}
	

	
	private List<String> getFileNames(List<String> files, String extension, Map<String, Object> solrDocMap ) throws IOException {
		logger.info(" Start of getFileNames: " );
		List<String> fileNames = new ArrayList<String>();		
		for(String file: files){
			logger.info(file);
			logger.info(FileUtil.getExtensionOfFile(file));
			if(extension.equalsIgnoreCase(FileUtil.getExtensionOfFile(file))){
				logger.info("11111");
				//String repFile = file.replace("\\", "\\\\");
				logger.info(file);
				logger.info(solrDocMap.containsKey(file));
				if (solrDocMap.containsKey(file)) {
					logger.info(" solrDocMap.containsKey : " + file );					
					Date lastIndexedOn  =  (Date) solrDocMap.get(file);					
					if (lastIndexedOn==null) {
						fileNames.add(file);						
					} else {
						logger.info("lastIndexedOn is not null and compare");
						logger.info(lastIndexedOn.getTime());
						File selextedFile = new File(file);
						Long lastFileModified = selextedFile.lastModified();
						if( lastFileModified > lastIndexedOn.getTime()) {
							logger.info(file  +  " lastFileModified  " + new Date(lastFileModified).toString());
							fileNames.add(file);
						}
					}
				} else {
					fileNames.add(file);						
				}
				
			}
		}
		return fileNames;
	}


	private DocumentIndexJobData constructJobData(String jobData) throws Exception
	{
		Map<String, JsonElement> jdm = JsonUtil.getJsonElementMap(jobData);
		
		JsonElement rootFolderElement = jdm.get("rootFolder");
		if(rootFolderElement == null || rootFolderElement.getAsString().length() < 0){
			String msg = "The roort folder value is not available.";
			throw new Exception(msg);
		}				
		String rootFolder = rootFolderElement.getAsString();
		logger.info("The root folder is : " + rootFolder);
		
		JsonElement fileTypes = jdm.get("fileType");
		if(fileTypes == null){
			String msg = "Required file types is not defined.";
			throw new Exception(msg);
		}
		logger.info("File type string from input is : " + fileTypes);
		List<String> extensions = getExtensions(fileTypes);
		
		JsonElement recurseFolder = jdm.get("recurseFolder");
		boolean recurse = false;
		if(recurseFolder != null){
			recurse = recurseFolder.getAsBoolean();
		}else{
			logger.info("recurseFolder is not set. Assuming false");
		}
		logger.info("Recurse Folder is set to: " + recurse);
		
		
		JsonElement projectNameElement = jdm.get("projectName");
		if(projectNameElement == null || projectNameElement.getAsString().length() < 0){
			String msg = "The ProjectName  is not available.";
			throw new Exception(msg);
		}				
		String projectName = projectNameElement.getAsString();
		logger.info("The projectName is : " + projectName);
		
		
		String onlyNew = "true";
		if (jdm.get("newAndModifiedOnly") != null) {
			onlyNew = jdm.get("newAndModifiedOnly").getAsString();
		} else {
			logger.info("newAndModifiedOnly is not set. Assuming newAndModifiedOnly as true");
		}
		logger.info("newAndModifiedOnly is set to: " + onlyNew);
				
		String solrCollectionName = "document";
		if(jdm.get("solrCollectionName") != null){
			solrCollectionName = jdm.get("solrCollectionName").getAsString();
		}else{
			logger.info("solrCollectionName is not set. Assuming document");		
		}
		logger.info("solr Collection Name is set to: " + solrCollectionName);
		
		String solrHost = "localhost";
		if(jdm.get("solrHost") != null){
			solrHost = jdm.get("solrHost").getAsString();
		}else{
			logger.info("solr Host is not set. Assuming localhost");		
		}
		logger.info("solr host is set to: " + solrHost);

		String solrPort = "80";
		if(jdm.get("solrPort") != null){
			solrPort = jdm.get("solrPort").getAsString();
		}else{
			logger.info("solr Port is not set. Assuming 80");		
		}
		logger.info("solr Port is set to: " + solrPort);

		JsonElement webAccess = jdm.get("webAccess");
		boolean isWebAccess = false;
		if(webAccess != null){
			isWebAccess = webAccess.getAsBoolean();
		}else{
			logger.info("Web Access is not set. Assuming false");
		}
		logger.info("Web Access is set to: " + isWebAccess);

		String virtualPathName = "";
		if(isWebAccess){
			JsonElement virtualPath = jdm.get("virtualPathName");
			if(virtualPath == null || virtualPath.getAsString().length() < 0){
				String msg = "The virtual path name value is not available.";
				throw new Exception(msg);
			}				
			virtualPathName = virtualPath.getAsString();
			logger.info("Virtual Path Name is set to: " + virtualPathName);
		}
		
		JsonElement fileAccess = jdm.get("fileAccess");
		boolean isFileAccess = false;
		if(fileAccess != null){
			isFileAccess = fileAccess.getAsBoolean();
		}else{
			logger.info("File Access is not set. Assuming false");
		}
		logger.info("File Access is set to: " + isWebAccess);

		
		return new DocumentIndexJobData(rootFolder, recurse, extensions, solrHost, solrPort, solrCollectionName, isWebAccess, virtualPathName, onlyNew, projectName, isFileAccess);
	}

	private void uploadJobRunData(String baseSolrURL, DocumentIndexJob indexJob, GeodatafyJobLog jobLogger) {
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		HttpPost post = new HttpPost(baseSolrURL + "/" + JOBS_COLLECTION + "/update/json?wt=json&commitWithin=1000&overwrite=true");
		
		try {
			String content = getDocContents(indexJob, jobLogger);
			content = "{\"add\": { \"doc\": " + content + "}}";
			StringEntity entity  = new StringEntity(content, "UTF-8");
			entity.setContentType("application/json");
			post.setEntity(entity);

			jobLogger.info("Adding the job run data to solr", content);
	    	logger.info("Adding the job run data to solr " + content);
	    	CloseableHttpResponse response = httpClient.execute(post);
			jobLogger.info("Added the job run data to solr and the response ", response.toString());
			logger.info("Added the job run data to solr and the response is: " + response.toString());
	    	
		} catch (ClientProtocolException e) {			
			logger.error(e.getMessage());
			logger.error(e.getStackTrace().toString());
			jobLogger.error("ClientProtocolException", e.getMessage());
		} catch (IOException e) {
			logger.error(e.getMessage());
			logger.error(e.getStackTrace().toString());
			jobLogger.error("IOException", e.getMessage());
		}	 
	}
	
	private String getDocContents(DocumentIndexJob indexJob,  GeodatafyJobLog jobLogger){
	    StringBuilder sb = new StringBuilder();
	    sb.append("{");
	    sb.append("\"id\":\"" + indexJob.getSolrDocID() + "\", ");
	    sb.append("\"datatype\":\"" + DocumentIndexJob.SOL_DATA_TYPE + "\", ");
	    sb.append("\"jobRunID\":\"" + indexJob.getSolrDocID() + "\", ");
	    sb.append("\"jobName\":\"" + indexJob.getJobName() + "\", ");	    
	    sb.append("\"jobType\":\"" + indexJob.getJobType() + "\", ");
	    sb.append("\"jobStatus\":\"" + indexJob.getJobStatus() + "\", ");
	    sb.append("\"startTime\":\"" + indexJob.getStartTime() + "\", ");
	    sb.append("\"endTime\":\"" + indexJob.getEndTime() + "\", ");
	    sb.append("\"logFileName\":\"" + indexJob.getLogFileName().replace("\\", "\\\\\\\\") + "\", ");
	    
	    
	    //StringBuilder jobDetails = new StringBuilder();
		//jobDetails.append("{");
		//jobDetails.append("\\\"jobID\\\":\\\"" + indexJob.getSolrDocID() + "\\\", ");
		//jobDetails.append("\\\"jobName\\\":\\\"" + indexJob.getJobName() + "\\\", ");
		//jobDetails.append("\\\"jobType\\\":\\\"" + indexJob.getJobType() + "\\\", ");
		//jobDetails.append("\\\"jobStatus\\\":\\\"" +  indexJob.getJobStatus() + "\\\", ");
		//jobDetails.append("\\\"startTime\\\":\\\"" + indexJob.getStartTime() + "\\\", ");
		//jobDetails.append("\\\"endTime\\\":\\\"" + indexJob.getEndTime() + "\\\", ");
		//jobDetails.append("\\\"logFileName\\\":\\\"" + indexJob.getLogFileName().replace("\\", "\\\\\\\\") + "\\\"");
		//jobDetails.append("}");
		
	    //sb.append("\"jobDetails\":\"" + jobDetails.toString() + "\", ");
	    String jobData = indexJob.getJobDataString();
	    jobData = jobData.replace("\\", "\\\\");
	    jobData = jobData.replace("\"", "\\\"");
	    sb.append("\"jobData\":\"" + jobData + "\"");    
	    
		//logger.info("The job details string is: " + jobDetails );
		//logger.info("The job data is: " + jobData);
		//jobLogger.debug("The job details string",  jobDetails.toString());
		//jobLogger.debug("The job data", jobData);	
	    if(indexJob.getStatistics() != null && indexJob.getStatistics().size() > 0){
	    	StringBuilder stat = new StringBuilder();
	    	stat.append("[");
	    	for(int i = 0; i < indexJob.getStatistics().size(); i++){
	    		DocumentIndexJobStatistics jobStatistics = indexJob.getStatistics().get(i);
	    		stat.append("\"{");
	    		stat.append("\\\"type\\\":\\\"" + jobStatistics.getExtension());
	    		stat.append("\\\", \\\"total\\\":" + jobStatistics.getTotal());
	    		stat.append(", \\\"successful\\\":" + jobStatistics.getSuccessful());
	    		stat.append(", \\\"skipped\\\":" + jobStatistics.getSkipped());
	    		stat.append(", \\\"failed\\\":" + jobStatistics.getFailed());
	    		if(i == (indexJob.getStatistics().size() - 1)){
	    			stat.append("}\"");
	    		}else{
	    			stat.append("}\",");
	    		}	    		
	    	}
	    	stat.append("]");
	    	logger.info("The job Statistics is: " + stat.toString());
	    	sb.append(",\"jobStatistics\":" + stat.toString());
	    }
    	sb.append("}");
    	
		//logger.info("Complete json is: " + sb.toString() );
		//jobLogger.debug("Complete json is: ", sb.toString() );
		//System.out.println("Complete json is: " + sb.toString() );

    	return sb.toString();
	}
	
/*	private String getDocContents(DocumentIndexJob indexJob){
	    SolrInputDocument doc = new SolrInputDocument();
	    doc.addField("id", indexJob.getSolrDocID());
	    doc.addField("datatype", "jobRuns");
	    
		StringBuilder jobDetails = new StringBuilder();
		jobDetails.append("{");
		jobDetails.append("\"jobName\":\"" + indexJob.getJobName() + "\", ");
		jobDetails.append("\"jobType\":\"" + indexJob.getJobType() + "\", ");
		jobDetails.append("\"jobStatus\":\"" +  indexJob.getJobStatus() + "\", ");
		jobDetails.append("\"startTime\":\"" + indexJob.getStartTime() + "\", ");
		jobDetails.append("\"endTime\":\"" + indexJob.getEndTime() + "\", ");
		jobDetails.append("\"logFileName\":\"" + indexJob.getLogFileName().replace("\\", "\\\\") + "\"");
		jobDetails.append("}");
		
		
		doc.addField("jobDetails", jobDetails.toString());
		doc.addField("jobData", indexJob.getJobDataString());
		logger.info("The job details string is: " + jobDetails );
		logger.info("The job data is: " + indexJob.getJobDataString());
		//jobLogger.debug("The job details string",  jobDetails.toString());
		//jobLogger.debug("The job data", indexJob.getJobDataString());
		
		for(DocumentIndexJobStatistics jobStatistics : indexJob.getStatistics()){
	    	StringBuilder stat = new StringBuilder();
	    	stat.append("{");
	    	stat.append("\"type\":\"" + jobStatistics.getExtension());
	    	stat.append("\", \"total\":" + jobStatistics.getTotal());
	    	stat.append(", \"successful\":" + jobStatistics.getSuccessful());
	    	stat.append(", \"skipped\":" + jobStatistics.getSkipped());
	    	stat.append(", \"failed\":" + jobStatistics.getFailed());
	    	stat.append("}");
			doc.addField("jobStatistics", stat.toString());				
			logger.info("The job Statistics is: " + stat.toString());
			//jobLogger.debug("The job Statistics", stat.toString());
		}		
		return doc.toString();

	}*/
	
/*	private void uploadJobRunData(String baseSolrURL, DocumentIndexJob indexJob, GeodatafyJobLog jobLogger) {		
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		HttpSolrClient solrClient = new HttpSolrClient.Builder(baseSolrURL).withHttpClient(httpClient).build();		
		
	    SolrInputDocument doc = new SolrInputDocument();
	    doc.addField("id", indexJob.getSolrDocID());
	    doc.addField("datatype", "jobRuns");
	    
		StringBuilder jobDetails = new StringBuilder();
		jobDetails.append("{");
		jobDetails.append("\"jobName\":\"" + indexJob.getJobName() + "\", ");
		jobDetails.append("\"jobType\":\"" + indexJob.getJobType() + "\", ");
		jobDetails.append("\"jobStatus\":\"" +  indexJob.getJobStatus() + "\", ");
		jobDetails.append("\"startTime\":\"" + indexJob.getStartTime() + "\", ");
		jobDetails.append("\"endTime\":\"" + indexJob.getEndTime() + "\", ");
		jobDetails.append("\"logFileName\":\"" + indexJob.getLogFileName().replace("\\", "\\\\") + "\"");
		jobDetails.append("}");
		
		
		doc.addField("jobDetails", jobDetails.toString());
		doc.addField("jobData", indexJob.getJobDataString());
		logger.info("The job details string is: " + jobDetails );
		logger.info("The job data is: " + indexJob.getJobDataString());
		jobLogger.debug("The job details string",  jobDetails.toString());
		jobLogger.debug("The job data", indexJob.getJobDataString());
		
		for(DocumentIndexJobStatistics jobStatistics : indexJob.getStatistics()){
	    	StringBuilder stat = new StringBuilder();
	    	stat.append("{");
	    	stat.append("\"type\":\"" + jobStatistics.getExtension());
	    	stat.append("\", \"total\":" + jobStatistics.getTotal());
	    	stat.append(", \"successful\":" + jobStatistics.getSuccessful());
	    	stat.append(", \"skipped\":" + jobStatistics.getSkipped());
	    	stat.append(", \"failed\":" + jobStatistics.getFailed());
	    	stat.append("}");
			doc.addField("jobStatistics", stat.toString());				
			logger.info("The job Statistics is: " + stat.toString());
			jobLogger.debug("The job Statistics", stat.toString());
		}		
	    try {
	    	jobLogger.info("Adding the job run data document to solr", doc.toString());					
	    	UpdateResponse response = solrClient.add(JOBS_COLLECTION,doc);
			jobLogger.info("Added the job run data to solr and the response", response.toString());
			logger.info("Added the job run data to solr and the response is: " + response.toString());
			response = solrClient.commit(JOBS_COLLECTION);
			jobLogger.info("Committed the job run data to solr and the response", response.toString());
			logger.info("Committed the job run data to solr and the response is: " + response.toString());
		} catch (SolrServerException e) {
			logger.error(e.getMessage());
			logger.error(e.getStackTrace().toString());
			jobLogger.error("SolrServerException", e.getMessage());			
		} catch (IOException e) {
			logger.error(e.getMessage());
			logger.error(e.getStackTrace().toString());
			jobLogger.error("IOException", e.getMessage());
		}
	}*/

	private List<String> getExtensions(JsonElement fileTypes) {
		JsonArray fileTypeArr = JsonUtil.convertToJsonArray(fileTypes); 
		List<String> extensions = new ArrayList<String>();		
		for (JsonElement jsonElement : fileTypeArr) {
			String type = jsonElement.getAsJsonObject().get("type").getAsString();
			boolean active = jsonElement.getAsJsonObject().get("active").getAsBoolean();
			logger.info("File type to consider : " + type + " and active is : " + active);
			if(active){
				extensions.add(type);
			}
		}
		return extensions;
	}

	private void debug(Map<String, String> elementsMap) {
		//Just for debug		
		for (Map.Entry<String, String> entry: elementsMap.entrySet()){
			String key = entry.getKey();
			String value =  entry.getValue();				
			logger.info("Key: " + key + " Value: " + value);
		}
	}
	
	public static void main(String[] args) throws Exception{
		
	/*
		 JSONObject json = new JSONObject();
			json.put("id", "DocumentIndex_job");
			json.put("datatype", "jobRuns");
			json.put("jobName", "DocumentIndex_job");	
			json.put("jobType", "DocumentIndex");	
			json.put("jobDescription", "");
			  JSONObject jsonObj = new JSONObject();
			   jsonObj.put("solrHost", "192.168.2.231");
			   jsonObj.put("solrPort", "8983");
			   jsonObj.put("rootFolder", "\\\\192.168.5.92\\vaish");
			   jsonObj.put("recurseFolder", true);
			   jsonObj.put("webAccess",false);
			   jsonObj.put("virtualPathName", "");
			   jsonObj.put("solrCollectionName", "document");
			   jsonObj.put("newAndModifiedOnly", true);
			   jsonObj.put("projectName", "VaishaliProj");
			   JSONArray fileList = new JSONArray();
			   JSONObject jsonfile = new JSONObject();
			   jsonfile.put("active", true);
			   jsonfile.put("type", ".txt");
			   fileList.put(jsonfile);
			 
			   jsonObj.put("fileType", fileList);
			   
			 
			   json.put("jobData", jsonObj.toString());
			   
			
			json.put("logLevel", "INFO");
			//json.put("ProjectName", "LakshmiProj");
			json.put("scheduled", false);
			json.put("startDateTime", "2018-10-08T06:38:33.857Z");		
			
			json.put("interval", 0);
			json.put("duration", "INFO");
			json.put("createdDate", "2018-10-08T06:38:33.857Z");
			json.put("createdBy", "LG111891");
			json.put("lasModifiedDate", "2018-10-08T06:38:33.857Z");
			json.put("editedBy", "LG111891");
			json.put("endPointURL", "http://192.168.2.231:80/service/jobs/document/indexer/run");
			json.put("jobCreateEndPointURL", "");
			json.put("jobRunsEndPointURL", "");
			json.put("jobLogEndPointURL", "");
			json.put("jobStatisticsEndPointURL", "");
			
			DocumentJobService job = new DocumentJobService();
			//job.runDocumentIndexJob(json.toString());
			String path = "\\\\192.168.2.231\\AutoBuild";
			//String path = "d://AutoBuild";
			 File file = new File(path);
			 String filepath = file.getPath();
			 System.out.println(filepath);
			 System.out.println(file.toURI().toString());
			 System.out.println(file.toURL());

			*/
		DocumentJobService d = new DocumentJobService();
		System.out.println(d.encodeURLStr("d:/A&R/cop%y+ copy"));
		
		
			
		
	}
	
private  String getFormatedUTCTime(String strDate) throws Exception{
		
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.sss'Z'");
		df.setTimeZone(TimeZone.getTimeZone("UTC"));	
		  ZonedDateTime zdt = ZonedDateTime.now(ZoneOffset.UTC);
		DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
		Date dateObj=null;
		try {
			dateObj = (Date)formatter.parse(strDate);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		String retStrDate = df.format(new Date(dateObj.getTime())).toString();
		return retStrDate;
	}
	
	
}
