package com.bct.geodatafy.rest.service;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.collections.map.MultiValueMap;
import org.apache.log4j.Logger;

import com.bct.geodatafy.util.EnvUtil;
import com.bct.geodatafy.util.FileUtil;
import com.bct.geodatafy.util.JsonUtil;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

@Path("/jobtypes")
public class JobTypeService {
	static Logger logger = Logger.getLogger(JobTypeService.class);
	
	public static final String JOBTYPE_DIR = "\\jobtypes";

	@GET
	@Path("")
	public String getAllJobTypes(@Context HttpServletRequest request) throws Exception{		
		logger.info("In service: /jobtypes and method: getAllJobTypes");

		//String namesJson = "";
		String typesJson = "";
		List<String> fileNames = new ArrayList<String>();
		//String basePathStr = System.getenv("GD_DATA_PATH").replace("\\", "\\\\");
		String basePathStr = EnvUtil.getGDDataPath().replace("\\", "\\\\");
		FileUtil.getFiles(basePathStr + JOBTYPE_DIR, ".json", fileNames);
		//MultiValueMap names = new MultiValueMap();
		MultiValueMap types = new MultiValueMap();
		
		for(String fileName: fileNames){
			String contents = new String(Files.readAllBytes(Paths.get(fileName)), StandardCharsets.UTF_8);
			Map<String, JsonElement> elementsMap = JsonUtil.getJsonElementMap(contents);
			printJsonElementMap(elementsMap);
			JsonObject jobType = (JsonObject)elementsMap.get("jobType");
			if(jobType != null){
				types.put("jobTypes", jobType);
				//JsonElement nameElement = jobType.get("name");
				//if(nameElement != null){
					//String name = nameElement.getAsString();
					//logger.info("Job Type Name: " + name);
					//names.put("names", name);								
				//}else {
					//logger.warn("Job name json element is not defined in " + fileName);
				//}
			}else {
				logger.info("Job Type json element is not defined in " + fileName);
			}
		}
		Gson gson = new Gson();
		typesJson = gson.toJson(types);
		return typesJson;
		//namesJson = gson.toJson(names);			
		//return namesJson;

	}
	
	@GET
	@Path("/{jobType}")
	public String getJobType(@Context UriInfo uri) throws Exception{		
		String details = "{}";
		
		logger.info("In service: /jobtypes/{jobType} and method: getJobType and the URI is: " + uri);
		//logger.info("uri.getAbsolutePath() " + uri.getAbsolutePath());
		//logger.info("uri.getBaseUri() " + uri.getBaseUri());
		//logger.info("uri.getPath() " + uri.getPath());
		//logger.info("uri.getRequestUri() " + uri.getRequestUri());
		//logger.info("uri.getPathSegments() " + uri.getPathSegments());
		//logger.info("uri.getPathParameters() " + uri.getPathParameters());
		//logger.info("uri.getMatchedURIs() " + uri.getMatchedURIs());
		
		List<String> input = uri.getPathParameters().get("jobType");		
		if(input == null || input.size() < 1){
			logger.error("The input value - Job Type is defined.");
			return details;
		}
		
		String jobType = input.get(0);
		
		List<String> fileNames = new ArrayList<String>();
		//String basePathStr = System.getenv("GD_DATA_PATH").replace("\\", "\\\\");
		String basePathStr = EnvUtil.getGDDataPath().replace("\\", "\\\\");
		FileUtil.getFiles(basePathStr + JOBTYPE_DIR, ".json", fileNames);
		JsonObject type = null;
		boolean matched = false;
		
		for(String fileName: fileNames){
			String contents = new String(Files.readAllBytes(Paths.get(fileName)), StandardCharsets.UTF_8);
			Map<String, JsonElement> elementsMap = JsonUtil.getJsonElementMap(contents);
			printJsonElementMap(elementsMap);
			type = (JsonObject)elementsMap.get("jobType");
			if(type != null){
				JsonElement nameElement = type.get("name");
				if(nameElement != null){
					String name = nameElement.getAsString();						
					logger.info("Job Type Name: " + name);
					if(name.equalsIgnoreCase(jobType)){
						logger.info("The given job type " + jobType + " is matched in: " + fileName);
						matched  = true;
						break;
					}					
				}else {
					logger.info("Job name json element is not defined in " + fileName);
				}
			}else {
				logger.warn("Job Type json element is not defined in " + fileName);
			}
		}
		if(matched){
			details = type.toString();
			logger.info("The details for the job: " + jobType + " is " + details);		
		}else {
			logger.warn("There is no Job Type defined for: " + jobType);
		}
		return details;
	}
	
	private void printJsonElementMap(Map<String, JsonElement> elementsMap) {
		//Just for debug		
		for (Map.Entry<String, JsonElement> entry: elementsMap.entrySet()){
			String key = entry.getKey();
			JsonElement value =  entry.getValue();				
			logger.info("Key: " + key + " Value: " + value);
		}
	}
}
