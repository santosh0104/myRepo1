package com.bct.geodatafy.rest.service;


import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;



import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.WinHttpClients;
import org.apache.log4j.Logger;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.SolrInputDocument;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;



import com.bct.geodatafy.job.GeodatafyJobLog;
import com.bct.geodatafy.job.alert.AlertJob;
import com.bct.geodatafy.job.document.DocumentIndexJob;
import com.bct.geodatafy.job.qc.ProjectDSInput;
import com.bct.geodatafy.job.qc.QCJob;
import com.bct.geodatafy.job.qc.QCJobData;
import com.bct.geodatafy.job.qc.QCJobStatistics;
import com.bct.geodatafy.job.qc.project;
import com.bct.geodatafy.qc.QCUtility;
import com.bct.geodatafy.util.EnvUtil;
import com.bct.geodatafy.util.GeoUtil;
import com.bct.geodatafy.util.JsonUtil;
import com.google.gson.Gson;


/**
 * 
 * @author LG111891
 *  
 */

@Path("/jobs/quality/scoreprojects")
public class QualityScoreJobService {
	static Logger logger = Logger.getLogger(QualityScoreJobService.class);
	public static final String JOB_TYPE = "QualityScoreJobService";
	public static final String JOBS_COLLECTION = "jobs";	
	public static int BATCH_SIZE= 1000;
	HttpSolrClient metadataHttpSolrClient;	
	 
	@POST
	@Path("/run")
	@Consumes(MediaType.APPLICATION_JSON)
	public String runScoreProjectsJob(String payLoad
		//	, @Context HttpServletRequest request
			) throws Exception{		
		logger.info("In service: /jobs/quality/scoreProjects and method: runScoreProjectsJob");	
		String retMsg = null;
		
		logger.info("Input payload is: " + payLoad);
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);	
		if(elementsMap == null || elementsMap.isEmpty()){
			retMsg = "The input payload is not a expected json string";
			logger.error(retMsg);
			return retMsg;
		}
		
		logger.info("Number of elements in input json : " + elementsMap.size() + " ");		
	
				
		String jobName = elementsMap.get("jobName");
		if(jobName == null || jobName.length() < 1){
			retMsg = "Job name is null or empty";
			logger.error(retMsg + " Returning without doing anything.");
			return retMsg;			
		}
		
		String jobType = elementsMap.get("jobType");
		if(jobType == null || jobType.length() < 1){
			retMsg = "Job Type is null or empty";
			logger.error(retMsg + " Returning without doing anything.");
			return retMsg;			
		}
		
		String jobData = elementsMap.get("jobData");
		if(jobData == null || jobData.length() < 1){
			retMsg = "Job Data is null or empty";
			logger.error(retMsg + " Returning without doing anything.");
			return retMsg;			
		}

		logger.info("Starting the Alert Job job: " + jobName + " ");
		QCJob indexJob = new QCJob();
		indexJob.setJobName(jobName);
		indexJob.setJobType(jobType);
		
		String solrDocID = jobName + "_" + Long.toString(System.currentTimeMillis());
		indexJob.setSolrDocID(solrDocID);
		String logFileName = "logs\\" + solrDocID + ".log";
		
		//String programDataDir = System.getenv("GD_LOG_PATH");
		String programDataDir = EnvUtil.getGDLogPath();
		logger.info("Geodatafy Log Path dir received from environment variable GD_LOG_PATH is: " + programDataDir);
		
		if(programDataDir != null && !programDataDir.isEmpty()){				
				String logDir = programDataDir + "\\logs\\indexers\\custom\\" + jobType + "\\";
				logFileName = logDir + solrDocID + ".log";				
				File dir = new File(logDir);
				if(dir == null || !dir.isDirectory()){ 
					dir.mkdir();
				}
		}

		String givenLogLevel = elementsMap.get("logLevel");
		String logLevel = GeodatafyJobLog.INFO;
		if(givenLogLevel != null && givenLogLevel.length() > 0){
			logLevel = givenLogLevel;	
		}
		
		GeodatafyJobLog jobLogger = new GeodatafyJobLog(logFileName, logLevel);
		indexJob.setLogFileName(logFileName);
		
		jobLogger.info("Input Payload", payLoad);
		jobLogger.info("Job Data from input", jobData);

		QCJobData indexJobData = constructJobData(jobData, jobLogger);
		ArrayList<project> projList = indexJobData.getProjectList();		
		if(projList == null || projList.size() < 1){
				String msg = "Projects is null or empty";
				logger.error(msg + " Returning without doing anything.");
				return msg;			
		}
		/*	
		for (project projectObj : projList) {
			if( projectObj.getName() == null || projectObj.getName().length() <=0 ) {
				String msg = "ProjectName is Null or Empty";
				logger.error(msg + " Returning without doing anything.");
				

				return msg;		
			}
			if( projectObj.getDataSource() == null || projectObj.getDataSource().length() <=0 ) {
				String msg = "DataSource is Null or Empty for " + projectObj.getName();
				logger.error(msg + " Returning without doing anything.");
				return msg;		
			}
			if( projectObj.getDataSourceTypeName() == null || projectObj.getDataSourceTypeName().length() <=0 ) {
				String msg = "DataSourceTypeName is Null or Empty for " + projectObj.getName();
				logger.error(msg + " Returning without doing anything.");
				return msg;		
			}
			if( projectObj.getQcRuleSet() == null || projectObj.getQcRuleSet().length() <=0 ) {
				String msg = "QcRuleSet is Null or Empty for " + projectObj.getName();
				logger.error(msg + " Returning without doing anything.");
				return msg;		
			}
		}
		*/
		indexJob.setJobDataString(jobData);
		indexJob.setJobData(indexJobData);
		indexJob.setJobStatus(QCJob.JOB_RUNNING);
		long startTime = System.currentTimeMillis();
		indexJob.setStartTime(GeodatafyJobLog.getCurrentDateTime(startTime));		
		indexJob.setEndTime("");	
		
		String protocol = null;
		if(protocol == null || protocol.isEmpty()){
			protocol = "http";
		}	
		BATCH_SIZE = getQCJobBatchSize(indexJobData.getSolrHost(), indexJobData.getSolrPort());

		String baseSolrURL = protocol + "://" + indexJobData.getSolrHost() + ":" + indexJobData.getSolrPort()+ "/solr";
		List<QCJobStatistics> statistics = getJobStatistics(indexJob, jobLogger);
		indexJob.setStatistics(statistics);
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		String solrMetadataCollectionUrl = baseSolrURL + "/metadata";
		metadataHttpSolrClient =   (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(solrMetadataCollectionUrl)).withHttpClient(httpClient).build();
		if(statistics == null){
			jobLogger.info("No Rules", "No Rules found ");
			indexJob.setJobStatus(QCJob.JOB_ERROR);				
			if(indexJobData.isProjectSet()) {
				try {
				updateProjectSet(indexJobData.getProjectSetName(), QCJob.JOB_ERROR , indexJob.getEndTime());
				} catch(Exception e ) {
					indexJob.setJobStatus(QCJob.JOB_ERROR);						
				}
			}
			uploadJobRunData(baseSolrURL, indexJob, jobLogger);
		}else if(statistics.size() == 0){
			jobLogger.info("No Rules", "No Rules found for the project");
			indexJob.setJobStatus(QCJob.JOB_COMPLETED);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());	
			
			if(indexJobData.isProjectSet()) {
				try {
					updateProjectSet(indexJobData.getProjectSetName(), QCJob.JOB_COMPLETED , indexJob.getEndTime());
					} catch(Exception e ) {
						indexJob.setJobStatus(QCJob.JOB_ERROR);						
					}				
			}
			uploadJobRunData(baseSolrURL, indexJob, jobLogger);
		}else{
			logger.info("Uploading the job run data before ScoreProject.");
			uploadJobRunData(baseSolrURL, indexJob, jobLogger);
			
			scoreProject(baseSolrURL, indexJob, jobLogger);
			//Thread.sleep(300000);
			logger.info("Uploading the job run data after ScoreProject.");		
			uploadJobRunData(baseSolrURL, indexJob, jobLogger);		
			
		}	
		//Thread.sleep(300000
		return "Job Scheduled Successfully";
	}
	
		public static void main(String args[]) throws Exception {
		
			 JSONObject json = new JSONObject();
		json.put("id", "ProjSet1_QC");
		json.put("datatype", "jobDefinition");
		json.put("jobName", "ProjSet1_QC");	
		json.put("jobType", "QC Job");	
		json.put("jobDescription", "");
		  JSONObject jsonObj = new JSONObject();
		   jsonObj.put("solrHost", "192.168.0.166");
		   jsonObj.put("solrPort", "8983");
		   jsonObj.put("projectSet", true);
		   jsonObj.put("projectSetName", "ProjSet1");
		   JSONArray projList = new JSONArray();
		   JSONObject jsonProjObj = new JSONObject();
		   //jsonProjObj.put("project" , "Shale_Plays_NorthAmerica");
		   //jsonProjObj.put("dataSource" , "US_EIA");
		   //projList.put(jsonProjObj);
		   //jsonProjObj = new JSONObject();
		   //jsonProjObj.put("project" , "BOEM");
		   //jsonProjObj.put("dataSource" , "BOEM");
		   //projList.put(jsonProjObj);
		   //jsonProjObj = new JSONObject();		   
		   //jsonProjObj.put("project" , "BOEM");
		   //jsonProjObj.put("dataSource" , "DocumentIndex_Job");
		   //projList.put(jsonProjObj);
		   jsonProjObj = new JSONObject();		   
		//   jsonProjObj.put("project" , "PPDM_SQL");
		//  jsonProjObj.put("dataSource" , "PPDM_SQL");
		  //jsonProjObj.put("datasourcetypeName" , "PPDM");
		  
		 // projList.put(jsonProjObj);
		  jsonProjObj = new JSONObject();
		
		  jsonProjObj.put("project" , "SaltCreek");
		  jsonProjObj.put("dataSource" , "Kingdom");
		  jsonProjObj.put("datasourcetypeName" , "Kingdom");
		  jsonProjObj.put("qcRuleSetName" , "Clay");
		 // projList.put(jsonProjObj);
		  
		  jsonProjObj = new JSONObject();
			
		  jsonProjObj.put("project" , "A");
		  jsonProjObj.put("dataSource" , "Fake_DB");
		  jsonProjObj.put("datasourcetypeName" , "Fake_DB");
		  jsonProjObj.put("qcRuleSetName" , "Default");
		  projList.put(jsonProjObj);
		  
		  jsonProjObj = new JSONObject();
			
		  jsonProjObj.put("project" , "B");
		  jsonProjObj.put("dataSource" , "Fake_DB");
		  jsonProjObj.put("datasourcetypeName" , "Fake_DB");
		  jsonProjObj.put("qcRuleSetName" , "Default");
		  projList.put(jsonProjObj);
		 
		   jsonObj.put("projects", projList);
		   
		   json.put("jobData", jsonObj.toString());
		   
		
		json.put("logLevel", "INFO");
		json.put("scheduled", false);
		json.put("startDateTime", "2018-10-08T06:38:33.857Z");		
		
		json.put("interval", 0);
		json.put("duration", "INFO");
		json.put("createdDate", "2018-10-08T06:38:33.857Z");
		json.put("createdBy", "LG111891");
		json.put("lasModifiedDate", "2018-10-08T06:38:33.857Z");
		json.put("editedBy", "LG111891");
		json.put("endPointURL", "http://192.168.0.166:80//service/jobs/quality/scoreprojects/run");
		json.put("jobCreateEndPointURL", "");
		json.put("jobRunsEndPointURL", "");
		json.put("jobLogEndPointURL", "");
		json.put("jobStatisticsEndPointURL", "");
		
		System.out.println(json.toString());
		/*  JSONObject jsonObj = new JSONObject();
		   jsonObj.put("solrHost", "192.168.1.80");
		   jsonObj.put("solrPort", "8983");
		   JSONArray projList = new JSONArray();
		   projList.put("petrobras");
		   projList.put("cloudspin");
		   jsonObj.put("projects", projList);
		   System.out.println(jsonObj.toString());
		   QualityScoreJobService qc = new QualityScoreJobService();
		   qc.constructJobData(jsonObj.toString());*/
		
		  QualityScoreJobService qc = new QualityScoreJobService();
		  qc.runScoreProjectsJob(json.toString());
		 // System.out.println( qc.getQCJobBatchSize("192.168.2.231", "8983"));
		   
	}
	private String scoreProject(String baseSolrURL, QCJob indexJob, GeodatafyJobLog jobLogger) throws Exception {

		
		try {	
		
			QCJobData indexJobData = indexJob.getJobData();
			if(indexJobData.isProjectSet()) {
				updateProjectSet(indexJobData.getProjectSetName(), QCJob.JOB_RUNNING , indexJob.getStartTime());
			}
			ArrayList<project> projList = indexJobData.getProjectList();						
			
			for (project projectObj : projList) {
				ArrayList<String> datatypeList = projectObj.getProjDataTypes();
				StringBuffer strBuf = new StringBuffer();
				if(datatypeList.size() > 0 ) {
					 strBuf.append("( ");
					 for(int i=0; i < datatypeList.size(); i++ ) {
						 String datatype = (String) datatypeList.get(i);
						 if (i== datatypeList.size()-1) {
							 strBuf.append("\"").append(datatype).append("\"").append(")");					 
						 } else {
							 strBuf.append("\"").append(datatype).append("\"").append(" || ");
						 }
					 }
				
					QCUtility qc = new QCUtility(indexJobData.getSolrHost(), indexJobData.getSolrPort(), indexJobData.getProjectCollectionName(), BATCH_SIZE, projectObj.getQcRuleSet(), strBuf.toString());
					String datasource = projectObj.getDataSource();
					String projectName = projectObj.getName();
					String dataSourceTypeName = projectObj.getDataSourceTypeName();
					jobLogger.info("Started to Score Project : " + projectName +  " and Datasource : " + datasource , "");
					HashMap<String, String> retMap = qc.scoreProject(datasource, projectName, dataSourceTypeName,  jobLogger);
					List<QCJobStatistics> statistics = getJobStatistics(retMap, projectName, datasource, dataSourceTypeName, indexJob, jobLogger);	
					indexJob.setStatistics(statistics);
					jobLogger.info(" Score Project : " + projectName +  " and Datasource : " + datasource + " Completed", "");
				} else {
					jobLogger.error("DataType not found for the Ruleset", projectObj.getQcRuleSet());
					
				}
			}
			indexJob.setJobStatus(DocumentIndexJob.JOB_COMPLETED);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
			if(indexJobData.isProjectSet()) {
				updateProjectSet(indexJobData.getProjectSetName(), indexJob.getJobStatus() , indexJob.getStartTime());
			}
	        String msg = "Projects updated with score successfully";
			return msg;
		} catch(Exception e) {
			e.printStackTrace();
			logger.error("Exception in QualityCheckService  " , e);
			jobLogger.error("Exception in QualityCheckService", e.getMessage());
			String msg=e.getMessage();
			indexJob.setJobStatus(DocumentIndexJob.JOB_ERROR);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
			return msg;
		}		
	}
	
	
	private void updateProjectSet(String projectSetName, String qcRunstatus,  String QCRunDateTime ) throws SolrServerException, IOException {	
		// get existing project doc's id
		SolrQuery query = new SolrQuery();
		query.set("q","*:*" );
		query.set("fl", "id" );
		query.addFilterQuery("datatype:projectSet");
		query.addFilterQuery("Name:\"" + GeoUtil.escapeQueryParams(projectSetName) + "\"");
		query.set("wt","json");
		try {
			QueryResponse resp = metadataHttpSolrClient.query(query);
			int status = resp.getStatus();
			if ( status==0 ) {
				SolrDocumentList docs = resp.getResults();
				// update the project doc's Last_Scored field with current UTC datetime 
				for(SolrDocument doc : docs) {
					String id = (String) doc.getFieldValue("id");
					
					System.out.println(id);
					SolrInputDocument projDoc = new SolrInputDocument();
					Map<String, String> partialUpdate = new HashMap<String, String>();
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
				    sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
				     String utcTime = sdf.format(stringDateToDate(QCRunDateTime));
					partialUpdate.put("set", ZonedDateTime.parse( utcTime + "Z").toString() );	
					projDoc.addField("id",  id);
					//projDoc.addField("id", id.replace("\\", "\\\\"));
					System.out.println("QCRunDateTime : " + QCRunDateTime);
					
					//ZonedDateTime d = ZonedDateTime.parse(dateTime);
					

				     System.out.println("utcTime : " + utcTime);
					System.out.println("Instant.now().toString() : " + ZonedDateTime.parse( utcTime + "Z").toString());
					projDoc.addField("Last_Scored_DateTime", partialUpdate);	
					Map<String, String> partialUpdate1 = new HashMap<String, String>();
					partialUpdate1.put("set", qcRunstatus  );	
					projDoc.addField("qcJobStatus", partialUpdate1);
					logger.info(projDoc.toString());
					
					metadataHttpSolrClient.add(projDoc);	
					metadataHttpSolrClient.commit();
				}						
			}
			else {
				logger.info("  Status: " + status);
			}

		} catch (Exception e ) {	
			logger.error(" updateProjectSet  Status: FAILED");
			logger.error("updateProjectSet " + e.getMessage(), e);	
			e.printStackTrace();
			throw e;
		}				
		logger.info(" ProjectSet: " + projectSetName + " Last_Scored updated.");
	}
	public static Date stringDateToDate(String StrDate) {
	    Date dateToReturn = null;
	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");

	    try {
	        dateToReturn = (Date)dateFormat.parse(StrDate);
	    }
	    catch (ParseException e) {
	        e.printStackTrace();
	    }

	    return dateToReturn;
	}
	private List<QCJobStatistics> getJobStatistics(QCJob indexJob,  GeodatafyJobLog jobLogger) throws IOException {
		List<QCJobStatistics> statistics = new ArrayList<QCJobStatistics>();
		ArrayList<project> projList = indexJob.getJobData().getProjectList();
		jobLogger.info("Project List Size : " , " " + projList.size());
		for(project projObj : projList) {		
			
			for(String datatype : projObj.getProjDataTypes()) {
				//jobLogger.info("Project  : " + "projObj.getName() DataType:  " + datatype, " ");
				QCJobStatistics qcStat = new QCJobStatistics();
				qcStat.setProject(projObj.getName());
				qcStat.setDatasource(projObj.getDataSource());
				qcStat.setDataSourceTypeName(projObj.getDataSourceTypeName());
				qcStat.setDatatype(datatype);
				statistics.add(qcStat);
			}	
		}		
		return statistics;
	}	
	
	private List<QCJobStatistics> getJobStatistics(HashMap<String, String> scoreMap, String projectName, String datasource, String dataSourceTypeName,  QCJob indexJob,  GeodatafyJobLog jobLogger) throws IOException {
		List<QCJobStatistics> statistics = indexJob.getStatistics();		
		for(QCJobStatistics qcStat : statistics) {		
			
			//System.out.println(" Before Project " + qcStat.getProject() + " DAtaSource: " + qcStat.getDatasource() + qcStat.getTotal());
	}	

		List<QCJobStatistics> retstatistics = new ArrayList<QCJobStatistics>();
		for(Entry<String, String> datatype : scoreMap.entrySet()) {		
			System.out.println("datatype " + datatype.getKey() );
			for(QCJobStatistics qcStat : statistics) {		
				if(qcStat.getProject().equals(projectName) && qcStat.getDatasource().equals(datasource) && qcStat.getDataSourceTypeName().equals(dataSourceTypeName) && qcStat.getDatatype().equals(datatype.getKey())) {
					String count = scoreMap.get(datatype.getKey());
					System.out.println("Project " + projectName + " DAtaSource: " + datasource + " Count "  + count);
					if(count!=null) {
						qcStat.setTotal(Integer.parseInt(count));
						//retstatistics.add(qcStat);
					}
				}
			}	
		}	
		
	
			for(QCJobStatistics qcStat : statistics) {		
				
				System.out.println("Project " + qcStat.getProject() + " DAtaSource: " + qcStat.getDatasource() + "DAteSourceTypeName : " + qcStat.getDataSourceTypeName() + "Total : " + qcStat.getTotal());
					
			}	
		
	
		if (statistics!=null && statistics.size()>0) {
			return statistics;
		} else {
			return statistics;
		}
	}	
	
	

	private void uploadJobRunData(String baseSolrURL, QCJob indexJob, GeodatafyJobLog jobLogger) throws Exception {
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		
		HttpPost post = new HttpPost(baseSolrURL + "/" + JOBS_COLLECTION + "/update/json?wt=json&commitWithin=1&overwrite=true");
		
		try {
			String content = getDocContents(indexJob, jobLogger);
			content = "{\"add\": { \"doc\": " + content + "}}";
			StringEntity entity  = new StringEntity(content, "UTF-8");
			entity.setContentType("application/json");
			post.setEntity(entity);

			jobLogger.info("Adding the QC job run data to solr", content);
	    	logger.info("Adding the QC job run data to solr " + content);
	    	CloseableHttpResponse response = httpClient.execute(post);
			jobLogger.info("Added the QC job run data to solr and the response ", response.toString());
			logger.info("Added the QC job run data to solr and the response is: " + response.toString());
	    	
		} catch (ClientProtocolException e) {			
			logger.error(e.getMessage());
			logger.error("IOException ", e);
			jobLogger.error("ClientProtocolException", e.getMessage());
			throw new Exception(e.getMessage());
		} catch (IOException e) {
			logger.error(e.getMessage());
			logger.error("IOException ", e);
			
			jobLogger.error("IOException", e.getMessage());
			throw new Exception(e.getMessage());
		} finally {
			post = null;
			httpClient.close();			
		}
	}
	
	
	private String getDocContents(QCJob indexJob,  GeodatafyJobLog jobLogger){
	    StringBuilder sb = new StringBuilder();
	    sb.append("{");
	    sb.append("\"id\":\"" + indexJob.getSolrDocID() + "\", ");
	    sb.append("\"datatype\":\"" + AlertJob.SOL_DATA_TYPE + "\", ");
	    sb.append("\"jobRunID\":\"" + indexJob.getSolrDocID() + "\", ");
	    sb.append("\"jobName\":\"" + indexJob.getJobName() + "\", ");	    
	    sb.append("\"jobType\":\"" + indexJob.getJobType() + "\", ");
	    sb.append("\"jobStatus\":\"" + indexJob.getJobStatus() + "\", ");
	    sb.append("\"startTime\":\"" + indexJob.getStartTime() + "\", ");
	    sb.append("\"endTime\":\"" + indexJob.getEndTime() + "\", ");
	    sb.append("\"logFileName\":\"" + indexJob.getLogFileName().replace("\\", "\\\\\\\\") + "\", ");
	    String jobData = indexJob.getJobDataString();
	    jobData = jobData.replace("\\", "\\\\");
	    jobData = jobData.replace("\"", "\\\"");
	    sb.append("\"jobData\":\"" + jobData + "\"");       
	
	    if(indexJob.getStatistics() != null && indexJob.getStatistics().size() > 0){
	    	QCJobStatistics jobStatisticsobj =  indexJob.getStatistics().get(0);
	    	if(!jobStatisticsobj.getDatatype().trim().isEmpty()) {
	    	StringBuilder stat = new StringBuilder();
	    	stat.append("[");
	    	for(int i = 0; i < indexJob.getStatistics().size(); i++){
	    		QCJobStatistics jobStatistics = indexJob.getStatistics().get(i);
	    		stat.append("\"{");
	    		 String projStr = jobStatistics.getProject();
	    		  projStr = projStr.replace("\\", "\\\\");
	    		
	    		 String projDS = jobStatistics.getDatasource();
	    		 projDS = projDS.replace("\\", "\\\\");
	    		 String dsTypeStr = jobStatistics.getDataSourceTypeName();
	    		 dsTypeStr = dsTypeStr.replace("\\", "\\\\");
	    		stat.append("\\\"Project\\\":\\\"" + projStr.replace("\\", "\\\\"));
	    		stat.append("\\\", \\\"DataSource\\\":\\\"" + projDS);
	    		stat.append("\\\", \\\"DataSourceTypeName\\\":\\\"" + dsTypeStr);
	    		stat.append("\\\", \\\"Datatype\\\":\\\"" + jobStatistics.getDatatype());
	    		stat.append("\\\", \\\"Total Doc Scored\\\":" + jobStatistics.getTotal());	  
	    		
	    		if(i == (indexJob.getStatistics().size() - 1)){
	    			stat.append("}\"");
	    		}else{
	    			stat.append("}\",");
	    		}	    		
	    	}
	    	stat.append("]");
	    	logger.info("The job Statistics is: " + stat.toString());
	    	sb.append(",\"jobStatistics\":" + stat.toString());
	    }
	    }
    	sb.append("}");
    	
		return sb.toString();
	}

	private QCJobData constructJobData(String jobData, GeodatafyJobLog jobLogger) throws Exception
	{		
		Gson m_gson = new Gson();
		QCJobData jobDataObj = m_gson.fromJson(jobData, QCJobData.class);
		if(jobDataObj.getProjects() == null || jobDataObj.getProjects().size() <= 0){
			String msg = "The projects is not available in input payload.";
			throw new Exception(msg);
		
		}
		ArrayList<ProjectDSInput> projList = jobDataObj.getProjects();
		for(ProjectDSInput proj : projList) {
			if(proj.getProject() == null || proj.getProject().length() <= 0){
				String msg = "Project is null or empty";
				throw new Exception(msg);
		
			}
			if(proj.getDataSource() == null || proj.getDataSource().length() <= 0){
				String msg = "DataSource is null or empty for project " + proj.getProject();
				throw new Exception(msg);
		
			}
			if(proj.getDatasourcetypeName() == null || proj.getDatasourcetypeName().length() <= 0){
				String msg = "DataSourceTypeName is Null or Empty for project " + proj.getProject();
				throw new Exception(msg);
		
			}
			if(proj.getQcRuleSetName() == null || proj.getQcRuleSetName().length() <= 0){
				String msg = "QCRuleSetName is null or empty for project " + proj.getProject();
				throw new Exception(msg);
			
			}
		}
		
		
		
		StringBuffer strBuf = new StringBuffer();
		ArrayList<ProjectDSInput> projectArrList = jobDataObj.getProjects();
		/*if(strProjList.size() > 0 ) {
			 strBuf.append(" ");
			 for(int i=0; i < strProjList.size(); i++ ) {
				 ProjectDSInput proj = (ProjectDSInput) strProjList.get(i);
				 if(proj.getProject() == null || proj.getDataSource() == null){
						String msg = "Either project/DataSource is not available.";
						throw new Exception(msg);
					
					}
				 proj.setDataSource(proj.getDataSource().replace("\\", "\\\\"));
				 proj.setProject(proj.getProject().replace("\\", "\\\\"));
				 proj.setDatasourcetypeName(proj.getDatasourcetypeName().replace("\\", "\\\\"));
				 if (i== strProjList.size()-1) {
					 strBuf.append("(Name:\"").append(proj.getProject()).append("\"  &&  DataSource:\"").append(proj.getDataSource()).append("\"  &&  DataSourceTypeName:\"").append(proj.getDatasourcetypeName()).append("\")");
										 
				 } else {
					 strBuf.append("(Name:\"").append(proj.getProject()).append("\"  &&  DataSource:\"").append(proj.getDataSource()).append("\"  &&  DataSourceTypeName:\"").append(proj.getDatasourcetypeName()).append("\") || ");
					
				 }
			 }
		 }*/
		
		String collectionName = getProjectCollection(jobDataObj.getSolrHost(), jobDataObj.getSolrPort());
		jobDataObj.setProjectCollectionName(collectionName);
		ArrayList<project> projectList = getProjectDetails(jobDataObj.getSolrHost(), jobDataObj.getSolrPort(), projectArrList, jobLogger);
		jobDataObj.setProjectList(projectList);
		
		return jobDataObj;		
	}


private ArrayList<project> getProjectDetails(String solarHost, String solarPort,  ArrayList<ProjectDSInput> projectList, GeodatafyJobLog jobLogger) throws Exception {		
		
		
		ArrayList<project> projList = new ArrayList<project>();
		try {
			
		
				for (ProjectDSInput projectInput : projectList) {
					project projectObj = new project();
					projectObj.setName(projectInput.getProject().replace("\\", "\\"));
					projectObj.setDataSource(projectInput.getDataSource().replace("\\", "\\"));
					projectObj.setDataSourceTypeName(projectInput.getDatasourcetypeName().replace("\\", "\\"));
					projectObj.setDatatype("Project");
					projectObj.setQcRuleSet(projectInput.getQcRuleSetName());
					System.out.println(" Project: " + projectObj.getName() + " DataSource: " + projectObj.getDataSource() + " Ruleset: " + projectObj.getQcRuleSet());		
					if( projectObj.getQcRuleSet()!=null &&  projectObj.getQcRuleSet().length() > 0) {
						//ArrayList<String> projDataType = getDataTypesForProject(solarHost,solarPort, projectObj );
						ArrayList<String> ruleSetDatatype = getDataTypesForProject(solarHost,solarPort, projectObj, jobLogger );
						//projDataType.retainAll(ruleSetDatatype);
						projectObj.setProjDataTypes(ruleSetDatatype);
					}
					projList.add(projectObj);
				}				
			
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error(e.getStackTrace().toString());
			logger.info("Exception during execution of Solar Query for getProjectDet : " ,  e);
			e.printStackTrace();
			throw new Exception(e.getMessage());
			//return null;
		} finally {
			
		}	
				
		return projList;
	
	}


	private String getProjectCollection(String solarHost, String solarPort) throws Exception {		
		
		
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
				"http://" + solarHost + ":" + solarPort + "/solr/metadata" )).withHttpClient(httpClient).build();
		ArrayList<project> projList = new ArrayList<project>();
		try {
			
			SolrQuery query = new SolrQuery();
	
			query.setQuery("*:*"); // main query
			query.set("wt", "json");
			query.setRows(2147483647);
			query.addFilterQuery("datatype:datatype");
			query.addFilterQuery("name:Project");
							
						
			QueryResponse resp = client.query(query);
			logger.info("getProjectCollection  QueryResponse: " + resp.getResponse().toString());
			
			SolrDocumentList docList = resp.getResults();
			logger.info(" getProjectCollection QueryResponse Num : " + docList.getNumFound());
			if (docList.getNumFound() > 0 ) {			
				
					SolrDocumentList docs = resp.getResults();
					String solrCoreUrl =  null;
					for(SolrDocument doc : docs) {
						
						String datatypeName = (String) doc.getFieldValue("name");
						solrCoreUrl = (String) doc.getFieldValue("solrCoreUrl");
						solrCoreUrl = solrCoreUrl.substring(solrCoreUrl.lastIndexOf("/")+1);
						
					}	
					return solrCoreUrl;
			} else {
				throw new Exception();
			}
				
			
				
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error(e.getStackTrace().toString());
			logger.info("Exception during execution of Solar Query for getProjectCollection   ------>: " ,  e);
			e.printStackTrace();
			throw new Exception(e.getMessage());
			//return null;
		} finally {
			client.close();
			httpClient.close();
		}	
				
		//return null;
	
	}
/*
	private ArrayList<String> getDataTypesForRuleset(String solarHost, String solarPort, project proj) throws Exception {		
		
		
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
				"http://" + solarHost + ":" + solarPort + "/solr/metadata" )).withHttpClient(httpClient).build();
		ArrayList<String> projList = new ArrayList<String>();
		try {
			
			SolrQuery query = new SolrQuery();
	
			query.setQuery("*:*"); // main query
			query.set("wt", "json");
			query.setRows(2147483647);
			query.set("fl",  "qcEntity" );
			
			query.addFilterQuery("datatype:qcRule");
			query.addFilterQuery("qcRuleSet:\"" + proj.getQcRuleSet() + "\"" );		
			query.set("group", true);
			query.set("group.field", "qcEntity");
			query.set("group.main", true);
			logger.info("Query: " + query.toQueryString());
			QueryResponse resp = client.query(query);
			logger.info("Job Def  QueryResponse: " + resp.getResponse().toString());
			
			SolrDocumentList docList = resp.getResults();
			logger.info(" QueryResponse Num : " + docList.getNumFound());
			if (docList.getNumFound() > 0 ) {			
				for (Map singleDoc : docList) {					
					JSONObject json = new JSONObject(singleDoc);
					logger.info(json.toString());
					if(json.has("qcEntity")) {
						projList.add( (String)json.get("qcEntity"));
					}
			
				}				
			} else {
				String msg="DataTypes not Found for ruleset " + proj.getQcRuleSet();
				logger.error(msg);
				
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error("Exception during execution of Solar Query for getProjectDet   ------>: " ,  e);
			e.printStackTrace();
			throw new Exception(e.getMessage());
			
		} finally {
			client.close();
			httpClient.close();
		}	
				
		return projList;
		
	
	}*/
	
	
private ArrayList<String> getSolrURL(String solarHost, String solarPort) throws Exception {		
		
		
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
				"http://" + solarHost + ":" + solarPort + "/solr/metadata" )).withHttpClient(httpClient).build();
		ArrayList<String> solrURLList = new ArrayList<String>();
		try {
			
			SolrQuery query = new SolrQuery();
	
			query.setQuery("*:*"); // main query
			query.set("wt", "json");
			query.setRows(2147483647);
			query.set("fl",  "solrCoreUrl" );
			
			query.addFilterQuery("datatype:datatype");
			//query.addFilterQuery("qcRuleSet:\"" + proj.getQcRuleSet() + "\"" );		
			query.set("group", true);
			query.set("group.field", "solrCoreUrl");
			query.set("group.main", true);
			logger.info("Query: " + query.toQueryString());
			QueryResponse resp = client.query(query);
			logger.info("Job Def  QueryResponse: " + resp.getResponse().toString());
			
			SolrDocumentList docList = resp.getResults();
			logger.info(" QueryResponse Num : " + docList.getNumFound());
			if (docList.getNumFound() > 0 ) {			
				for (Map singleDoc : docList) {					
					JSONObject json = new JSONObject(singleDoc);
					logger.info(json.toString());
					System.out.println(json.toString());
					if(json.has("solrCoreUrl")) {
						String solrCoreUrl = (String)json.get("solrCoreUrl");
						solrCoreUrl = solrCoreUrl.substring(solrCoreUrl.lastIndexOf("/")+1);
						if(!solrURLList.contains(solrCoreUrl)) {
							solrURLList.add(solrCoreUrl);
						}
						System.out.println(solrCoreUrl);
					}
			
				}				
			} else {
				String msg="DataTypes not Found for Project " ;
				logger.error(msg);
				
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error("Exception during execution of Solar Query for getSolrURL   ------>: " ,  e);
			e.printStackTrace();
			throw new Exception(e.getMessage());
			
		} finally {
			client.close();
			httpClient.close();
		}	
				
		return solrURLList;
	
	}

private ArrayList<String> getDataTypesForProject(String solarHost, String solarPort, project proj, GeodatafyJobLog jobLogger) throws Exception {		
	
	
	CloseableHttpClient httpClient = WinHttpClients.createDefault();
	ArrayList<String> solrUrlList = getSolrURL(solarHost, solarPort);
	ArrayList<String> projList = new ArrayList<String>();

	for (String collection : solrUrlList) {
		HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
				"http://" + solarHost + ":" + solarPort + "/solr/" + collection )).withHttpClient(httpClient).build();

		try {			
		
				SolrQuery query = new SolrQuery();
		
				query.setQuery("*:*"); // main query
				query.set("wt", "json");
				query.setRows(2147483647);
				query.set("fl",  "datatype" );
				
				query.addFilterQuery("Project:\"" + GeoUtil.escapeQueryParams(proj.getName()) + "\"" );
				query.addFilterQuery("DataSource:\"" + GeoUtil.escapeQueryParams(proj.getDataSource()) + "\"" );
				query.addFilterQuery("DataSourceTypeName:\"" + GeoUtil.escapeQueryParams(proj.getDataSourceTypeName()) + "\"" );
				//query.addFilterQuery("qcRuleSet:\"" + proj.getQcRuleSet() + "\"" );		
				query.set("group", true);
				query.set("group.field", "datatype");
				query.set("group.main", true);
				System.out.println("Query: " + query.toQueryString());
				QueryResponse resp = client.query(query);
				System.out.println("Job Def  QueryResponse: " + resp.getResponse().toString());
				
				SolrDocumentList docList = resp.getResults();
				System.out.println(" 111 QueryResponse Num : " + docList.getNumFound());
				if (docList.getNumFound() > 0 ) {			
					for (Map singleDoc : docList) {					
						JSONObject json = new JSONObject(singleDoc);
						logger.info(json.toString());
						if(json.has("datatype")) {
							String strDatatype = (String)json.get("datatype");
							if(!strDatatype.equals("Project") && !projList.contains(strDatatype)) {
								projList.add(strDatatype);
							}							
							System.out.println((String)json.get("datatype"));
						}
				
					}				
				} else {
					String msg="DataTypes not Found for Project " + proj.getName() + " in the collection : " + collection;
					logger.error(msg);
					jobLogger.info(msg, " ");
					
				}
			
			} catch (Exception e) {
				logger.error(e.getMessage());
				logger.error("Exception during execution of Solar Query for getDataTypesForProject   ------>: " ,  e);
				e.printStackTrace();
				throw new Exception(e.getMessage());
				
			} finally {
				client.close();
				
			}
	}
			
	httpClient.close();		
	return projList;

}

private int getQCJobBatchSize(String solarHost, String solarPort) throws Exception {		
	int batchSize = BATCH_SIZE;
	
	CloseableHttpClient httpClient = WinHttpClients.createDefault();
	HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
			"http://" + solarHost + ":" + solarPort + "/solr/metadata" )).withHttpClient(httpClient).build();
	ArrayList<String> solrURLList = new ArrayList<String>();
	try {
		
		SolrQuery query = new SolrQuery();

		query.setQuery("*:*"); // main query
		query.set("wt", "json");
		query.setRows(2147483647);
		query.set("fl",  "qcBatch" );
		
		query.addFilterQuery("datatype:AppConfig");
		//query.addFilterQuery("qcRuleSet:\"" + proj.getQcRuleSet() + "\"" );		
		//query.set("group", true);
		//query.set("group.field", "solrCoreUrl");
		//query.set("group.main", true);
		logger.info("Query: " + query.toQueryString());
		QueryResponse resp = client.query(query);
		logger.info("Job Def  QueryResponse: " + resp.getResponse().toString());
		
		SolrDocumentList docList = resp.getResults();
		logger.info(" QueryResponse Num : " + docList.getNumFound());
		if (docList.getNumFound() > 0 ) {			
			for (Map singleDoc : docList) {					
				JSONObject json = new JSONObject(singleDoc);
				logger.info(json.toString());
				System.out.println(json.toString());
				if(json.has("qcBatch")) {
					batchSize = ((Long)json.get("qcBatch")).intValue();		
					BATCH_SIZE = batchSize;
				}
		
			}				
		} 
	} catch (Exception e) {
		logger.error(e.getMessage());
		logger.error("Exception during execution of Solar Query for getQCJobBatchSize   ------>: " ,  e);
		e.printStackTrace();
		//throw new Exception(e.getMessage());
		
	} finally {
		client.close();
		httpClient.close();
	}	
			
	return batchSize;

}



}
