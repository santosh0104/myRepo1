package com.bct.geodatafy.rest.service;

import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.FileEntity;
import org.apache.http.Header;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.WinHttpClients;
import org.apache.log4j.Logger;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.request.ContentStreamUpdateRequest;
import org.apache.solr.client.solrj.response.UpdateResponse;
import org.apache.solr.common.SolrInputDocument;
import org.apache.solr.common.util.NamedList;
import org.apache.solr.client.solrj.request.AbstractUpdateRequest;

import com.bct.geodatafy.job.GeodatafyJobLog;
import com.bct.geodatafy.job.document.DocumentIndexJob;
import com.bct.geodatafy.job.document.DocumentIndexJobData;
import com.bct.geodatafy.job.document.DocumentIndexJobStatistics;
import com.bct.geodatafy.util.FileUtil;
import com.bct.geodatafy.util.JsonUtil;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;


@Path("/jobs")
public class GeodatafyJobService {
	static Logger logger = Logger.getLogger(GeodatafyJobService.class);

	
	@GET
	@Path("/")
	@Produces(MediaType.APPLICATION_JSON)
	public String getJobs() throws Exception{		
		logger.info("In service: /jobs and method: getJobs");		
		//We may not need this method as it can be queried from solr directly
		return "Done";
	}
	
	@GET
	@Path("/runs")
	@Produces(MediaType.APPLICATION_JSON)
	public String getAllJobRuns() throws Exception{		
		logger.info("In service: /jobs/runs and method: getAllJobRuns");		
		//This should be implemented for Openspirit and custom jobs implemented using Talend
		//Done for openspirit
		return "Done";
	}

	@GET
	@Path("/{jobName}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getSpecificJob(@PathParam("jobName") String jobName) throws Exception{		
		logger.info("In service: /jobs/{jobName} and method: getSpecificJob");	
		logger.info("Given job name is: " + jobName);
		//We may not need this method as it can be queried from solr directly
		return "Done";
	}

	@GET
	@Path("/{jobName}/runs")
	@Produces(MediaType.APPLICATION_JSON)
	public String getJobRuns(@PathParam("jobName") String jobName) throws Exception{		
		logger.info("In service: /jobs/{jobName}/runs and method: getJobRuns");	
		logger.info("Given job name is: " + jobName);
		//This should be implemented for Openspirit and custom jobs implemented using Talend
		return "Done";
	}

	@GET
	@Path("/{jobName}/runs/{jobID}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getSpecificJobRuns(@PathParam("jobName") String jobName, @PathParam("jobID") String jobID) throws Exception{		
		logger.info("In service: /jobs/{jobName}/runs/{jobID} and method: getSpecificJobRuns");	
		logger.info("Given job name is: " + jobName + " and the given job ID is: " + jobID);
		//This should be implemented for Openspirit and custom jobs implemented using Talend
		return "Done";
	}

	@POST
	@Path("/{jobName}/create")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public String createJob(String payLoad, @PathParam("jobName") String jobName) throws Exception{		
		logger.info("In service: /jobs/{jobName}/create and method: createJob");	
		logger.info("Given job name is: " + jobName);
		logger.info("Given payload is: " + payLoad);
		//Call the end point URL for creation with the job data given in the payload
		//In addition, should update the solr to have the jobs created
		//This should be implemented for Openspirit and custom jobs implemented using Talend
		return "Done";
	}

	@POST
	@Path("/{jobName}/run")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public String runJob(String payLoad, @PathParam("jobName") String jobName) throws Exception{		
		logger.info("In service: /jobs/{jobName}/run and method: runJob");	
		logger.info("Given job name is: " + jobName);
		logger.info("Given payload is: " + payLoad);
		//Call the end point URL with the job data given in the payload
		//This should be implemented for Openspirit and custom jobs implemented using Talend
		return "Done";
	}
}
