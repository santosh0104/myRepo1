package com.bct.geodatafy.rest.service.exception;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Provider
public class InputExceptionHandler  implements ExceptionMapper<GeodatafyInputException> {
	 @Override
	    public Response toResponse(GeodatafyInputException exception)
	    {
	        Error error = new Error(
	        		500,
	        		"Input Error",
	                exception.getLocalizedMessage());
	        return Response.status(error.getStatusCode())
	                .entity(error.getErrorMessage())
	                .type(MediaType.APPLICATION_JSON)
	                .build();	      
	    } 
	 
	}
