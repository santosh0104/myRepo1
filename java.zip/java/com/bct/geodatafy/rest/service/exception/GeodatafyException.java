package com.bct.geodatafy.rest.service.exception;
import java.io.Serializable;
public class GeodatafyException  extends RuntimeException implements Serializable {
	
	 private static final long serialVersionUID = 1L;
	 
	    public GeodatafyException() {
	        super();
	    }
	    public GeodatafyException(String msg)   {
	        super(msg);
	    }
	    public GeodatafyException(String msg, Exception e)  {
	        super(msg, e);
	    }

}
