package com.bct.geodatafy.rest.service.exception;
import java.io.Serializable;
public class GeodatafyRestoreException  extends RuntimeException implements Serializable {
	
	 private static final long serialVersionUID = 1L;
	 
	    public GeodatafyRestoreException() {
	        super();
	    }
	    public GeodatafyRestoreException(String msg)   {
	        super(msg);
	    }
	    public GeodatafyRestoreException(String msg, Exception e)  {
	        super(msg, e);
	    }

}
