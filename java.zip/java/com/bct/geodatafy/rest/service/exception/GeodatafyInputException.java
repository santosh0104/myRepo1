package com.bct.geodatafy.rest.service.exception;
import java.io.Serializable;
public class GeodatafyInputException  extends RuntimeException implements Serializable {
	
	 private static final long serialVersionUID = 1L;
	 
	    public GeodatafyInputException() {
	        super();
	    }
	    public GeodatafyInputException(String msg)   {
	        super(msg);
	    }
	    public GeodatafyInputException(String msg, Exception e)  {
	        super(msg, e);
	    }

}
