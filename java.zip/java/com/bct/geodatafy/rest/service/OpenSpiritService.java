package com.bct.geodatafy.rest.service;

import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.FileEntity;
import org.apache.http.Header;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.WinHttpClients;
import org.apache.log4j.Logger;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.request.ContentStreamUpdateRequest;
import org.apache.solr.client.solrj.response.UpdateResponse;
import org.apache.solr.common.SolrInputDocument;
import org.apache.solr.common.util.NamedList;
import org.apache.solr.client.solrj.request.AbstractUpdateRequest;

import com.bct.geodatafy.job.GeodatafyJobLog;
import com.bct.geodatafy.job.document.DocumentIndexJob;
import com.bct.geodatafy.job.document.DocumentIndexJobData;
import com.bct.geodatafy.job.document.DocumentIndexJobStatistics;
import com.bct.geodatafy.job.openspirit.OpenSpiritIndexJobProcessor;
import com.bct.geodatafy.job.openspirit.OpenSpiritDatasource;
import com.bct.geodatafy.job.openspirit.OpenSpiritModelView;
import com.bct.geodatafy.openspirit.TransferCapabilities;
import com.bct.geodatafy.util.FileUtil;
import com.bct.geodatafy.util.JsonUtil;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.openspirit.BadArgumentsException;
import com.openspirit.InitializationException;
import com.openspirit.LicenseException;
import com.openspirit.NotFoundException;


@Path("/openspirit")
public class OpenSpiritService {
	static Logger logger = Logger.getLogger(OpenSpiritService.class);
	
	@GET
	@Path("/modelviews")	
	public String getModelViews(){		
		logger.info("In service: /openspirit/modelviews and method: getModelViews");		
		List<OpenSpiritModelView> modelViews = new ArrayList<OpenSpiritModelView>();
		try {
			modelViews = OpenSpiritIndexJobProcessor.getInstance().getModelViews();
			logger.info("Number of model views: " + modelViews.size());			
		} catch (ClassNotFoundException e) {
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		} catch (BadArgumentsException e) {
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		} catch (NotFoundException e) {
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		} catch (InitializationException e) {
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		} catch (LicenseException e) {
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		} catch (SQLException e) {
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		}	
		Gson gson = new Gson();
		return gson.toJson(modelViews);
	}
	
	@GET
	@Path("/datasources")	
	public String getDataSources(){		
		logger.info("In service: /openspirit/datasources and method: getDataSources");		
		List<OpenSpiritDatasource> dataSources = new ArrayList<OpenSpiritDatasource>();
		try {
			dataSources = OpenSpiritIndexJobProcessor.getInstance().getDatasources();
			logger.info("Number of data sources: " + dataSources.size());			
		} catch (NotFoundException e) {
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		} catch (InitializationException e) {
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		} catch (LicenseException e) {
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		}	
		Gson gson = new Gson();
		return gson.toJson(dataSources);
	}

	@POST
	@Path("/transfercapabilities")	
	@Consumes(MediaType.APPLICATION_JSON)
	public String updateTransferCapabilities(String payLoad){		
		logger.info("In service: /openspirit/transfercapabilities and method: updateTransferCapabilities");
		logger.info("Input payload is: " + payLoad);
		
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);
		
		if(elementsMap == null || elementsMap.isEmpty()){
			String msg = "The input payload is not a expected json string";
			logger.info(msg);
			return msg;
		}

		String solrHost = elementsMap.get("solrHost");
		if(solrHost == null || solrHost.length() < 1){
			String msg = "solr Host is null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}

		String solrPort = elementsMap.get("solrPort");
		if(solrPort == null || solrPort.length() < 1){
			String msg = "solr Port is null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}

		
		try{
			TransferCapabilities.getInstance(solrHost, solrPort).updateTransferCapabilities();	
		}catch(NotFoundException e){
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		} catch(InitializationException e){
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		} catch(LicenseException e){
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		}catch(Exception e){
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		}	
		return "Success";
	}
	
	@POST
	@Path("/projects")	
	@Consumes(MediaType.APPLICATION_JSON)
	public String getProjects(String payLoad){		
		logger.info("In service: /openspirit/projects and method: getProjects");
		logger.info("Input payload is: " + payLoad);
		
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);	
		if(elementsMap == null || elementsMap.isEmpty()){
			String msg = "The input payload is not a expected json string";
			logger.info(msg);
			return msg;
		}

		String datasourceName = elementsMap.get("dataSourceName");
		if(datasourceName == null || datasourceName.length() < 1){
			String msg = "Name is null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}

		String datasourceType = elementsMap.get("dataSourceType");
		if(datasourceType == null || datasourceType.length() < 1){
			String msg = "Data Source Type is null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}

		String datasourceTypeVersion = elementsMap.get("dataSourceTypeVersion");
		if(datasourceTypeVersion == null || datasourceTypeVersion.length() < 1){
			String msg = "Data Source Type version is null or Empty";
			logger.error(msg + " Returning without doing anything.");
			return msg;			
		}
		
		String[] projects = new String[1];
		StringBuilder sb = new StringBuilder();
		try {
			projects = OpenSpiritIndexJobProcessor.getInstance().getProjects(datasourceName, datasourceType, datasourceTypeVersion);
			logger.info("Number of projects in datasource "+ datasourceName + " is: " + projects.length);
			
			sb.append("[");
			for(int i = 0; i <  projects.length; i++){
				sb.append("{\"name\":\"" + projects[i] + "\"");
	    		if(i == (projects.length - 1)){
	    			sb.append("}");
	    		}else{
	    			sb.append("},");
	    		}
			}
			sb.append("]");
		} catch (NotFoundException e) {
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		} catch (InitializationException e) {
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		} catch (LicenseException e) {
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		}	
		
		return sb.toString();
	}

	private void debug(Map<String, String> elementsMap) {
		//Just for debug		
		for (Map.Entry<String, String> entry: elementsMap.entrySet()){
			String key = entry.getKey();
			String value =  entry.getValue();				
			logger.info("Key: " + key + " Value: " + value);
		}
	}	
}
