package com.bct.geodatafy.rest.service;


import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.WinHttpClients;
import org.apache.log4j.Logger;
import org.apache.solr.client.solrj.SolrQuery;

import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.SolrException;
import org.apache.solr.common.SolrInputDocument;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.bct.geodatafy.dedup.DeDupManager;
import com.bct.geodatafy.dedup.Source;
import com.bct.geodatafy.dedup.DeDupManager.PreferenceStrategy;
import com.bct.geodatafy.job.GeodatafyJobLog;
import com.bct.geodatafy.job.alert.AlertJob;
import com.bct.geodatafy.job.dedup.DedupJob;
import com.bct.geodatafy.job.dedup.DedupJobData;
import com.bct.geodatafy.job.dedup.DedupJobStatistics;
import com.bct.geodatafy.job.document.DocumentIndexJob;
import com.bct.geodatafy.job.qc.ProjectDSInput;

import com.bct.geodatafy.job.qc.project;
import com.bct.geodatafy.rest.service.exception.GeodatafyInputException;
import com.bct.geodatafy.util.EnvUtil;
import com.bct.geodatafy.util.GeoUtil;
import com.bct.geodatafy.util.JsonUtil;
import com.google.gson.Gson;


/**
 * 
 * @author LG111891
 *  
 */

@Path("/jobs/quality/dedup")
public class DetectDuplicateService {
	static Logger logger = Logger.getLogger(DetectDuplicateService.class);
	
	public static final String JOB_TYPE = "DeDuplicateJob";
	public static final String SOURCEPRIORITY = "sourcepriority";
	public static final String SCOREPRIORITY = "scorepriority";
	public static final String JOBS_COLLECTION = "jobs";	
	public static int BATCH_SIZE= 1000;
	HttpSolrClient metadataHttpSolrClient;	
	
	@POST
	@Path("/check")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response preCheckDedupJobDetails(String payLoad
			//, @Context HttpServletRequest request
			) throws Exception{	
		
		logger.info("In service: /jobs/quality/dedup/check and method: preCheckDedupJobDetails");	
		String retMsg = "success";
		Gson gson = new Gson();
		logger.info("Input payload is: " + payLoad);
		ArrayList<String> retMsgList = new ArrayList<String>();
		try {	
			DedupJobData indexJobData = constructJobData(payLoad);
			ArrayList<String> rulesetDatatypeList = indexJobData.getRuleSetDatatypeList();	
			if(rulesetDatatypeList == null || rulesetDatatypeList.size() < 1){
				retMsg = "No Matching Fields defined";
				logger.error(retMsg );
				retMsg =  getStatusMsg("failure", retMsg, null);
				//throw retMsg);
				return Response.status(200).entity(retMsg).build(); 
				
				
			}
			ArrayList<String> solrUrlList = getSolrURL(indexJobData.getSolrHost(),  indexJobData.getSolrPort());
			HashMap<ProjectDSInput, ArrayList<String>> datatypeProjectMap = new HashMap<ProjectDSInput, ArrayList<String>>();
			ArrayList<String> noRuleDT = new ArrayList<String>();
			for( ProjectDSInput projectObj : indexJobData.getProjects() ) {
				boolean ruleDefined = false;
				ArrayList<String> projDataTypeList = new ArrayList<String>();
				ArrayList<String> tmpList = getDataTypesForProject(indexJobData.getSolrHost(), indexJobData.getSolrPort(), projectObj, solrUrlList);				
				for (String  datatypeName : tmpList)  {
					if (rulesetDatatypeList.contains(datatypeName)) {
						ruleDefined = true;						
						projDataTypeList.add(datatypeName);
					}
				}
				if(!ruleDefined) {
					noRuleDT.add(projectObj.getProject());
				} else {
				
				datatypeProjectMap.put(projectObj, projDataTypeList);
				}
			}
			
			if (noRuleDT.size()>0) {				
				retMsg = "No Matching Fields defined" ;		
				retMsg = getStatusMsg("failure", retMsg, null);
				//throw new GeodatafyInputException(retMsg);
				return  Response.status(200).entity(retMsg).build(); 
				
			}
			
			ArrayList<String> projectDatatypeList = new ArrayList<String>();	
			
			
			
			//indexJobData.setRuleSetDatatypeList(projectDatatypeList);
			//rulesetDatatypeList = indexJobData.getRuleSetDatatypeList();	
			
			List<String> matchFieldsNotDefined = new ArrayList <String>();
			
			for (Map.Entry<ProjectDSInput,ArrayList<String>> entry : datatypeProjectMap.entrySet())  {
				ProjectDSInput projObj = entry.getKey();
				ArrayList<String> dtList = entry.getValue();
				
				for (String  datatypeName : dtList)  {
					List<String>  matchingFields = getMatchingFeilds(indexJobData.getSolrHost(), indexJobData.getSolrPort(), datatypeName, indexJobData.getQcRuleSetName(), null);
					logger.info(" The matchingFields count " + "is " + matchingFields.size());	
					if (matchingFields!=null && matchingFields.size() == 0 ) {
						if(!matchFieldsNotDefined.contains(datatypeName)) {
							matchFieldsNotDefined.add(datatypeName);
						}
					}
				}
			}
			if (matchFieldsNotDefined.size()>0) {				
				retMsg = "No Matching Fields defined for the datatypes " + String.join(",", matchFieldsNotDefined);		
				retMsg = getStatusMsg("failure", retMsg, null);
				//throw new GeodatafyInputException(retMsg);
				return  Response.status(200).entity(retMsg).build(); 
				
			}
			String tmpRetMsg = null;
			ArrayList<JSONObject> qcNotScoredList = new ArrayList<JSONObject>();
			if(indexJobData.getPriority().equalsIgnoreCase(SCOREPRIORITY)) {
				//for( ProjectDSInput projectObj : indexJobData.getProjects() ) {
				//for (String datatypeName : rulesetDatatypeList) {				
				for (Map.Entry<ProjectDSInput,ArrayList<String>> entry : datatypeProjectMap.entrySet())  {
				            ProjectDSInput projectObj = entry.getKey();
				            ArrayList<String> datatypeList = entry.getValue();          
				            
				            for(String datatypeName : datatypeList) {
				            	String collection = getDatatypeCollection(indexJobData.getSolrHost(), indexJobData.getSolrPort(), datatypeName);
				            	boolean isQcScored = isProjectQcScored(projectObj, datatypeName, indexJobData.getSolrHost(), indexJobData.getSolrPort(), collection);		
				            	if(!isQcScored) {
				            		tmpRetMsg = "The Project " + projectObj.getProject() + " DataSource : " + projectObj.getDataSource() + " DataSourceTypeName : " + projectObj.getDatasourcetypeName() + " in Datatype : " + datatypeName + " is not QC Scored";
				            		JSONObject projJson = new JSONObject();
				            		projJson.put("Project", projectObj.getProject());
				            		projJson.put("DataSource", projectObj.getDataSource());
				            		projJson.put("DataSourceTypeName", projectObj.getDatasourcetypeName());
				            		projJson.put("Datatype", datatypeName);
				            		
				            		qcNotScoredList.add(projJson);
				            	}
				            }
					}	
					
				//}			
				 if(qcNotScoredList.size() > 0) {
					 retMsg =  getStatusMsg("failure", "No QC Score Exists", qcNotScoredList);
					// throw new GeodatafyInputException(retMsg);
					 return Response.status(200).entity(retMsg).build(); 
					 //return json;
				 }
				
			}
			retMsg =  getStatusMsg("success", "", null);	
			return Response.status(200).entity(retMsg).build(); 
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.error("Exception in precheck validation for deduplicate job  " , e);			
			//String msg=e.getMessage();
			throw e;
		}		
		
		
		
	
	}
	
	private String getStatusMsg(String status, String msg, ArrayList<JSONObject> list) {
		try {
		  JSONObject returnMsg = new JSONObject();
		  returnMsg.put("status", status);
		  returnMsg.put("message", msg);
		  JSONArray jsonArray = new JSONArray();
		  if(list!=null) {
		  for(JSONObject jsonObj : list) {
			  jsonArray.put(jsonObj);
			  
		  }
		  if(list!=null && jsonArray.length() > 0 ) {
			  returnMsg.put("details" , jsonArray);
		  }
		  }
		
		  return  returnMsg.toString();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception in creating json object   " , e);			
			//String msg=e.getMessage();
			return null;
			
		}
		  
		
	}
	 
	@POST
	@Path("/run")
	@Consumes(MediaType.APPLICATION_JSON)
	public String runDedupJob(String payLoad
			//, @Context HttpServletRequest request
			) throws Exception{		
		logger.info("In service: /jobs/quality/scoreProjects and method: runScoreProjectsJob");	
		String retMsg = null;
		
		logger.info("Input payload is: " + payLoad);
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);	
		if(elementsMap == null || elementsMap.isEmpty()){
			retMsg = "The input payload is not a expected json string";
			logger.error(retMsg);
			return retMsg;
		}
		
		logger.info("Number of elements in input json : " + elementsMap.size() + " ");		
	
				
		String jobName = elementsMap.get("jobName");
		if(jobName == null || jobName.length() < 1){
			retMsg = "Job name is null or empty";
			logger.error(retMsg + " Returning without doing anything.");
			return retMsg;			
		}
		
		String jobType = elementsMap.get("jobType");
		if(jobType == null || jobType.length() < 1){
			retMsg = "Job Type is null or empty";
			logger.error(retMsg + " Returning without doing anything.");
			return retMsg;			
		}
		
		String jobData = elementsMap.get("jobData");
		if(jobData == null || jobData.length() < 1){
			retMsg = "Job Data is null or empty";
			logger.error(retMsg + " Returning without doing anything.");
			return retMsg;			
		}

		logger.info("Starting the Alert Job job: " + jobName + " ");
		DedupJob indexJob = new DedupJob();
		indexJob.setJobName(jobName);
		indexJob.setJobType(jobType);
		
		String solrDocID = jobName + "_" + Long.toString(System.currentTimeMillis());
		indexJob.setSolrDocID(solrDocID);
		String logFileName = "logs\\" + solrDocID + ".log";
		
		//String programDataDir = System.getenv("GD_LOG_PATH");
		String programDataDir = EnvUtil.getGDLogPath();
		logger.info("ProgramData dir received from environment variable ProgramData is: " + programDataDir);
		
		if(programDataDir != null && !programDataDir.isEmpty()){				
				String logDir = programDataDir + "\\logs\\indexers\\custom\\" + jobType + "\\";
				logFileName = logDir + solrDocID + ".log";				
				File dir = new File(logDir);
				if(dir == null || !dir.isDirectory()){ 
					dir.mkdir();
				}
		}

		String givenLogLevel = elementsMap.get("logLevel");
		String logLevel = GeodatafyJobLog.INFO;
		if(givenLogLevel != null && givenLogLevel.length() > 0){
			logLevel = givenLogLevel;	
		}
		
		GeodatafyJobLog jobLogger = new GeodatafyJobLog(logFileName, logLevel);
		indexJob.setLogFileName(logFileName);
		
		jobLogger.info("Input Payload", payLoad);
		jobLogger.info("Job Data from input", jobData);

		DedupJobData indexJobData = constructJobData(jobData);
		ArrayList<String> ruleSetDAtatypeList = indexJobData.getRuleSetDatatypeList();		
		if(ruleSetDAtatypeList == null || ruleSetDAtatypeList.size() < 1){
				String msg = "RuleSet has no datatype";
				logger.error(msg + " Returning without doing anything.");
				return msg;			
		}
		
		indexJob.setJobDataString(jobData);
		indexJob.setJobData(indexJobData);
		indexJob.setJobStatus(DedupJob.JOB_RUNNING);
		long startTime = System.currentTimeMillis();
		indexJob.setStartTime(GeodatafyJobLog.getCurrentDateTime(startTime));		
		indexJob.setEndTime("");	
		
		String protocol = null;
		if(protocol == null || protocol.isEmpty()){
			protocol = "http";
		}	
		//BATCH_SIZE = getQCJobBatchSize(indexJobData.getSolrHost(), indexJobData.getSolrPort());

		String baseSolrURL = protocol + "://" + indexJobData.getSolrHost() + ":" + indexJobData.getSolrPort()+ "/solr";
		List<DedupJobStatistics> statistics = getJobStatistics(indexJob, jobLogger);
		indexJob.setStatistics(statistics);
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		String solrMetadataCollectionUrl = baseSolrURL + "/metadata";
		metadataHttpSolrClient =   (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(solrMetadataCollectionUrl)).withHttpClient(httpClient).build();
		
		if(statistics == null){
			jobLogger.info("No datatype", "No datatype found for Ruleset ");
			indexJob.setJobStatus(DedupJob.JOB_ERROR);	
			uploadJobRunData(baseSolrURL, indexJob, jobLogger);
			updateProjectSet(indexJobData.getProjectSetName(), DedupJob.JOB_ERROR , indexJob.getEndTime());
			
		}else if(statistics.size() == 0){
			jobLogger.info("No datatype", "No datatype found for Ruleset");
			indexJob.setJobStatus(DedupJob.JOB_COMPLETED);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());	
			uploadJobRunData(baseSolrURL, indexJob, jobLogger);			
			updateProjectSet(indexJobData.getProjectSetName(), DedupJob.JOB_COMPLETED , indexJob.getEndTime());
			jobLogger.info("No datatype", "No datatype found for Ruleset ");
			
		}else{
			logger.info("Uploading the job run data before Dedup Job.");
			uploadJobRunData(baseSolrURL, indexJob, jobLogger);		
			jobLogger.info("ProjectSet ", " Dedupe status updated as running ");
			//updateProjectSet(indexJobData.getProjectSetName(), DedupJob.JOB_RUNNING , indexJob.getStartTime());
			dedupProjectSet(baseSolrURL, indexJob, jobLogger);
			//Thread.sleep(300000);
			logger.info("Uploading the job run data after Dedup Job.");		
			uploadJobRunData(baseSolrURL, indexJob, jobLogger);		
			//updateProjectSet(indexJobData.getProjectSetName(), DedupJob.JOB_COMPLETED , indexJob.getEndTime());
			jobLogger.info("ProjectSet ", " Dedupe status updated  as completed ");
			
		}	
		
		return "Job Scheduled Successfully";
	}
	
		public static void main(String args[]) throws Exception {
		
			 JSONObject json = new JSONObject();
		json.put("id", "p1_Dup");
		json.put("datatype", "jobDefinition");
		json.put("jobName", "p1_Dup");	
		json.put("jobType", "DeDuplicateJob");	
		json.put("jobDescription", "");
		  JSONObject jsonObj = new JSONObject();
		   jsonObj.put("solrHost", "192.168.0.166");
		   jsonObj.put("solrPort", "8983");
		   //jsonObj.put("priority", "sourcepriority");
		   jsonObj.put("priority", "scorepriority");
		   jsonObj.put("qcRuleSetName", "Test");
		   jsonObj.put("projectSetName", "Test1");
		   JSONArray projList = new JSONArray();
		   JSONObject jsonProjObj = new JSONObject();

		   jsonProjObj = new JSONObject();		   

		  jsonProjObj = new JSONObject();

		/*  jsonProjObj.put("project" , "A");
		  jsonProjObj.put("dataSource" , "FakeDB");
		  jsonProjObj.put("datasourcetypeName" , "FakeDB");		
		  jsonProjObj.put("qcRuleSetName" , "Clay");
		//  projList.put(jsonProjObj);
		  jsonProjObj = new JSONObject();
		  jsonProjObj.put("project" , "B");
		  jsonProjObj.put("dataSource" , "FakeDB");
		  jsonProjObj.put("datasourcetypeName" , "FakeDB");		
		  jsonProjObj.put("qcRuleSetName" , "Clay");*/
		 // projList.put(jsonProjObj);
		  jsonProjObj = new JSONObject();
		  jsonProjObj.put("project" , "Index10");
		  jsonProjObj.put("dataSource" , "TALEND_INDEX_12000_PRLL_BATCH");
		  jsonProjObj.put("datasourcetypeName" , "Document");		
		  jsonProjObj.put("qcRuleSetName" , "Test");
		  projList.put(jsonProjObj);
		  jsonProjObj = new JSONObject();
		  jsonProjObj.put("project" , "Index600");
		  jsonProjObj.put("dataSource" , "TALEND_INDEX_600_PRLL_2");
		  jsonProjObj.put("datasourcetypeName" , "Document");		
		  jsonProjObj.put("qcRuleSetName" , "Test");
		  projList.put(jsonProjObj);
		  jsonProjObj = new JSONObject();
		  jsonProjObj.put("project" , "SaltCreek");
		  jsonProjObj.put("dataSource" , "Kingdom");
		  jsonProjObj.put("datasourcetypeName" , "Kingdom");		
		  jsonProjObj.put("qcRuleSetName" , "Test");
		  projList.put(jsonProjObj);
		  jsonObj.put("projects", projList);
		  
		   json.put("jobData", jsonObj.toString());
		   
		
		json.put("logLevel", "INFO");
		json.put("scheduled", false);
		json.put("startDateTime", "2018-10-08T06:38:33.857Z");		
		
		json.put("interval", 0);
		json.put("duration", "INFO");
		json.put("createdDate", "2018-10-08T06:38:33.857Z");
		json.put("createdBy", "LG111891");
		json.put("lasModifiedDate", "2018-10-08T06:38:33.857Z");
		json.put("editedBy", "LG111891");
		json.put("endPointURL", "http://192.168.0.166:80//service/jobs/quality/scoreprojects/run");
		json.put("jobCreateEndPointURL", "");
		json.put("jobRunsEndPointURL", "");
		json.put("jobLogEndPointURL", "");
		json.put("jobStatisticsEndPointURL", "");
		
		System.out.println(jsonObj.toString());	
		
		DetectDuplicateService dd = new DetectDuplicateService();
		 // dd.runDedupJob(json.toString());
		 dd.preCheckDedupJobDetails( jsonObj.toString());
		
		//System.out.println(jsonRtn.toString());	
		   
	}
	private String dedupProjectSet(String baseSolrURL, DedupJob indexJob, GeodatafyJobLog jobLogger) throws Exception {
		int batchSize= 10000;
		int commitWithinMs= 5000;		
		try {	
		
			DedupJobData indexJobData = indexJob.getJobData();
			updateProjectSet(indexJobData.getProjectSetName(), DedupJob.JOB_RUNNING , indexJob.getStartTime());
			jobLogger.info(" Getting the datatypes of the RuleSet ", " ");
			ArrayList<String> rulesetDatatypeList = indexJobData.getRuleSetDatatypeList();	
			PreferenceStrategy preferenceStrategy;
			
			if(indexJobData.getPriority().equalsIgnoreCase(SOURCEPRIORITY)) {
				preferenceStrategy = PreferenceStrategy.BY_SOURCE_PRORITY;				
			} else {
				preferenceStrategy = PreferenceStrategy.BY_SCORE;
			}
			
			for (String datatypeName : rulesetDatatypeList) {
				
				jobLogger.info(" Getting the colllection for the datatype ", datatypeName);
				String collection = getDatatypeCollection(indexJobData.getSolrHost(), indexJobData.getSolrPort(), datatypeName);
				jobLogger.info(" The colllection name for the datatype" + datatypeName + "  is  ", collection);
				DeDupManager deDupManager = new DeDupManager(indexJobData.getSolrHost(), indexJobData.getSolrPort(), collection, batchSize, commitWithinMs);
				List<String> matchingFields = getMatchingFeilds(indexJobData.getSolrHost(), indexJobData.getSolrPort(), datatypeName, indexJobData.getQcRuleSetName(), jobLogger);
				jobLogger.info(" The matchingFields count ", "is " + matchingFields.size());			
				List<Source> sources = new ArrayList <Source>();
				for( ProjectDSInput projectObj : indexJobData.getProjects() ) {
					sources.add( new Source(projectObj.getDataSource(), projectObj.getProject()) );
				}
				
				long starttime= System.currentTimeMillis();	   
				try {
					jobLogger.info(" Invoking the DetectDuplicates across project for the datatype  ", datatypeName);
					
					int nDocs = deDupManager.detectDuplicates(datatypeName, sources, matchingFields, preferenceStrategy);
					long endtime= System.currentTimeMillis();	   
					
					System.out.println(nDocs + " solr docs read. " +  deDupManager.getUniqueCount() + " unique wells found for datatype " + datatypeName + "  in " +  (endtime-starttime)/1000 + " seconds");
					jobLogger.info(nDocs + " solr docs read. " +  deDupManager.getUniqueCount() + " unique wells found for datatype " + datatypeName + "  in " +  (endtime-starttime)/1000 + " seconds", " ");
					logger.info(nDocs + " solr docs read. " +  deDupManager.getUniqueCount() + " unique wells found for datatype " + datatypeName + "  in " +  (endtime-starttime)/1000 + " seconds");
					updateJobStatistics(datatypeName, nDocs,  deDupManager.getUniqueCount(), indexJob,  jobLogger);
					//for(DedupJobStatistics qcStat : statistics) {							
						//System.out.println(" After Project " + qcStat.getDatatype() + " Total: " + qcStat.getTotal() +  " Unique: " + qcStat.getUnique() + " Match: " + qcStat.getMatch());
					//}	
				} catch (Exception e) {
					e.printStackTrace();
					throw e;
				}	
			}
			
			indexJob.setJobStatus(DocumentIndexJob.JOB_COMPLETED);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
			updateProjectSet(indexJobData.getProjectSetName(), DedupJob.JOB_COMPLETED , indexJob.getEndTime());
	        String msg = "Deduplication completed successfully";
			return msg;
		} catch(Exception e) {
			e.printStackTrace();
			logger.error("Exception in DetectDuplicateService  " , e);
			jobLogger.error("Exception in DetectDuplicateService", e.getMessage());
			String msg=e.getMessage();
			indexJob.setJobStatus(DocumentIndexJob.JOB_ERROR);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
			return msg;
		}		
	}
	
	
	private void updateProjectSet(String projectSetName, String qcRunstatus,  String dedupRunDateTime ) throws Exception {	
		// get existing project doc's id
		SolrQuery query = new SolrQuery();
		query.set("q","*:*" );
		query.set("fl", "id" );
		query.addFilterQuery("datatype:projectSet");
		query.addFilterQuery("Name:\"" + GeoUtil.escapeQueryParams(projectSetName) + "\"");
		query.set("wt","json");
		try {
			QueryResponse resp = metadataHttpSolrClient.query(query);
			int status = resp.getStatus();
			if ( status==0 ) {
				SolrDocumentList docs = resp.getResults();
				// update the project doc's Last_Scored field with current UTC datetime 
				for(SolrDocument doc : docs) {
					String id = (String) doc.getFieldValue("id");
					
					System.out.println(id);
					SolrInputDocument projDoc = new SolrInputDocument();
					Map<String, String> partialUpdate = new HashMap<String, String>();
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
				    sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
				     String utcTime = sdf.format(stringDateToDate(dedupRunDateTime));
					partialUpdate.put("set", ZonedDateTime.parse( utcTime + "Z").toString() );	
					projDoc.addField("id",  id);
					//projDoc.addField("id", id.replace("\\", "\\\\"));
					System.out.println("dedupRunDateTime : " + dedupRunDateTime);
					
					//ZonedDateTime d = ZonedDateTime.parse(dateTime);
					

				     System.out.println("utcTime : " + utcTime);
					System.out.println("Instant.now().toString() : " + ZonedDateTime.parse( utcTime + "Z").toString());
					projDoc.addField("Last_dedupe_DateTime", partialUpdate);	
					Map<String, String> partialUpdate1 = new HashMap<String, String>();
					partialUpdate1.put("set", qcRunstatus  );	
					projDoc.addField("dedupeJobStatus", partialUpdate1);
					logger.info(projDoc.toString());
					
					metadataHttpSolrClient.add(projDoc);	
					metadataHttpSolrClient.commit();
				}						
			}
			else {
				logger.info("  Status: " + status);
			}

		} catch (Exception e ) {	
			logger.error(" updateProjectSet  Status: FAILED");
			logger.error("updateProjectSet " + e.getMessage(), e);	
			e.printStackTrace();
			throw e;
		}				
		logger.info(" ProjectSet: " + projectSetName + " Last_Scored updated.");
	} 
	public static Date stringDateToDate(String StrDate) {
	    Date dateToReturn = null;
	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");

	    try {
	        dateToReturn = (Date)dateFormat.parse(StrDate);
	    }
	    catch (ParseException e) {
	        e.printStackTrace();
	    }

	    return dateToReturn;
	}  
	
	
	
	private List<DedupJobStatistics> getJobStatistics(DedupJob indexJob,  GeodatafyJobLog jobLogger) throws IOException {
		List<DedupJobStatistics> statistics = new ArrayList<DedupJobStatistics>();
		ArrayList<String> dataTypeList = indexJob.getJobData().getRuleSetDatatypeList();
		jobLogger.info("RuleSet DataTypeList List Size : " , " " + dataTypeList.size());
		for(String  dataTypeName : dataTypeList) {
				DedupJobStatistics qcStat = new DedupJobStatistics();
				qcStat.setRuleSetName(indexJob.getJobData().getQcRuleSetName());
				qcStat.setDatatype(dataTypeName);
				statistics.add(qcStat);			
		}		
		return statistics;
	}	
	
	
	private List<DedupJobStatistics> updateJobStatistics(String datatypeName, long total, long unique,  DedupJob indexJob,  GeodatafyJobLog jobLogger) throws IOException {
		List<DedupJobStatistics> statistics = indexJob.getStatistics();		
		//for(DedupJobStatistics qcStat : statistics) {	
			
			//System.out.println(" Before Project " + qcStat.getProject() + " DAtaSource: " + qcStat.getDatasource() + qcStat.getTotal());
		//}	

					
			
		for(DedupJobStatistics dedupStat : statistics) {		
			if(dedupStat.getDatatype().equals(datatypeName) ) {	
				dedupStat.setTotal(total);	
				dedupStat.setUnique(unique);
				dedupStat.setMatch(total - unique);
			}
		}	
	
		if (statistics!=null && statistics.size()>0) {
			return statistics;
		} else {
			return statistics;
		}
	}	
	
	

	private void uploadJobRunData(String baseSolrURL, DedupJob indexJob, GeodatafyJobLog jobLogger) throws Exception {
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		
		HttpPost post = new HttpPost(baseSolrURL + "/" + JOBS_COLLECTION + "/update/json?wt=json&commitWithin=1&overwrite=true");
		
		try {
			String content = getDocContents(indexJob, jobLogger);
			content = "{\"add\": { \"doc\": " + content + "}}";
			StringEntity entity  = new StringEntity(content, "UTF-8");
			entity.setContentType("application/json");
			post.setEntity(entity);

			jobLogger.info("Adding the Dedupe job run data to solr", content);
	    	logger.info("Adding the Dedupe job run data to solr " + content);
	    	CloseableHttpResponse response = httpClient.execute(post);
			jobLogger.info("Added the Dedupe job run data to solr and the response ", response.toString());
			logger.info("Added the Dedupe job run data to solr and the response is: " + response.toString());
	    	
		} catch (ClientProtocolException e) {			
			logger.error(e.getMessage());
			logger.error("IOException ", e);
			jobLogger.error("ClientProtocolException", e.getMessage());
			throw new Exception(e.getMessage());
		} catch (IOException e) {
			logger.error(e.getMessage());
			logger.error("IOException ", e);
			
			jobLogger.error("IOException", e.getMessage());
			throw new Exception(e.getMessage());
		} finally {
			post = null;
			httpClient.close();			
		}
	}
	
	
	private String getDocContents(DedupJob indexJob,  GeodatafyJobLog jobLogger){
	    StringBuilder sb = new StringBuilder();
	    sb.append("{");
	    sb.append("\"id\":\"" + indexJob.getSolrDocID() + "\", ");
	    sb.append("\"datatype\":\"" + AlertJob.SOL_DATA_TYPE + "\", ");
	    sb.append("\"jobRunID\":\"" + indexJob.getSolrDocID() + "\", ");
	    sb.append("\"jobName\":\"" + indexJob.getJobName() + "\", ");	    
	    sb.append("\"jobType\":\"" + indexJob.getJobType() + "\", ");
	    sb.append("\"jobStatus\":\"" + indexJob.getJobStatus() + "\", ");
	    sb.append("\"startTime\":\"" + indexJob.getStartTime() + "\", ");
	    sb.append("\"endTime\":\"" + indexJob.getEndTime() + "\", ");
	    sb.append("\"logFileName\":\"" + indexJob.getLogFileName().replace("\\", "\\\\\\\\") + "\", ");
	    String jobData = indexJob.getJobDataString();
	    jobData = jobData.replace("\\", "\\\\");
	    jobData = jobData.replace("\"", "\\\"");
	    sb.append("\"jobData\":\"" + jobData + "\"");       
	
	    if(indexJob.getStatistics() != null && indexJob.getStatistics().size() > 0){
	    	DedupJobStatistics jobStatisticsobj =  indexJob.getStatistics().get(0);
	    	if(!jobStatisticsobj.getDatatype().trim().isEmpty()) {
	    	StringBuilder stat = new StringBuilder();
	    	stat.append("[");
	    	for(int i = 0; i < indexJob.getStatistics().size(); i++){
	    		DedupJobStatistics jobStatistics = indexJob.getStatistics().get(i);
	    		stat.append("\"{");
	    		 String ruleSetNAme = jobStatistics.getRuleSetName();
	    		stat.append("\\\"QC RuleSetName\\\":\\\"" + ruleSetNAme.replace("\\", "\\\\"));
	    		stat.append("\\\", \\\"Datatype\\\":\\\"" + jobStatistics.getDatatype());
	    		stat.append("\\\", \\\"Total Doc \\\":" + jobStatistics.getTotal());	  
	    		stat.append(", \\\"Unique Doc \\\":" + jobStatistics.getUnique());
	    		stat.append(", \\\"Matching Doc \\\":" + jobStatistics.getMatch());
	    		
	    		if(i == (indexJob.getStatistics().size() - 1)){
	    			stat.append("}\"");
	    		}else{
	    			stat.append("}\",");
	    		}	    		
	    	}
	    	stat.append("]");
	    	logger.info("The job Statistics is: " + stat.toString());
	    	sb.append(",\"jobStatistics\":" + stat.toString());
	    }
	    }
    	sb.append("}");
    	
		return sb.toString();
	}

	private DedupJobData constructJobData(String jobData) throws Exception
	{		
		Gson gson = new Gson();
		DedupJobData jobDataObj = gson.fromJson(jobData, DedupJobData.class);
		if(jobDataObj.getProjects() == null || jobDataObj.getProjects().size() <= 0){
			String msg = "The projects is not available in input payload.";
			throw new Exception(msg);
		
		}
		ArrayList<ProjectDSInput> projList = jobDataObj.getProjects();
		for(ProjectDSInput proj : projList) {
			if(proj.getProject() == null || proj.getProject().length() <= 0){
				String msg = "Project is null or empty";
				throw new Exception(msg);
		
			}
			if(proj.getDataSource() == null || proj.getDataSource().length() <= 0){
				String msg = "DataSource is null or empty for project " + proj.getProject();
				throw new Exception(msg);
		
			}
			if(proj.getDatasourcetypeName() == null || proj.getDatasourcetypeName().length() <= 0){
				String msg = "DataSourceTypeName is Null or Empty for project " + proj.getProject();
				throw new Exception(msg);
		
			}
		
		}
		
	
		ArrayList<String> rulesetDataTypeList = getDatatypeListFromRuleSet(jobDataObj.getSolrHost(), jobDataObj.getSolrPort(), jobDataObj.getQcRuleSetName());
		
		
		jobDataObj.setRuleSetDatatypeList(rulesetDataTypeList);;
		
		return jobDataObj;		
	}


private String getDatatypeCollection(String solarHost, String solarPort, String datatype) throws Exception {		
	
	
	CloseableHttpClient httpClient = WinHttpClients.createDefault();
	HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
			"http://" + solarHost + ":" + solarPort + "/solr/metadata" )).withHttpClient(httpClient).build();
	
	try {
		
		SolrQuery query = new SolrQuery();

		query.setQuery("*:*"); // main query
		query.set("wt", "json");
		query.setRows(2147483647);
		query.addFilterQuery("datatype:datatype");
		query.addFilterQuery("name:\"" + datatype + "\"");
						
					
		QueryResponse resp = client.query(query);
		logger.info("getDatatypeCollection  QueryResponse: " + resp.getResponse().toString());
		
		SolrDocumentList docList = resp.getResults();
		logger.info(" getDatatypeCollection QueryResponse Num : " + docList.getNumFound());
		if (docList.getNumFound() > 0 ) {			
			
				SolrDocumentList docs = resp.getResults();
				String solrCoreUrl =  null;
				for(SolrDocument doc : docs) {
					
					//String datatypeName = (String) doc.getFieldValue("name");
					solrCoreUrl = (String) doc.getFieldValue("solrCoreUrl");
					solrCoreUrl = solrCoreUrl.substring(solrCoreUrl.lastIndexOf("/")+1);
					
				}	
				return solrCoreUrl;
		} else {
			throw new Exception();
		}
			
		
			
	} catch (Exception e) {
		logger.error(e.getMessage());
		logger.error(e.getStackTrace().toString());
		logger.info("Exception during execution of Solar Query for getProjectCollection   ------>: " ,  e);
		e.printStackTrace();
		throw new Exception(e.getMessage());
		//return null;
	} finally {
		client.close();
		httpClient.close();
	}	
			
	//return null;

}

private boolean  isProjectQcScored(ProjectDSInput projectObj, String datatypeName, String solarHost, String solarPort, String collection) throws Exception {
	CloseableHttpClient httpClient = WinHttpClients.createDefault();
	HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
			"http://" + solarHost + ":" + solarPort + "/solr/" + collection )).withHttpClient(httpClient).build();
	
	try {
		
		SolrQuery query = new SolrQuery();
		query.setQuery("*:*"); // main query
		query.set("wt", "json");
		//query.setRows(2147483647);
		query.addFilterQuery("datatype:\"" + datatypeName + "\"");
		query.addFilterQuery("Project:\"" + projectObj.getProject() + "\"");
		query.addFilterQuery("DataSource:\"" + projectObj.getDataSource() + "\"");
		//query.addFilterQuery("!(datatype:Project)");
		query.addFilterQuery("DataSourceTypeName:\"" + projectObj.getDatasourcetypeName() + "\"");
		query.addFilterQuery("qcscore:[* TO *]");			
		QueryResponse resp = client.query(query);
		logger.info("getProjectCollection  QueryResponse: " + resp.getResponse().toString());
		
		SolrDocumentList docList = resp.getResults();
		logger.info(" getProjectCollection QueryResponse Num : " + docList.getNumFound());
		ArrayList<String> retList = new ArrayList<String>();
		if (docList.getNumFound() > 0 ) {			
			return true;
		} else {
			return false;
		}	
		
			
	} catch (Exception e) {
		logger.error(e.getMessage());
		logger.error(e.getStackTrace().toString());
		logger.info("Exception during execution of Solar Query for getURLAndDisplayName   ------>: " ,  e);
		e.printStackTrace();
		throw new Exception(e.getMessage());
		//return null;
	} finally {
		client.close();
		httpClient.close();
	}	
			
		
}

private ArrayList<String> getMatchingFeilds(String solarHost, String solarPort, String datatype, String qcRuleSetName , GeodatafyJobLog jobLogger) throws Exception {		
	
	
	CloseableHttpClient httpClient = WinHttpClients.createDefault();
	HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
			"http://" + solarHost + ":" + solarPort + "/solr/metadata" )).withHttpClient(httpClient).build();
	ArrayList<String> matchingFeildsList = new ArrayList<String>();
	try {
		
		SolrQuery query = new SolrQuery();

		query.setQuery("*:*"); // main query
		query.set("wt", "json");
		query.setRows(2147483647);
		query.addFilterQuery("datatype:qcRule");
		query.addFilterQuery("qcMatchingColumn:true");
		query.addFilterQuery("qcRuleSet:\"" + qcRuleSetName + "\"");
		query.addFilterQuery("qcEntity:\"" + datatype + "\"");
		
						
					
		QueryResponse resp = client.query(query);
		logger.info("getMatchingFeilds  QueryResponse: " + resp.getResponse().toString());
		
		SolrDocumentList docList = resp.getResults();
		logger.info(" getMatchingFeilds QueryResponse Num : " + docList.getNumFound());
		if (docList.getNumFound() > 0 ) {			
			
				SolrDocumentList docs = resp.getResults();
				
				for(SolrDocument doc : docs) {
					
					String qcFeild = (String) doc.getFieldValue("qcField");
					matchingFeildsList.add(qcFeild);
					
					
				}	
				
		} else {
			System.out.println("No Matching Feilds defined for the ruleSet :" + qcRuleSetName + " for datatype:" + datatype);
			if(jobLogger== null) {
				logger.error("No Matching Feilds defined for the ruleSet :" + qcRuleSetName + " for datatype:" +  datatype);
			} else {
				jobLogger.error("No Matching Feilds defined for the ruleSet :" + qcRuleSetName + " for datatype:" ,  datatype);
			}
			//throw new Exception("No Matching Feilds defined for the ruleSet :" + qcRuleSetName + " for datatype:" + datatype);
		}
			
		
			
	} catch (Exception e) {
		logger.error(e.getMessage());
		logger.error(e.getStackTrace().toString());
		logger.info("Exception during execution of Solar Query for getProjectCollection   ------>: " ,  e);
		e.printStackTrace();
		throw new Exception(e.getMessage());
		//return null;
	} finally {
		client.close();
		httpClient.close();
	}	
			
	return matchingFeildsList;
	//return null;

}


private boolean isProjecSettHasDatatype(String solarHost, String solarPort, String collection, String datatype,  ArrayList<ProjectDSInput>  projectSet, HashMap<String, ArrayList<ProjectDSInput>> datatypeProjectMap) 
		throws Exception {		
	
	
	CloseableHttpClient httpClient = WinHttpClients.createDefault();
	HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
			"http://" + solarHost + ":" + solarPort + "/solr/" + collection )).withHttpClient(httpClient).build();
	
	ArrayList<ProjectDSInput> projList = new ArrayList<ProjectDSInput>();
	try {
		for( ProjectDSInput projectObj : projectSet ) { 
			SolrQuery query = new SolrQuery();
	
			query.setQuery("*:*"); // main query
			query.set("wt", "json");
			query.setRows(2147483647);
			query.addFilterQuery("Project:\"" + projectObj.getProject() + "\"");
			query.addFilterQuery("DataSource:\"" + projectObj.getDataSource() + "\"");
			query.addFilterQuery("DataSourceTypeName:\"" + projectObj.getDatasourcetypeName() + "\"");
			query.addFilterQuery("datatype:\"" + datatype + "\"");
			
							
						
			QueryResponse resp = client.query(query);
			logger.info("isProjectHasDatatype  QueryResponse: " + resp.getResponse().toString());
			
			SolrDocumentList docList = resp.getResults();
			logger.info(" isProjectHasDatatype QueryResponse Num : " + docList.getNumFound());
			if (docList.getNumFound() > 0 ) {	
				projList.add(projectObj);
								
			}  
		}
		if(projList!=null && projList.size() > 0) {
			datatypeProjectMap.put(datatype, projList);
			return true;
		} else {
			return false;
		}
			
		
			
	} catch (Exception e) {
		logger.error(e.getMessage());
		logger.error(e.getStackTrace().toString());
		logger.info("Exception during execution of Solar Query for getProjectCollection   ------>: " ,  e);
		e.printStackTrace();
		throw new Exception(e.getMessage());
		//return null;
	} finally {
		client.close();
		httpClient.close();
	}	
			
	
	//return null;

}

	private ArrayList<String> getDatatypeListFromRuleSet(String solarHost, String solarPort, String qcRuleSetName) throws Exception {
	
		
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
				"http://" + solarHost + ":" + solarPort + "/solr/metadata" )).withHttpClient(httpClient).build();
		ArrayList<String> projList = new ArrayList<String>();
		try {
			
			SolrQuery query = new SolrQuery();
	
			query.setQuery("*:*"); // main query
			query.set("wt", "json");
			query.setRows(2147483647);
			query.set("fl",  "qcEntity" );
			
			query.addFilterQuery("datatype:qcRule");
			query.addFilterQuery("qcRuleSet:\"" + qcRuleSetName + "\"" );		
			query.set("group", true);
			query.set("group.field", "qcEntity");
			query.set("group.main", true);
			logger.info("Query: " + query.toQueryString());
			QueryResponse resp = client.query(query);
			logger.info("Job Def  QueryResponse: " + resp.getResponse().toString());
			
			SolrDocumentList docList = resp.getResults();
			logger.info(" QueryResponse Num : " + docList.getNumFound());
			if (docList.getNumFound() > 0 ) {			
				for (Map singleDoc : docList) {					
					JSONObject json = new JSONObject(singleDoc);
					logger.info(json.toString());
					if(json.has("qcEntity")) {
						projList.add( (String)json.get("qcEntity"));
					}
			
				}				
			} else {
				String msg="DataTypes not Found for ruleset " + qcRuleSetName;
				logger.error(msg);
				
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error("Exception during execution of Solar Query for getProjectDet   ------>: " ,  e);
			e.printStackTrace();
			throw new Exception(e.getMessage());
			
		} finally {
			client.close();
			httpClient.close();
		}	
				
		return projList;
		
	
	}
	
	
private ArrayList<String> getSolrURL(String solarHost, String solarPort) throws Exception {		
		
		
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
				"http://" + solarHost + ":" + solarPort + "/solr/metadata" )).withHttpClient(httpClient).build();
		ArrayList<String> solrURLList = new ArrayList<String>();
		try {
			
			SolrQuery query = new SolrQuery();
	
			query.setQuery("*:*"); // main query
			query.set("wt", "json");
			query.setRows(2147483647);
			query.set("fl",  "solrCoreUrl" );
			
			query.addFilterQuery("datatype:datatype");
			//query.addFilterQuery("qcRuleSet:\"" + proj.getQcRuleSet() + "\"" );		
			query.set("group", true);
			query.set("group.field", "solrCoreUrl");
			query.set("group.main", true);
			//logger.info("Query: " + query.toQueryString());
			QueryResponse resp = client.query(query);
			//logger.info("Job Def  QueryResponse: " + resp.getResponse().toString());
			
			SolrDocumentList docList = resp.getResults();
			//logger.info(" QueryResponse Num : " + docList.getNumFound());
			if (docList.getNumFound() > 0 ) {			
				for (Map singleDoc : docList) {					
					JSONObject json = new JSONObject(singleDoc);
					//logger.info(json.toString());
					//System.out.println(json.toString());
					if(json.has("solrCoreUrl")) {
						String solrCoreUrl = (String)json.get("solrCoreUrl");
						solrCoreUrl = solrCoreUrl.substring(solrCoreUrl.lastIndexOf("/")+1);
						if(!solrURLList.contains(solrCoreUrl)) {
							solrURLList.add(solrCoreUrl);
						}
						//System.out.println(solrCoreUrl);
					}
			
				}				
			} else {
				String msg="DataTypes not Found for Project " ;
				//logger.error(msg);
				
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error("Exception during execution of Solar Query for getSolrURL   ------>: " ,  e);
			e.printStackTrace();
			throw new Exception(e.getMessage());
			
		} finally {
			client.close();
			httpClient.close();
		}	
				
		return solrURLList;
	
	} 

private ArrayList<String> getDataTypesForProject(String solarHost, String solarPort,ProjectDSInput project, ArrayList<String> solrUrlList) throws Exception {		
	
	
	CloseableHttpClient httpClient = WinHttpClients.createDefault();
	
	ArrayList<String> projList = new ArrayList<String>();

	for (String collection : solrUrlList) {
		HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
				"http://" + solarHost + ":" + solarPort + "/solr/" + collection )).withHttpClient(httpClient).build();

		try {			
		
				SolrQuery query = new SolrQuery();
		
				query.setQuery("*:*"); // main query
				query.set("wt", "json");
				query.setRows(2147483647);
				query.set("fl",  "datatype" );
				
				query.addFilterQuery("Project:\"" + GeoUtil.escapeQueryParams(project.getProject()) + "\"" );
				query.addFilterQuery("DataSource:\"" + GeoUtil.escapeQueryParams(project.getDataSource()) + "\"" );
				query.addFilterQuery("DataSourceTypeName:\"" + GeoUtil.escapeQueryParams(project.getDatasourcetypeName()) + "\"" );
				//query.addFilterQuery("qcRuleSet:\"" + proj.getQcRuleSet() + "\"" );		
				query.set("group", true);
				query.set("group.field", "datatype");
				query.set("group.main", true);
				//System.out.println("Query: " + query.toQueryString());
				QueryResponse resp = client.query(query);
				//System.out.println("Job Def  QueryResponse: " + resp.getResponse().toString());
				
				SolrDocumentList docList = resp.getResults();
				//System.out.println(" 111 QueryResponse Num : " + docList.getNumFound());
				if (docList.getNumFound() > 0 ) {			
					for (Map singleDoc : docList) {					
						JSONObject json = new JSONObject(singleDoc);
						logger.info(json.toString());
						if(json.has("datatype")) {
							String strDatatype = (String)json.get("datatype");
							if(!strDatatype.equals("Project") && !projList.contains(strDatatype)) {
								projList.add(strDatatype);
							}							
							//System.out.println((String)json.get("datatype"));
						}
				
					}				
				} else {
					String msg="DataTypes not Found for Project " + project.getProject() + " in the collection : " + collection;
					//logger.error(msg);
					
					
				}
			
			} catch (Exception e) {
				logger.error(e.getMessage());
				logger.error("Exception during execution of Solar Query for getDataTypesForProject   ------>: " ,  e);
				e.printStackTrace();
				throw new Exception(e.getMessage());
				
			} finally {
				client.close();
				
			}
	}
			
	httpClient.close();		
	return projList;

} 
/*
private int getQCJobBatchSize(String solarHost, String solarPort) throws Exception {		
	int batchSize = BATCH_SIZE;
	
	CloseableHttpClient httpClient = WinHttpClients.createDefault();
	HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
			"http://" + solarHost + ":" + solarPort + "/solr/metadata" )).withHttpClient(httpClient).build();
	ArrayList<String> solrURLList = new ArrayList<String>();
	try {
		
		SolrQuery query = new SolrQuery();

		query.setQuery("*:*"); // main query
		query.set("wt", "json");
		query.setRows(2147483647);
		query.set("fl",  "qcBatch" );
		
		query.addFilterQuery("datatype:AppConfig");
		//query.addFilterQuery("qcRuleSet:\"" + proj.getQcRuleSet() + "\"" );		
		//query.set("group", true);
		//query.set("group.field", "solrCoreUrl");
		//query.set("group.main", true);
		logger.info("Query: " + query.toQueryString());
		QueryResponse resp = client.query(query);
		logger.info("Job Def  QueryResponse: " + resp.getResponse().toString());
		
		SolrDocumentList docList = resp.getResults();
		logger.info(" QueryResponse Num : " + docList.getNumFound());
		if (docList.getNumFound() > 0 ) {			
			for (Map singleDoc : docList) {					
				JSONObject json = new JSONObject(singleDoc);
				logger.info(json.toString());
				System.out.println(json.toString());
				if(json.has("qcBatch")) {
					batchSize = ((Long)json.get("qcBatch")).intValue();		
					BATCH_SIZE = batchSize;
				}
		
			}				
		} 
	} catch (Exception e) {
		logger.error(e.getMessage());
		logger.error("Exception during execution of Solar Query for getQCJobBatchSize   ------>: " ,  e);
		e.printStackTrace();
		//throw new Exception(e.getMessage());
		
	} finally {
		client.close();
		httpClient.close();
	}	
			
	return batchSize;

} */



}
