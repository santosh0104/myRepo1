package com.bct.geodatafy.rest.service;


import java.io.File;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.file.Files;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.activation.MimetypesFileTypeMap;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;

import javax.ws.rs.Path;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;

import org.apache.commons.io.FileUtils;

import org.apache.log4j.Logger;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

import com.bct.geodatafy.exportimportjson.ExportImportJsonUtil;
import com.bct.geodatafy.exportimportjson.config.CommandLineConfig;
import com.bct.geodatafy.exportimportjson.config.ConfigFactory;

import com.bct.geodatafy.rest.service.exception.GeodatafyInputException;
import com.bct.geodatafy.util.EnvUtil;
import com.bct.geodatafy.util.FileUtil;
import com.bct.geodatafy.util.JsonUtil;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;


@Path("/admin")
public class JsonImportExportService {
	static Logger logger = Logger.getLogger(JsonImportExportService.class);
	//public static final String JOB_TYPE = "DocumentIndexer";
		//public static final String JOBS_COLLECTION = "jobs";
	

	//private static final String DATASOURCE="Document";
	
	
	@POST
	@Path("/export")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response exportCollection(String payLoad
			, @Context HttpServletRequest request
			) throws Exception{		
		logger.info("In service: /admin/export and method: exportCollection");		
		
		Map<String, JsonElement> elementsMap = JsonUtil.getJsonElementMap(payLoad);
				
		String sourceCollection = elementsMap.get("sourceCollection").getAsString();
		
		if(sourceCollection == null || sourceCollection.length() < 1){
			String msg = "sourceCollection  is Null or Empty";
			logger.error(msg + " Returning without doing anything.");
			throw new GeodatafyInputException(msg);			
		}
		String solrHost = "localhost";
		solrHost = elementsMap.get("solrHost").getAsString();
		
		String solrPort="8983";
		solrPort=elementsMap.get("solrPort").getAsString();
	
		String isZip = "false";
		if (elementsMap.get("isZip") != null) {
			isZip = elementsMap.get("isZip").getAsString();
		} 		
		
		System.out.println("json values are " + sourceCollection + " " + solrHost + " " + solrPort);
	
		String programDataDir =  EnvUtil.getGDDataPath() + "\\tmp\\export\\";
		if(programDataDir != null && !programDataDir.isEmpty()){				
			File dir = new File(programDataDir);
			if(dir == null || !dir.isDirectory()){ 
				dir.mkdir();
			}
		}
		DateFormat dateFormat = new SimpleDateFormat("ddMMyyyy_HHmmss");
		Date date = new Date();
		String currentDate = dateFormat.format(date);
		String exportDir = programDataDir +  currentDate + "\\" ;	
		logger.info("export directory "+ exportDir );
		if(exportDir != null && !exportDir.isEmpty()){				
			File dir = new File(exportDir);
			if(dir == null || !dir.isDirectory()){ 
				dir.mkdir();
			}
		}
		 JsonElement jsonArrElem = elementsMap.get("filterContent");
		 String strFilerCondition = null;
		 if (jsonArrElem == null) {
			 
		 } else  {
			JsonArray expJsonArr = JsonUtil.convertToJsonArray(jsonArrElem);
			List<JsonObject> list = new ArrayList<JsonObject>();
			for (JsonElement je :  expJsonArr) {
			    JsonObject jsonObj = je.getAsJsonObject();
			    list.add(jsonObj);
			}
			
			StringBuilder sb = new StringBuilder();
			int i= 0;
			for(JsonObject jsonObj : list) {
				sb.append("( ");
				sb.append("Project:").append("\"").append(jsonObj.get("project").getAsString()).append("\" && ");
				sb.append("DataSource:").append("\"").append(jsonObj.get("datasource").getAsString()).append("\" && ");
				sb.append("DataSourceTypeName:").append("\"").append(jsonObj.get("datasourcetype").getAsString()).append("\" && ");
				sb.append("DataSourceTypeVersion:").append("\"").append(jsonObj.get("version").getAsString()).append("\" && ");
				sb.append("datatype:").append("\"").append(jsonObj.get("datatype").getAsString()).append("\" ) || ");
				i++;
			}
			if(i > 0 ) {
				strFilerCondition = sb.toString();
				strFilerCondition = strFilerCondition.substring(0, strFilerCondition.length()-4);
			}
		 }
			logger.info("The strFilerCondition contructed is  " + strFilerCondition);
			
			
		String exportDirFile = exportDir +  sourceCollection +  ".json"; 
		logger.info("exportdirectory without zippig is " + exportDirFile);
		String solrCollectionUrl = "http://" + solrHost+ ":" + solrPort + "/solr/" + sourceCollection;
	//	ConfigFactory.getConfig(solrUrl, skipFields, includeFields, file, filterQuery, uniqueKey, deleteAll, dryRun, actionType, blockSize, skipCount, commitAfter, dateTimeFormat)
		  
		 CommandLineConfig configObj =  ConfigFactory.getConfig(solrCollectionUrl, "_version_", null, exportDirFile, strFilerCondition, null, false, false, "export", null, null, null, null);
		 ExportImportJsonUtil.callExportImportJson(configObj);
		 logger.info("Successfully exported the data to file " + exportDirFile);
		
		 if(isZip.equalsIgnoreCase("true")) {
			 exportDirFile = exportDir +  sourceCollection +  ".zip";
			 FileUtil.zipDirectory(exportDir, exportDirFile);
			 logger.info("The Files are zipped and is in directory " + exportDirFile);

		 } 
		
		 
		 final String filePath =  new File(exportDirFile).toURI().toString();
		 logger.warn("Exported File Path to be sent to client : " + filePath);
	        StreamingOutput fileStream =  new StreamingOutput()
	        {
	            @Override
	            public void write(java.io.OutputStream output) throws IOException, WebApplicationException
	            {
	                try
	                {
	                	String fileUNCPath = filePath;
	                	if (filePath.startsWith("file://")) {
	                		// do nothing
	                	} else {
	                		if (filePath.startsWith("file:/")) {
	                			fileUNCPath = fileUNCPath.replace("file:/", "file:///");
	                		}
	                	}
	                	
	                	URL url1 = new URL(fileUNCPath.replace("%", "%25").replace("+", "%2B").replace("#", "%23"));
	                	File file = new File(URLDecoder.decode(url1.getPath(), "UTF-8"));
	                   
	                    byte[] data = Files.readAllBytes(file.toPath());
	                    output.write(data);
	                    output.flush();
	                }
	                catch (Exception e)
	                {
	                	logger.error("Exception in getFile " , e);
	                    throw new GeodatafyInputException("File Not Found !!");
	                }
	            }
	        };
	       String fileName = filePath.substring(filePath.lastIndexOf("/")+1);
	       logger.info("fileName in downloadFile " + fileName );
	        String attach = "attachment; filename = " + fileName;      
	        logger.info("attach in downloadFile " + attach);
	        MimetypesFileTypeMap fileTypeMap = new MimetypesFileTypeMap();
	        String mime = fileTypeMap.getContentType(filePath);
	        if(!isZip.equalsIgnoreCase("true")) {
	        	mime ="application/json";
	        }
	        logger.info("mime in downloadFile " + mime);
	        return Response
	                .ok(fileStream,mime)
	                .header("content-disposition",attach)
	                .build();
		
					
		
	}
	
	@POST
	@Path("/import")
	@Consumes({MediaType.MULTIPART_FORM_DATA})
	public Response importCollection(  @FormDataParam("file") InputStream fileInputStream,
									@FormDataParam("importJson") String payLoad,
	                                @FormDataParam("file") FormDataContentDisposition fileMetaData) throws Exception
	{
		logger.info("In service: /admin/import and method: importCollection");
		
		
		String importDir = "";
	    String programDataDir =  EnvUtil.getGDDataPath() + "\\tmp\\import\\";
		if(programDataDir != null && !programDataDir.isEmpty()){				
			File dir = new File(programDataDir);
			if(dir == null || !dir.isDirectory()){ 
				dir.mkdir();
			}
		}
		DateFormat dateFormat = new SimpleDateFormat("ddMMyyyy_HHmmss");
		Date date = new Date();
		String currentDate = dateFormat.format(date);
		importDir = programDataDir +  currentDate + "\\" ;	
		if(importDir != null && !importDir.isEmpty()){				
			File dir = new File(importDir);
			if(dir == null || !dir.isDirectory()){ 
				dir.mkdir();
				dir = new File(importDir + "unzip\\");
				dir.mkdir();
			}
		}
			
	    try
	    {
	        int read = 0;
	        byte[] bytes = new byte[1024];
	 
	        OutputStream out = new FileOutputStream(new File(importDir + fileMetaData.getFileName()));
	        while ((read = fileInputStream.read(bytes)) != -1)
	        {
	            out.write(bytes, 0, read);
	        }
	        out.flush();
	        out.close();
	    } catch (IOException e)
	    {	    	
	    	logger.error("Error while reading the file : " + e.getMessage());
	        throw new GeodatafyInputException("Error while uploading file. Please try again !!");
	    }
	    logger.info("Saved the uploaded file in the import dir: " + importDir);
	    Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);
		
		String targetCollection = elementsMap.get("targetCollection");
		
		if(targetCollection == null || targetCollection.length() < 1){
			String msg = "targetCollection  is Null or Empty";
			logger.error(msg + " Returning without doing anything.");			
			throw new GeodatafyInputException(msg);
						
		}
		String solrHost = "localhost";
		solrHost = elementsMap.get("solrHost");	
		
		
		//String solrPort="80";
		String solrPort="8983";
		solrPort=elementsMap.get("solrPort");	
	
		String isZip = "false";
		/*if (elementsMap.get("isZip") != null) {
			isZip = elementsMap.get("isZip");
		} 	*/	
		String importJsonFile =  null;
		
		if(fileMetaData.getFileName().endsWith("zip")) {
			isZip = "true";
		} else {
			isZip = "false";
		}
		 
		if(isZip.equalsIgnoreCase("true")) {
			 FileUtil.unzip(importDir + fileMetaData.getFileName(), importDir + "unzip\\");	
			 importJsonFile = importDir + "unzip\\";
			 importDir = importDir + "unzip\\";
			 logger.info("importjsonfile in import service when isZip is true " +importJsonFile );
		} else {		 
			importJsonFile = importDir + fileMetaData.getFileName();
			
			logger.info("importjsonfile in import service when isZip is false " +importJsonFile );
		}
		
		  
		 String solrCollectionUrl = "http://" + solrHost+ ":" + solrPort + "/solr/" + targetCollection;
		 logger.info("solrCollectionUrl " + solrCollectionUrl);
		
		 File folder = new File(importJsonFile);
		 logger.info("File Path  " + folder.getAbsolutePath());
		 String jsonErrMsg = ExportImportJsonUtil.validateJsonFile(importDir);
		 logger.info("File Validation String  " + jsonErrMsg);
		 if(!jsonErrMsg.equalsIgnoreCase("validjsonfile")) {			 
				logger.error("Json File Validation fails . The error is  " + jsonErrMsg);
				throw new GeodatafyInputException(jsonErrMsg);
		 }
		try {	
		 String[] files = folder.list();
		 if(isZip.equalsIgnoreCase("true")) {
		     for (String file : files)  {
		    	 logger.info("File Name Importing " + importJsonFile);
		    	 logger.info("File Name Importing " + file);
		    	 importJsonFile = importJsonFile + file;
		    	 
		    	 logger.info("File  Importing " + importJsonFile);
		    	 CommandLineConfig configObj =  ConfigFactory.getConfig(solrCollectionUrl, "_version_", null, importJsonFile , null, null, false, false, "import", "500", null, "6000", null);
				 ExportImportJsonUtil.callExportImportJson(configObj);	
				 logger.info("file imported successfully to the collection " + targetCollection);
				 
		     }
		 } else {
			 logger.info("File Name Importing else condition" + importJsonFile);
			 CommandLineConfig configObj =  ConfigFactory.getConfig(solrCollectionUrl, "_version_", null, importJsonFile, null, null, false, false, "import", "500", null, "6000", null);
			 
			 ExportImportJsonUtil.callExportImportJson(configObj);
			 logger.info("File imported successfully to the collection " + targetCollection);
			 
			 
			 
			 
		 }
		 FileUtils.deleteDirectory(new File(importDir));
		}
		catch (Exception e) {
			// TODO: handle exception
			logger.error("error in uploading the  json file  " + e);
			logger.error("error in uploading the  json file  " + e.getMessage());
			 FileUtils.deleteDirectory(new File(importDir));
			throw new GeodatafyInputException(e.getMessage());
		}
		
	    return Response.ok("File imported successfully.").build();
		
	}
	
	
	@POST
	@Path("/importConfig")
	@Consumes({MediaType.MULTIPART_FORM_DATA})
	public Response importConfig(  
			@FormDataParam("file") InputStream fileInputStream, 
			@FormDataParam("file") FormDataContentDisposition fileMetaData, 
			@FormDataParam("importjson") String payLoad
	                                ) throws Exception
	{
		
		logger.info("In service: /admin/importConfig and method: importConfig");
		String importDir = "";
		
		
	    String programDataDir =  EnvUtil.getGDDataPath() + "\\tmp\\import\\";
	    logger.debug("programDataDir value in importConfig service" + programDataDir);
		if(programDataDir != null && !programDataDir.isEmpty()){				
			File dir = new File(programDataDir);
			if(dir == null || !dir.isDirectory()){ 
				dir.mkdir();
			}
		}
		
		DateFormat dateFormat = new SimpleDateFormat("ddMMyyyy_HHmmss");
		Date date = new Date();
		String currentDate = dateFormat.format(date);
		importDir = programDataDir +  currentDate + "\\" ;
		logger.info("importDir value in importConfig service" + importDir);
		
		if(importDir != null && !importDir.isEmpty()){				
			File dir = new File(importDir);
			if(dir == null || !dir.isDirectory()){ 
				dir.mkdir();
				dir = new File(importDir + "unzip\\");
				dir.mkdir();
			}
		}
		logger.info("Saved the uploaded file in the import dir: " + importDir);	
	    try
	    {
	        int read = 0;
	        byte[] bytes = new byte[1024];
	 
	        OutputStream out = new FileOutputStream(new File(importDir + fileMetaData.getFileName()));
	        while ((read = fileInputStream.read(bytes)) != -1)
	        {
	            out.write(bytes, 0, read);
	        }
	        out.flush();
	        out.close();
	    } catch (IOException e)
	    {	    	
	    	logger.error("Error while uploading file : " + e.getMessage());
	        throw new GeodatafyInputException("Error while uploading file. Please try again !!");
	    }
	    
	    Map<String, JsonElement> elementsMap = JsonUtil.getJsonElementMap(payLoad);
		
	    String solrHost = "localhost";
		if(elementsMap.get("solrHost") != null){
			solrHost = elementsMap.get("solrHost").getAsString();
		}else{
			logger.info("solr Host is not set. Assuming localhost");		
		}
		logger.info("solr host is set to: " + solrHost);
				
		String solrPort = "80";
		if(elementsMap.get("solrPort") != null){
			solrPort = elementsMap.get("solrPort").getAsString();
		}else{
			logger.info("solr Port is not set. Assuming 80");		
		}
		logger.info("solr Port is set to: " + solrPort);	
	
	
		String isZip = "false";
		/*if (elementsMap.get("isZip") != null) {
			isZip = elementsMap.get("isZip").getAsString();
		} */
		
		if(fileMetaData.getFileName().endsWith("zip")) {
			isZip = "true";
		} else {
			isZip = "false";
		}
		logger.info("isZip is set to: " + isZip);
		JsonElement jsonArrElem =  elementsMap.get("importConfig");
		if(jsonArrElem  == null){
			throw new GeodatafyInputException("Config to be imported  is null returns without doing anything ");
		}
			
		JsonArray expJsonArr = JsonUtil.convertToJsonArray(jsonArrElem);
		List<String> list = new ArrayList<String>();
		for (JsonElement je :  expJsonArr) {
		    list.add( je.getAsString() );
		}
		
		String importJsonDir =  null;
		if(isZip.equalsIgnoreCase("true")) {
			 FileUtil.unzip(importDir + fileMetaData.getFileName(), importDir + "unzip\\");	
			 importJsonDir = importDir + "unzip\\";
			 logger.info("importJsonDir in imporconfig service when iszip is true");
		} else {		 
			importJsonDir = importDir;
			logger.info("importJsonDir in imporconfig service when iszip is false");
		}
		
		logger.error("importJsonDir is set to: " + importJsonDir);
		
		try {
		
			File folder = new File(importJsonDir);
			logger.info("folder path is " + folder);
			System.out.println("folder path " + folder);
			
			 String jsonErrMsg = ExportImportJsonUtil.validateJsonFile(importJsonDir);
			 if(!jsonErrMsg.equalsIgnoreCase("validjsonfile")) {			 
					logger.error("Json File Validation fails . The error is  " + jsonErrMsg);
					throw new GeodatafyInputException(jsonErrMsg);
			 }
			 
	        String[] files = folder.list();
	        
	
	        	for (String file : files) {
	        		logger.info("File to be imported : " + file);
	        		if(file.startsWith("General") || file.startsWith("DataTypes") || 
	        				file.startsWith("Users") || file.startsWith("ExportCapabilities") || file.startsWith("TransferCapabilities"))
	    			{	
	        			
	    				String targetCollection= "metadata";
	    				String importFile = importJsonDir  +  file;
	    				String solrCollectionUrl = "http://" + solrHost+ ":" + solrPort + "/solr/" + targetCollection;
	    				CommandLineConfig configObj =  ConfigFactory.getConfig(solrCollectionUrl, null, null, importFile, "_version_", null, false, false, "import", null, null, null, null);
	    				ExportImportJsonUtil.callExportImportJson(configObj);   
	    				logger.info(" The File " + importFile + " is imported successfully in the collection " + targetCollection );
	    				
	    				
	    			}
	        		if(file.startsWith("jobDefinition")||file.startsWith("jobRuns"))
	        		{
	        			
	        			logger.info("File is set to import : " + "222222" );
	        			String targetCollection="jobs";
	        			String importFile =importJsonDir  +  file;
	        			String solrCollectionUrl = "http://" + solrHost+ ":" + solrPort + "/solr/" + targetCollection;
	    				CommandLineConfig configObj =  ConfigFactory.getConfig(solrCollectionUrl, null, null, importFile, "_version_", null, false, false, "import", null, null, null, null);
	    				ExportImportJsonUtil.callExportImportJson(configObj);    
	    				logger.info(" The File " + importFile + " is imported successfully in the collection " + targetCollection );
	        		
	    				
	        		}
	        	} 
	        	
		} catch(Exception e) {
			logger.error("Exception during import of Configuration " , e);
			throw new GeodatafyInputException("Exception during import of Configuration " + e.getMessage());
			
		}
	   
	    return Response.ok("File imported successfully.").build();
	}
	
	
	
	@POST
	@Path("/exportConfig")
	@Consumes({MediaType.APPLICATION_JSON})
	public Response exportConfig(String payLoad
			,@Context HttpServletRequest request
			) throws Exception {		
	
		logger.info("Inside the service admin/exportConfig and  method name: exportConfig "  + payLoad);
		String importDir = "";
		String programDataDir =  EnvUtil.getGDDataPath() + "\\tmp\\export\\";
	  		if(programDataDir != null && !programDataDir.isEmpty()){				
			File dir = new File(programDataDir);
			if(dir == null || !dir.isDirectory()){ 
				dir.mkdir();
			}
		}
		logger.info("programDataDir in exportConfig service  "  + programDataDir);
		DateFormat dateFormat = new SimpleDateFormat("ddMMyyyy_HHmmss");
		Date date = new Date();
		String currentDate = dateFormat.format(date);
		String exportDir = programDataDir +  currentDate + "\\" ;	
		if(exportDir != null && !exportDir.isEmpty()){				
			File dir = new File(exportDir);
			if(dir == null || !dir.isDirectory()){ 
				dir.mkdir();
			}
		}
		
		
	    Map<String, JsonElement> elementsMap = JsonUtil.getJsonElementMap(payLoad);
		
	    String solrHost = "localhost";
		if(elementsMap.get("solrHost") != null){
			solrHost = elementsMap.get("solrHost").getAsString();
		}else{
			logger.info("solr Host is not set. Assuming localhost");		
		}
		logger.error("solr host is set to: " + solrHost);
				
		String solrPort = "80";
		if(elementsMap.get("solrPort") != null){
			solrPort = elementsMap.get("solrPort").getAsString();
		}else{
			logger.info("solr Port is not set. Assuming 80");		
		}
		logger.info("solr Port is set to: " + solrPort);	
	
	
		String isZip = "false";
		if (elementsMap.get("isZip") != null) {
			isZip = elementsMap.get("isZip").getAsString();
		} 
		logger.info("isZip is set to: " + isZip);
		JsonElement jsonArrElem =  elementsMap.get("exportConfig");
		if(jsonArrElem  == null){
			throw new GeodatafyInputException("Config to be exported  is null returns without doing anything ");
		}
			
		JsonArray expJsonArr = JsonUtil.convertToJsonArray(jsonArrElem);
		List<String> list = new ArrayList<String>();
		for (JsonElement je :  expJsonArr) {
		    list.add( je.getAsString() );
		}
		
		String sourceCollection=null;
		for(String str :list){
			String tempExpDir = exportDir;
			logger.info("File to be experted : " + tempExpDir);
			if(str.equalsIgnoreCase("General"))
			{
				String filterQuery= "datatype:\"AppConfig\" OR \"colorTheme\" OR \"mapService\" OR \"mailService\"";
				sourceCollection= "metadata";
				tempExpDir = tempExpDir  +  "General.json";
				String solrCollectionUrl = "http://" + solrHost+ ":" + solrPort + "/solr/" + sourceCollection;
				  //ConfigFactory.getConfig(solrUrl, skipFields, includeFields, file, filterQuery, uniqueKey, deleteAll, dryRun, actionType, blockSize, skipCount, commitAfter, dateTimeFormat)
				 CommandLineConfig configObj =  ConfigFactory.getConfig(solrCollectionUrl, "_version_", null, tempExpDir, filterQuery, null, false, false, "export", null, null, null, null);
				 ExportImportJsonUtil.callExportImportJson(configObj);
				 logger.info(" The File " + tempExpDir + " contains the exported data from the collection " + sourceCollection );

				logger.info("Creating the document index job: " + sourceCollection + " ");
				//Logic to create a job in solr						
			}
			if(str.equalsIgnoreCase("DataTypes")) {
				sourceCollection="metadata";
				String filterQuery= "datatype:\"datatype\" OR \"projectset\"";
				tempExpDir = tempExpDir +   "DataTypes.json";
				String solrCollectionUrl = "http://" + solrHost+ ":" + solrPort + "/solr/" + sourceCollection;
				  
				 CommandLineConfig configObj =  ConfigFactory.getConfig(solrCollectionUrl, "_version_", null, tempExpDir, filterQuery, null, false, false, "export", null, null, null, null);
				 ExportImportJsonUtil.callExportImportJson(configObj);
				

				 logger.info(" The File " + tempExpDir + " contains the exported data from the collection " + sourceCollection );
				//Logic to create a job in solr						

			}
			
			if(str.equalsIgnoreCase("JobDefinitions")) {
				sourceCollection="jobs";
				String filterQuery= "datatype:\"jobDefinition\"";
				tempExpDir = tempExpDir +    "jobDefinition.json";
				String solrCollectionUrl = "http://" + solrHost+ ":" + solrPort + "/solr/" + sourceCollection;
				  
				 CommandLineConfig configObj =  ConfigFactory.getConfig(solrCollectionUrl, "_version_", null, tempExpDir, filterQuery, null, false, false, "export", null, null, null, null);
				 ExportImportJsonUtil.callExportImportJson(configObj);
				 

				 logger.info(" The File " + tempExpDir + " contains the exported data from the collection " + sourceCollection );
				//Logic to create a job in solr						

			}
			if(str.equalsIgnoreCase("JobRuns")) {
				sourceCollection="jobs";
				String filterQuery= "datatype:\"jobRuns\"";
				tempExpDir = tempExpDir +    "jobRuns.json";
				StringBuffer solrCollectionUrl = new StringBuffer();
				solrCollectionUrl.append("http://");
				solrCollectionUrl.append(solrHost+":");
				solrCollectionUrl.append(solrPort);
				solrCollectionUrl.append("/solr/");
				solrCollectionUrl.append(sourceCollection);;  
				 CommandLineConfig configObj =  ConfigFactory.getConfig(solrCollectionUrl.toString(), "_version_", null, tempExpDir, filterQuery, null, false, false, "export", null, null, null, null);
				 ExportImportJsonUtil.callExportImportJson(configObj);
				
				  

				 logger.info(" The File " + tempExpDir + " contains the exported data from the collection " + sourceCollection );
				//Logic to create a job in solr						

			}
			if(str.equalsIgnoreCase("Users")) {
				sourceCollection="metadata";
				
				String filterQuery= "datatype:\"userRoles\" OR \"activeDirectory\" OR \"deniedUser\" OR \"userSession\"";
				tempExpDir = tempExpDir +    "Users.json";
				String solrCollectionUrl = "http://" + solrHost+ ":" + solrPort + "/solr/" + sourceCollection;
				  
				 CommandLineConfig configObj =  ConfigFactory.getConfig(solrCollectionUrl, "_version_", null, tempExpDir, filterQuery, null, false, false, "export", null, null, null, null);
				 ExportImportJsonUtil.callExportImportJson(configObj);
				

				 logger.info(" The File " + tempExpDir + " contains the exported data from the collection " + sourceCollection );
				//Logic to create a job in solr						
 
			}	
			if(str.equalsIgnoreCase("ExportCapabilities")) {
				sourceCollection="metadata";
				String filterQuery= "datatype:\"exportCap\" OR \"exportFormat\"";
				tempExpDir = tempExpDir +    "ExportCapabilities.json";
				String solrCollectionUrl = "http://" + solrHost+ ":" + solrPort + "/solr/" + sourceCollection;
				  
				 CommandLineConfig configObj =  ConfigFactory.getConfig(solrCollectionUrl, "_version_", null, tempExpDir, filterQuery, null, false, false, "export", null, null, null, null);
				 ExportImportJsonUtil.callExportImportJson(configObj);
				

				 logger.info(" The File " + tempExpDir + " contains the exported data from the collection " + sourceCollection );
				//Logic to create a job in solr						

			}
			if(str.equalsIgnoreCase("TransferCapabilities")) {
				sourceCollection="metadata";
				String filterQuery= "datatype:\"transferCap\"";
				tempExpDir = tempExpDir +    "TransferCapabilities.json";
				String solrCollectionUrl = "http://" + solrHost+ ":" + solrPort + "/solr/" + sourceCollection;
				  
				 CommandLineConfig configObj =  ConfigFactory.getConfig(solrCollectionUrl, "_version_", null, tempExpDir, filterQuery, null, false, false, "export", null, null, null, null);
				 ExportImportJsonUtil.callExportImportJson(configObj);
				 
				  

				 logger.info(" The File " + tempExpDir + " contains the exported data from the collection " + sourceCollection );
				//Logic to create a job in solr						

			}
		}
		
		
		if(isZip.equalsIgnoreCase("true")) {
			String exportDirFile = exportDir +  currentDate +  ".zip";
			 FileUtil.zipDirectory(exportDir, exportDirFile);
			 logger.info("zipping the file to the directory " + exportDirFile);
		 } 
	
    	
   
    	 final String filePath =  new File(exportDir+currentDate+".zip").toURI().toString();
		 logger.info("Exported File Path to be sent to client : " + filePath);
	        StreamingOutput fileStream =  new StreamingOutput()
	        {
	            @Override
	            public void write(java.io.OutputStream output) throws IOException, WebApplicationException
	            {
	                try
	                {
	                	String fileUNCPath = filePath;
	                	if (filePath.startsWith("file://")) {
	                		// do nothing
	                	} else {
	                		if (filePath.startsWith("file:/")) {
	                			fileUNCPath = fileUNCPath.replace("file:/", "file:///");
	                		}
	                	}
	                	
	                	URL url1 = new URL(fileUNCPath.replace("%", "%25").replace("+", "%2B").replace("#", "%23"));
	                	File file = new File(URLDecoder.decode(url1.getPath(), "UTF-8"));
	                   
	                    byte[] data = Files.readAllBytes(file.toPath());
	                    output.write(data);
	                    output.flush();
	                }
	                catch (Exception e)
	                {
	                	logger.error("Exception in getFile " , e);
	                    throw new GeodatafyInputException("Exported file not found in the path or not able to read !!");
	                }
	            }
	        };
	       String fileName = filePath.substring(filePath.lastIndexOf("/")+1);
	        String attach = "attachment; filename = " + fileName;      

	        MimetypesFileTypeMap fileTypeMap = new MimetypesFileTypeMap();
	        String mime = fileTypeMap.getContentType(filePath);
	        return Response.ok(fileStream,mime).header("content-disposition",attach).build();
		

	}
	
	

	
	
public static void main(String[] args) throws Exception {
	JsonImportExportService export = new JsonImportExportService();
	JSONObject json = new JSONObject();
	json.put("solrHost", "localhost");
	json.put("sourceCollection", "metadata");
	json.put("solrPort", "8983");
	json.put("isZip", "false");
	 JSONArray jsonArr = new JSONArray();
	
	jsonArr.put("jonRuns");
	jsonArr.put("User");
	json.put("exportConfig", jsonArr);
	System.out.println(json.toString());
	//export.exportCollection(json.toString());
	 System.out.println(new File("C:\\ProgramData\\Geodatafy\\tmp\\export\\06092019_134816\\metadata.json").toURI());
	 try {
	        // First try to resolve as URL (file:...)
	        //Path path = Paths.get();
	       
	       // FileSystemResource resource = new FileSystemResource(path.toFile());
	        //return resource;
	    } catch (Exception  e) {
	        // If given file string isn't an URL, fall back to using a normal file 
	       // return new FileSystemResource(file);
	    }
	
}
	
	
}
