package com.bct.geodatafy.rest.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.commons.io.FileUtils;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.WinHttpClients;
import org.apache.log4j.Logger;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.bct.geodatafy.backup.BackupUtil;
import com.bct.geodatafy.job.GeodatafyJobLog;
import com.bct.geodatafy.job.backup.BackupJobData;
import com.bct.geodatafy.job.backup.SolrBackupJob;
import com.bct.geodatafy.job.backup.SolrBackupJobStatistics;
import com.bct.geodatafy.job.document.DocumentIndexJob;
import com.bct.geodatafy.job.document.DocumentIndexJobData;
import com.bct.geodatafy.job.qc.project;
import com.bct.geodatafy.util.JsonUtil;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

/**
 * 
 * @author LG111891
 *  This class is used to take solr backup of all collections and ZooData configuration.
 */

@Path("/jobs/backup")
public class BackupService{
	static Logger logger = Logger.getLogger(BackupService.class);
	public static final String JOB_TYPE = "SolrBackupservice";
	public static final int COMMIT_SIZE = 10;
	public static final String JOBS_COLLECTION = "jobs";
	
	 
	@POST
	@Path("/run")
	@Consumes(MediaType.APPLICATION_JSON)
	public String runSolrBackupJobService(String payLoad
			, @Context HttpServletRequest request
			) throws Exception{		
		logger.info("In service: /jobs/backup/run and method: runSolrBackupJob");	
		String retMsg = null;
		
		logger.info("Input payload is: " + payLoad);
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);	
		if(elementsMap == null || elementsMap.isEmpty()){
			retMsg = "The input payload is not a expected json string";
			logger.error(retMsg);
			return retMsg;
		}
		
		logger.info("Number of elements in input json : " + elementsMap.size() + " ");		
	
				
		String jobName = elementsMap.get("jobName");
		if(jobName == null || jobName.length() < 1){
			retMsg = "Job Name is null or empty";
			logger.error(retMsg + " Returning without doing anything.");
			return retMsg;			
		}
		
		String jobType = elementsMap.get("jobType");
		if(jobType == null || jobType.length() < 1){
			retMsg = "Job Type is null or empty";
			logger.error(retMsg + " Returning without doing anything.");
			return retMsg;			
		}
		
		String jobData = elementsMap.get("jobData");
		if(jobData == null || jobData.length() < 1){
			retMsg = "Job Data is null or empty";
			logger.error(retMsg + " Returning without doing anything.");
			return retMsg;			
		}

		logger.info("Starting the document index job: " + jobName + " ");
		SolrBackupJob indexJob = new SolrBackupJob();
		indexJob.setJobName(jobName);
		indexJob.setJobType(jobType);
		
		String solrDocID = jobName + "_" + Long.toString(System.currentTimeMillis());
		indexJob.setSolrDocID(solrDocID);
		String logFileName = "logs\\" + solrDocID + ".log";
		
		String programDataDir = System.getenv("GD_LOG_PATH"); 
		logger.info("ProgramData dir received from environment variable ProgramData is: " + programDataDir);
		
		if(programDataDir != null && !programDataDir.isEmpty()){				
				String logDir = programDataDir + "\\logs\\indexers\\custom\\" + jobType + "\\";
				
				logFileName = logDir + solrDocID + ".log";
				File dir = new File(logDir);
				if(dir == null || !dir.isDirectory()){ 
					dir.mkdir();
				}
		}

		String givenLogLevel = elementsMap.get("logLevel");
		String logLevel = GeodatafyJobLog.INFO;
		if(givenLogLevel != null && givenLogLevel.length() > 0){
			logLevel = givenLogLevel;	
		}
		
		GeodatafyJobLog jobLogger = new GeodatafyJobLog(logFileName, logLevel);
		indexJob.setLogFileName(logFileName);
		
		jobLogger.debug("Input Payload", payLoad);
		jobLogger.debug("Job Data from Input", jobData);
		
		BackupJobData indexJobData = constructJobData(jobData);
		indexJob.setJobDataString(jobData);
		indexJob.setJobData(indexJobData);
		indexJob.setJobStatus(DocumentIndexJob.JOB_RUNNING);
		indexJob.setStartTime(GeodatafyJobLog.getCurrentDateTime());		
		indexJob.setEndTime("");		
		indexJob.setBkupRunsFolder("");	

		String protocol = request.getScheme();
		//String protocol = null;
		if(protocol == null || protocol.isEmpty()){
			protocol = "http";
		}		
		try {	
			BackupUtil backupObj = new  BackupUtil();
			backupObj.runSolrBackupJobService(indexJob, protocol, jobLogger);
		} catch(Exception e) {
			logger.error("Exception in solr backup ", e);
			logger.info("Exception in solr backup   " + e.getMessage() );
			e.printStackTrace();
			return "Backup failed for the given collection";
				
		}
		//Thread.sleep(180000);
		return "Done";
		
	}
	
	public static void main(String args[]) throws Exception {
		System.out.println("******************************************");
		JSONObject json = new JSONObject();
		json.put("jobName","Lakshmi_Backup");
		json.put("jobType","Backup");
		json.put("jobData","{\"BackupFolder\":\"D:\\\\BACKUP_SOLR\\\\\",\"NoOfBackup\":1,\"SolrCollectionName\":[\"data\",\"gis\",\"metadata\"],\"solrHost\":\"192.168.2.231\",\"solrPort\":\"8983\"}");
		BackupService serv = new BackupService();
	//	serv.runSolrBackupJobService(json.toString());
	
		
	}
	
	
	private BackupJobData constructJobData(String jobData) throws Exception
	{
		Map<String, JsonElement> jdm = JsonUtil.getJsonElementMap(jobData);
		
		JsonElement backupFolderElement = jdm.get("BackupFolder");
		if(backupFolderElement == null || backupFolderElement.getAsString().length() < 0){
			String msg = "The roort folder value is not available.";
			throw new Exception(msg);
		}				
		String backupFolder = backupFolderElement.getAsString();
		logger.info("The Backup folder is : " + backupFolder);
		
		
		JsonElement jsonCollection = jdm.get("SolrCollectionName");
		
		if(jsonCollection == null ){
			
			String msg = "CollectionName os not available";	
			throw new Exception(msg);
		}
		JsonArray jsonCollArray = JsonUtil.convertToJsonArray(jsonCollection);
		System.out.println(jsonCollArray);
		String colllections = "";
		for(JsonElement JsonElemcollection : jsonCollArray) {
			colllections = colllections + JsonElemcollection.getAsString() + ",";
			
		}
		colllections = colllections.substring(0, colllections.length()-1);
		System.out.println(colllections);
		String solrCollectionName = colllections;
		logger.info("Solr Collection Name is set to: " + solrCollectionName);
		
		String solrHost = "localhost";
		if(jdm.get("solrHost") != null){
			solrHost = jdm.get("solrHost").getAsString();
		}else{
			logger.info("solr Host is not set. Assuming localhost");		
		}
		logger.info("solr host is set to: " + solrHost);

		String solrPort = "8983";
		if(jdm.get("solrPort") != null){
			solrPort = jdm.get("solrPort").getAsString();
		}else{
			logger.info("solr Port is not set. Assuming 80");		
		}
		logger.info("solr Port is set to: " + solrPort);
		
		int noOfBackupRetained = 2;
		if(jdm.get("NoOfBackup") != null){
			noOfBackupRetained = jdm.get("NoOfBackup").getAsInt();
		}else{
			logger.info("solr noOfBackupRetained is not set. Assuming 2");		
		}
		logger.info("solr noOfBackupRetained is set to: " + noOfBackupRetained);


			return new BackupJobData(backupFolder,  solrHost, solrPort, solrCollectionName, noOfBackupRetained);
	}


}
