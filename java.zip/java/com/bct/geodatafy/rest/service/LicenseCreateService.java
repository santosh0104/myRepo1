package com.bct.geodatafy.rest.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import org.apache.log4j.Logger;
import com.bct.geodatafy.license.License;
import com.bct.geodatafy.license.LicenseFeature;
import com.bct.geodatafy.license.LicenseUtil;
import com.bct.geodatafy.util.JsonUtil;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths; 

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;

@Path("/licensekey")
public class LicenseCreateService {
	static Logger logger = Logger.getLogger(LicenseCreateService.class);	
	public static String DEFAULT_LICENSE_FILE= "LicenseKey_";

	@POST
	@Path("/create")
	@Consumes(MediaType.APPLICATION_JSON)
	public void createLicense(String payLoad, @Context HttpServletRequest request) throws Exception{
		logger.info("In /license/create service and createLicense method.");
		logger.info("Input payload is: " + payLoad);
		
		Map<String, JsonElement> elementsMap = JsonUtil.getJsonElementMap(payLoad);
		JsonElement orgName = elementsMap.get("CompanyName");
		if(orgName == null || orgName.getAsString().isEmpty()){
			String msg = "CompanyName name is null or empty.";
			throw new Exception(msg);
		}
		JsonElement licenseID = elementsMap.get("id");
		if(licenseID == null || licenseID.getAsString().isEmpty()){
			String msg = "licenseID is null or empty.";
			throw new Exception(msg);
		}

		JsonElement macAddress = elementsMap.get("MACAddress");
		if(macAddress == null || macAddress.getAsString().isEmpty()){
			String msg = "MAC address is null or empty.";
			throw new Exception(msg);
		}

		JsonElement featuresElement = elementsMap.get("Features");
		if(featuresElement == null){
			String msg = "Features is null.";
			throw new Exception(msg);
		}

		JsonArray featuresArray = JsonUtil.convertToJsonArray(featuresElement); 
		if(featuresArray == null){
			String msg = "Features is null.";
			throw new Exception(msg);
		}
		
		List<LicenseFeature> features = new ArrayList<LicenseFeature>();
		
		for (JsonElement featureElement : featuresArray) {
			String name = featureElement.getAsJsonObject().get("Name").getAsString();
			String licenseExpDate = featureElement.getAsJsonObject().get("LicenseExpDate").getAsString();
			String mainExpDate = featureElement.getAsJsonObject().get("MaintExpDate").getAsString();
			String numUsers = featureElement.getAsJsonObject().get("NumberOfUsers").getAsString();
			LicenseFeature feature = new LicenseFeature();
			feature.setLicenseExpiryDate(LicenseUtil.FORMATTER.parse(licenseExpDate));
			feature.setMaintenanceExpiryDate(LicenseUtil.FORMATTER.parse(mainExpDate));
			feature.setName(name);
			feature.setNumberOfUsers(Integer.parseInt(numUsers));
			features.add(feature);
		}
		
		License license = new License();
		license.setLicenseId(licenseID.getAsString());
		license.setOrgName(orgName.getAsString());
		license.setMachineAddress(macAddress.getAsString());
		license.setFeatures(features);
		LicenseUtil.createLicenseFile(license);
	}
	
	@POST  
	@Path("/getFile")

    public Response downloadLicenseFile(String licenseId)
    {
		logger.info(licenseId);
        StreamingOutput fileStream =  new StreamingOutput()
        {
            @Override
            public void write(java.io.OutputStream output) throws IOException, WebApplicationException
            {
                try
                {
                	String fileName = DEFAULT_LICENSE_FILE + licenseId;
                	String programDataDir = System.getenv("ProgramData"); 
            		if(programDataDir != null && !programDataDir.isEmpty()){				
            			String logDir = programDataDir + "\\GeodatafyLicense\\License\\";
            			fileName = logDir.concat(fileName);
            			logger.info(fileName);
            		}
                    java.nio.file.Path path = Paths.get(fileName);
                    byte[] data = Files.readAllBytes(path);
                    logger.info(fileName);
                    output.write(data);
                    output.flush();
                }
                catch (Exception e)
                {
                	 logger.info(e.getMessage());
                	 logger.info("File Not Found !!" , e);
                    throw new WebApplicationException("File Not Found !!");
                }
            }
        };
        return Response
                .ok(fileStream, MediaType.APPLICATION_OCTET_STREAM)
                .header("content-disposition","attachment; filename = " +  DEFAULT_LICENSE_FILE + licenseId)
                .build();
    }
	
	
}