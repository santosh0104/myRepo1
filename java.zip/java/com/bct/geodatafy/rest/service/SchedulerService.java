package com.bct.geodatafy.rest.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.bct.geodatafy.scheduler.quartz.QuartzScheduler;
import com.bct.geodatafy.util.JsonUtil;
import com.bct.geodatafy.util.RestUtil;
import com.bct.geodatafy.util.SchedulerUtil;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

@Path("/jobs")
public class SchedulerService {
	static Logger logger = Logger.getLogger(SchedulerService.class);
	
	@POST
	@Path("/schedule")
	@Consumes(MediaType.APPLICATION_JSON)
	public String scheduleJob(String payLoad) throws Exception{ 
		//Input payload contains all the job and job data details
		logger.info("In service /jobs/schedule and in method scheduleJob.");
		logger.info("Input payload is: " + payLoad);
		//JsonObject jobObject = getJsonObject(payLoad);
		
		JsonElement element = JsonUtil.getJsonElement(payLoad);
		JsonObject jobObject = element.getAsJsonObject();		
		QuartzScheduler scheduler = new QuartzScheduler();
		return scheduler.addJob(jobObject);			
	}
	
	@PUT
	@Path("/schedule")
	@Consumes(MediaType.APPLICATION_JSON)
	public String updateScheduledJob(String payLoad) throws Exception {
		//Input payload contains job name only
		logger.info("In PUT service /jobs/schedule and in method updateScheduledJob.");
		logger.info("The input payload is: " + payLoad);
		//JsonObject jobObject = getJsonObject(payLoad);
		
		JsonElement element = JsonUtil.getJsonElement(payLoad);
		JsonObject jobObject = element.getAsJsonObject();		
		QuartzScheduler scheduler = new QuartzScheduler();
		return scheduler.updateJob(jobObject);
	}
	
	@DELETE
	@Path("/schedule/{jobName}")
	public String deleteScheduledJob(@PathParam("jobName") String jobName) throws Exception {
		logger.info("In DELETE service /jobs/schedule/{jobName} and in method deleteScheduledJob.");
		logger.info("The input job name is: " + jobName);
		//JsonObject jobObject = getJsonObject(payLoad);
		
		QuartzScheduler scheduler = new QuartzScheduler();
		return scheduler.deleteJob(jobName);
	}



/*	private JsonObject getJsonObject(String payLoad) {
		Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);
		logger.info("Number of elements in input json : " + elementsMap.size() + " ");
		
		String solrURL = elementsMap.get("solrUrl");	
		String core = elementsMap.get("core");
		String datatype = elementsMap.get("datatype");
		String jobName = elementsMap.get("jobName");
		logger.info("Given Parameters: solrUrl: " + solrURL + " datatype: " + datatype + " core: " + core + " jobName: " + jobName);
		
		String url = solrURL + "/" + core + "/select?fq=datatype:" + datatype + "&fq=jobName:" + jobName	+ "&indent=on&q=*:*&wt=json";
		String result = RestUtil.getURLResponse(url);
		
		logger.info("Called the URL for scheduler " + url);
		logger.info("The result from solr query for scheduler : " + result);		
		
		JsonArray elements = JsonUtil.getDocElementsArray(result);
		JsonObject docObj = null;
		
		if(elements != null){			
			for (JsonElement jsonElement : elements) {
				logger.info("The job definiton JSON element is " + jsonElement.getAsJsonObject());				
				docObj = jsonElement.getAsJsonObject();
				docObj.addProperty("solrUrl", solrURL);
								
				//Just for info
				for (Map.Entry<String, JsonElement> entry: docObj.entrySet()){
					String key = entry.getKey();
					String value =  entry.getValue().getAsString();				
					logger.info("Key: " + key + " Value: " + value);
				}
			}
		}
		return docObj;
	}*/
	
/*	@POST
	@Path("/run")
	@Consumes(MediaType.APPLICATION_JSON)
	public String runJob(String payLoad) throws Exception{ 
		
		Map<String, String> elementsMap = JsonUtil.getJsonElementsMap(payLoad);
		logger.info("Number of elements in input json : " + elementsMap.size() + " ");
		
		//Just for debug		
		for (Map.Entry<String, String> entry: elementsMap.entrySet()){
			String key = entry.getKey();
			String value =  entry.getValue();				
			logger.debug("Key: " + key + " Value: " + value);
		}		
		return "Successfully run the job";
	}*/


}
