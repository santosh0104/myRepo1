package com.bct.geodatafy.rest.service;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;


import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;


@Path("/Config")
public class GetConfigService {
	static Logger logger = Logger.getLogger(GetConfigService.class);
	//private static GetConfigService instance = null;
	private HashMap<String, String> configMap = null;
	
	/* public static GetConfigService getInstance() {
	        if (GetConfigService.instance == null) {
	        	GetConfigService.instance = new GetConfigService();
	        }

	        return GetConfigService.instance;
	    }*/
	 
	/* private GetConfigService() {		 
		 this.loadConfig();
	 }*/
	 
	 private boolean loadConfig( )   { 
			
			try {
				WindowsService wService = new WindowsService();
				String installPath = wService.getGDInstallationPath();	
				String configPath = installPath + "\\assets\\config.json";
				System.out.println(" File Name : " + configPath);
				BufferedReader bufferedReader = new BufferedReader(new FileReader(configPath));
				Gson gson = new Gson();
				HashMap<String, String> json = gson.fromJson(bufferedReader, HashMap.class);
				this.configMap = json;
				System.out.println("Config " + json);		
				return true;

			} catch (Exception e) {
				String errMsg = "Exception during execution of getting Geodatafy Intsallation Path";
				logger.error(errMsg);
				logger.error("The Error is " + e.getMessage());
				e.printStackTrace();
				return false;
			}
	 
	 }

	
	@GET
	@Path("/")
	@Consumes(MediaType.APPLICATION_JSON)
	public String getConfig() throws Exception{ 
		
		logger.info("In service /getConfig/ and in method GetConfigService.");
		String jsonStr = null;
		try {
				Gson gson = new Gson();	
				this.loadConfig();
			    jsonStr = gson.toJson(this.configMap);
			    System.out.println("Config Map to String " + jsonStr );			
			    return jsonStr;

		} catch (Exception e) {
			String errMsg = "Exception during execution of getConfig JSON";
			logger.error(errMsg);
			logger.error("The Error is " + e.getMessage());
			e.printStackTrace();
			return errMsg;
		}

		
		
	}
	
	 @GET
	 @Path("/{key}")
	 public String getConfigKeyValue(@PathParam("key") String key) { 	
		
		logger.info("In service /config/ and in method GetConfigService.");		
		
		try {			
				this.loadConfig();
				if( this.configMap.containsKey(key)) {
					return this.configMap.get(key);					
				} else {
					return "";
				}
		} catch (Exception e) {
			String errMsg = "Exception during execution of getConfig JSON/key";
			logger.error(errMsg);
			logger.error("The Error is " + e.getMessage());
			e.printStackTrace();
			return errMsg;
		}	
		
	}
	
	public static void main(String args[]) throws Exception {
		GetConfigService g = new GetConfigService();
		g.getConfig();
		
	}
	
}

