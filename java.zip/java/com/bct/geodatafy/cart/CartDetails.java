package com.bct.geodatafy.cart;

import java.util.ArrayList;


public class CartDetails {
	
	String cartId;
	public String getCartId() {
		return cartId;
	}
	public void setCartId(String cartId) {
		this.cartId = cartId;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDatatype() {
		return datatype;
	}
	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getCartDatatype() {
		return cartDatatype;
	}
	public void setCartDatatype(String cartDatatype) {
		this.cartDatatype = cartDatatype;
	}
	public String getCartSelection() {
		return cartSelection;
	}
	public void setCartSelection(String cartSelection) {
		this.cartSelection = cartSelection;
	}
	public ArrayList<String> getSelectedValues() {
		return selectedValues;
	}
	public void setSelectedValues(ArrayList<String> selectedValues) {
		this.selectedValues = selectedValues;
	}
	String  id;
    String  datatype;
    public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	String  columnName;
    String  cartDatatype;
    String cartSelection;
    String  displayName;
    boolean fromQc;
    public boolean getFromQc() {
		return fromQc;
	}
	public void setFromQc(boolean fromQc) {
		this.fromQc = fromQc;
	}
	ArrayList<String> SelectedCriteria;
    String mainCriteriaQry;
    public String getMainCriteriaQry() {
		return mainCriteriaQry;
	}
	public void setMainCriteriaQry(String mainCriteriaQry) {
		this.mainCriteriaQry = mainCriteriaQry;
	}
	public ArrayList<String> getSelectedCriteria() {
		return SelectedCriteria;
	}
	public void setSelectedCriteria(ArrayList<String> cartSelectedCriteria) {
		this.SelectedCriteria = cartSelectedCriteria;
	}
	String cartCollectionUrl;
    public String getCartCollectionUrl() {
		return cartCollectionUrl;
	}
	public void setCartCollectionUrl(String cartCollection) {
		this.cartCollectionUrl = cartCollection;
	}
	ArrayList<String> selectedValues;
	
	
	

}
