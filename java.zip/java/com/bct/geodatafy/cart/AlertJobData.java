package com.bct.geodatafy.cart;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AlertJobData {
	
	private String cartId;
	private String emailRecipient;
	private String updatedDate;
	private boolean sendMail;
	
	private String solrHost;
	private String solrPort;
	private String solrCollectionName;	
	
	private String lalstModifiedDate;
	
	private Alert alert;
	

	private ArrayList<CartDetails> cartDetailsList;
	
	public boolean isSendMail() {
		return sendMail;
	}


	public void setSendMail(boolean sendMail) {
		this.sendMail = sendMail;
	}


	public String getUpdatedDate() {
		return updatedDate;
	}


	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}


	public String getCartId() {
		return cartId;
	}


	public void setCartId(String cartId) {
		this.cartId = cartId;
	}


	public String getEmailRecipient() {
		return emailRecipient;
	}


	public void setEmailRecipient(String emailRecipient) {
		this.emailRecipient = emailRecipient;
	}


	public String getLalstModifiedDate() {
		return lalstModifiedDate;
	}


	public void setLalstModifiedDate(String lalstModifiedDate) {
		this.lalstModifiedDate = lalstModifiedDate;
	}


	

	
		public ArrayList<CartDetails> getCartDetailsList() {
		return cartDetailsList;
	}


	public void setCartDetailsList(ArrayList<CartDetails> cartDetailsList) {
		this.cartDetailsList = cartDetailsList;
	}


		public Alert getAlert() {
		return alert;
	}


	public void setAlert(Alert alertObj) {
		this.alert = alertObj;
	}


		public AlertJobData(String cartId, String emailRecipient, String solrHost, String solrPort, String solrCollectionName){
		this.cartId = cartId;	
		this.emailRecipient = emailRecipient;
		this.solrHost = solrHost;
		this.solrPort = solrPort;
		this.solrCollectionName = solrCollectionName;
		//this.lalstModifiedDate = lastModifiedDate;
		
		
	}


		

		public String getSolrHost() {
			return solrHost;
		}


		public void setSolrHost(String solrHost) {
			this.solrHost = solrHost;
		}


		public String getSolrPort() {
			return solrPort;
		}


		public void setSolrPort(String solrPort) {
			this.solrPort = solrPort;
		}


		public String getSolrCollectionName() {
			return solrCollectionName;
		}


		public void setSolrCollectionName(String solrCollectionName) {
			this.solrCollectionName = solrCollectionName;
		}
}
