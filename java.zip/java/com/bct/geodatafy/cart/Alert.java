package com.bct.geodatafy.cart;

import java.util.Date;

public class Alert {
	public String getAlertId() {
		return alertId;
	}
	public void setAlertId(String alertId) {
		this.alertId = alertId;
	}
	public String getDataCartId() {
		return dataCartId;
	}
	public void setDataCartId(String dataCartId) {
		this.dataCartId = dataCartId;
	}
	public String getAlertOwner() {
		return alertOwner;
	}
	public void setAlertOwner(String alertOwner) {
		this.alertOwner = alertOwner;
	}
	public boolean getActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public String getEmailRecipient() {
		return emailRecipient;
	}
	public void setEmailRecipient(String emailRecipient) {
		this.emailRecipient = emailRecipient;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getLastExecutionDate() {
		return LastExecutionDate;
	}
	public void setLastExecutionDate(Date lastExecutionDate) {
		LastExecutionDate = lastExecutionDate;
	}
	String alertId;
	String  dataCartId;
	String  alertOwner;
	boolean  active;
	String  emailRecipient;
	Date  createdDate;
	Date  LastExecutionDate;

}
