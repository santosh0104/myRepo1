package com.bct.geodatafy.cart;

import java.util.Date;

public class CartAlertJob {
	
	
	private String id;
	private String datatype;
	private String  jobName;
	private String  jobType;
	private String  logLevel;
	private String  jobData;
	private String  scheduled;
	private String  startDateTime;
	private String  interval;
	private String  duration;
	private String  active;
	private String  endPointURL;
	private String  createdDate;
	private String  createdBy;
	private String  lasModifiedDate;
	private String  editedBy;
	//private String  LastExecutionTime;
	
	private String solrDocID;
	private String jobStatus;
	private String startTime;	
	private String endTime;
	private String logFileName;
	private String jobDataString;
	public String getSolrDocID() {
		return solrDocID;
	}
	public void setSolrDocID(String solrDocID) {
		this.solrDocID = solrDocID;
	}
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getJobStatus() {
		return jobStatus;
	}
	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getLogFileName() {
		return logFileName;
	}
	public void setLogFileName(String logFileName) {
		this.logFileName = logFileName;
	}
	public String getJobDataString() {
		return jobDataString;
	}
	public void setJobDataString(String jobDataString) {
		this.jobDataString = jobDataString;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDatatype() {
		return datatype;
	}
	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}
	public String getLogLevel() {
		return logLevel;
	}
	public void setLogLevel(String logLevel) {
		this.logLevel = logLevel;
	}
	public String getJobData() {
		return jobData;
	}
	public void setJobData(String jobData) {
		this.jobData = jobData;
	}
	public String getScheduled() {
		return scheduled;
	}
	public void setScheduled(String scheduled) {
		this.scheduled = scheduled;
	}
	public String getStartDateTime() {
		return startDateTime;
	}
	public void setStartDateTime(String startDateTime) {
		this.startDateTime = startDateTime;
	}
	public String getInterval() {
		return interval;
	}
	public void setInterval(String interval) {
		this.interval = interval;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	public String getEndPointURL() {
		return endPointURL;
	}
	public void setEndPointURL(String endPointURL) {
		this.endPointURL = endPointURL;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getLasModifiedDate() {
		return lasModifiedDate;
	}
	public void setLasModifiedDate(String lasModifiedDate) {
		this.lasModifiedDate = lasModifiedDate;
	}
	public String getEditedBy() {
		return editedBy;
	}
	public void setEditedBy(String editedBy) {
		this.editedBy = editedBy;
	}
	/*public String getLastExecutionTime() {
		return LastExecutionTime;
	}
	public void setLastExecutionTime(String lastExecutionTime) {
		LastExecutionTime = lastExecutionTime;
	}*/
	
	
	
	

}
