package com.bct.geodatafy.cart;

import java.util.ArrayList;

public class AlertExecution {
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCartId() {
		return cartId;
	}
	public void setCartId(String cartId) {
		this.cartId = cartId;
	}
	public String getAlertId() {
		return alertId;
	}
	public void setAlertId(String alertId) {
		this.alertId = alertId;
	}
	public String getDatatype() {
		return datatype;
	}
	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getCartDatatype() {
		return cartDatatype;
	}
	public void setCartDatatype(String cartDatatype) {
		this.cartDatatype = cartDatatype;
	}
	
	public String getCartCollection() {
		return cartCollection;
	}
	public void setCartCollection(String cartCollection) {
		this.cartCollection = cartCollection;
	}
	String  id;
	String cartId;
	String  alertId;
    String  datatype;
    String  columnName;
    String  cartDatatype;
    String displayName;
    public boolean isFromQc() {
		return fromQc;
	}
	public void setFromQc(boolean fromQc) {
		this.fromQc = fromQc;
	}
	boolean fromQc;
    public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	ArrayList<String> selectedValues;
    public ArrayList<String> getSelectedValues() {
		return selectedValues;
	}
	public void setSelectedValues(ArrayList<String> selectedValues) {
		this.selectedValues = selectedValues;
	}
	public String getCartCollectionUrl() {
		return cartCollectionUrl;
	}
	public void setCartCollectionUrl(String cartCollectionUrl) {
		this.cartCollectionUrl = cartCollectionUrl;
	}

	String cartCollection;
    String cartCollectionUrl;
    String cartSelection;
	public String getCartSelection() {
		return cartSelection;
	}
	public void setCartSelection(String cartSelection) {
		this.cartSelection = cartSelection;
	}
    
    
    
    

}
