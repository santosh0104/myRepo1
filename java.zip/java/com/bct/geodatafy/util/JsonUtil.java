package com.bct.geodatafy.util;

import java.io.File;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.log4j.Logger;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;


public class JsonUtil {

	static Logger logger = Logger.getLogger(JsonUtil.class);

	public static final String SOLR_THEME_QUERY = "http://localhost:8983/solr/metadata/select?facet.field=datatype&facet=on&fq=datatype:colorTheme&fq=name:Default&indent=on&q=*:*&wt=json";
	public static final String TEST_JSON_THEME= "{\"solrUrl\": \"http://localhost:8983/solr/metadata/select?facet.field=datatype&facet=on&fq=datatype:colorTheme&fq=name:Default&indent=on&q=*:*&wt=json\", \"cssFileName\": \"dafault\"}";
	public static final String TEST_JSON_SCHEDULER= "{\"solrUrl\": \"http://localhost:8983/solr\", \"core\": \"metadata\", \"datatype\": \"jobDefinition\", \"jobName\": \"DocumentIndex_Job\"}";

	public static JsonElement getJsonElement(String json){
		JsonElement response = null;
		
		if(json != null && !json.isEmpty()){
			JsonParser jp = new JsonParser();
			response = jp.parse(json);
		}
		return response;
	}
	
	//Returns the key value pair of the elements in the given json which has 
	//only one set of elements without any sub elements. This cannot be used if json 
	//consists of other than simple key value pair of strings. It will fail even for
	//JSOn array element
	public static Map<String, String> getJsonStringMap(String jsonString){
		Map<String, String> elementsMap = null;
		JsonElement element = getJsonElement(jsonString);
		if(element != null){
			elementsMap = new HashMap<String, String>();
			
			JsonObject docObj = element.getAsJsonObject();
			
			for (Map.Entry<String, JsonElement> entry: docObj.entrySet()){
				String key = entry.getKey();
				String value =  entry.getValue().getAsString();				
				elementsMap.put(key, value);
			}
		}
		return elementsMap;
	}
	
	public static Map<String, JsonElement> getJsonElementMap(String jsonString){
		Map<String, JsonElement> elementsMap = null;
		JsonElement element = getJsonElement(jsonString);
		if(element != null){
			elementsMap = new HashMap<String, JsonElement>();
			
			JsonObject docObj = element.getAsJsonObject();
			
			for (Map.Entry<String, JsonElement> entry: docObj.entrySet()){
				String key = entry.getKey();
				JsonElement value =  entry.getValue();				
				elementsMap.put(key, value);
			}
		}
		return elementsMap;
	}

	public static JsonArray getDocElementsArray(String json){
		JsonArray elements = null;
		if (json != null && json.length() > 0) {
			JsonParser jp = new JsonParser();	
			JsonElement response = getSubElement(jp.parse(json), "response");
			if(response != null){
				JsonElement docs = getSubElement(response, "docs");
				System.out.println(docs);

				if(docs != null){
					elements = convertToJsonArray(docs);
				}
			}
		}
		return elements;
	}
	
	public static JsonElement getSubElement(JsonElement jason, String key) {
		JsonElement subElement = null;
		if (jason != null && jason.isJsonObject() && !jason.isJsonNull()) {
			subElement = jason.getAsJsonObject().get(key);
		}
		return subElement;
	}
	
	public static JsonArray convertToJsonArray(JsonElement je) {
		JsonArray ja = null;
		if (je.isJsonArray() && !je.isJsonNull()) {
			ja = je.getAsJsonArray();
		}
		return ja;
	}
	
	public static JsonArray convertToJsonArray(String json) {
		JsonArray ja = null;

		JsonParser jp = new JsonParser();
		JsonElement response = jp.parse(json);		
		ja = JsonUtil.convertToJsonArray(response);		
		return ja;
	}
		
	private static void testFileString(){
		String fileName = System.getenv("user.dir") + File.separator + "vale";
		String val = "C:\\ProgramData\\geodatafy\\logs\\indexers\\document\\DocumentIndex_Job1_1512554159010.log";
		System.out.println(fileName);
		System.out.println(val);
		fileName = fileName.replace("\\", "\\\\");
		val = val.replace("\\", "\\\\");
		System.out.println(fileName);
		System.out.println(val);
	}
		

	   public static void main(String args[])  throws Exception{ 
		   String[] testStrings = {"All\\ fall\\ gala\\ hall", "A&R", 
           "this\\is/a%test\t_~!@#$%^&*()dude"};
		   for (String s : testStrings)
		   {
			   String encodedString = URLEncoder.encode(s, "UTF-8");
			   System.out.format("'%s'\n", encodedString);
		   }  
		   String testStr = "< > \" &";
		   String value = new String(testStr.getBytes("UTF-8"));
		   System.out.println("Original : " + testStr);		
		   System.out.println("Original : " + value);		
			System.out.println("Escaped : " + StringEscapeUtils.escapeHtml(testStr));
			//String encodedString = UrlEscapers.urlFragmentEscaper().escape(testStr);
			
	   }   
}

