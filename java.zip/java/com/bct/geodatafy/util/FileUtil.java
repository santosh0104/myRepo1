package com.bct.geodatafy.util;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.FilenameUtils;

import org.apache.log4j.Logger;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;



public class FileUtil {
	static Logger logger = Logger.getLogger(FileUtil.class);
	
	
	
	
	
	public static void writeToCSSFile(String cssStr, String filePath, String fileName) throws IOException {
		logger.info("The file name to write is: " + filePath + File.separator + fileName + ".css");
		System.out.println("The file name to write is: " + filePath + File.separator + fileName + ".css");
		File file = new File(filePath + File.separator + fileName + ".css");
		if (file.exists()) {
			file.delete();
		}		
		file.createNewFile();
		writeFile(file, cssStr,false);
	}
	
	public static void writeFile(File file, String input, boolean flag) throws IOException {
		FileOutputStream is = new FileOutputStream(file, flag);
		OutputStreamWriter osw = new OutputStreamWriter(is);
		BufferedWriter w = new BufferedWriter(osw);
		w.write(input);
		w.close();
	}
	
	public static void updateHtmlFile(String htmlFile, String themeName) throws IOException{
		
		String cssRefrence = "<link rel='stylesheet' href='assets/ThemeCss/" + themeName + ".css'>\n\r\r\n";
		
		StringBuilder contentBuilder = new StringBuilder();
		
		String text = new String(Files.readAllBytes(Paths.get(htmlFile)), StandardCharsets.UTF_8);
		contentBuilder.append(text);
		contentBuilder.append(cssRefrence);
				
		File file = new File(htmlFile);
		if (file.exists()) {
			writeFile(file, contentBuilder.toString(),false);
		}
	}
		
	public static void getFilesRecursively(String dirName, List<String> extensions, List<String> fileNames) throws IOException{

		File dir = new File(dirName);
		if(dir == null || !dir.isDirectory()){
			String msg = "Given dir name " + dir + " is null or not a directory"; 
			logger.warn(msg);
			System.out.println(msg);
			return;
			//throw new IOException(msg);
		}
		logger.info("The diretory name is: " + dir.getCanonicalPath());
		System.out.println("The diretory name is: " + dir.getCanonicalPath());
		
		File[] files = dir.listFiles();		
		if(files == null){
			logger.warn("Given dir " + dir + " Does not have any files or cannot be accessed");
			System.out.println("Given dir " + dir + " Does not have any files or cannot be accessed");
			return;
		}
		logger.info("The files are " + files);
		System.out.println("The files are " + files);
		
		for (File file : files) {
			logger.info("The directory is " + dir + " and the file is " + file);
			System.out.println("The directory is " + dir + " and the file is " + file);
			if (file.isDirectory()) {
				logger.info("The file " + file + " is a directory. Calling the same method again.");
				System.out.println("The file " + file + " is a directory. Calling the same method again.");
				getFilesRecursively(file.getCanonicalPath(), extensions, fileNames);
			} else {
				logger.info("The file is not a directory. Processing the file " + file);
				System.out.println("The file is not a directory. Processing the file " + file);
				String fileExtension = getExtensionOfFile(file);
				for(String extension : extensions){
					if (extension.equalsIgnoreCase(fileExtension)) {
						fileNames.add(file.getCanonicalPath());
						break;
					}
				}
			} 
		}
	}
	
	public static void getFilesRecurWithMatchDir(String dirName, List<String> extensions, String dirextn, List<String> fileNames) throws IOException{

		File dir = new File(dirName);
		if(dir == null || !dir.isDirectory()){
			String msg = "Given dir name " + dir + " is null or not a directory"; 
			logger.warn(msg);
			System.out.println(msg);
			return;
			//throw new IOException(msg);
		}
		logger.info("The diretory name is: " + dir.getCanonicalPath());
		System.out.println("The diretory name is: " + dir.getCanonicalPath());
		
		File[] files = dir.listFiles();		
		if(files == null){
			logger.warn("Given dir " + dir + " Does not have any files or cannot be accessed");
			System.out.println("Given dir " + dir + " Does not have any files or cannot be accessed");
			return;
		}
		logger.info("The files are " + files);
		System.out.println("The files are " + files);
		
		for (File file : files) {
			logger.info("The directory is " + dir + " and the file is " + file);
			System.out.println("The directory is " + dir + " and the file is " + file);
			if (file.isDirectory()) {
				logger.info("The file " + file + " is a directory. Calling the same method again.");
				System.out.println("The file " + file + " is a directory. Calling the same method again.");
				getFilesRecurWithMatchDir(file.getCanonicalPath(), extensions, dirextn, fileNames);
			} else {
				logger.info("The file is not a directory. Processing the file " + file);
				System.out.println("The file is not a directory. Processing the file " + file);
				String fileExtension = getExtensionOfFile(file);
				for(String extension : extensions){										
					if (extension.equalsIgnoreCase(fileExtension)) {
						String path = file.getCanonicalPath();
						System.out.println(" getCanonicalPath " + path);
						String dirPath = path.substring(0, path.lastIndexOf(".")+1)  + dirextn;
						System.out.println(" dirPath " + dirPath);
						File MatchDirForFile = new File(dirPath);
						if(MatchDirForFile.exists() && MatchDirForFile.isDirectory() ) {
							file.setLastModified(MatchDirForFile.lastModified());
							fileNames.add(file.getCanonicalPath());
							break;
						}
					}
				}
			} 
		}
	}
	
	public static void getFiles(String dirName, List<String> extensions, List<String> fileNames) throws IOException{
				
		File dir = new File(dirName);
		if(dir == null || !dir.isDirectory()){
			String msg = "Given dir name " + dir + " is null or not a directory"; 
			logger.error(msg);
			System.out.println(msg);
			return;
			//throw new IOException(msg);
		}
		logger.info("The diretory name is: " + dir.getCanonicalPath());
		System.out.println("The diretory name is: " + dir.getCanonicalPath());
		File[] files = dir.listFiles();
		
		if(files == null){
			logger.error("Given dir " + dir + " Does not have any files or cannot be accessed");
			System.out.println("Given dir " + dir + " Does not have any files or cannot be accessed");
			return;
		}
		for (File file : files) {
			if (!file.isDirectory()) {
				String fileExtension = getExtensionOfFile(file);				
				for(String extension : extensions){
					if (extension.equalsIgnoreCase(fileExtension)) {
						fileNames.add(file.getCanonicalPath());
						break;
					}
				}
			} 
		}
	}

	public static void getFiles(String dirName, String extension, List<String> fileNames) throws IOException{
		
		File dir = new File(dirName);
		if(dir == null || !dir.isDirectory()){
			String msg = "Given dir name " + dir + " is null or not a directory"; 
			logger.info(msg);
			throw new IOException(msg);
		}
		logger.info("The diretory name is: " + dir.getCanonicalPath());
		File[] files = dir.listFiles();
		
		if(files == null){
			logger.info("Given dir " + dir + " Does not have any files");
			return;
		}
		for (File file : files) {
			if (!file.isDirectory()) {
				String fileExtension = getExtensionOfFile(file);				
				if (extension.equalsIgnoreCase(fileExtension)) {
					fileNames.add(file.getCanonicalPath());
				}
			} 
		}
	}
	
	
public static void getFilesWithMatchDir(String dirName, String extension, String dirextn, List<String> fileNames) throws IOException{
		
		File dir = new File(dirName);
		if(dir == null || !dir.isDirectory()){
			String msg = "Given dir name " + dir + " is null or not a directory"; 
			logger.info(msg);
			throw new IOException(msg);
		}
		logger.info("The diretory name is: " + dir.getCanonicalPath());
		File[] files = dir.listFiles();
		
		if(files == null){
			logger.info("Given dir " + dir + " Does not have any files");
			return;
		}
		for (File file : files) {
			if (!file.isDirectory()) {
				String fileExtension = getExtensionOfFile(file);	
				System.out.println("fileExtension"+fileExtension);
				if (extension.equalsIgnoreCase(fileExtension)) {
					String path = file.getCanonicalPath();
					//System.out.println(" getCanonicalPath " + path);
					String dirPath = path.substring(0, path.lastIndexOf(".")+1)  + dirextn;
					//System.out.println(" dirPath " + dirPath);
					File MatchDirForFile = new File(dirPath);
					if(MatchDirForFile.exists() && MatchDirForFile.isDirectory() ) {
						file.setLastModified(MatchDirForFile.lastModified());
						fileNames.add(file.getCanonicalPath());
					}
				}
			} 
		}
	}

	public static String getExtensionOfFile(File file) throws IOException {
		return getExtensionOfFile(file.getCanonicalPath());
	}

	public static String getExtensionOfFile(String fileName) throws IOException {
		String fileExtension = "";
		
		// If fileName do not contain "." or starts with "." then it does nor contain extension
		if (fileName.contains(".") && fileName.lastIndexOf(".") != 0) {
			fileExtension = fileName.substring(fileName.lastIndexOf("."));
			if(fileExtension.equals(".")){
				fileExtension = "";
			}		
		}
		return fileExtension;
	}
	
	public static int getCountByExtension(List<String> fileNames, String extension) throws IOException{
		int count = 0;
		for(String fileName : fileNames){
			if(getExtensionOfFile(fileName).equals(extension)){
				count ++;
			}			
		}
		return count;
	}
	
	public static void zipDirectory(String sourceDirectoryPath, String zipPath) throws IOException {
        Path zipFilePath = Files.createFile(Paths.get(zipPath));

        try (ZipOutputStream zipOutputStream = new ZipOutputStream(Files.newOutputStream(zipFilePath))) {
            Path sourceDirPath = Paths.get(sourceDirectoryPath);

            Files.walk(sourceDirPath).filter(path -> !Files.isDirectory(path) )
                    .forEach(path -> {
                    	
                    	if(!sourceDirPath.relativize(path).toString().endsWith("zip")) {
                    		
                        ZipEntry zipEntry = new ZipEntry(sourceDirPath.relativize(path).toString());
                        try {
                            zipOutputStream.putNextEntry(zipEntry);
                            zipOutputStream.write(Files.readAllBytes(path));
                            zipOutputStream.closeEntry();
                        } catch (Exception e) {
                            System.err.println(e);
                        }
                    	}
                    });
        }
    }

	 public static void unzip(final String zipFilePath, final String unzipLocation) throws IOException {

	        if (!(Files.exists(Paths.get(unzipLocation)))) {
	            Files.createDirectories(Paths.get(unzipLocation));
	        }
	        try (ZipInputStream zipInputStream = new ZipInputStream(new FileInputStream(zipFilePath))) {
	            ZipEntry entry = zipInputStream.getNextEntry();
	            while (entry != null) {
	                Path filePath = Paths.get(unzipLocation, entry.getName());
	                if (!entry.isDirectory()) {
	                    unzipFiles(zipInputStream, filePath);
	                } else {
	                    Files.createDirectories(filePath);
	                }

	                zipInputStream.closeEntry();
	                entry = zipInputStream.getNextEntry();
	            }
	        }
	    }

	    public static void unzipFiles(final ZipInputStream zipInputStream, final Path unzipFilePath) throws IOException {

	        try (BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(unzipFilePath.toAbsolutePath().toString()))) {
	            byte[] bytesIn = new byte[1024];
	            int read = 0;
	            while ((read = zipInputStream.read(bytesIn)) != -1) {
	                bos.write(bytesIn, 0, read);
	            }
	        }

	    }
	
	
}


