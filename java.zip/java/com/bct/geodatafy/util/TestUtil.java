/**
 * 
 */
package com.bct.geodatafy.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.map.MultiValueMap;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.WinHttpClients;
import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.request.AbstractUpdateRequest.ACTION;
import org.apache.solr.client.solrj.request.ContentStreamUpdateRequest;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.util.NamedList;
/*import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.image.TiffParser;
import org.apache.tika.parser.jpeg.JpegParser;
import org.apache.tika.sax.BodyContentHandler;*/
import org.xml.sax.SAXException;

import com.bct.geodatafy.job.GeodatafyJobTypes;
import com.bct.geodatafy.job.openspirit.OpenSpiritIndexJobProcessor;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.tibco.openspirit.jobs.api.Job;

/**
 * @author KS111138
 *
 */
public class TestUtil {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		//testMatchingColumns();
		//System.out.println(testGetAllJobTypeNames("C:\\ProgramData\\geodatafy\\jobtypes"));
		//System.out.println(testJobTypeDetails("C:\\ProgramData\\geodatafy\\jobtypes", "Kesavan"));
		//testVirtualPath();
		//ZonedDateTime now = ZonedDateTime.now(ZoneOffset.UTC);
		//System.out.println(now.toString());
		//testTika();
		//indexingMultiDocsWithTika();
/*		List<Job> jobs = OpenSpiritIndexJobProcessor.getInstance().getJobs();
		System.out.println(jobs);
		if(jobs != null && jobs.size() > 0){
			Set<Job> jobSets = new HashSet<Job>(jobs);
			System.out.println("The jobs are " + jobSets.size());
			Iterator itr = jobSets.iterator(); 
			while(itr.hasNext()){
				Job job = (Job)itr.next();
				System.out.println(OpenSpiritIndexJobProcessor.getInstance().jobExists(job.getName()));
				//System.out.println(new Gson().toJson(job));
			}*/

			
			//for(int i=0; i< jobSets.size(); i++){
			//	System.out.println(jobSets.get(i));
			//}
			//Job job = jobSets.get(0);
			//OpenSpiritIndexJobProcessor.getInstance().deleteJob(job.getName());
			//System.out.println("The job " + job.getName() + " is deleted!");
		//}

		String dirName = "D:\\";
		
		if (!Files.isDirectory(Paths.get(dirName))) {
			String msg = "The root folder specified is null or not a directory.";
			System.out.println(msg);
		}
		else
		{
			System.out.println("Good");
		}
		List<String> fileNames = new ArrayList<String>();
		List<String> extensions = new ArrayList<String>();
		extensions.add(".pdf");
		extensions.add(".html");
		extensions.add(".htm");
		FileUtil.getFiles(dirName, extensions, fileNames);
		
		for(String file: fileNames ){
			System.out.println(file);
		}

		dirName = "C:";
		if (!Files.isDirectory(Paths.get(dirName))) {
			String msg = "The dist folder specified is null or not a directory.";
			System.out.println(msg);
		}
		else
		{
			System.out.println("Good 2");
		}
		
		fileNames = new ArrayList<String>();
		extensions = new ArrayList<String>();
		extensions.add(".pdf");
		extensions.add(".html");
		extensions.add(".htm");
		FileUtil.getFilesRecursively(dirName, extensions, fileNames);
		
		for(String file: fileNames ){
			System.out.println(file);
		}
	}


	private static void indexingMultiDocsWithTika() throws Exception {
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder("http://localhost/solr/document")).withHttpClient(httpClient).build();
		
		SolrQuery query = new SolrQuery();
		query.set("q","*:*");
		query.set("wt","json");
		QueryResponse resp = client.query(query);
		System.out.println(" Response: " + resp.toString());
		
	    ContentStreamUpdateRequest req = new ContentStreamUpdateRequest("/update/extract");
	    req.addFile(new File("D:\\Tibco\\OpenSpirit\\OpenSpirit Admin Training.pptx"), "application/octet-stream");
	    req.addFile(new File("D:\\Tibco\\OpenSpirit\\OpenSpirit Product Overview.pptx"), "application/octet-stream");
	   // req.setParam(ExtractingParams.EXTRACT_ONLY, "true");
	    req.setAction(ACTION.COMMIT, true, true);
	    NamedList<Object> result = client.request(req);
	    System.out.println("Result: " + result);		
	}

	private static void testTika() throws Exception {
/*		 //detecting the file type
	      BodyContentHandler handler = new BodyContentHandler();
	      Metadata metadata = new Metadata();
	      FileInputStream inputstream = new FileInputStream(new File("D:\\Teapot\\Well 48-X-28 Core Data\\48-x-28 Cores.xls"));
	      ParseContext pcontext = new ParseContext();
	      
	      //Jpeg Parse
	      JpegParser  jpegParser = new JpegParser();
	      jpegParser.parse(inputstream, handler, metadata,pcontext);
	      System.out.println("Contents of the document:" + handler.toString());
	      System.out.println("Metadata of the document:");
	      String[] metadataNames = metadata.names();
	      
	      for(String name : metadataNames) { 		        
	         System.out.println(name + ": " + metadata.get(name));
	      }
*/
	}
	private static void testVirtualPath() {
		String virtualPath = "http://" + "192.168.6.168" + ":" + 
				80 + "/" + "Kesavan";
		
		String rootFolder = "D:\\SampleDocs";
		String fileName = "D:\\SampleDocs\\html\\index.html";

		String docId = fileName.replace("\\", "%5C");
		docId = docId.replace(" ", "%20");

		String virtualFileName = virtualPath + fileName.replace(rootFolder, "");
		virtualFileName = virtualFileName.replace("\\", "/");
		virtualFileName = virtualFileName.replace(" ", "%20");
		
		String param = "literal.id=" + docId + "&literal.datatype=document&commit=false&overwrite=true";
		param = param + "&literal.url=" + virtualFileName;
		System.out.println("The virtual file name is: " + virtualFileName);
		System.out.println("The param is: " + param);
	}
	
	private static void testMatchingColumns() {
		String setA = "[{\"Wellbore\":\"Test1\",\"Operator\":\"Op1\",\"TDUnit\":\"m\",\"DataSource\":\"Kingdom\"}," +
					   "{\"Wellbore\":\"Test2\",\"Operator\":\"Op2\",\"TDUnit\":\"m\",\"DataSource\":\"Kingdom\"}," +
					   "{\"Wellbore\":\"Test3\",\"Operator\":\"Op1\",\"TDUnit\":\"m\",\"DataSource\":\"EPOS\"}," +
					   "{\"Wellbore\":\"Test4\",\"Operator\":\"Op1\",\"TDUnit\":\"m\",\"DataSource\":\"OW\"}," +
					   "]";
		String setB = "[{\"Wellbore\":\"Test1\",\"Operator\":\"Op1\",\"TDUnit\":\"m\",\"DataSource\":\"Kingdom\"}," +
				       "{\"Wellbore\":\"Test5\",\"Operator\":\"Op2\",\"TDUnit\":\"m\",\"DataSource\":\"Kingdom\"}," +
				       "{\"Wellbore\":\"Test6\",\"Operator\":\"Op1\",\"TDUnit\":\"m\",\"DataSource\":\"EPOS\"}," +
				       "{\"Wellbore\":\"Test4\",\"Operator\":\"Op1\",\"TDUnit\":\"m\",\"DataSource\":\"OW\"}," +
				       "{\"Wellbore\":\"Test7\",\"Operator\":\"Op2\",\"TDUnit\":\"m\",\"DataSource\":\"Kingdom\"}," +
				       "]";
	
		String match = "[{\"Item1\":\"Wellbore\"},{\"Item2\":\"DataSource\"}]";
		String matches[] = {"Wellbore","DataSource"};
		int size = matches.length;
		
		List<HashMap<String, String>> setAValues = new ArrayList<HashMap<String,String>>(); 
		List<HashMap<String, String>> setBValues = new ArrayList<HashMap<String,String>>();
		setAValues(setA, setAValues);		
		setBValues(setB, setBValues);
		
		int sizeA = setAValues.size();
		int sizeB = setBValues.size();
		
		for(int a=0; a < sizeA; a++){
			for(int b=0; b < sizeB; b++){
				boolean matched = true;
				for(int m=0; m < size; m++){
					if(matched){
						matched = setBValues.get(b).get(matches[m]).equals(setAValues.get(a).get(matches[m]));
					}
					if(!matched){
						break;
					}
				}
				if(matched){
					System.out.println("Matched the columns setA: " + a + " and setB: " + b);
					System.out.println(setAValues.get(a));
					System.out.println(setBValues.get(b));
				} else {
					System.out.println("Not Matched the columns setA: " + a + " and setB: " + b);
					System.out.println(setAValues.get(a));
					System.out.println(setBValues.get(b));
				}
			}
		}
	}

	private static void setAValues(String setA, List<HashMap<String, String>> setAValues) {
		HashMap<String, String> item1 = new HashMap<String, String>();
		item1.put("Wellbore", "Test1");
		item1.put("Operator", "Op1");
		item1.put("TDUnit", "m");
		item1.put("DataSource", "Kingdom");
		setAValues.add(item1);
		HashMap<String, String> item2 = new HashMap<String, String>();
		item2.put("Wellbore", "Test2");
		item2.put("Operator", "Op2");
		item2.put("TDUnit", "m");
		item2.put("DataSource", "Kingdom");
		setAValues.add(item2);
		HashMap<String, String> item3 = new HashMap<String, String>();
		item3.put("Wellbore", "Test3");
		item3.put("Operator", "Op1");
		item3.put("TDUnit", "m");
		item3.put("DataSource", "EPOS");
		setAValues.add(item3);
		HashMap<String, String> item4 = new HashMap<String, String>();
		item4.put("Wellbore", "Test4");
		item4.put("Operator", "Op1");
		item4.put("TDUnit", "m");
		item4.put("DataSource", "OW");
		setAValues.add(item4);
	}
	
	private static void setBValues(String setB, List<HashMap<String, String>> setBValues) {
		HashMap<String, String> item1 = new HashMap<String, String>();
		item1.put("Wellbore", "Test1");
		item1.put("Operator", "Op1");
		item1.put("TDUnit", "m");
		item1.put("DataSource", "Kingdom");
		setBValues.add(item1);
		HashMap<String, String> item2 = new HashMap<String, String>();
		item2.put("Wellbore", "Test5");
		item2.put("Operator", "Op2");
		item2.put("TDUnit", "m");
		item2.put("DataSource", "Kingdom");
		setBValues.add(item2);
		HashMap<String, String> item3 = new HashMap<String, String>();
		item3.put("Wellbore", "Test6");
		item3.put("Operator", "Op1");
		item3.put("TDUnit", "m");
		item3.put("DataSource", "EPOS");
		setBValues.add(item3);
		HashMap<String, String> item4 = new HashMap<String, String>();
		item4.put("Wellbore", "Test4");
		item4.put("Operator", "Op2");
		item4.put("TDUnit", "m");
		item4.put("DataSource", "OW");
		setBValues.add(item4);
		HashMap<String, String> item5 = new HashMap<String, String>();
		item5.put("Wellbore", "Test7");
		item5.put("Operator", "Op1");
		item5.put("TDUnit", "m");
		item5.put("DataSource", "Kingdom");
		setBValues.add(item5);
	}

	private static String testGetAllJobTypeNames(String baseDir) throws IOException {
		String namesJson = "";
		List<String> fileNames = new ArrayList<String>();
		FileUtil.getFiles(baseDir, ".json", fileNames);
		MultiValueMap names = new MultiValueMap();
		
		for(String fileName: fileNames){
			String contents = new String(Files.readAllBytes(Paths.get(fileName)), StandardCharsets.UTF_8);
			Map<String, JsonElement> elementsMap = JsonUtil.getJsonElementMap(contents);
			printJsonElementMap(elementsMap);
			JsonObject jobType = (JsonObject)elementsMap.get("jobType");
			if(jobType != null){
				JsonElement nameElement = jobType.get("name");
				if(nameElement != null){
					String name = nameElement.getAsString();
					System.out.println("Name: " + name);
					names.put("names", name);								
				}else {
					System.out.println("Job name json element is not defined");
				}
			}else {
				System.out.println("Job Type json element is not defined");
			}
		}
		Gson gson = new Gson();
		namesJson = gson.toJson(names);		
		return namesJson;
	}
	
	private static String testJobTypeDetails(String baseDir, String jobName) throws IOException{
		String details = "{}";
		List<String> fileNames = new ArrayList<String>();
		FileUtil.getFiles(baseDir, ".json", fileNames);
		MultiValueMap names = new MultiValueMap();
		JsonObject jobType = null;
		
		for(String fileName: fileNames){
			String contents = new String(Files.readAllBytes(Paths.get(fileName)), StandardCharsets.UTF_8);
			Map<String, JsonElement> elementsMap = JsonUtil.getJsonElementMap(contents);
			printJsonElementMap(elementsMap);
			jobType = (JsonObject)elementsMap.get("jobType");
			if(jobType != null){
				JsonElement nameElement = jobType.get("name");
				if(nameElement != null){
					String name = nameElement.getAsString();						
					System.out.println("Name: " + name);
					if(name.equals(jobName)){
						break;
					}					
				}else {
					System.out.println("Job name json element is not defined");
				}
			}else {
				System.out.println("Job Type json element is not defined");
			}
		}
		if(jobType != null){
			details = jobType.toString();
			System.out.println("The details for the job: " + jobName + " is " + details);		
		}else {
			System.out.println("There is no Job Type defined for: " + jobName);
		}
		return details;
	}		

/*			
			
			//System.out.println(gson.fromJson(contents, JobType.class));
			JobTypes types = new JobTypes();
			Map<String, String> elements = new Hashtable<String, String>();
			elements.put("name", "Type1");
			elements.put("name1", "Type2");
			elements.put("name2", "Type4");
			types.setParameters(elements);
			
			
			mapping.put("name","val1");
			mapping.put("name","val2");
			mapping.put("name","val3");
			
			
*//*			 
			
			for (Map.Entry<String, JsonElement> entry: elementsMap.entrySet()){
//				JsonElement endPointURL = jobType.get("endPointURL");
//				if(endPointURL == null){
//					return;
//				}
//				String endPoint = jobType.get("endPointURL").getAsString();
				
				//System.out.println(endPoint);
				JsonArray arr  = convertToJsonArray(jobType.get("parameters"));
				System.out.println(arr);
				List<JobParameter> parameters = new ArrayList<JobParameter>(); 
				for(int i = 0; i < arr.size(); i++){
					JsonObject parameter = (JsonObject) arr.get(i);
					JsonElement paramName = parameter.get("name");
					JsonElement paramType = parameter.get("type");
					JobParameter param = new JobParameter();
					param.setName(paramName.getAsString());
					param.setType(paramType.getAsString());
					Map<String, String> additional = new HashMap<String, String>();
					additional.put("values", "value1,value2,value3");
					additional.put("keys", "key1,key2,key3");
					param.setOptionalValues(additional);
					parameters.add(param);
					System.out.println(parameter);
					System.out.println(paramName);	
					System.out.println(paramType);
				}
				JobType typeJob = new JobType();
				typeJob.setName("Kesavan");
				typeJob.setParameters(parameters);
				
				Gson gson = new Gson();
				String json = gson.toJson(typeJob);
				System.out.println(json);
			}
	}
	}
*/	
	
	private static void printJsonElementMap(Map<String, JsonElement> elementsMap) {
		//Just for debug		
		for (Map.Entry<String, JsonElement> entry: elementsMap.entrySet()){
			String key = entry.getKey();
			JsonElement value =  entry.getValue();				
			System.out.println(("Key: " + key + " Value: " + value));
		}
	}
	private static void printJsonStringMap(Map<String, String> elementsMap) {
		//Just for debug		
		for (Map.Entry<String, String> entry: elementsMap.entrySet()){
			String key = entry.getKey();
			String value =  entry.getValue();				
			System.out.println("Key: " + key + " Value: " + value);
		}
	}


}
