package com.bct.geodatafy.util;

public class EnvUtil {
	
	public static String getGDDataPath() {
		String gdDataPath  = System.getenv("GD_DATA_PATH");
		return gdDataPath;
	}
	
	public static String getGDLogPath() {
		String gdLOGPath  = System.getenv("GD_LOG_PATH");
		return gdLOGPath;
	}

}
