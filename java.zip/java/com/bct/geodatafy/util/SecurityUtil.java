package com.bct.geodatafy.util;
import java.security.AlgorithmParameters;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Random;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.apache.log4j.Logger;

public class SecurityUtil {
	static Logger logger = Logger.getLogger(SecurityUtil.class);
  private static int KEY_SIZE = 16;
  private static String ENCRYPTION_KEY = "8080808080808080";

  public static void main(String[] args) {
    String plaintext = "Star@123";
    System.out.println("Plain text: " + plaintext);
    try {
      // Ensure that the key is no more than 16-bytes long
      String passphrase = (ENCRYPTION_KEY.length() > KEY_SIZE) ? ENCRYPTION_KEY.substring(0, KEY_SIZE) : ENCRYPTION_KEY;
      byte[] key = passphrase.getBytes("UTF-8");

      // Generate initialization vector 
      byte[] iv = generateInitializationVector(ENCRYPTION_KEY , KEY_SIZE);
      System.out.println("IV: " + new String(iv, "UTF-8"));
      
      // Encrypt plain text
      String ciphertext = encrypt(plaintext.getBytes("UTF-8"), key, iv);
      System.out.println("Encrypted text: " + ciphertext);
      
      // Decrypt cipher text
      String decryptedtext = decrypt(ciphertext, key, iv);
      System.out.println("Decrypted text: " + decryptedtext);
      decryptedtext = decrypt("ZiW+dSI8nwzA0+vxDo0Stw==");
      System.out.println("Decrypted text: " + decryptedtext);
    } catch (Exception e) {
      logger.error("Exception during encrypting plain text : " , e);
      System.out.println("Exception during encrypting plain text : " + e);
    }
  }
  
  public static String decrypt(String encryptedValue) throws Exception{
	  String ciphertext = encryptedValue;
	    System.out.println("Input String : " + ciphertext);
	    try {
	      // Ensure that the key is no more than 16-bytes long
	      String passphrase = (ENCRYPTION_KEY.length() > KEY_SIZE) ? ENCRYPTION_KEY.substring(0, KEY_SIZE) : ENCRYPTION_KEY;
	      byte[] key = passphrase.getBytes("UTF-8");

	      // Generate initialization vector 
	      byte[] iv = generateInitializationVector(ENCRYPTION_KEY, KEY_SIZE);
	      System.out.println("IV: " + new String(iv, "UTF-8"));
	      logger.info("IV: " + new String(iv, "UTF-8"));
	      
	      // Decrypt cipher text
	      String decryptedtext = decrypt(ciphertext, key, iv);
	      System.out.println("Decrypted text: " + decryptedtext);
	      logger.info("Decrypted text: " + decryptedtext);
	      return decryptedtext;
	    } catch (Exception e) {
	      System.out.println("Exception occurred while encrypting plain text : " + e);
	      logger.error("Exception occurred while descrypting " , e);
	      throw e;
	    }
	  
  }

  /**
   * Encrypt using AES 128-bit encryption with CBC mode
   * 
   * @param plaintext (byte[]) The plain text
   * @param key (byte[]) The secret key
   * @param iv (byte) the initializatoin vector
   *
   * @return (String) Encrypted text
   */
  private static String encrypt(byte[] plaintext, byte[] key, byte[] iv) {
    try {
      SecretKeySpec secretKeySpec;
      secretKeySpec = new SecretKeySpec(key, "AES");
      
      // PKCS#5 Padding
      Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
      AlgorithmParameters algorithmParams = AlgorithmParameters.getInstance("AES");
      algorithmParams.init(new IvParameterSpec(iv));
      cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, algorithmParams);
      byte[] encryptedBytes = cipher.doFinal(plaintext);
      return DatatypeConverter.printBase64Binary(encryptedBytes);
    } catch (NoSuchPaddingException | BadPaddingException e) {
      System.out.println("Padding exception in encrypt(): " + e);
      logger.error("Padding exception in encrypt(): : " , e);
    } catch ( NoSuchAlgorithmException | InvalidKeyException	| IllegalBlockSizeException e ) {
      System.out.println("Validation exception in encrypt(): " + e);
      logger.error("Validation exception in encrypt(): " , e);
    } catch (Exception e) {
      System.out.println("Exception in encrypt(): " + e);
      logger.error("Exception in encrypt(): " , e);
    }
    return null;
  }
  
  /**
   * Decrypt using AES 128-bit encryption with CBC mode
   * 
   * @param ciphertext (byte[]) The cipher text
   * @param key (byte[]) The secret key
   * @param iv (byte) the initializatoin vector
   *
   * @return (String) Plain text
   */
  public static String decrypt(String ciphertext, byte[] key, byte[] iv ) throws Exception {
    try {
      SecretKeySpec secretKeySpec;
      secretKeySpec = new SecretKeySpec(key, "AES");
      Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
      AlgorithmParameters algorithmParams = AlgorithmParameters.getInstance("AES");
      algorithmParams.init(new IvParameterSpec(iv));
      cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, algorithmParams);
      return new String(cipher.doFinal(DatatypeConverter.parseBase64Binary(ciphertext)), "UTF-8");
    } catch (NoSuchPaddingException | BadPaddingException e) {
      System.out.println("Padding exception in decrypt(): " + e);
      throw new Exception("Padding exception in decrypt(): ");
    } catch ( NoSuchAlgorithmException | InvalidKeyException	| IllegalBlockSizeException e ) {
      System.out.println("Validation exception in decrypt(): " + e);
      throw new Exception("Validation exception in decrypt(): ");
    } catch (Exception e) {
      System.out.println("Exception in decrypt(): " + e);
      throw new Exception("Exception in decrypt(): ");
    }
   
  }
  

  /**
   * Utility function to generate initialization vector
   *
   * @return bytes
   */
  private static byte[] generateInitializationVector(String iv, int len) {
    try {
      char[] CHAR_ARRAY = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456879".toCharArray();
      SecureRandom srand = new SecureRandom();
      Random rand = new Random();
      StringBuilder sb = new StringBuilder();
      for (int i = 0; i < len; ++i) {
        if ((i % 10) == 0) {
          rand.setSeed(srand.nextLong());
        }
        sb.append(Integer.toHexString(rand.nextInt(CHAR_ARRAY.length)));
      }
      return iv.substring(0, KEY_SIZE).getBytes("UTF-8");
    } catch (Exception e) {
    	logger.error("Error generating Initialization Vector: ");
      System.out.println("Error generating Initialization Vector: " + e);
    }
    return null; 
  }
}