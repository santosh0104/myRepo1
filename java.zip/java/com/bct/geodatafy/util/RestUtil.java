package com.bct.geodatafy.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.log4j.Logger;

public class RestUtil {
	static Logger logger = Logger.getLogger(RestUtil.class);
	
	public static String getURLResponse(String url) {
		StringBuilder stringBuilder = new StringBuilder();
		BufferedReader reader = null;
		HttpURLConnection connection = null;
		url = url.replace("\\", "%5C");
		url = url.replace(" ", "%20");
		try {
			URL tempUrl = new URL(url);
			connection = (HttpURLConnection) tempUrl.openConnection();
			connection.connect();
			reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));			
			String line = null;
			while ((line = reader.readLine()) != null) {
				stringBuilder.append(line + "\n");
			}
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
			if (connection != null) {
				connection.disconnect();
			}
		}
		return stringBuilder.toString();
	}
}

