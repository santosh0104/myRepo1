package com.bct.geodatafy.util;

import org.apache.log4j.Logger;
import org.quartz.JobDetail;

import com.bct.geodatafy.scheduler.quartz.QuartzScheduler;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class SchedulerUtil {
	static Logger logger = Logger.getLogger(SchedulerUtil.class);
	
	public static boolean canAdd(JsonObject jobObject) {
		String jobName = jobObject.get("jobName").getAsString();
		
		JsonElement scheduled = jobObject.get("scheduled");		
		if(scheduled == null || !scheduled.getAsBoolean()){
			logger.info(jobName + ": The 'scheduled' parameter is not defined or false.");
			return false;
		}
		
		JsonElement active = jobObject.get("active");
		if(active == null || active.getAsString().equalsIgnoreCase("false")){
			logger.info(jobName + ": The 'active' parameter is not defined or false.");
			return false;
		}

		//JsonElement deleted = jobObject.get("deleted");
		//if(deleted != null && deleted.getAsString().equalsIgnoreCase("true")){
			//logger.info(jobName + ": The 'deleted' parameter is true.");
			//return false;
		//}
		return true;
	}
	
	public static boolean canUpdate(JsonObject jobObject) {
		String jobName = jobObject.get("jobName").getAsString();
		
		JsonElement scheduled = jobObject.get("scheduled");		
		if(scheduled != null && scheduled.getAsBoolean()){			
			return true;
		}
		
		logger.info(jobName + ": The 'scheduled' parameter is not defined or false.");
		return false;
	}

	public static boolean canUpdate(org.quartz.JobDataMap jdm) {
		String jobName = jdm.getString("jobName");
		
		String scheduled = jdm.getString("scheduled");		
		if(scheduled != null && scheduled.equalsIgnoreCase("true")){			
			return true;
		}
		
		logger.info(jobName + ": The 'scheduled' parameter is not defined or false.");
		return false;
	}

	public static boolean canAdd(org.quartz.JobDataMap jdm){
		
		String jobName = jdm.getString("jobName");
		
		String active = jdm.getString("active");
		if(active == null || active.equalsIgnoreCase("false")){
			logger.info(jobName + ": The 'active' parameter is not defined or false.");
			return false;
		}
		
		//String deleted = jdm.getString("deleted");
		//if(deleted != null && deleted.equalsIgnoreCase("true")){
			//logger.info(jobName + ": The 'deleted' parameter is true.");
			//return false;
		//}
		
		return true;
	}
}
