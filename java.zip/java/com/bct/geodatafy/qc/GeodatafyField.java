package com.bct.geodatafy.qc;

import java.util.Date;

public class GeodatafyField {	
	String name = null;
	String displayName = null;
	boolean visible = false;
	boolean filter = false;
	String solrType = null;
	boolean mandatory = false;
	String pattern = null;
	Long min = null;
	Long max = null;
	Date minDate = null;
	Date maxDate = null;
	
	public Long getQcType() {
		return qcType;
	}

	public void setQcType(Long qcType) {
		this.qcType = qcType;
	}

	Long qcType = null;

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getDisplayName() {
		return displayName;
	}
	
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	
	public boolean isVisible() {
		return visible;
	}
	
	public void setVisible(boolean visible) {
		this.visible = visible;
	}
	
	public boolean isFilter() {
		return filter;
	}
	
	public void setFilter(boolean filter) {
		this.filter = filter;
	}
	
	public String getSolrType() {
		return solrType;
	}
	
	public void setSolrType(String solrType) {
		this.solrType = solrType;
	}
	
	public boolean isMandatory() {
		return mandatory;
	}
	
	public void setMandatory(boolean mandatory) {
		this.mandatory = mandatory;
	}
	
	public String getPattern() {
		return pattern;
	}
	
	public void setPattern(String pattern) {
		this.pattern = pattern;
	}
	
	public Long getMin() {
		return min;
	}
	
	public void setMin(Long min) {
		this.min = min;
	}
	
	public Long getMax() {
		return max;
	}
	
	public void setMax(Long max) {
		this.max = max;
	}
	
	public Date getMinDate() {
		return minDate;
	}
	
	public void setMinDate(Date minDate) {
		this.minDate = minDate;
	}
	
	public Date getMaxDate() {
		return maxDate;
	}
	
	public void setMaxDate(Date maxDate) {
		this.maxDate = maxDate;
	}
}



