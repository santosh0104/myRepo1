package com.bct.geodatafy.qc;

import java.util.HashMap;
import java.util.Map;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.apache.log4j.Logger;

import com.bct.geodatafy.rest.service.QualityScoreJobService;

public class SampleExpressionEvaluation {
	private static ScriptEngineManager factory = new ScriptEngineManager();
	private static ScriptEngine scriptEngine = factory.getEngineByName("JavaScript");
	static Logger logger = Logger.getLogger(QualityScoreJobService.class);
	public static boolean evaluateExpression(String expr) {				
		try {
			Boolean b = (Boolean) scriptEngine.eval(expr);	
			System.out.println("The result is: "+b);
			return b;
		} catch (ScriptException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public static ScriptEngineManager getFactory() {
		return factory;
	}

	

	public static boolean evaluateExpression(ScriptEngine scriptEngine1, String expr) {				
		try {
					
			Boolean b = (Boolean) scriptEngine1.eval(expr);	
			System.out.println("The result is: "+b);
			return b;
		} catch (ScriptException e) {
			e.printStackTrace();
			return false;
		}
	}
	public static boolean evaluateExpression(HashMap<String, Object> params, String expr) {			
		
		try {
			//ScriptEngine scriptEngineObj = factory.getEngineByName("JavaScript");
			for (Map.Entry<String, Object> entry : params.entrySet()) {
				System.out.println(" evaluateExpression key : " +entry.getKey() +  "  Value :  " + entry.getValue());
				logger.info(" evaluateExpression key : " +entry.getKey() +  "  Value :  " + entry.getValue());
				scriptEngine.put(entry.getKey(), entry.getValue().toString());
			}
			System.out.println(" evaluateExpression  : " +expr);
			Boolean b = (Boolean) scriptEngine.eval(expr);	
			System.out.println("The result is: "+b);
			return b;
		} catch (ScriptException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public static ScriptEngine getScriptEngine() {		
		return scriptEngine;
	}	

	public static void main(String args[]) {
		//String str = "datatype=='Play'  && DataSource=='US_EIA' && count <= 3";
		String str = "url===''";
		//scriptEngine.put("datatype", "Play");
		//scriptEngine.put("DataSource", "US_EIA");
		//scriptEngine.put("count", "22");
		ScriptEngine scriptEngine1 = getFactory().getEngineByName("JavaScript");
	/*	scriptEngine1.put("datatype", "Play");
		scriptEngine1.put("DataSource", "US_EIA");
		scriptEngine1.put("count", "22");*/
		
		scriptEngine1.put("url", "''");
		scriptEngine1.put("content_type", "''");
		SampleExpressionEvaluation.evaluateExpression(scriptEngine1, str);
	}

}
