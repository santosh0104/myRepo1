package com.bct.geodatafy.qc;

public class QCRule {
	
	
	private String qcRuleSet;
	private String qcEntity;
	private String qcField;
	private String qcMandatory;
	private String qcPattern;
	private String qcMin;
	private String qcMax;
	private String qcTestString;
	private String datatype;
	private String qcRegxOption;
	private String qcStartWith;
	private String qcEndWith;
	private String qcDateMin;
	private String cDateMax;
	private String createdDate;
	private String createdBy;
	private String LastModified_DateTime;
	private String editedBy;
	private String id;
	private String qcType;
	public String getQcRuleSet() {
		return qcRuleSet;
	}
	public void setQcRuleSet(String qcRuleSet) {
		this.qcRuleSet = qcRuleSet;
	}
	public String getQcEntity() {
		return qcEntity;
	}
	public void setQcEntity(String qcEntity) {
		this.qcEntity = qcEntity;
	}
	public String getQcField() {
		return qcField;
	}
	public void setQcField(String qcField) {
		this.qcField = qcField;
	}
	public String getQcMandatory() {
		return qcMandatory;
	}
	public void setQcMandatory(String qcMandatory) {
		this.qcMandatory = qcMandatory;
	}
	public String getQcPattern() {
		return qcPattern;
	}
	public void setQcPattern(String qcPattern) {
		this.qcPattern = qcPattern;
	}
	public String getQcMin() {
		return qcMin;
	}
	public void setQcMin(String qcMin) {
		this.qcMin = qcMin;
	}
	public String getQcMax() {
		return qcMax;
	}
	public void setQcMax(String qcMax) {
		this.qcMax = qcMax;
	}
	public String getQcTestString() {
		return qcTestString;
	}
	public void setQcTestString(String qcTestString) {
		this.qcTestString = qcTestString;
	}
	public String getDatatype() {
		return datatype;
	}
	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}
	public String getQcRegxOption() {
		return qcRegxOption;
	}
	public void setQcRegxOption(String qcRegxOption) {
		this.qcRegxOption = qcRegxOption;
	}
	public String getQcStartWith() {
		return qcStartWith;
	}
	public void setQcStartWith(String qcStartWith) {
		this.qcStartWith = qcStartWith;
	}
	public String getQcEndWith() {
		return qcEndWith;
	}
	public void setQcEndWith(String qcEndWith) {
		this.qcEndWith = qcEndWith;
	}
	public String getQcDateMin() {
		return qcDateMin;
	}
	public void setQcDateMin(String qcDateMin) {
		this.qcDateMin = qcDateMin;
	}
	public String getcDateMax() {
		return cDateMax;
	}
	public void setcDateMax(String cDateMax) {
		this.cDateMax = cDateMax;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getLastModified_DateTime() {
		return LastModified_DateTime;
	}
	public void setLastModified_DateTime(String lastModified_DateTime) {
		LastModified_DateTime = lastModified_DateTime;
	}
	public String getEditedBy() {
		return editedBy;
	}
	public void setEditedBy(String editedBy) {
		this.editedBy = editedBy;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getQcType() {
		return qcType;
	}
	public void setQcType(String qcType) {
		this.qcType = qcType;
	}
	
	
	

}
