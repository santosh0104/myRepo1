package com.bct.geodatafy.qc;

import java.io.IOException;
import java.lang.reflect.Type;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import com.bct.geodatafy.util.GeoUtil;

import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.WinHttpClients;
import org.apache.log4j.Logger;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.client.solrj.response.UpdateResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.SolrInputDocument;
import org.codehaus.jettison.json.JSONObject;

import com.bct.geodatafy.job.GeodatafyJobLog;
import com.bct.geodatafy.util.JsonUtil;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;


public class QCUtility {	
	HttpSolrClient dataHttpSolrClient;
	HttpSolrClient dataTypeHttpSolrClient;
	HttpSolrClient metadataHttpSolrClient;	
	static Logger logger = Logger.getLogger(QCUtility.class);	
	Gson gsonObj;
	HashMap< String, List <GeodatafyField>> datatypesList;
	HashMap< String, ArrayList<JSONObject>> complexRule_datatypes;
	HashMap< String, String> datatypesUrlMap;
	HashMap< String, String> dataTypesSolrTypeMap;
	int batchSize;
	String baseSolrURL;

	/**
	 * @param host Geodatafy host name
	 * @param port Geodatafy service port
	 * @param collectionName  The name of Solr collection that contains the data docs that will be scored
	 * @param batchSize  The number of docs to read/write at a time 
	 */
	public QCUtility (String host, String port, String collectionName, int batchSize, String ruleSet, String datatypeList)  throws Exception {
		String solrDataCollectionUrl = "http://" + host + ":" + port + "/solr/" + collectionName;
		this.baseSolrURL = "http://" + host + ":" + port + "/solr/";
		String solrMetadataCollectionUrl = "http://" + host + ":" + port + "/solr/metadata";
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		dataHttpSolrClient =   (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(solrDataCollectionUrl)).withHttpClient(httpClient).build();
		metadataHttpSolrClient =   (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(solrMetadataCollectionUrl)).withHttpClient(httpClient).build();
		gsonObj = new Gson();
		datatypesList = new HashMap< String, List <GeodatafyField>>();
		complexRule_datatypes = new HashMap< String, ArrayList<JSONObject>>();
		datatypesUrlMap = new HashMap<String, String>();		
		dataTypesSolrTypeMap = new HashMap<String, String>();		
		this.batchSize = batchSize;
		getDatatypes(ruleSet, datatypeList);
	}

	
	
	/**
	 *
	 * Apply current set of QC rules defined in datatype docs to all datatypes in specified project/datasource
	 * @param datasourceName
	 * @param projectName
	 * @throws Exception
	 */
	public HashMap<String, String> scoreProject(String datasourceName, String projectName,  String dataSourceTypeName, GeodatafyJobLog jobLogger ) throws Exception {
		
		long startTime = System.currentTimeMillis();
		int totaldoc = 0;
		CloseableHttpClient httpClient1 = WinHttpClients.createDefault();
		HashMap<String, String> returnMap = new HashMap<String, String>();
		for (Entry datatype : datatypesList.entrySet() ) {
			//System.out.println("Datatype: " +  datatype.getKey());
			logger.info("Datatype: " +  datatype.getKey());
			// find which fields have rules for them for this datatype
			List <GeodatafyField> mandatoryFields = getMandatoryFields( (List<GeodatafyField>) datatype.getValue());
			List <GeodatafyField> patternFields = getPatternFields( (List<GeodatafyField>) datatype.getValue());
			List <GeodatafyField> minFields = getMinFields( (List<GeodatafyField>) datatype.getValue());
			List <GeodatafyField> maxFields = getMaxFields( (List<GeodatafyField>) datatype.getValue());
			List <GeodatafyField> minDateFields = getMinDateFields( (List<GeodatafyField>) datatype.getValue());
			List <GeodatafyField> maxDateFields = getMaxDateFields( (List<GeodatafyField>) datatype.getValue());
			ArrayList ComplexRuleSetList = null;
			if(complexRule_datatypes!=null && complexRule_datatypes.size() > 0) {
				ComplexRuleSetList = complexRule_datatypes.get(datatype.getKey());
			}
			
			HashMap<String, HashMap<String, String>> complex_ruleSetType= new HashMap<String, HashMap<String, String>>();
			HashMap<String, String> complex_ruleSet = new HashMap<String, String>();
			
			List<String> fieldNames =  getUniqueFieldNames( mandatoryFields, patternFields, minFields,  maxFields, minDateFields, maxDateFields, ComplexRuleSetList, complex_ruleSetType, complex_ruleSet);		
			int numRules = mandatoryFields.size() + patternFields.size() + minFields.size() +  maxFields.size() +  minDateFields.size() +  maxDateFields.size();
			
			int noOfComplexRules = 0;
			if(ComplexRuleSetList!=null && ComplexRuleSetList.size() > 0 ) {
				noOfComplexRules = ComplexRuleSetList.size();
				logger.info("Datatype: " +  datatype.getKey() + " Number Of Complex RuleSet  : " +  noOfComplexRules);
				numRules = numRules + noOfComplexRules;
			}
			logger.info("Datatype: " +  datatype.getKey() + " Number Of Rules  : " + numRules);
			jobLogger.info("Datatype: " +  datatype.getKey() + " Number Of Rules  : "  + numRules, " ");
			// if there are no rules go on to next datatype
			if ( numRules == 0) continue;
			int start =0;
			String url = this.baseSolrURL + datatypesUrlMap.get( datatype.getKey());
			String strSolrDatatype =  dataTypesSolrTypeMap.get( datatype.getKey());
			//System.out.println(strSolrDatatype);
			dataTypeHttpSolrClient =   (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(url)).withHttpClient(httpClient1).build();
			
			SolrDocumentList docs =  getDocs( dataTypeHttpSolrClient, strSolrDatatype , fieldNames, datasourceName, projectName, dataSourceTypeName,  batchSize, start);
			if(docs!=null && docs.size() > 0) {
				logger.info("Datatype: " +  datatype.getKey() + " Number Of docs found  : " +  docs.getNumFound());
				jobLogger.info("Datatype: " +  datatype.getKey() + " Number Of docs found   : "  +  docs.getNumFound(), " ");
				totaldoc = totaldoc + docs.size();				
				processDocs( dataTypeHttpSolrClient, docs, mandatoryFields, patternFields, minFields,  maxFields, minDateFields, maxDateFields, ComplexRuleSetList, complex_ruleSetType, complex_ruleSet, numRules);
				

				long numFound = docs.getNumFound();
				//System.out.println("Ist Num Found : " + numFound);
				start = start + batchSize;
				
				UpdateResponse ures =  dataTypeHttpSolrClient.commit();
				System.out.println("Batch 1: " +   " Started with start row " + ures.getResponse().toString() );
				jobLogger.info("Batch 1:  commit completed for rows " + start, "  ");
				int i=2;
				//HttpSolrClient dataTypeHttpSolrClient1 =   (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(url)).withHttpClient(httpClient1).build();
				while (start <  numFound) {
					System.out.println("Batch : " + i + " Started with start row " + start );
					jobLogger.info("Batch : " + i + " Started with start row " + start, "  ");
					docs =  getDocs(dataTypeHttpSolrClient,  strSolrDatatype, fieldNames, datasourceName, projectName, dataSourceTypeName,  batchSize, start);
				//	System.out.println("Docs Size : " + docs.size());
					
					processDocs( dataTypeHttpSolrClient, docs, mandatoryFields, patternFields, minFields,  maxFields, minDateFields, maxDateFields, ComplexRuleSetList, complex_ruleSetType, complex_ruleSet, numRules);
					start = start + docs.size();						
					jobLogger.info("Batch : " + i + " before Commit starts " ,  "  ");					
					ures =  dataTypeHttpSolrClient.commit();
					jobLogger.info("Batch : " + i + " Commit Completed " ,  "  ");
					//System.out.println("Batch : " + i + " commit response " + ures.getResponse().toString() );
					i++;
				}	
				logger.info("   " + numFound + " scores written in total for this datatype.");
				jobLogger.info("Datatype: " +  datatype.getKey() + "  Total " + numFound + " scores written in total for this datatype." , " ");
				 ures =  dataTypeHttpSolrClient.commit();
				

				returnMap.put((String) datatype.getKey(), (new Long(numFound)).toString());
			} else {
				logger.info("Datatype: " +  datatype.getKey() + " Number Of docs found  : 0" );
				jobLogger.info("Datatype: " +  datatype.getKey() + " Number Of docs found   : 0" , " ");
			}
		} 	
		long stopTime = System.currentTimeMillis();
		
		if(totaldoc > 0) {
			updateProject(datasourceName, projectName, dataSourceTypeName);
		}
		logger.info("Time taken: " + (stopTime-startTime)/1000.0 + "sec.");
		jobLogger.info("Time taken: " + (stopTime-startTime)/1000.0 + "sec." , " ");
		return returnMap;
	}
	
	/**
	 * Apply QC rules to Solr docs to generate a score for each doc and then write back to Solr data collection
	 * @param docs  SolrDocumentList of docs
	 * @param mandatoryFields List of GeodatafyFields that are to be checked for existence
	 * @param patternFields List of GeodatafyFields that are to be checked for compliance with pattern
	 * @param minFields List of GeodatafyFields that are to be checked against minimum value
	 * @param maxFields List of GeodatafyFields that are to be checked against maximum value
	 * @param numRules  Total number of QC rules that are used
	 * @throws Exception
	 */
	private void processDocs( HttpSolrClient dataTypeHttpSolrClient,  SolrDocumentList docs, List <GeodatafyField> mandatoryFields, List <GeodatafyField> patternFields,
							  List <GeodatafyField> minFields, List <GeodatafyField> maxFields, List <GeodatafyField> minDateFields,
							  List <GeodatafyField> maxDateFields, ArrayList<JSONObject> ComplexRuleSetList,
							  HashMap<String, HashMap<String, String>> complex_ruleSetType, HashMap<String, String> complex_ruleSet, 
							  int numRules) throws Exception{
		if ( docs.size() == 0) {
			return;
		}
		HashMap< String, Float> scoreMap = new HashMap< String, Float>();
		HashMap< String, ArrayList<String>> qcMapComment = new HashMap< String, ArrayList<String>>();
		
		for (SolrDocument doc: docs ){
			int score= 0;			
			ArrayList<String> qcDetails = new ArrayList<String>();
			//System.out.println("ID Processed : " + doc.getFieldValue("id"));
			for (GeodatafyField field : mandatoryFields ){
				if ( doc.containsKey(field.name)) {
					score++;					
					//qcDetails.add( " mandatory check passed for " + field.name);					
					qcDetails.add("{\"field\":\""+ field.name + "\", \"status\":\"passed\", \"rule\":\"mandatory\", \"reason\":\"exists\"}");
				} else {
					
					//qcDetails.add( "mandatory check failed for " + field.name);
					qcDetails.add("{\"field\":\""+ field.name + "\", \"status\":\"failed\", \"rule\":\"mandatory\", \"reason\":\"does not exist\"}");
					//logger.info("PatterField " + field.name   + " mandatory check failed  ");
				}
			}
			for (GeodatafyField field : minFields ){
				//System.out.println("Min Field MAtch ");
				if ( doc.containsKey(field.name)  && field.min!=null  && ((Number)doc.getFieldValue(field.name)).longValue() >= field.min) {					
					//qcDetails.add( " minFields check passed for " + field.name + " and is > " + field.min);
					qcDetails.add("{\"field\":\""+ field.name + "\", \"status\":\"passed\", \"rule\":\"minField\", \"reason\":\"greater than " + field.min + "\"}");
					score++;
				} else {
					if ( doc.containsKey(field.name) ) {
						
						//qcDetails.add( " minFields check failed for " + field.name + " and is < " + field.min);
						qcDetails.add("{\"field\":\""+ field.name + "\", \"status\":\"failed\", \"rule\":\"minField\", \"reason\":\"is not greater than " + field.min + "\"}");
						//logger.info(" PatterField " + field.name  + " PatterField  Value " +  (Number) doc.getFieldValue(field.name) + " is not greater than " + field.max);
					} else {
						
						//qcDetails.add( " minFields check failed for " + field.name + " as field not present");
						qcDetails.add("{\"field\":\""+ field.name + "\", \"status\":\"failed\", \"rule\":\"minField\", \"reason\":\"field does not exist.\"}");
						//logger.info(" PatterField " + field.name  + "not present");
					}
				}
			}
			for (GeodatafyField field : maxFields ){
				//System.out.println("Max Field MAtch ");
				if ( doc.containsKey(field.name)  && field.max!=null  && ((Number)doc.getFieldValue(field.name)).longValue() <= field.max) {
					
					//qcDetails.add(" maxField check passed for " + field.name + " and is < " + field.max);
					qcDetails.add("{\"field\":\""+ field.name + "\", \"status\":\"passed\", \"rule\":\"maxField\", \"reason\":\"less than " + field.max + "\"}");
					score++;
				} else {
					if ( doc.containsKey(field.name) ) {
						
						//qcDetails.add( " maxField check failed for " + field.name + " as field value" + ((Number)doc.getFieldValue(field.name)).longValue() + " is > " + field.max);
						qcDetails.add("{\"field\":\""+ field.name + "\", \"status\":\"failed\", \"rule\":\"maxField\", \"reason\":\"is not less than " + field.max + "\"}");
						//logger.info(" PatterField " + field.name  + " PatterField  Value " +  (Number) doc.getFieldValue(field.name) + " is not lesser than  " + field.max);
					} else {
						
						//qcDetails.add( " maxField check failed for " + field.name + " as field not present");
						qcDetails.add("{\"field\":\""+ field.name + "\", \"status\":\"failed\", \"rule\":\"maxField\", \"reason\":\"field does not exist.\"}");
						//logger.info(" PatterField " + field.name  + "not present");
					}
				}
			}
			for (GeodatafyField field : minDateFields ){
				
				if ( doc.containsKey(field.name)  && field.minDate!=null && ((Date)doc.getFieldValue(field.name)).getTime() >= field.minDate.getTime()) {
					
					//qcDetails.add( " minDateField check passed for " + field.name + " and field value is > " + field.minDate);
					qcDetails.add("{\"field\":\""+ field.name + "\", \"status\":\"passed\", \"rule\":\"minDateField\", \"reason\":\"greater than " + field.minDate + "\"}");
					score++;
					//System.out.println("Min Field MAtch " + score);
				} else {
					if ( doc.containsKey(field.name) ) {
						
						//qcDetails.add( " minDateField check failed for " + field.name + " and field value is < " + field.minDate);
						qcDetails.add("{\"field\":\""+ field.name + "\", \"status\":\"failed\", \"rule\":\"minDateField\", \"reason\":\"is not greater than " + field.minDate + "\"}");
						//logger.info( " Min DAte PatterField " + field.name  + " PatterField  Value " +  (Date) doc.getFieldValue(field.name) + "is not greater than  " + field.minDate);
					} else {
						
						//qcDetails.add( " minDateField check failed for " + field.name + " as field not present");
						qcDetails.add("{\"field\":\""+ field.name + "\", \"status\":\"failed\", \"rule\":\"minDateField\", \"reason\":\"field does not exist.\"}");
						//logger.info("Min DAte PatterField " + field.name  + "not present");
					}
				}
			}
			for (GeodatafyField field : maxDateFields ){
			
				if ( doc.containsKey(field.name) && field.maxDate!=null && ((Date)doc.getFieldValue(field.name)).getTime() <= field.maxDate.getTime()) {
					
					//qcDetails.add(" maxDateField check passed for " + field.name + " and field value is < " + field.maxDate);
					qcDetails.add("{\"field\":\""+ field.name + "\", \"status\":\"passed\", \"rule\":\"maxDateField\", \"reason\":\"lesser than " + field.maxDate + "\"}");
					score++;
					//System.out.println("Max Field MAtch " + score);
				} else {
					if ( doc.containsKey(field.name) ) {
						
						//qcDetails.add(" maxDateField check failed for " + field.name + " and field value is < " + field.maxDate);
						qcDetails.add("{\"field\":\""+ field.name + "\", \"status\":\"failed\", \"rule\":\"maxDateField\", \"reason\":\"is not lesser than " + field.maxDate + "\"}");
						//logger.info(" Max Date PatterField " + field.name  + " PatterField  Value " +  (Date) doc.getFieldValue(field.name) + "is not greater than  " + field.minDate);
					} else {
						
						//qcDetails.add(" maxDateField check failed for " + field.name + " as field not present");
						qcDetails.add("{\"field\":\""+ field.name + "\", \"status\":\"failed\", \"rule\":\"maxDateField\", \"reason\":\"field does not exist.\"}");
						//logger.info("Max Date PatterField " + field.name  + "not present");
					}
					
				}
			}
			for (GeodatafyField field : patternFields ){
				//System.out.println(" PatterField " + field.name  + " PatterField  Value " +  (String) doc.getFieldValue(field.name));
				if (doc.containsKey(field.name) && Pattern.matches(field.pattern.trim(), ((String) doc.getFieldValue(field.name)).trim())) {
					
					//qcDetails.add(" patternField check passed for " + field.name + " and field value matches the patteren " + field.pattern);
					qcDetails.add("{\"field\":\""+ field.name + "\", \"status\":\"passed\", \"rule\":\"matchPattern\", \"reason\":\"Matched pattern " + field.pattern + "\"}");
					score++;
				} else {
					if ( doc.containsKey(field.name) ) {
						
						//qcDetails.add(" patternField check failed for " + field.name + " and field value not matches the patteren " + field.pattern);
						qcDetails.add("{\"field\":\""+ field.name + "\", \"status\":\"failed\", \"rule\":\"matchPattern\", \"reason\":\"Did not match pattern " + field.pattern + "\"}");
						//System.out.println(" PatterField " + field.name  + " PatterField  Value " +  (String) doc.getFieldValue(field.name) + "not matched");
					} else {
						
						//qcDetails.add(" patternField check failed for " + field.name + " as field not present");
						qcDetails.add("{\"field\":\""+ field.name + "\", \"status\":\"failed\", \"rule\":\"matchPattern\", \"reason\":\"field does not exist.\"}");
						logger.info(" Min PatterField " + field.name  +  "  is not Present in the document ");
					}
				}
			}
			
			try {
				if (complex_ruleSet != null && complex_ruleSet.size() > 0) {
						//for(int i=0; i < complex_ruleSet.size(); i++) {
					int i = 0;
					/* Loop for each complex Rule */
					for (Map.Entry<String, String> entryRule : complex_ruleSet.entrySet()) {
							String ruleExpr = entryRule.getValue();
							HashMap<String, String> hMApFeilds = complex_ruleSetType.get(entryRule.getKey());
							HashMap<String,  Object> hpScObj = new HashMap<String, Object>();
							/* Loop for variable to substitute the values in complex Rule */
							for (Map.Entry<String, String> entry : hMApFeilds.entrySet())
							{
							    System.out.println(entry.getKey() + "/" + entry.getValue());
							    String fieldName = entry.getKey();
							    
							    if ( doc.containsKey(entry.getKey()) ) {							    	
							      	if(entry.getValue().equalsIgnoreCase(Constants.STRING)) {							      		
							    		 hpScObj.put(entry.getKey().replace("-", "_"), (String)doc.getFieldValue(fieldName));							    		 
							    	} else if(entry.getValue().equalsIgnoreCase(Constants.TINT )) {
							    		 hpScObj.put(entry.getKey().replace("-", "_"), ((Number)doc.getFieldValue(fieldName)).intValue());
							    	}else if(entry.getValue().equalsIgnoreCase(Constants.TLONG )) {
							    		 hpScObj.put(entry.getKey().replace("-", "_"), ((Number)doc.getFieldValue(fieldName)).longValue());
							    	} else if(entry.getValue().equalsIgnoreCase(Constants.TFLOAT )) {
							    		 Number num = (Number)doc.getFieldValue(fieldName);							    		 
							    		 hpScObj.put(entry.getKey().replace("-", "_"),  ((Number)doc.getFieldValue(fieldName)).floatValue());							    		
							    	} else if(entry.getValue().equalsIgnoreCase(Constants.TDOUBLE )) {
							    		 hpScObj.put(entry.getKey().replace("-", "_"),  ((Number)doc.getFieldValue(fieldName)).doubleValue());							    		
							    	} else if(entry.getValue().equalsIgnoreCase(Constants.TDATE )) {							    		
							    		hpScObj.put(entry.getKey().replace("-", "_"), ((Date)doc.getFieldValue(fieldName)).getTime());
							    	} else {
							    		hpScObj.put(entry.getKey().replace("-", "_"), (String)doc.getFieldValue(fieldName));
							    	}	
							    } else {		
							    	/*if(entry.getValue().equalsIgnoreCase(Constants.STRING)) {		*/					      		
							    		 hpScObj.put(entry.getKey().replace("-", "_"), "''");							    		 
							    	/*} else if(entry.getValue().equalsIgnoreCase(Constants.TINT )) {
							    		 hpScObj.put(entry.getKey().replace("-", "_"), 0.0);
							    	}else if(entry.getValue().equalsIgnoreCase(Constants.TLONG )) {
							    		 hpScObj.put(entry.getKey().replace("-", "_"), 0.0);
							    	} else if(entry.getValue().equalsIgnoreCase(Constants.TFLOAT )) {
							    		 Number num = (Number)doc.getFieldValue(fieldName);							    		 
							    		 hpScObj.put(entry.getKey().replace("-", "_"),  0.0);							    		
							    	} else if(entry.getValue().equalsIgnoreCase(Constants.TDOUBLE )) {
							    		 hpScObj.put(entry.getKey().replace("-", "_"),  0.0);							    		
							    	} else if(entry.getValue().equalsIgnoreCase(Constants.TDATE )) {							    		
							    		hpScObj.put(entry.getKey().replace("-", "_"), "''");
							    	} else {
							    		hpScObj.put(entry.getKey().replace("-", "_"), (String)doc.getFieldValue(fieldName));
							    	}	*/
									logger.info(entryRule.getKey() + " field.name  " + fieldName + " is not Present in the document ");
								}
							}
							// System.out.println("Utility RuleExpr " + ruleExpr);
							boolean result  = SampleExpressionEvaluation.evaluateExpression(hpScObj, ruleExpr);
							if(result) {								
								//json.put("qcRuleId" , entryRule.getKey());
								populateQCDetailsForComplexRules(ComplexRuleSetList, entryRule, qcDetails, "passed");							
								logger.info(entryRule.getKey() + " check passed for doc with Id : " + doc.getFieldValue("id") );
								score++;
							} else {
								populateQCDetailsForComplexRules(ComplexRuleSetList, entryRule, qcDetails, "failed");
								logger.info(entryRule.getKey() + " check failed for doc with Id : " + doc.getFieldValue("id") );
							}
						}
					}
				} catch(Exception e){
					e.printStackTrace();
					logger.error("Exception occurred during processing complex rule set and the message is " + e.getMessage());
					throw e;
				}

			
			float totalScore =  (float) (100. * score/ numRules);
			logger.info("Score  : " + score  +" Number of Rules: " + numRules + " Total Score : " + totalScore);
			scoreMap.put((String)doc.getFieldValue("id"), totalScore);	

			//Gson gson = new Gson();	
			//String json = gson.toJson(qcDetails, new TypeToken<List<String>>() {}.getType());
			qcMapComment.put((String)doc.getFieldValue("id"), qcDetails);
		}
		writeScores(scoreMap, qcMapComment, dataTypeHttpSolrClient);	
	}
	
	//Populate the qc details with the complex rule results in a the same format as normal rules
	//All the fileds used in the complex rules are considered as failed even though individually they have passed in normal rules
	private void populateQCDetailsForComplexRules(ArrayList<JSONObject> complexRuleSetList, Map.Entry<String, String> entryRule, ArrayList<String> qcDetails, String result) throws Exception{
		if (complexRuleSetList != null && complexRuleSetList.size() > 0) {
			for(JSONObject complexRule : complexRuleSetList) {
				String id = (String) complexRule.get("id");
				if(entryRule.getKey().equals(id)){
					String rules = (String) complexRule.get("rules");
					JsonArray jsonArr = JsonUtil.convertToJsonArray(rules);
					Set<String> fieldNames = new HashSet<String>();
					for(int k = 0; k < jsonArr.size(); k++) {
						JsonElement jsonObj = jsonArr.get(k);
						Map<String, String> elementsMap = JsonUtil.getJsonStringMap(jsonObj.toString());
						
						String fieldName = elementsMap.get("field");						
						fieldNames.add(fieldName);
						//String elemlookUp = elementsMap.get("lookUp");
						//if(elemlookUp != null && elemlookUp.equals("true")){
						//	String value = elementsMap.get("value");
						//	fieldNames.add(value);
						//}
					}
					
					String qcPattern = (String) complexRule.get("qcPattern");
					for(String fieldName : fieldNames){
						JSONObject json = new JSONObject();
						json.put("field", fieldName);
						json.put("status", result);
						json.put("rule", qcPattern);
						if(result.equals("passed")){
							json.put("reason", "Matched the pattern: " + qcPattern);	
						}
						else{
							json.put("reason", "Did not match the pattern: " + qcPattern);
						}
						

						qcDetails.add(json.toString());
					}
				}
			}
		}
	}


	/**
	 *  Given the fields that will be used for QC scoring get the unique field names
	 * @param fields1 List of GeodatafyFields
	 * @param fields2 List of GeodatafyFields
	 * @param fields3 List of GeodatafyFields
	 * @param fields4 List of GeodatafyFields
	 * @return
	 */
	List <String> getUniqueFieldNames (List <GeodatafyField> fields1, List <GeodatafyField> fields2, 
			List <GeodatafyField> fields3, List <GeodatafyField> fields4, List <GeodatafyField> fields5,
			List <GeodatafyField> fields6, ArrayList<JSONObject> ComplexRuleSetList, HashMap<String, HashMap<String, String>> complex_ruleSetType
			, HashMap<String, String> complex_ruleSet) throws Exception{
		HashSet<String> fieldNames = new HashSet<String>();
		for (GeodatafyField field: fields1 ){
			fieldNames.add(field.name);
		}
		for (GeodatafyField field: fields2 ){
			fieldNames.add(field.name);
		}
		for (GeodatafyField field: fields3 ){
			fieldNames.add(field.name);
		}
		for (GeodatafyField field: fields4 ){
			fieldNames.add(field.name);
		}
		for (GeodatafyField field: fields5 ){
			fieldNames.add(field.name);
		}
		for (GeodatafyField field: fields6 ){
			fieldNames.add(field.name);
		}
		getComplexRulesExprAndFields(ComplexRuleSetList, complex_ruleSetType, complex_ruleSet, fieldNames);
		
		return new ArrayList<String>(fieldNames);
	}
	
	private void getComplexRulesExprAndFields(ArrayList<JSONObject> ComplexRuleSetList, HashMap<String, HashMap<String, String>> complex_ruleSetType
			, HashMap<String, String> complex_ruleSet, HashSet<String> fieldNames) throws Exception {
		
		try {
			if (ComplexRuleSetList != null && ComplexRuleSetList.size() > 0) {
				int j=0;
				for(JSONObject json : ComplexRuleSetList) {			
					//JSONObject json = new JSONObject(doc);
					String rules = (String) json.get("rules");
					String qcPattern = (String) json.get("qcPattern");
					String id = (String) json.get("id");
					
					JsonArray jsonArr = JsonUtil.convertToJsonArray(rules);
					
					HashMap<String, String> fieldMap = new HashMap<String, String>();
					for(int i=0; i < jsonArr.size(); i++) {
						
						JsonElement jsonObj = jsonArr.get(i);
						Map<String, String> elementsMap = JsonUtil.getJsonStringMap(jsonObj.toString());
						String elemlookUp = elementsMap.get("lookUp");
						boolean blookUp= new Boolean(elemlookUp);
						if(blookUp) {
							String fieldName = elementsMap.get("field");
							String valfieldName = elementsMap.get("value");
							String solrType = elementsMap.get("solrType");
							System.out.println(solrType);
							fieldMap.put(fieldName, solrType);
							fieldMap.put(valfieldName, solrType);
							if (!fieldNames.contains(fieldName)) {
								fieldNames.add(fieldName);
							}
							if (!fieldNames.contains(valfieldName)) {
								fieldNames.add(valfieldName);
							}	
							
							
						} else {
							String fieldName = elementsMap.get("field");
							String solrType = elementsMap.get("solrType");
							System.out.println(solrType);
							if (!fieldNames.contains(fieldName)) {
								fieldNames.add(fieldName);
							}
							fieldMap.put(fieldName, solrType);
						}
						
					}
					String key = "Rule" + j++;
					complex_ruleSetType.put(id, fieldMap);
					String strRuleExpr = GenerateRule.buildRules(rules);
					//System.out.println(" getUniqueField - > " + strRuleExpr);
					logger.info("getUniqueField method the RuleExpression is : " +  strRuleExpr);
					complex_ruleSet.put(id, strRuleExpr);
					
				}
					
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error("Exception in getUniqueField method", e);
			throw e;
			
		}
		
	}

	/**
	 * Given a list of GeodatafyFields just return those that have the mandatory attribute=true 
	 * 
	 * @param fields
	 * @return List of mandatory GeodatafyFields
	 */
	List <GeodatafyField> getMandatoryFields (List <GeodatafyField> fields ){
		return fields.stream().filter(p -> p.mandatory).collect(Collectors.<GeodatafyField> toList());
	}
	/**
	 * Given a list of GeodatafyFields just return those that have the pattern attribute set
	 * 
	 * @param fields
	 * @return List of GeodatafyFields with a pattern attribute set
	 */
	List <GeodatafyField> getPatternFields (List <GeodatafyField> fields ){
		return fields.stream().filter(p -> p.pattern != null && p.pattern.length() > 0).collect(Collectors.<GeodatafyField> toList());
	}
	/**
	 * Given a list of GeodatafyFields just return those that have the minimum attribute set
	 * 
	 * @param fields
	 * @return List of GeodatafyFields with a minimum value set
	 */
	List <GeodatafyField> getMinFields (List <GeodatafyField> fields ){
		return fields.stream().filter(p -> ( (p.solrType.equalsIgnoreCase(Constants.TLONG) || p.solrType.equalsIgnoreCase(Constants.TFLOAT) || p.solrType.equalsIgnoreCase(Constants.TINT) || p.solrType.equalsIgnoreCase(Constants.TDOUBLE)  ) && p.min != null) ).collect(Collectors.<GeodatafyField> toList());
	}
	/**
	 * Given a list of GeodatafyFields just return those that have the maximum attribute set
	 * 
	 * @param fields
	 * @return List of GeodatafyFields with a maximum value set
	 */
	List <GeodatafyField> getMaxFields (List <GeodatafyField> fields ){
		return fields.stream().filter(p -> ( (p.solrType.equalsIgnoreCase(Constants.TLONG) || p.solrType.equalsIgnoreCase(Constants.TFLOAT) || p.solrType.equalsIgnoreCase(Constants.TINT) || p.solrType.equalsIgnoreCase(Constants.TDOUBLE) ) && p.max != null) ).collect(Collectors.<GeodatafyField> toList());
	}
	
	/**
	 * Given a list of GeodatafyFields just return those that have the minimum attribute set
	 * 
	 * @param fields
	 * @return List of GeodatafyFields with a minimum value set
	 */
	List <GeodatafyField> getMinDateFields (List <GeodatafyField> fields ){
		return fields.stream().filter(p ->   p.minDate != null).collect(Collectors.<GeodatafyField> toList());
	}
	/**
	 * Given a list of GeodatafyFields just return those that have the minimum attribute set
	 * 
	 * @param fields
	 * @return List of GeodatafyFields with a minimum value set
	 */
	List <GeodatafyField> getMaxDateFields (List <GeodatafyField> fields ){
		return fields.stream().filter(p ->   p.maxDate != null).collect(Collectors.<GeodatafyField> toList());
	}

	List <GeodatafyField> getFields ( String attributeString) {		 
		Type geodatafyListType = new TypeToken<ArrayList<GeodatafyField>>(){}.getType(); 
		List <GeodatafyField> fields = gsonObj.fromJson(attributeString, geodatafyListType);
		return fields;
	}

	/**
	 * Query Solr to get docs of given datatype for a specified project/datasource
	 * 
	 * @param datatypeName Name of datatype to retrieve
	 * @param fieldNames  Fields to query for 
	 * @param datasource  Datasource for Solr docs
	 * @param project  Project for Solr docs
	 * @param nDocs  Maximum number of docs to return
	 * @param start Starting number of doc to return (allows reading in batches) 
	 * @return  A Solr
	 */
	private SolrDocumentList getDocs(HttpSolrClient dataTypeHttpSolrClient, String datatypeName, List<String> fieldNames, String datasource, String project, String dataSourceTypeName,  int nDocs, int start) throws Exception {
		SolrQuery query = new SolrQuery();
		query.set("q","*:*" );
		query.set("fl", String.join(",", fieldNames) + ",id" );
		
		query.addFilterQuery(datatypeName);
		query.addFilterQuery("DataSource:\"" + GeoUtil.escapeQueryParams(datasource) + "\"");
		query.addFilterQuery("DataSourceTypeName:\"" + GeoUtil.escapeQueryParams(dataSourceTypeName) + "\"");
		query.addFilterQuery("Project:\"" + GeoUtil.escapeQueryParams(project) + "\"");	
		query.setSort("id", SolrQuery.ORDER.desc);
		query.set("wt","json");
		query.setStart(start);
		query.setRows(nDocs);
		logger.info(query.toQueryString());
		//System.out.println(datatypeName);
		//System.out.println("Get Docs" + query.toQueryString());
		try {
			QueryResponse resp = dataTypeHttpSolrClient.query(query);
			int status = resp.getStatus();
			if ( status==0 ) {
				return resp.getResults();
										
			}
			else {
				logger.info("  Status: " + status);
				return null;
			}

		} catch (Exception e ) {	
			logger.error(" getDocs  Status: FAILED");
			logger.error(e.getMessage(), e);	
			//return null;
			throw e;
			//e.printStackTrace();
		}

	}  

	/**
	 * Get the datatypes from the metadata collection and put them into the m_datatypes HashMap 
	 */
	private void getDatatypes(String ruleSet,  String datatypeList) throws Exception{
		StringBuffer strBuf = new StringBuffer();
		
		System.out.println(datatypeList);
		SolrQuery query = new SolrQuery();
		query.set("q","*:*");
		query.addFilterQuery("datatype:datatype");
		query.addFilterQuery("name:" + datatypeList);
		query.set("wt","json");
		query.set("rows",100);
		try {
			QueryResponse resp = metadataHttpSolrClient.query(query);
			int status = resp.getStatus();
			if ( status==0 ) {
				SolrDocumentList docs = resp.getResults();
				for(SolrDocument doc : docs) {
					
					String attributeString = (String) doc.getFieldValue("attributes");
					List <GeodatafyField> fields = getFields(attributeString);
					String datatypeName = (String) doc.getFieldValue("name");
					String solrCoreUrl = (String) doc.getFieldValue("solrCoreUrl");
					String solrDataType = (String) doc.getFieldValue("fq");
					solrCoreUrl = solrCoreUrl.substring(solrCoreUrl.lastIndexOf("/")+1);
					//System.out.println(datatypeName + " // " + solrDataType + "  :  " + attributeString);
					datatypesList.put(datatypeName, fields);		
					datatypesUrlMap.put(datatypeName, solrCoreUrl);
					dataTypesSolrTypeMap.put(datatypeName, solrDataType);
					
				}							
			}
			else {
				logger.error(" getDatatypes Status: " + status);
				String errMsg = "getDatatypes Solr Query " + query.getQuery() + "  Failed";
				logger.error(errMsg);
				throw new Exception("fail");
			}
			getRulesForDatatypes(ruleSet);

		} catch (Exception e ) {	
			String errMsg = e.getMessage();
			logger.error("  getDatatypes Status: FAILED");
			logger.error(e.getMessage());	
			logger.error("getDatatypes exception in getDatatypes  " , e);
			throw new Exception(errMsg);
		}
		
	}
	

	
	
	/**
	 * Get the Rules for the datatypes from the metadata collection
	 */
	private void getRulesForDatatypes(String ruleSet) throws Exception {
		for (Entry datatype : datatypesList.entrySet() ) {
			List <GeodatafyField> fieldsList =  (List<GeodatafyField>) datatype.getValue();
			
			SolrQuery query = new SolrQuery();
			String strMainQry = "qcRuleSet:\"" + GeoUtil.escapeQueryParams(ruleSet) + "\" && " +"datatype:qcRule && qcEntity:\"" + datatype.getKey() + "\"";
			//System.out.println(strMainQry);
			query.set("q",strMainQry);
			//query.addFilterQuery("datatype:qcRule");
			query.set("wt","json");
			query.set("rows",100000);
			try {
				QueryResponse resp = metadataHttpSolrClient.query(query);
				int status = resp.getStatus();
				if ( status==0 ) {
					SolrDocumentList docs = resp.getResults();
					ArrayList docsComplex = new ArrayList();
					//System.out.println(" getResults : " + resp.toString());
					//System.out.println(" getResults size : " + docs.size());
					for(Map doc : docs) {	
						JSONObject json = new JSONObject(doc);
						if(json.has("qcField")) {
							String strqcField = (String) json.get("qcField");
							for(int cnt=0; cnt < fieldsList.size(); cnt++) {
								GeodatafyField  fieldsObj = fieldsList.get(cnt);
								if (strqcField.equals(fieldsObj.name)) {
								System.out.println(strqcField + " equals : " + fieldsObj.name);
									if(json.has("qcMandatory")) {
										fieldsObj.mandatory = (boolean) json.get("qcMandatory");
									}
									if(json.has("qcPattern")) {
										fieldsObj.pattern = (String) json.get("qcPattern");
									}
									if(json.has("qcMin")) { 
										System.out.println(strqcField + " qcMin : " + (Long) json.get("qcMin"));
										fieldsObj.min = (Long) json.get("qcMin");
									}
									if(json.has("qcMax")) {
										System.out.println(strqcField + " qcMin : " + (Long) json.get("qcMax"));
										fieldsObj.max = (Long) json.get("qcMax");
									}
									if(json.has("qcMinDate")) {
										Date minDate = (Date) json.get("qcMinDate");
										fieldsObj.minDate =  minDate;
									}
									if(json.has("qcMaxDate")) {
										Date maxDate  = (Date) json.get("qcMaxDate");
										fieldsObj.maxDate =  maxDate;
									}
									
								}							
							}
						} else if (json.has("compositeRules") && json.has("rules")){	
							docsComplex.add(json);
							
						}
					}
					if (docsComplex!=null && docsComplex.size() > 0 ) {
						complexRule_datatypes.put((String)datatype.getKey(), docsComplex);
					}
					
				} else {
					System.out.println("  Status: " + status);
					String errMsg = "getRulesForDatatypes Solr Query " + query.getQuery() + "  Failed";
					logger.error(errMsg);
					throw new Exception("fail");
				}

			} catch (Exception e ) {	
				String errMsg = e.getMessage();
				System.out.println("  Status: FAILED");
				System.out.println(e.getMessage());	
				logger.error("getRulesForDatatypes exception in getDatatypes method " , e);
				throw new Exception(errMsg);	
			}
			
		} 	
		
	}
	
	
	
	/**
	 * Write all the docs in the scoreMap. Does an incremental write to just add/update score on existing solr docs
	 * @param scoreMap 
	 * @throws SolrServerException
	 * @throws IOException
	 */
	private void writeScores(HashMap<String, Float> scoreMap, HashMap<String, ArrayList<String>>qcMapComment, HttpSolrClient dataTypeHttpSolrClient) throws SolrServerException, IOException {	
		List <SolrInputDocument> docs = new ArrayList<SolrInputDocument>();
		for(Entry score: scoreMap.entrySet()){
			SolrInputDocument doc = new SolrInputDocument();
			Map<String, Float> partialUpdate = new HashMap<String, Float>();
			partialUpdate.put("set", (Float) score.getValue());
			doc.addField("id", score.getKey() );			
			doc.addField("qcscore", partialUpdate);	
			
			ArrayList<String> qcdetail = qcMapComment.get(score.getKey());
						
			if(qcdetail!=null && qcdetail.size() > 0) {
				Map<String, String[]> partialUpdate2 = null;
				String[] strArr = new String[qcdetail.size()];
				int i=0;
				for(String qcDet: qcdetail) {
					strArr[i] = qcDet;	
					i++;
				}	
				partialUpdate2 = new HashMap<String, String[]>();
				partialUpdate2.put("set", strArr);
				doc.addField("qcCheckDetails", partialUpdate2);
				
			}
			docs.add(doc);						
		}		
		dataTypeHttpSolrClient.add(docs);			
	}
	

	/**
	 * Update Last Scored field on project
	 * @param scoreMap 
	 * @throws SolrServerException
	 * @throws IOException
	 */
	private void updateProject(String datasource, String project, String dataSourceTypeName) throws SolrServerException, IOException {	
		// get existing project doc's id
		SolrQuery query = new SolrQuery();
		query.set("q","*:*" );
		query.set("fl", "id" );
		query.addFilterQuery("datatype:Project");
		query.addFilterQuery("Project:\"" + GeoUtil.escapeQueryParams(project) + "\"");
		query.addFilterQuery("DataSource:\"" + GeoUtil.escapeQueryParams(datasource) + "\"");
		query.addFilterQuery("DataSourceTypeName:\"" + GeoUtil.escapeQueryParams(dataSourceTypeName) + "\"");
		query.set("wt","json");
		try {
			QueryResponse resp = dataHttpSolrClient.query(query);
			int status = resp.getStatus();
			if ( status==0 ) {
				SolrDocumentList docs = resp.getResults();
				// update the project doc's Last_Scored field with current UTC datetime 
				for(SolrDocument doc : docs) {
					String id = (String) doc.getFieldValue("id");
					
					System.out.println(id);
					SolrInputDocument projDoc = new SolrInputDocument();
					Map<String, String> partialUpdate = new HashMap<String, String>();
					partialUpdate.put("set", Instant.now().toString()  );	
					projDoc.addField("id",  id);
					//projDoc.addField("id", id.replace("\\", "\\\\"));
					projDoc.addField("Last_Scored_DateTime", partialUpdate);		
					logger.info(projDoc.toString());
					
					dataHttpSolrClient.add(projDoc);	
					dataHttpSolrClient.commit();
				}						
			}
			else {
				logger.info("  Status: " + status);
			}
		} catch (Exception e ) {	
			logger.error(" updateProject  Status: FAILED");
			logger.error("updateProject " + e.getMessage(), e);	
			e.printStackTrace();
			throw e;
		}				
		logger.info("Datasource:   " + datasource + "  Project:" + project + " Last_Scored updated.");
	}
	
	private String encodeURLStr(String str){
		str = str.replace(" ", "%20");
		str = str.replace("&", "%26");
		
		str = str.replace("!", "%21");
		str = str.replace("(", "%28");
		str = str.replace(")", "%29");
		
		str = str.replace("{", "%7B");
		str = str.replace("|", "%7C");
		str = str.replace("}", "%7D");
		
		str = str.replace("[", "%5B");
		str = str.replace("]", "%5D");
		
		str = str.replace("+", "%2B");
		str = str.replace("-", "%2D");
		str = str.replace("^", "%27");
		str = str.replace("~", "%7E");
		str = str.replace("#", "%23");
		return str;		
	}
}
