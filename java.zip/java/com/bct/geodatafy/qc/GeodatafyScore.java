package com.bct.geodatafy.qc;

public class GeodatafyScore {
	
	String solrHost = "localhost";
	String solrPort = "8983";
	String solrCollectionName;
	String projectName;
	String dataSourceName;
	String ruleSet;
	public String getSolrHost() {
		return solrHost;
	}
	public void setSolrHost(String solrHost) {
		this.solrHost = solrHost;
	}
	public String getSolrPort() {
		return solrPort;
	}
	public void setSolrPort(String solrPort) {
		this.solrPort = solrPort;
	}
	public String getSolrCollectionName() {
		return solrCollectionName;
	}
	public void setSolrCollectionName(String solrCollectionName) {
		this.solrCollectionName = solrCollectionName;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getDataSourceName() {
		return dataSourceName;
	}
	public void setDataSourceName(String dataSourceName) {
		this.dataSourceName = dataSourceName;
	}
	public String getRuleSet() {
		return ruleSet;
	}
	public void setRuleSet(String ruleSet) {
		this.ruleSet = ruleSet;
	}	

}
