package com.bct.geodatafy.qc;

public interface Constants {
	public static final String EQUAL = "equal";
	public static final String NOTEQUAL = "not equal";
	public static final String IN = "in";
	public static final String NOTIN = "not in";
	public static final String LESS = "less than";
	public static final String LESSOREQUAL = "less than or equal to";
	public static final String GREATER = "greater than";
	public static final String GREATEROREQUAL = "greater than or equal to";	
	public static final String ISNULL = "is null";
	public static final String ISNOTNULL = "is not null";	
	public static final String BEGINWITH = "begins with";
	public static final String NOTBEGINWITH = "does not begin with";
	public static final String CONTAINS = "contains";
	public static final String NOTCONTAINS = "does not contain";
	public static final String ENDSWITH = "ends with";
	public static final String NOTENDSWITH = "does not end with";
	public static final String BEFORE = "before";
	public static final String AFTER = "after";
	
	public static final String TINT = "pint";
	public static final String TLONG = "plong";
	public static final String TFLOAT = "pfloat";
	public static final String TDOUBLE = "pdouble";
	public static final String STRING = "string";
	public static final String TDATE = "pdate";
	public static final String BOOLEAN = "boolean";
	
	
	public static final String GEOMENTRY = "Geometry";
	public static final String LOCATIONRPT = "location_rpt";
	public static final String DISPLAYORDER = "displayOrder";
	public static final String VERSION = "_version_";
	public static final String LASTMODIFIED = "LastModified";
	public static final String CREATEDDATE = "CreateDate";
	public static final String VISIBLE = "visible";
	
	

}
