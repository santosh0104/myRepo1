package com.bct.geodatafy.qc;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.script.ScriptEngine;

import com.bct.geodatafy.util.JsonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

public class GenerateRule {
	
	public static HashMap<String, String> docRuleLookUpField = new HashMap<String, String>();

	public static void main(String args[]) throws Exception {
	//	ArrayList<String> fieldNames = new ArrayList<String>();		
		
		 String str1 = "[{\"field\":\"datatype\",\"solrType\":\"string\",\"operator\":\"in\",\"value\":\"Play,Well,Well log\",\"condition\":\"AND\",\"lookUp\":false},"
		 		+ "{\"field\":\"DataSource\",\"solrType\":\"string\",\"operator\":\"EQUAL\",\"value\":\"US_EIA\",\"condition\":\"AND\",\"lookUp\":false},"
		 		+ "{\"field\":\"TD\",\"solrType\":\"tfloat\",\"operator\":\"IN\",\"value\":\"10,20,30\",\"condition\":\"AND\",\"lookUp\":false}]";
		
		//String str1 = "[{\"field\":\"Name\",\"solrType\":\"pint\", \"operator\":\"in\",\"value\":\"1,2,3\",\"condition\":\"AND\",\"lookUp\":false}]";
		 System.out.println(" result " + buildRules(str1));
		 ScriptEngine scriptEngine1 = SampleExpressionEvaluation.getFactory().getEngineByName("JavaScript");
			
		  
		scriptEngine1.put("datatype", "Play1");
		scriptEngine1.put("DataSource", "US_EIA");
		scriptEngine1.put("TD", "10");
		scriptEngine1.put("Name", "1");
		//scriptEngine1.put("Name", "c");
		//scriptEngine1.put("GeologicAge", "Play");
	boolean bResult = SampleExpressionEvaluation.evaluateExpression(scriptEngine1, buildRules(str1));
		// System.out.println(bResult);
	
		
		
	}
	public static String buildRules(String rules) {
		JsonArray jsonArr = JsonUtil.convertToJsonArray(rules);
		StringBuffer strBuf = new StringBuffer();
		ScriptEngine scriptEngine = SampleExpressionEvaluation
				.getScriptEngine();
		for (int i = 0; i < jsonArr.size(); i++) {
			JsonElement jsonObj = jsonArr.get(i);
			Map<String, String> elementsMap = JsonUtil.getJsonStringMap(jsonObj
					.toString());
			String elemlookUp = elementsMap.get("lookUp");
			boolean blookUp = new Boolean(elemlookUp);
			if (blookUp) {
				String fieldName = elementsMap.get("field");
				fieldName = fieldName.replaceAll("-", "_");
				String operator = elementsMap.get("operator");
				String value = elementsMap.get("value");
				value = value.replaceAll("-", "_");
				String openBracket = elementsMap.get("openBracket");
				String closeBracket = elementsMap.get("closeBracket");
				String condition = elementsMap.get("condition");
				String solrType = elementsMap.get("solrType");
				scriptEngine.put(fieldName, value);
				strBuf = (openBracket != null && openBracket.trim().length() > 0) ? strBuf.append(openBracket) : strBuf
						.append("");
				
				if(solrType.equalsIgnoreCase(Constants.STRING)) {
					strBuf = getStringOperatorExpression(strBuf, fieldName , operator, value, blookUp);
				} else if(solrType.equalsIgnoreCase(Constants.TINT) ) {
					strBuf = getNumberOperatorExpression(strBuf, fieldName , operator, value);					
				}else if(solrType.equalsIgnoreCase(Constants.TLONG)) {
					strBuf = getNumberOperatorExpression(strBuf, fieldName , operator, value);					
				}else if(solrType.equalsIgnoreCase(Constants.TFLOAT)) {
					strBuf = getNumberOperatorExpression(strBuf, fieldName , operator, value);					
				}else if(solrType.equalsIgnoreCase(Constants.TDOUBLE)) {
					strBuf = getNumberOperatorExpression(strBuf, fieldName , operator, value);					
				} else if(solrType.equalsIgnoreCase(Constants.TDATE)) {
					strBuf = getDateOperatorExpression(strBuf, fieldName , operator, value, blookUp);					
				} else {
					strBuf = getStringOperatorExpression(strBuf, fieldName , operator, value, blookUp);
				}

							
				strBuf = (closeBracket != null && closeBracket.trim().length() > 0) ? strBuf.append(closeBracket) : strBuf
						.append("");
				strBuf = (condition != null && condition
						.equalsIgnoreCase("AND")) ? strBuf.append(" ")
						.append("&&").append(" ") : strBuf.append(" ")
						.append("||").append(" ");
				;

			} else {
				String fieldName = elementsMap.get("field");
				fieldName = fieldName.replaceAll("-", "_");
				String operator = elementsMap.get("operator");
				String value = elementsMap.get("value");
				String openBracket = elementsMap.get("openBracket");
				String closeBracket = elementsMap.get("closeBracket");
				String condition = elementsMap.get("condition");
				String solrType = elementsMap.get("solrType");

				strBuf = (openBracket != null  && openBracket.trim().length() > 0) ? strBuf.append(openBracket) : strBuf
						.append("");
				if(solrType.equalsIgnoreCase(Constants.STRING)) {
					strBuf = getStringOperatorExpression(strBuf, fieldName , operator, value);
				} else if( (solrType.equalsIgnoreCase(Constants.TINT) || solrType.equalsIgnoreCase(Constants.TLONG) 
						|| solrType.equalsIgnoreCase(Constants.TFLOAT) || solrType.equalsIgnoreCase(Constants.TDOUBLE)) && 
						(operator.equalsIgnoreCase(Constants.IN) || operator.equalsIgnoreCase(Constants.NOTIN) ) ) {
					strBuf = getNumberOperatorExpression(strBuf, fieldName , operator, value);
					
				} else if(solrType.equalsIgnoreCase(Constants.TINT)) {
					strBuf = getNumberOperatorExpression(strBuf, fieldName , operator, (value!=null && value.trim().length()> 0) ? new Integer(value):0);
				}else if(solrType.equalsIgnoreCase(Constants.TLONG)) {
					strBuf = getNumberOperatorExpression(strBuf, fieldName , operator,(value!=null && value.trim().length()> 0)? new Long(value):0);
				}else if(solrType.equalsIgnoreCase(Constants.TFLOAT)) {
					strBuf = getNumberOperatorExpression(strBuf, fieldName , operator, (value!=null && value.trim().length()> 0) ? new Float(value): 0.0);
				}else if(solrType.equalsIgnoreCase(Constants.TDOUBLE)) {
					strBuf = getNumberOperatorExpression(strBuf, fieldName , operator, (value!=null && value.trim().length()> 0) ? new Double(value):0.0);
				} else if(solrType.equalsIgnoreCase(Constants.TDATE)) {
					strBuf = getDateOperatorExpression(strBuf, fieldName , operator, value);					
				} else {
					strBuf = getStringOperatorExpression(strBuf, fieldName , operator, value);
				}
				
				strBuf = (closeBracket != null && closeBracket.trim().length() > 0) ? strBuf.append(closeBracket) : strBuf
						.append("");
				strBuf = (condition != null && condition
						.equalsIgnoreCase("AND")) ? strBuf.append(" ")
						.append("&&").append(" ") : strBuf.append(" ")
						.append("||").append(" ");
				;

			}

		}
		String strexpr = strBuf.toString();
		strexpr = strexpr.substring(0, strexpr.length() - 4);
		System.out.println(strexpr);

		return strexpr;
	}
	public static StringBuffer getStringOperatorExpression(StringBuffer strBuf, String fieldName, String operator, String value) {
		System.out.println("get  ----> " );
		if (operator.equalsIgnoreCase(Constants.EQUAL)) {
			strBuf.append(fieldName).append("==='").append(value).append("' ");
		}
		if (operator.equalsIgnoreCase(Constants.NOTEQUAL)) {
			strBuf.append(fieldName).append("!=='").append(value).append("' ");
		}
		if (operator.equalsIgnoreCase(Constants.IN)) {
			 System.out.println(value);
			String[] strValueList = value.split("(?<!\\\\),");	
			strBuf.append("(");
			for (int i=0; i < strValueList.length; i++) {
				 System.out.println(strValueList[i]);
				 String strValue = strValueList[i].replace("\\,", ",");
				if(i==strValueList.length-1) {	
					strBuf.append(fieldName).append("==='").append(strValue).append("' ");					
				} else {
					strBuf.append(fieldName).append("==='").append(strValue).append("' || ");					
				}				
			}	
			strBuf.append(")");
			
		}
		if (operator.equalsIgnoreCase(Constants.NOTIN)) {
			String[] strValueList = value.split("(?<!\\\\),");		
			strBuf.append("(");
			for (int i=0; i < strValueList.length; i++) {
				 System.out.println(strValueList[i]);
				 String strValue = strValueList[i].replace("\\,", ",");
				if(i==strValueList.length-1) {	
					strBuf.append(fieldName).append("!=='").append(strValue).append("' ");					
				} else {
					strBuf.append(fieldName).append("!=='").append(strValue).append("' && ");					
				}				
			}
			strBuf.append(")");
			
		}
		if (operator.equalsIgnoreCase(Constants.BEGINWITH)) {
			strBuf.append(fieldName).append(".startsWith('").append(value).append("') ");
		}
		if (operator.equalsIgnoreCase(Constants.NOTBEGINWITH)) {
			strBuf.append("!").append(fieldName).append(".startsWith('").append(value).append("') ");
		}
		if (operator.equalsIgnoreCase(Constants.CONTAINS)) {
			strBuf.append(fieldName).append(".indexOf('").append(value).append("')!=-1 ");
		}
		if (operator.equalsIgnoreCase(Constants.NOTCONTAINS)) {
			strBuf.append(fieldName).append(".indexOf('").append(value).append("')==-1 ");
		}
		if (operator.equalsIgnoreCase(Constants.ENDSWITH)) {
			strBuf.append(fieldName).append(".endsWith('").append(value).append("') ");
		}
		if (operator.equalsIgnoreCase(Constants.NOTENDSWITH)) {
			strBuf.append("!").append(fieldName).append(".endsWith('").append(value).append("') ");
		}			
		if (operator.equalsIgnoreCase(Constants.ISNULL)) {
			
			strBuf.append(fieldName).append("===").append("\"''\"").append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.ISNOTNULL)) {
			value=null;
			strBuf.append(fieldName).append("!==").append("\"''\"").append(" ");
		}
		
		return strBuf;
	}
	
	
	
	
	public static StringBuffer getStringOperatorExpression(StringBuffer strBuf, String fieldName, String operator, String value, boolean lookup) {
		System.out.println("get  ----> " );
		if (operator.equalsIgnoreCase(Constants.EQUAL)) {
			strBuf.append(fieldName).append("==").append(value).append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.NOTEQUAL)) {
			strBuf.append(fieldName).append("!=").append(value).append(" ");
		}
		
		if (operator.equalsIgnoreCase(Constants.BEGINWITH)) {
			strBuf.append(fieldName).append(".startsWith(").append(value).append(") ");
		}
		if (operator.equalsIgnoreCase(Constants.NOTBEGINWITH)) {
			strBuf.append("!").append(fieldName).append(".startsWith(").append(value).append(") ");
		}
		if (operator.equalsIgnoreCase(Constants.CONTAINS)) {
			strBuf.append(fieldName).append(".indexOf(").append(value).append(")!=-1 ");
		}
		if (operator.equalsIgnoreCase(Constants.NOTCONTAINS)) {
			strBuf.append(fieldName).append(".indexOf(").append(value).append(")==-1 ");
		}
		if (operator.equalsIgnoreCase(Constants.ENDSWITH)) {
			strBuf.append(fieldName).append(".endsWith(").append(value).append(") ");
		}
		if (operator.equalsIgnoreCase(Constants.NOTENDSWITH)) {
			strBuf.append("!").append(fieldName).append(".endsWith(").append(value).append(") ");
		}			
		if (operator.equalsIgnoreCase(Constants.ISNULL)) {
			value = null;
			strBuf.append(fieldName).append("===").append("\"''\"").append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.ISNOTNULL)) {
			value = null;
			strBuf.append(fieldName).append("!==").append("\"''\"").append(" ");
		}
		
		return strBuf;
	}
	
	
	public  static StringBuffer getNumberOperatorExpression(StringBuffer strBuf, String fieldName, String operator, java.lang.Number value) {
		System.out.println("get  ----> " );
		if (operator.equalsIgnoreCase(Constants.EQUAL)) {
			strBuf.append(fieldName).append("==").append(value).append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.NOTEQUAL)) {
			strBuf.append(fieldName).append("!==").append(value).append(" ");
		}
		
		if (operator.equalsIgnoreCase(Constants.LESS)) {
			strBuf.append(fieldName).append("<").append(value).append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.LESSOREQUAL)) {
			strBuf.append(fieldName).append("<=").append(value).append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.GREATER)) {
			strBuf.append(fieldName).append(">").append(value).append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.GREATEROREQUAL)) {
			strBuf.append(fieldName).append(">=").append(value).append(" ");
		}
		
		if (operator.equalsIgnoreCase(Constants.ISNULL)) {		
			strBuf.append(fieldName).append("==").append("\"''\"").append(" ");			
		}
		if (operator.equalsIgnoreCase(Constants.ISNOTNULL)) {
			strBuf.append(fieldName).append("!=").append("\"''\"").append(" ");
		}
		
		return strBuf;
	}

	public  static StringBuffer getNumberOperatorExpression(StringBuffer strBuf, String fieldName, String operator, String value) {
		
		if (operator.equalsIgnoreCase(Constants.EQUAL)) {
			strBuf.append(fieldName).append("==").append(value).append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.NOTEQUAL)) {
			strBuf.append(fieldName).append("!==").append(value).append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.IN)) {
			String[] strValueList = value.split("(?<!\\\\),");		
			strBuf.append("(");
			for (int i=0; i < strValueList.length; i++) {
				 System.out.println(strValueList[i]);
				 String strValue = strValueList[i].replace("\\,", ",");
				if(i==strValueList.length-1) {	
					strBuf.append(fieldName).append("==").append(strValue).append(" ");					
				} else {
					strBuf.append(fieldName).append("==").append(strValue).append(" || ");					
				}				
			}	
			strBuf.append(")");
			
		}
		if (operator.equalsIgnoreCase(Constants.NOTIN)) {
			String[] strValueList = value.split("(?<!\\\\),");		
			strBuf.append("(");
			for (int i=0; i < strValueList.length; i++) {
				 System.out.println(strValueList[i]);
				 String strValue = strValueList[i].replace("\\,", ",");
				if(i==strValueList.length-1) {	
					strBuf.append(fieldName).append("!=").append(strValue).append(" ");					
				} else {
					strBuf.append(fieldName).append("!=").append(strValue).append(" && ");					
				}				
			}
			strBuf.append(")");
			
		}
		if (operator.equalsIgnoreCase(Constants.LESS)) {
			strBuf.append(fieldName).append("<").append(value).append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.LESSOREQUAL)) {
			strBuf.append(fieldName).append("<=").append(value).append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.GREATER)) {
			strBuf.append(fieldName).append(">").append(value).append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.GREATEROREQUAL)) {
			strBuf.append(fieldName).append(">=").append(value).append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.ISNULL)) {
			strBuf.append(fieldName).append("==").append("\"''\"").append(" ");
		
		}
		if (operator.equalsIgnoreCase(Constants.ISNOTNULL)) {
			strBuf.append(fieldName).append("!=").append("\"''\"").append(" ");
		}
		
		return strBuf;
	}

	
	public  static StringBuffer getDateOperatorExpression(StringBuffer strBuf, String fieldName, String operator, String value) {
		System.out.println("get  ----> " );
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.sss'Z'");
		df.setTimeZone(TimeZone.getTimeZone("UTC"));
		long dateObjinmillis=0;
		try {
			if(value!=null && value.length() > 1) {
				dateObjinmillis = ((Date)df.parse(value)).getTime();
			}
		} catch (Exception e) {
			e.printStackTrace();			
		}
		if (operator.equalsIgnoreCase(Constants.EQUAL)) {
			strBuf.append(fieldName).append("===").append(dateObjinmillis).append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.NOTEQUAL)) {
			strBuf.append(fieldName).append("!==").append(dateObjinmillis).append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.BEFORE)) {
			
			strBuf.append(fieldName).append("<").append(dateObjinmillis).append(" ");
		}		
		if (operator.equalsIgnoreCase(Constants.AFTER)) {
			strBuf.append(fieldName).append(">").append(dateObjinmillis).append(" ");
		}	
		if (operator.equalsIgnoreCase(Constants.ISNULL)) {
			value = null;
			strBuf.append(fieldName).append("==").append("\"''\"").append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.ISNOTNULL)) {
			value = null;
			strBuf.append(fieldName).append("!=").append("\"''\"").append(" ");
		}
		
		return strBuf;
	}
	
	public  static StringBuffer getDateOperatorExpression(StringBuffer strBuf, String fieldName, String operator, String value, boolean lookup) {		
	
		if (operator.equalsIgnoreCase(Constants.EQUAL)) {
			strBuf.append(fieldName).append("===").append(value).append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.NOTEQUAL)) {
			strBuf.append(fieldName).append("!==").append(value).append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.BEFORE)) {
			
			strBuf.append(fieldName).append("<").append(value).append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.AFTER)) {
			strBuf.append(fieldName).append(">").append(value).append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.ISNULL)) {
			value = null;
			strBuf.append(fieldName).append("==").append("''").append(" ");
		}
		if (operator.equalsIgnoreCase(Constants.ISNOTNULL)) {
			value = null;
			strBuf.append(fieldName).append("!=").append("\"''\"").append(" ");
		}		
		return strBuf;
	}


}
