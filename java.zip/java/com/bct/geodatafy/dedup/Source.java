package com.bct.geodatafy.dedup;

/**
 * 
 * A source is uniquely identified by its DataSource and Project name
 *
 */
public class Source {
	String dataSource;
	String project;
	public Source  (String dataSource, String project) {
		this.dataSource= dataSource;
		this.project= project;			
	}
	public String getDataSource() {
		return dataSource;
	}
	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
}