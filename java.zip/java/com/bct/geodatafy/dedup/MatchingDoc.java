package com.bct.geodatafy.dedup;

/**
 * A MatchingDoc holds id of a Solr doc and attributes that may be used to determine the preferred doc
 *
 */
public class MatchingDoc {
	String id;
	String dataSource;
	String project;
	float qcscore;		
	boolean preferred;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDataSource() {
		return dataSource;
	}
	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public float getQcscore() {
		return qcscore;
	}
	public void setQcscore(float qcscore) {
		this.qcscore = qcscore;
	}				
	public boolean isPreferred() {
		return preferred;
	}
	public void setPreferred(boolean preferred) {
		this.preferred = preferred;
	}
}
