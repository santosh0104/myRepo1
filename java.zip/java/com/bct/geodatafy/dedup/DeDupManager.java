package com.bct.geodatafy.dedup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrQuery.SortClause;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.SolrInputDocument;
import org.apache.solr.common.params.CursorMarkParams;

import com.google.gson.Gson;

public class DeDupManager {
	public enum PreferenceStrategy { BY_SOURCE_PRORITY, BY_SCORE};



	

	HttpSolrClient solrDataCollection;
	HttpSolrClient solrMetadataCollection;
	Gson gson;
	int batchSize;
	int commitWithinMs;
	HashMap <String,List<MatchingDoc>> m_docMap; // a map whose key is the concatenation of fields used for matching and value is a list of MatchingDoc objects

	 public long  getUniqueCount() {
		 return m_docMap.size();
	 }

	/**
	 * Used for testing 
	 * 
	 * @param args not used...
	 */
	public static void main (String[] args) {
		String host= "192.168.0.166";
		String port = "8983";
		String collection = "data";
		int batchSize= 10000;
		int commitWithinMs= 5000;
		DeDupManager deDupManager = new DeDupManager(host, port, collection, batchSize, commitWithinMs);
		//List<String> matchingFields = Arrays.asList("WellboreUWI");		
		List<String> matchingFields = Arrays.asList("id");
		String datatypeName = "Well";
		List<Source> sources = new ArrayList <Source>();
		sources.add( new Source("FakeDB", "B" ) );
		sources.add( new Source("FakeDB", "A" ) );
		//sources.add( deDupManager.new Source("USA_Wells", "USA_Wells" ) );
		sources.add( new Source("PPDM", "PPDM" ) );
		sources.add( new Source("Kingdom", "SaltCreek" ) );
		long t1= System.currentTimeMillis();	   
		try {
			int nDocs = deDupManager.detectDuplicates(datatypeName, sources, matchingFields, PreferenceStrategy.BY_SOURCE_PRORITY);
			long t2= System.currentTimeMillis();	    	 
			System.out.println(nDocs + " solr docs read. " +  deDupManager.m_docMap.size() + " unique wells found.  " + (t2-t1)/1000 + " seconds");
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}

	/**
	 * Iterate through list of keys and if there is only 1 matching doc set it as preferred.  If more than one and 
	 * sourcePriorty is supplied then set the doc with the highest priority source as preferred. 
	 * Otherwise set the doc with highest qcscore as preferred (in case of tie take first). 
	 * The source Solr docs are then updated with the determined preferred, duplicate, and key field values.
	 * @param sourcePriority If null use qcscore to select preferred doc. Otherwise use the sourcePriorty order of sources to determine preferred source.
	 * @throws IOException 
	 * @throws SolrServerException 
	 */
	private void updateDocs(List<Source> sourcePriority) throws SolrServerException, IOException {
		List<SolrInputDocument> solrDocs = new ArrayList<SolrInputDocument>();		
		for ( Entry<String, List<MatchingDoc>> entry :m_docMap.entrySet() ) {
			String key= entry.getKey();
			List<MatchingDoc> matchingDocs = entry.getValue();
			processMatchingDocs(matchingDocs, sourcePriority);
			boolean duplicate = false;
			if ( matchingDocs.size() > 1) duplicate= true;
			for ( MatchingDoc matchingDoc : matchingDocs ){		   
				SolrInputDocument doc = new SolrInputDocument();
				doc.addField("id", matchingDoc.id );
				Map<String,Object> fieldModifier = new HashMap<>(1);
				fieldModifier.put("set", matchingDoc.isPreferred() );
				doc.addField("preferred", fieldModifier);
				Map<String,Object> fieldModifier2 = new HashMap<>(1);
				fieldModifier2.put("set", duplicate );
				doc.addField("duplicate", fieldModifier2);
				Map<String,Object> fieldModifier3 = new HashMap<>(1);
				fieldModifier3.put("set", key );
				doc.addField("key", fieldModifier3);
				solrDocs.add(doc);
				// write docs to Solr when list exceeds batch size
				if (solrDocs.size() >= batchSize ) {										
					solrDataCollection.add(solrDocs, commitWithinMs);					
					solrDocs.clear();					
				}
			}		
		}   
		if (solrDocs.size() > 0) {
			solrDataCollection.add(solrDocs, commitWithinMs);
		}	
	}

	/**
	 * Process the matchingDocs at set the preferred flag based on PreferenceStrategy. 
	 * @param matchingDocs The List of one or more MatchingDocs
	 * @param sourcePriority The source priority to use to determine the preferred doc. If null then use qcscore 
	 */
	private void processMatchingDocs(List<MatchingDoc> matchingDocs, List<Source> sourcePriority ) {
		if ( matchingDocs.size() == 1 ) {
			matchingDocs.get(0).setPreferred(true);
		}
		else {
			if ( sourcePriority != null && sourcePriority.size() > 0) {	
				setPreferredDocbySource(sourcePriority, matchingDocs);	
			}
			else {
				setPreferredDocbyQcScore (matchingDocs);
			}			
		}		
	}

	/**
	 *  Set the MatchingDoc with the highest source priority as preferred
	 * @param sourcePriority the source priorty (highest -lowest) 
	 * @param docs  MatchingDocs to examine
	 */
	private void setPreferredDocbySource ( List<Source> sourcePriority,  List<MatchingDoc> docs){
		for ( Source source: sourcePriority ){
			for ( MatchingDoc doc : docs ) {			
				if ( doc.project.equals(source.project) && doc.dataSource.equals(source.dataSource) ) {
					doc.setPreferred(true);	
					return;
				}				
			}
		}
	}

	/**
	 * Set the MatchingDoc with the highest qcscore as preferred
	 * @param docs MatchingDocs to examine
	 * 
	 */
	private void setPreferredDocbyQcScore ( List<MatchingDoc> docs) {
		docs.sort( Comparator.comparing(MatchingDoc::getQcscore).reversed() );
		docs.get(0).setPreferred(true);
	}


	/**
	 * Add a MatchingDoc  to the m_docMap with a key value that is the concatenation of the matching fields. 
	 * If a matching key already exists in the map then add the MatchingDoc to the map items MatchingDoc list.
	 * @param doc
	 * @param matchingFields
	 */
	private void addDoc(SolrDocument doc, List<String> matchingFields) {
		String key = makeKey( doc, matchingFields);
		List<MatchingDoc> matchingDocs = m_docMap.get(key);
		if (matchingDocs == null){
			matchingDocs =  new ArrayList<MatchingDoc>();	
		}	
		MatchingDoc  matchingDoc = new MatchingDoc();
		matchingDoc.setId ( (String)doc.getFieldValue("id") );
		matchingDoc.setProject ( (String)doc.getFieldValue("Project") );
		matchingDoc.setDataSource ( (String)doc.getFieldValue("DataSource") );
		if (doc.getFieldValue("qcscore") != null ) {
			matchingDoc.setQcscore( (float)doc.getFieldValue("qcscore") );
		}		
		matchingDocs.add( matchingDoc ) ;		
		m_docMap.put(key, matchingDocs);
	}

	/**
	 * Make an identifying key by concatenating the values of the Solr doc's  matching fields. Two docs that have
	 *  the same key are considered to represent the same physical entity
	 * @param doc The solr document
	 * @param matchingFields List of field names to use to create key
	 * @return The key
	 */
	private String makeKey(SolrDocument doc, List<String> matchingFields) {
		String key = "";
		for ( String fieldName:matchingFields){
			key = key + doc.getFieldValue(fieldName);
		}
		//System.out.println(key);
		return key;
	}
	/**
	 * @param host Solr host name
	 * @param port Solr  port
	 * @param collectionName  The name of Solr collection that contains the data docs that will be scored
	 * @param batchSize  The number of docs to read/write at a time 
	 */
	public DeDupManager (String host, String port, String collectionName, int iBatchSize, int iCommitWithinMs) {
		String solrDataCollectionUrl = "http://" + host + ":" + port + "/solr/" + collectionName;
		String solrMetadataCollectionUrl = "http://" + host + ":" + port + "/solr/metadata";
		CloseableHttpClient httpClient = HttpClients.createDefault();
		solrDataCollection =   (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(solrDataCollectionUrl)).withHttpClient(httpClient).build();
		solrMetadataCollection =   (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(solrMetadataCollectionUrl)).withHttpClient(httpClient).build();
		gson = new Gson();
		batchSize = iBatchSize;	
		commitWithinMs = iCommitWithinMs;
		m_docMap = new HashMap <String,List<MatchingDoc> >();
	}

	/**
	 * Detect duplicates across the specified sources for the specified datatype.  Duplicates are docs whose matching fields are equal. 
	 * Set a doc's Preferred field to true if there is only one doc with the same set of matching field values. If there are multiple matching 
	 * docs then set one as preferred based on the preferenceStrategy.  
	 * 
	 * So docs are updated with: 
	 * <ul><li> <i>preferred</i> field </li>
	 * <li> <i>key</i> field (concatenated values of matching fields) </li>
	 * <li> <i>duplicate</i> field (true if multiple docs have the same key) </li></ul> 
	 * @param datatypeName e.g "Well", "Well Pick" etc....
	 * @param sources A list of datasources ( DataSource and Project).  If strategy= BY_SOURCE_PRIORTY then these should be supplied in order
	 * of descending priority(e.g. highest priority is first)  
	 * @param matchingFields A list of field names to use in matching docs 
	 * @param preferenceStrategy If BY_SCORE then set the matching doc with the highest qcscore as preferred (if tied then pick first) . 
	 * If BY_SOURCE_PRIORITY then choose the doc who's source appears first in the sources list. 
	 * @return total number of docs read
	 * @throws Exception 
	 */
	public int detectDuplicates(String datatypeName, List<Source> sources, List<String> matchingFields , PreferenceStrategy preferenceStrategy) throws Exception {		
		int nDocs = readDocs( datatypeName,  matchingFields, sources,  batchSize);
		switch (preferenceStrategy) {
			case BY_SOURCE_PRORITY:
				updateDocs(sources);
				break;
			case BY_SCORE:
				updateDocs(null);
				break;
			default:
				break;
		}	
		return nDocs;
	}

	/**
	 * Query Solr to get docs of given datatype for specified projects/datasources and then 
	 * create MatchingDocs and add them to the m_docMap map .  Use the Solr cursor to iterate through the 
	 * query results  batchSize docs at a time
	 * 
	 * @param datatypeName Name of datatype to retrieve
	 * @param matchingFields  Field names to be used for matching 
	 * @param source  Sources for Solr docs (define by datasource and project)
	 * @param batchSize  Number of docs to read in each query
	 * @return total number of docs read
	 * @throws Exception 
	 */
	private int readDocs(String datatypeName, List<String> matchingFields, List<Source> sources, int batchSize) throws Exception {
		String fq = "";
		int nDocs = 0;
		for ( Source source : sources) {
			fq = fq + "(DataSource:" + source.getDataSource() + " AND  Project:" + source.getProject() + ") ";
		}
		SolrQuery query = new SolrQuery();
		query.set("q","*:*" );
		query.set("fl", String.join(",", matchingFields) + ",id,qcscore,DataSource,Project" );
		//System.out.println("matchingFields : " +  String.join(",", matchingFields));
		query.addFilterQuery("datatype:\"" + datatypeName + "\"");
		query.addFilterQuery(fq );	
		query.set("wt","json");
		query.setSort(SortClause.asc("id"));
		query.setRows(batchSize);
		String cursorMark = CursorMarkParams.CURSOR_MARK_START;
		boolean done = false;
		while (! done) {
			query.set(CursorMarkParams.CURSOR_MARK_PARAM, cursorMark);
			//System.out.println("query : " + query.toQueryString());
			//System.out.println("query : " + query.toString());
			QueryResponse resp = solrDataCollection.query(query);	
			//System.out.println("resp : " + resp.getResults());
			int status = resp.getStatus();
			String nextCursorMark = resp.getNextCursorMark();
			if ( status==0 ) {
				SolrDocumentList docs= resp.getResults();				
				//clearPreferredFlags( docs );
				docs.forEach( doc -> addDoc(doc, matchingFields) );
				nDocs = nDocs+ docs.size();
			}
			else {
				throw (new Exception("Solr query failed. status=" + status));
			}
			if (cursorMark.equals(nextCursorMark)) {
				done = true;
			}
			cursorMark = nextCursorMark;
		}
		return nDocs;	
	}
}
