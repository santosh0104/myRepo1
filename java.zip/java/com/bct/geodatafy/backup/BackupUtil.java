package com.bct.geodatafy.backup;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;





import org.apache.commons.io.FileUtils;

import javax.ws.rs.Path;




import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.WinHttpClients;
import org.apache.log4j.Logger;
import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.bct.geodatafy.job.GeodatafyJobLog;
import com.bct.geodatafy.job.backup.BackupJobData;
import com.bct.geodatafy.job.backup.RestoreJob;
import com.bct.geodatafy.job.backup.SolrBackupJob;
import com.bct.geodatafy.job.backup.SolrBackupJobStatistics;



import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


/**
 * 
 * @author LG111891
 *  This class is used to take solr backup of all collections and ZooData configuration.
 */

@Path("/jobs/backup")
public class BackupUtil{
	static Logger logger = Logger.getLogger(BackupUtil.class);
	public static final String JOB_TYPE = "SolrBackupservice";
	public static final int COMMIT_SIZE = 10;
	public static  int BKUPPOLLTIME = 30000;
	public static final String JOBS_COLLECTION = "jobs";
	
	 public static int getRandom(int max){
	        return (int) (Math.random()*max);
	    }
	

	public String runSolrBackupJobService(SolrBackupJob  indexJob, String protocol,  GeodatafyJobLog jobLogger )
		 throws Exception{		
		
		String retMsg = null;
		BackupJobData indexJobData = indexJob.getJobData();
		
		String baseSolrURL = protocol + "://" + indexJobData.getSolrHost() + ":" + indexJobData.getSolrPort()+ "/solr";
		BKUPPOLLTIME = getBkupPollTime(indexJobData.getSolrHost(), indexJobData.getSolrPort());
		List<SolrBackupJobStatistics> statistics = getJobStatistics(indexJob.getJobName(), indexJobData, jobLogger);
		indexJob.setStatistics(statistics);
		if(statistics == null){
			jobLogger.warn("No Collection", "Given Collection is null");
			indexJob.setJobStatus(SolrBackupJob.JOB_ERROR);	
			uploadJobRunData(baseSolrURL, indexJob, jobLogger);
			
		}else if(statistics.size() == 0){
			jobLogger.warn("No Collection", "Given Collection is empty");
			indexJob.setJobStatus(SolrBackupJob.JOB_COMPLETED);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());	
			uploadJobRunData(baseSolrURL, indexJob, jobLogger);
		}else{
			logger.info("Uploading the job run data before backup.");
			uploadJobRunData(baseSolrURL, indexJob, jobLogger);
			RestoreJob restoreJob = getSolrBackupJobs(indexJob, jobLogger);
			String collectionName = indexJobData.getSolrCollectionName();
			SolrBackupAll(indexJob, jobLogger);
			logger.info("Uploading the job run data after indexing.");		
			uploadJobRunData(baseSolrURL, indexJob, jobLogger);
			if(indexJob.getJobStatus().equalsIgnoreCase(SolrBackupJob.JOB_COMPLETED)) {
				String targetFolder = indexJobData.getBackupFolder();	
				targetFolder = targetFolder.concat("\\" + indexJobData.getSolrHost()).concat("\\"+ indexJob.getJobName() );
				System.out.println("Deleting Older backup in " + targetFolder);
			
				File directory = new File(targetFolder);        
				File[] files = directory.listFiles();
				
				if(files==null || files.length <= 0 ) {
					logger.info("NO Older backup in " + targetFolder);					
				} else {
					Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
					int nobkuptobe = indexJobData.getNoOfBackupRetained();
					nobkuptobe = nobkuptobe ;
					System.out.println("Files Length   " + files.length + " nobkuptobe  " +  nobkuptobe);
					if(files.length > nobkuptobe) {
						for (int i=nobkuptobe; i < files.length; i++)
						{
							try {
								System.out.println("i : " + i + " " + files[i]);
								FileUtils.deleteDirectory(files[i]);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}	
					} 
				}
				
				//updateBackupDetails(baseSolrURL, indexJob, jobLogger );
			} else {
				if(restoreJob==null) {
					 String urlString = baseSolrURL + "/metadata"; 
				      SolrClient solrClinent = new HttpSolrClient.Builder(urlString).build();   
				      //Delete by id
				     //solrClinet.deleteByQuery("id:1");           
				      
				      //Delete by other field
				      //solrClinet.deleteByQuery("city:Washington");
				      //Deleting all documents
				      String id = "id:\"" + indexJob.getJobName() + "\"";
				      solrClinent.deleteByQuery(id);        
				         
				      //Saving the document 
				      solrClinent.commit(); 
				      logger.info("Documents deleted");
					
				} else {
					updateBackupDetails(restoreJob, indexJob, jobLogger );
				}
					
				
			}
		}
		return "Done";
	}
	
	public RestoreJob getSolrBackupJobs( SolrBackupJob indexJob,  GeodatafyJobLog jobLogger)  {
		
		RestoreJob restoreJob = null;
		try {
			CloseableHttpClient httpClient = WinHttpClients.createDefault();
			HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
					"http://" + indexJob.getJobData().getSolrHost() + ":" + indexJob.getJobData().getSolrPort() + "/solr/metadata" )).withHttpClient(httpClient).build();

			SolrQuery query = new SolrQuery();

			query.setQuery("*:*"); // main query
			query.set("wt", "json");
			
			String strQryBybackupId = "id:\"" + indexJob.getJobName() + "\"";
			logger.info(" strQryBy: " + strQryBybackupId);			
			query.addFilterQuery(strQryBybackupId, "datatype:backupDetails");
			query.setRows(2147483647);
					
			QueryResponse resp = client.query(query);
			logger.info("backupdetails  QueryResponse: " + resp.getResponse().toString());
			//System.out.println("backupdetails  QueryResponse: " + resp.getResponse().toString());
			SolrDocumentList docList = resp.getResults();
			logger.info(" backupdetails QueryResponse Num : " + docList.getNumFound());
			//System.out.println(" backupdetails QueryResponse Num : " + docList.getNumFound());
			if (docList.getNumFound() > 0 ) {	
				
				for (Map singleDoc : docList) {
					Gson gson = new Gson();		
					//System.out.println(gson.toJson(singleDoc));
					 restoreJob = gson.fromJson(gson.toJson(singleDoc), RestoreJob.class);
					//bkupJobList = gson.fromJson("[" + gson.toJson(singleDoc) + "]", new TypeToken<List<RestoreJob>>(){}.getType());
				
				}
							
			} else {
				String msg="Backup list not available  ";
				logger.warn(msg);
				
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error(e.getStackTrace().toString());
			logger.info("Exception during execution of Solar Query for getBackupList   ------>: " ,  e);
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
			//return null;
		} finally {

		}	
		
		return restoreJob;
		
	}	

	
	/*
	public String runSolrBackupJob(String payLoad ) throws Exception{		
			logger.info("In service: /jobs/backup/run and method: runSolrBackupJob");	
			String retMsg = null;
			
			logger.warn("Input payload is: " + payLoad);
			Map<String, String> elementsMap = JsonUtil.getJsonStringMap(payLoad);	
			if(elementsMap == null || elementsMap.isEmpty()){
				retMsg = "The input payload is not a expected json string";
				logger.error(retMsg);
				return retMsg;
			}
			
			logger.info("Number of elements in input json : " + elementsMap.size() + " ");		
		
					
			String jobName = elementsMap.get("jobName");
			if(jobName == null || jobName.length() < 1){
				retMsg = "Job Name is Null or Empty";
				logger.error(retMsg + " Returning without doing anything.");
				return retMsg;			
			}
			
			String jobType = elementsMap.get("jobType");
			if(jobType == null || jobType.length() < 1){
				retMsg = "Job Type is Null or Empty";
				logger.error(retMsg + " Returning without doing anything.");
				return retMsg;			
			}
			
			String jobData = elementsMap.get("jobData");
			if(jobData == null || jobData.length() < 1){
				retMsg = "Job Data is Null or Empty";
				logger.error(retMsg + " Returning without doing anything.");
				return retMsg;			
			}

			logger.info("Starting the document index job: " + jobName + " ");
			SolrBackupJob indexJob = new SolrBackupJob();
			indexJob.setJobName(jobName);
			indexJob.setJobType(jobType);
			
			String solrDocID = jobName + "_" + Long.toString(System.currentTimeMillis());
			indexJob.setSolrDocID(solrDocID);
			String logFileName = "logs\\" + solrDocID + ".log";
			
			String programDataDir = System.getenv("ProgramData"); 
			logger.info("ProgramData dir received from environment variable ProgramData is: " + programDataDir);
			
			if(programDataDir != null && !programDataDir.isEmpty()){				
					String logDir = programDataDir + "\\geodatafy\\logs\\indexers\\custom\\" + jobType + "\\";
					
					logFileName = logDir + solrDocID + ".log";
					File dir = new File(logDir);
					if(dir == null || !dir.isDirectory()){ 
						dir.mkdir();
					}
			}

			String givenLogLevel = elementsMap.get("logLevel");
			String logLevel = GeodatafyJobLog.INFO;
			if(givenLogLevel != null && givenLogLevel.length() > 0){
				logLevel = givenLogLevel;	
			}
			
			GeodatafyJobLog jobLogger = new GeodatafyJobLog(logFileName, logLevel);
			indexJob.setLogFileName(logFileName);
			
			jobLogger.debug("Input Payload", payLoad);
			jobLogger.debug("Job Data from Input", jobData);

			BackupJobData indexJobData = constructJobData(jobData);
			indexJob.setJobDataString(jobData);
			indexJob.setJobData(indexJobData);
			indexJob.setJobStatus(SolrBackupJob.JOB_RUNNING);
			indexJob.setStartTime(GeodatafyJobLog.getCurrentDateTime());		
			indexJob.setEndTime("");		
			indexJob.setBkupRunsFolder("");	

			//String protocol = request.getScheme();
			String protocol = null;
			if(protocol == null || protocol.isEmpty()){
				protocol = "http";
			}			

			String baseSolrURL = protocol + "://" + indexJobData.getSolrHost() + ":" + indexJobData.getSolrPort()+ "/solr";

			List<SolrBackupJobStatistics> statistics = getJobStatistics(indexJob.getJobName(), indexJobData, jobLogger);
			indexJob.setStatistics(statistics);
			if(statistics == null){
				indexJob.setJobStatus(SolrBackupJob.JOB_ERROR);	
				//uploadJobRunData(baseSolrURL, indexJob, jobLogger);
				
			}else if(statistics.size() == 0){
				jobLogger.warn("No Collection", "Given Collection does not have any matching Collection in Solr");
				indexJob.setJobStatus(SolrBackupJob.JOB_COMPLETED);
				indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());	
				
			}else{
				logger.info("Uploading the job run data before backup.");
				
				String collectionName = indexJobData.getSolrCollectionName();
				SolrBackupAll(indexJob, jobLogger);
				
				logger.info("Uploading the job run data after indexing.");		
				
				if(indexJob.getJobStatus().equalsIgnoreCase((SolrBackupJob.JOB_COMPLETED))) {
					String targetFolder = indexJobData.getBackupFolder();	
					targetFolder = targetFolder.concat("\\" + indexJobData.getSolrHost()).concat("\\"+ indexJob.getJobName() );
					System.out.println("Deleting Older backup in " + targetFolder);
				
					File directory = new File(targetFolder);        
					File[] files = directory.listFiles();
					
					if(files==null || files.length <= 0 ) {
						logger.info("NO  Older backup in " + targetFolder);					
					} else {
						Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
						int nobkuptobe = indexJobData.getNoOfBackupRetained();
						nobkuptobe = nobkuptobe ;
						System.out.println("Files Length   " + files.length + " nobkuptobe  " +  nobkuptobe);
						if(files.length > nobkuptobe) {
							for (int i=nobkuptobe; i < files.length; i++)
							{
								try {
									System.out.println("i : " + i + " " + files[i]);
									FileUtils.deleteDirectory(files[i]);
								} catch (Exception e) {
									e.printStackTrace();
								}
							}	
						} 
					}
					
				//	updateBackupDetails(baseSolrURL, indexJob, jobLogger );
				}
			}
			return "Done";
		} */
	public static void main(String args[]) throws Exception {
		System.out.println("******************************************");
		JSONObject json = new JSONObject();
		json.put("jobName","DataBackup");
		json.put("jobType","Backup");
		json.put("jobData","{\"BackupFolder\":\"D:\\\\test solr\",\"NoOfBackup\":4,\"SolrCollectionName\":\"metadata\",\"solrHost\":\"192.168.2.231\",\"solrPort\":\"8983\"}");
	//	BackupService serv = new BackupService();
		 String urlString = "http://localhost:8983/solr" + "/metadata"; 
	      SolrClient solrClinent = new HttpSolrClient.Builder(urlString).build();   
	      //Delete by id
	     //solrClinet.deleteByQuery("id:1");           
	      
	      //Delete by other field
	      //solrClinet.deleteByQuery("city:Washington");
	      //Deleting all documents
	      String id = "id:\"" + "All_Backup_job" + "\"";
	      solrClinent.deleteByQuery(id);        
	         
	      //Saving the document 
	      solrClinent.commit(); 
	      logger.info("Documents deleted");

	
		
	}
	
		
	private void SolrBackupAll( SolrBackupJob indexJob, GeodatafyJobLog jobLogger) throws Exception {
		boolean isDirectoryCreated = false;
     
		  
		BackupJobData indexJobData = indexJob.getJobData();
		String host = indexJobData.getSolrHost();
		String portNo = indexJobData.getSolrPort();
		jobLogger.info("Preparing for full  Solr backup ", "Collection");
		String url =  "http://" + host+ ":" + portNo + "/solr/";	
		String[] collectionList = null;
		try {
			
			
			String strCollections = indexJobData.getSolrCollectionName();			
			jobLogger.debug("Collections to restore  ", strCollections);
			collectionList = strCollections.split(",");

			String targetFolder = indexJobData.getBackupFolder();
					
		
			targetFolder = targetFolder.concat("\\"+ host).concat("\\"+ indexJob.getJobName() );
			DateFormat dateFormat = new SimpleDateFormat("ddMMyyyy_HHmmss");
			Date date = new Date();
			String currentDate = dateFormat.format(date);
			targetFolder = targetFolder.concat("\\" + currentDate);
			String baseSolrUrl = url.concat("admin/collections?action=BACKUP&name=");
			indexJob.setBkupRunsFolder(targetFolder);
			updateBackupDetails("http://" + host+ ":" + portNo + "/solr", indexJob, jobLogger );
			//String tmptargetFolder = targetFolder.replace(" ", "\\ ");				
			//logger.info("targetFolder " + tmptargetFolder );
			File file = new File(targetFolder);
			if (!file.exists() && !file.isDirectory()) {
				isDirectoryCreated = file.mkdirs();
			}
			if (isDirectoryCreated) {
				//File targetfile = new File(tmptargetFolder);
				URI uri = file.toURI();	
				for (int i = 0; i < collectionList.length; i++) {				
					String collection = collectionList[i].trim();				
					
						logger.info("isDirectoryCreated   " + isDirectoryCreated );
						StringBuilder sb1 = new StringBuilder();
						int backupId = getRandom(1000);
						String posturl = sb1.append(baseSolrUrl).append(collection)
							.append("&collection=").append(collection)
							.append("&location=").append(replaceSpzCharacter(file.getCanonicalPath()))
							.append("&async=").append(backupId)
							.toString();
						jobLogger.info("Requesting Solr backup for Collection via   ", posturl);
						logger.info("Requesting Solr backup for Collection via   " + posturl);
						postSolr(backupId, targetFolder.replace("\\", "/"), posturl, collection, indexJob, jobLogger);
				}			

			} else {
				System.out.println(" Failed to create directory for backup in " + targetFolder);
				logger.info(" Failed to create directory for backup in " + targetFolder);
				jobLogger.debug("Failed to create directory for backup in   ", targetFolder);
				indexJob.setJobStatus(SolrBackupJob.JOB_ERROR);
				indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());				
				indexJob.getStatistics().get(0).setFailed(collectionList.length);
			}
		} catch (Exception e) {
			logger.error("Exception occurred in solr backup ", e);
			logger.info("Exception in solr backup   " + e.getMessage() );
						e.printStackTrace();
			if (e.getMessage().contains("Connection refused")) {
				System.out.println("Given Port Number is Wrong...");
			}
			indexJob.setJobStatus(SolrBackupJob.JOB_ERROR);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
			if(collectionList!=null ) {
				indexJob.getStatistics().get(0).setFailed(collectionList.length);
			}
			
		}	
		

	}

	private void postSolr(int asyncId, String targetFolder, String url, String collectionName, SolrBackupJob indexJob,  GeodatafyJobLog jobLogger) throws Exception {
		HttpClient httpClient = HttpClientBuilder.create()
					  .build();	
		HttpGet httpGet = new HttpGet(url);
		HttpResponse response = httpClient.execute(httpGet);
			
		try {
			if (response.getStatusLine().getStatusCode() != 200) {
				logger.info("  Failed : HTTP error code : " + response.getStatusLine().getStatusCode() + "::"
						+ response.getStatusLine().getReasonPhrase());
				jobLogger.info("Solr backup Failed : HTTP error code :   ", ":" + response.getStatusLine().getStatusCode());
				jobLogger.info("Solr backup Failed : HTTP Reason :   ", ":" + response.getStatusLine().getReasonPhrase()  );
				indexJob.setJobStatus(SolrBackupJob.JOB_ERROR);
				indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
				indexJob.getStatistics().get(0).setFailed(indexJob.getStatistics().get(0).getFailed() +1);
			} else {
				int status = checkBackUpStatus(asyncId, indexJob, jobLogger);
				for(; ;) {
					Thread.sleep(BKUPPOLLTIME); //sleep for 30 second
					status = checkBackUpStatus(asyncId, indexJob, jobLogger);
					if(status==1 || status==3) {
						break;						
					} else {
						continue;
					}
				}
				if(status==1) {
					logger.info("Successfully backed up for :" + collectionName + " at: " + targetFolder);
					jobLogger.info("Successfully backed up for :  ", collectionName);
					jobLogger.info("Successfully backed up at :  ", targetFolder);
				
					indexJob.setJobStatus(SolrBackupJob.JOB_COMPLETED);
					indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
					indexJob.getStatistics().get(0).setSuccessful(indexJob.getStatistics().get(0).getSuccessful() +1);
				} else {
					jobLogger.info("Solr backup failed : HTTP error code :   ", ":" + response.getStatusLine().getStatusCode());
					jobLogger.info("Solr backup failed : HTTP Reason :   ", ":" + response.getStatusLine().getReasonPhrase()  );
					indexJob.setJobStatus(SolrBackupJob.JOB_ERROR);
					indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
					indexJob.getStatistics().get(0).setFailed(indexJob.getStatistics().get(0).getFailed() +1);
				}
				
			}

		} catch (Exception e) {
			jobLogger.info("Exception in SolrBackupAll and the error message  :  ", e.getMessage());
			logger.info("Exception in SolrBackupAll and the error message  :  ",  e);
			e.printStackTrace();			
			if (e.getMessage().contains("Connection refused")) {
				jobLogger.info("\"Given Port Number is Wrong... or Solr is not running..   ", e.getMessage());
				logger.info("\"Given Port Number is Wrong... or Solr is not running..   " + e.getMessage());
			}
			indexJob.setJobStatus(SolrBackupJob.JOB_ERROR);
			indexJob.setEndTime(GeodatafyJobLog.getCurrentDateTime());
			indexJob.getStatistics().get(0).setFailed(indexJob.getStatistics().get(0).getFailed() +1);
			
		} finally {
			//response.close();
			//httpClient.close();
		}

	}
	private int checkBackUpStatus(int asyncId, SolrBackupJob indexJob, GeodatafyJobLog jobLogger) throws Exception {
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		String statusUrl = "http://" + indexJob.getJobData().getSolrHost() + ":" +   indexJob.getJobData().getSolrPort()
				+ "/solr/admin/collections?action=REQUESTSTATUS&requestid=" + asyncId ;
		HttpGet httpGet = new HttpGet(statusUrl);
		HttpResponse response = httpClient.execute(httpGet);
		if (response.getStatusLine().getStatusCode() != 200) {
			jobLogger.info("checkBackUpStatus : HTTP error code :   ", ":" + response.getStatusLine().getStatusCode());
			jobLogger.info("checkBackUpStatus : HTTP Reason :   ", ":" + response.getStatusLine().getReasonPhrase()  );
			throw new Exception("Exception occured in getting the backup staus request API");
		} else {
		 StringBuffer strBuffer = new StringBuffer();
		 BufferedReader rd = new BufferedReader(new InputStreamReader(
                    response.getEntity().getContent()));
            String line = "";
            while ((line = rd.readLine()) != null) {
            	strBuffer.append(line);
            }
            logger.info(strBuffer.toString());
            JSONObject json = new JSONObject(strBuffer.toString());
            Iterator it = json.keys();
            while(it.hasNext()) {
            	 String key = (String)it.next();
            	 if ( json.get(key) instanceof JSONObject ) {
            		 JSONObject jsonKeyObj = new JSONObject(json.get(key).toString());
            		 if(jsonKeyObj.has("STATUS")) {
            			 String bkupState = (String) jsonKeyObj.get("STATUS");
            			 if(bkupState.equalsIgnoreCase("failed")) {
            				 jobLogger.info("BAckup status Failed " , "");
            				 String responseFromsolr = (String) jsonKeyObj.get("Response");
            				 jobLogger.info("Reason For backup failure " , responseFromsolr);
            				 return 3;
            			 }
 
            		 }
            			 
            	 }
            }
          
            if (json.has("status")) {
            	JSONObject jsonObj = json.getJSONObject("status");
            	String bkupState = (String) jsonObj.get("state");
            	
            	if(bkupState.equalsIgnoreCase("completed")) {
            		return 1;	            		
            	} else if(bkupState.equalsIgnoreCase("running")) {
            		return 2;            		
            	} else if(bkupState.equalsIgnoreCase("submitted")) {
            		return 2;
            	} else {
            		return 3;
            	}
            	
            } else {
            	jobLogger.info("checkBackUpStatus : json has no status in response. Requesting once again to check status", "");
            	//return 2;
            	
            	throw new Exception("checkBackUpStatus in getting the backup staus request API");
            }	
		}
		
		
	}
	
	
	
	 
	public static String replaceSpzCharacter(String filepath) {
		
		String strFileName = filepath.replace("\\", "%5C");
		strFileName = strFileName.replace(" ", "%20");
		strFileName = strFileName.replace(":", "%3A");
		strFileName = strFileName.replace("&", "%26");
		
		strFileName = strFileName.replace("!", "%21");
		strFileName = strFileName.replace("(", "%28");
		strFileName = strFileName.replace(")", "%29");
		
		strFileName = strFileName.replace("{", "%7B");
		strFileName = strFileName.replace("|", "%7C");
		strFileName = strFileName.replace("}", "%7D");
		
		strFileName = strFileName.replace("[", "%5B");
		strFileName = strFileName.replace("]", "%5D");
		
		strFileName = strFileName.replace("+", "%2B");
		strFileName = strFileName.replace("-", "%2D");
		strFileName = strFileName.replace("^", "%27");
		strFileName = strFileName.replace("~", "%7E");
		strFileName = strFileName.replace("#", "%23");
		return strFileName;
		
	}

	
	  private boolean updateBackupDetails(String baseSolrURL,  SolrBackupJob indexJob,  GeodatafyJobLog jobLogger) {
		  
			boolean result = false;
			try {
				 
				BackupJobData indexJobData = indexJob.getJobData();
				String solrUrl = baseSolrURL + "/metadata" ;	
				logger.info("solrUrl  :  " + solrUrl);
				
				CloseableHttpClient httpClient = WinHttpClients.createDefault();
				HttpPost post = new HttpPost(solrUrl + "/update/json?wt=json&commit=true&overwrite=true");				
				
				HttpSolrClient client1 = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
						"http://" + indexJobData.getSolrHost() + ":" + indexJobData.getSolrPort() + "/solr/jobs")).withHttpClient(httpClient).build();
				
				SolrQuery query = new SolrQuery();
				query.set("q","*:*");
				query.addFilterQuery("datatype:jobRuns");
				query.addFilterQuery("jobType:Backup");				
				query.addFilterQuery("jobStatus:COMPLETED");
				query.addFilterQuery("jobName:\"" + indexJob.getJobName() + "\"");
				
				query.setSort("_version_", SolrQuery.ORDER.desc);
				query.set("wt","json");
				query.set("rows",indexJobData.getNoOfBackupRetained()-1);
				//logger.warn("http://" + indexJobData.getSolrHost() + ":" + indexJobData.getSolrPort() + "/solr/jobs" + query.toQueryString());
				
				QueryResponse resp = client1.query(query);
				//logger.warn("  QueryResponse: " + resp.getResponse().toString());
				//System.out.println("  QueryResponse: " + resp.getResponse().toString());
				int status = resp.getStatus();
				//logger.warn(resp.getResults().toString());
				JSONArray backupRetainedDetails = new JSONArray();
				backupRetainedDetails.put(indexJob.getBkupRunsFolder().replace("\\", "\\\\"));
				if ( status==0 ) {
					SolrDocumentList docs = resp.getResults();
					//logger.warn(resp.getResults().toString());
					for(SolrDocument doc : docs) {						
						String bkupRunPath = (String) doc.getFieldValue("runsBkupFolder");
						//logger.warn(bkupRunPath);						
						backupRetainedDetails.put(bkupRunPath);
					}							
				}
				else {
					logger.error(" getLatestJobRuns Status: " + status);
					String errMsg = "getLatestJobRuns Solr Query " + query.getQuery() + "  Failed";
					logger.error(errMsg);
					throw new Exception("fail");
				}
				
				JSONObject backupDoc = new JSONObject();
				
				String id = indexJob.getJobName();
				backupDoc.put("id", id);
				backupDoc.put("Name",  indexJob.getJobName());				
				backupDoc.put("datatype", "backupDetails");
				String targetFolder = indexJobData.getBackupFolder();
				backupDoc.put("backupRootFolder", targetFolder);
				backupDoc.put("collection", indexJobData.getSolrCollectionName());	
				backupDoc.put("backupRetainedDetails", backupRetainedDetails);				
				//logger.warn(backupRetainedDetails.toString());
				System.out.println(backupRetainedDetails.toString());

				LocalDateTime localDateTime = LocalDateTime.ofInstant(new Date().toInstant(), ZoneId.systemDefault());
				ZonedDateTime utc = ZonedDateTime.of(localDateTime, ZoneOffset.UTC);				
				String Last_Modified_DateTime = utc.toString();					
				backupDoc.put("Last_Modified_DateTime", Last_Modified_DateTime);						
				logger.info(backupDoc.toString());	
				System.out.println(backupDoc.toString());	
				jobLogger.info(backupDoc.toString(), "");
					StringEntity entity  = new StringEntity("["+backupDoc.toString()+"]", "UTF-8");
					//StringEntity entity  = new StringEntity(backupDoc.toString(), "UTF-8");
					entity.setContentType("application/json");
					post.setEntity(entity);			    	
			    	CloseableHttpResponse response = httpClient.execute(post);
			    	
			    	logger.info("Added the Project Document to solr and the response is: " + response.toString());
			    	jobLogger.info("Added the Project Document to solr and the response is: " , response.toString());
			    	
					StringBuffer strBuffer = new StringBuffer();
					 BufferedReader rd = new BufferedReader(new InputStreamReader(
			                    response.getEntity().getContent()));
			            String line = "";
			            while ((line = rd.readLine()) != null) {
			            	strBuffer.append(line);
			            }
			            logger.info(strBuffer.toString());
			            System.out.println(strBuffer.toString());
			            JSONObject json = new JSONObject(strBuffer.toString());
			            
			            if (json.has("responseHeader")) {
			            	JSONObject jsonObj = json.getJSONObject("responseHeader");
			            	
			            	if((int)jsonObj.get("status") ==0 ) {
			            		logger.info("Successfully updated the backup details doc :      " + jsonObj.get("status"));
			            		jobLogger.info("Successfully updated the backup details doc :      " , "");
			            		return true;
			            	}  else {
				            	throw new Exception("Exception in post request for updating  backup details ");
				            }		
			            
			            	
			            } else {
			            	throw new Exception("Exception in post request for updating  backup details ");
			            }	

			} catch (Exception e ) {	
				logger.error("  Status: FAILED");
				logger.error(e.getMessage(), e);	
				jobLogger.error("  Status: FAILED", "");
				jobLogger.error(e.getMessage(), "");	
				e.printStackTrace();
				result =  false;
			}	
			finally {
				
			}
			
			return result;
		  
	  }
	  
	  
	  private boolean updateBackupDetails(RestoreJob restoreJob,  SolrBackupJob indexJob, GeodatafyJobLog jobLogger) {
		  
			boolean result = false;
			try {
				BackupJobData indexJobData = indexJob.getJobData();
				
				String solrUrl = "http://" + indexJobData.getSolrHost() + ":" + indexJobData.getSolrPort() + "/solr/metadata";
				logger.info("solrUrl  :  " + solrUrl);
				
				CloseableHttpClient httpClient = WinHttpClients.createDefault();
				HttpPost post = new HttpPost(solrUrl + "/update/json?wt=json&commitWithin=1&overwrite=true");				
				
				HttpSolrClient client1 = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
						"http://" + indexJobData.getSolrHost() + ":" + indexJobData.getSolrPort() + "/solr/jobs")).withHttpClient(httpClient).build();
				Gson gsonBuilder = new GsonBuilder().create();
				String restoreObjStr = gsonBuilder.toJson(restoreJob);
			
				
					StringEntity entity  = new StringEntity("["+restoreObjStr+"]", "UTF-8");
					//StringEntity entity  = new StringEntity(backupDoc.toString(), "UTF-8");
					entity.setContentType("application/json");
					post.setEntity(entity);			    	
			    	CloseableHttpResponse response = httpClient.execute(post);
			    	logger.info("Added the BackupDetails document to solr and the response is: " + response.toString());
			    	jobLogger.info("Added the BackupDetails document to solr and the response is: " , response.toString());
			    	
					StringBuffer strBuffer = new StringBuffer();
					 BufferedReader rd = new BufferedReader(new InputStreamReader(
			                    response.getEntity().getContent()));
			            String line = "";
			            while ((line = rd.readLine()) != null) {
			            	strBuffer.append(line);
			            }
			            logger.info(strBuffer.toString());
			            System.out.println(strBuffer.toString());
			            JSONObject json = new JSONObject(strBuffer.toString());
			            
			            if (json.has("responseHeader")) {
			            	JSONObject jsonObj = json.getJSONObject("responseHeader");
			            	
			            	if((int)jsonObj.get("status") ==0 ) {
			            		logger.info("Successfully updated the backup details doc :      " + jsonObj.get("status"));
			            		jobLogger.info("Successfully updated the backup details  doc : " , "");
			            		return true;
			            	}  else {
				            	throw new Exception("Exception in post request for updating backup details ");
				            }		
			            
			            	
			            } else {
			            	throw new Exception("Exception in post request for updating backup details ");
			            }	

			} catch (Exception e ) {	
				logger.error("  Status: FAILED");
				logger.error(e.getMessage(), e);	
				jobLogger.error("  Status: FAILED", "");
				jobLogger.error(e.getMessage(), "");	
				e.printStackTrace();
				result =  false;
			}	
			finally {
				
			}
			
			return result;
		  
	  }
	
	
	private List<SolrBackupJobStatistics> getJobStatistics(String jobName, BackupJobData indexJobData, GeodatafyJobLog jobLogger) throws IOException {
		List<SolrBackupJobStatistics> statistics = new ArrayList<SolrBackupJobStatistics>();
		String root = indexJobData.getBackupFolder();
		logger.info("BAckup Folder folder: " + root);
		jobLogger.info("Backup Foler is ", root);
		if (!Files.isDirectory(Paths.get(root))) {
			String msg = "The root folder specified " + root + " is null or not a directory.";
			logger.error(msg);
			jobLogger.error("Backup Fole error." , msg);
			return null;
		}
		String collectionName = indexJobData.getSolrCollectionName();
		List<String> extensionFiles = new ArrayList<String>();
		String[] collectionList = collectionName.split(",");

			for (int i = 0; i < collectionList.length; i++) {
				
				String collection = collectionList[i].trim();
				extensionFiles.add(collection);
			}
			
		
		SolrBackupJobStatistics statistic = new SolrBackupJobStatistics(jobName);	
		statistic.setFileNames(extensionFiles);
		logger.info("getTotal for statistics " + statistic.getTotal());
		statistics.add(statistic);			
		//StringBuilder fileLog = new StringBuilder();
		jobLogger.info("Backup to be taken for", " Collection " + collectionName);
		return statistics;
	}


	

	
	

	
	private void uploadJobRunData(String baseSolrURL, SolrBackupJob indexJob, GeodatafyJobLog jobLogger) {
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		HttpPost post = new HttpPost(baseSolrURL + "/" + JOBS_COLLECTION + "/update/json?wt=json&commitWithin=1&overwrite=true");
		
		try {
			String content = getDocContents(indexJob, jobLogger);
			content = "{\"add\": { \"doc\": " + content + "}}";
			StringEntity entity  = new StringEntity(content, "UTF-8");
			entity.setContentType("application/json");
			post.setEntity(entity);

			jobLogger.info("Adding the backup job run data to solr", content);
	    	logger.info("Adding the backup job run data to solr " + content);
	    	CloseableHttpResponse response = httpClient.execute(post);
			jobLogger.info("Added the backup job run data to solr and the response : ", response.toString());
			logger.info("Added the backup job run data to solr and the response is: " + response.toString());
	    	
		} catch (ClientProtocolException e) {	
			logger.error("ClientProtocolException eccured in uploadJobRunData ", e);
			logger.error(e.getMessage());
			logger.error(e.getStackTrace().toString());
			jobLogger.error("ClientProtocolException", e.getMessage());
		} catch (IOException e) {
			logger.error("IOException eccured in uploadJobRunData ", e);
			logger.error(e.getMessage());
			logger.error(e.getStackTrace().toString());
			jobLogger.error("IOException", e.getMessage());
		}	finally {
			try {
			httpClient.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
			
		}
	}
	
	private String getDocContents(SolrBackupJob indexJob,  GeodatafyJobLog jobLogger){
	    StringBuilder sb = new StringBuilder();
	    sb.append("{");
	    sb.append("\"id\":\"" + indexJob.getSolrDocID() + "\", ");
	    sb.append("\"datatype\":\"" + SolrBackupJob.SOL_DATA_TYPE + "\", ");
	    sb.append("\"jobRunID\":\"" + indexJob.getSolrDocID() + "\", ");
	    sb.append("\"jobName\":\"" + indexJob.getJobName() + "\", ");	    
	    sb.append("\"jobType\":\"" + indexJob.getJobType() + "\", ");
	    sb.append("\"jobStatus\":\"" + indexJob.getJobStatus() + "\", ");
	    sb.append("\"startTime\":\"" + indexJob.getStartTime() + "\", ");
	    sb.append("\"endTime\":\"" + indexJob.getEndTime() + "\", ");
	    sb.append("\"logFileName\":\"" + indexJob.getLogFileName().replace("\\", "\\\\\\\\") + "\", ");
	    sb.append("\"runsBkupFolder\":\"" + indexJob.getBkupRunsFolder().replace("\\", "\\\\\\\\") + "\", ");
	    
	   
	    String jobData = indexJob.getJobDataString();
	    jobData = jobData.replace("\\", "\\\\");
	    jobData = jobData.replace("\"", "\\\"");
	    sb.append("\"jobData\":\"" + jobData + "\"");    
	    
	
	    if(indexJob.getStatistics() != null && indexJob.getStatistics().size() > 0){
	    	StringBuilder stat = new StringBuilder();
	    	stat.append("[");
	    	for(int i = 0; i < indexJob.getStatistics().size(); i++){
	    		SolrBackupJobStatistics jobStatistics = indexJob.getStatistics().get(i);
	    		stat.append("\"{");
	    		stat.append("\\\"type\\\":\\\"" + jobStatistics.getExtension());
	    		stat.append("\\\", \\\"total\\\":" + jobStatistics.getTotal());
	    		stat.append(", \\\"successful\\\":" + jobStatistics.getSuccessful());
	    		stat.append(", \\\"skipped\\\":" + jobStatistics.getSkipped());
	    		stat.append(", \\\"failed\\\":" + jobStatistics.getFailed());
	    		if(i == (indexJob.getStatistics().size() - 1)){
	    			stat.append("}\"");
	    		}else{
	    			stat.append("}\",");
	    		}	    		
	    	}
	    	stat.append("]");
	    	logger.info("The job Statistics is: " + stat.toString());
	    	sb.append(",\"jobStatistics\":" + stat.toString());
	    }
    	sb.append("}");
    	
		return sb.toString();
	}
	
	private int getBkupPollTime(String solarHost, String solarPort) throws Exception {		
		int bkuppolltime = BKUPPOLLTIME;
		
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
				"http://" + solarHost + ":" + solarPort + "/solr/metadata" )).withHttpClient(httpClient).build();
		ArrayList<String> solrURLList = new ArrayList<String>();
		try {
			
			SolrQuery query = new SolrQuery();

			query.setQuery("*:*"); // main query
			query.set("wt", "json");
			query.setRows(2147483647);
			query.set("fl",  "backupPoltime" );
			
			query.addFilterQuery("datatype:AppConfig");
			//query.addFilterQuery("qcRuleSet:\"" + proj.getQcRuleSet() + "\"" );		
			//query.set("group", true);
			//query.set("group.field", "solrCoreUrl");
			//query.set("group.main", true);
			logger.info("Query: " + query.toQueryString());
			QueryResponse resp = client.query(query);
			logger.info("Job Def QueryResponse: " + resp.getResponse().toString());
			
			SolrDocumentList docList = resp.getResults();
			logger.info(" QueryResponse Num : " + docList.getNumFound());
			if (docList.getNumFound() > 0 ) {			
				for (Map singleDoc : docList) {					
					JSONObject json = new JSONObject(singleDoc);
					logger.info(json.toString());
					System.out.println(json.toString());
					if(json.has("backupPoltime")) {
						bkuppolltime = ((Long)json.get("backupPoltime")).intValue();		
						BKUPPOLLTIME = bkuppolltime;
					}
			
				}				
			} 
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error("Exception during execution of Solar Query for getQCJobBatchSize   ------>: " ,  e);
			e.printStackTrace();
			//throw new Exception(e.getMessage());
			
		} finally {
			client.close();
			httpClient.close();
		}	
				
		return bkuppolltime;

	}
	

}
