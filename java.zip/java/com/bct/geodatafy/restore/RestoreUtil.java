package com.bct.geodatafy.restore;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.TimeZone;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.WinHttpClients;
import org.apache.log4j.Logger;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.SolrInputDocument;
import org.codehaus.jettison.json.JSONObject;

import com.bct.geodatafy.backup.BackupUtil;
import com.bct.geodatafy.job.GeodatafyJobLog;
import com.bct.geodatafy.job.backup.BackupActiveJob;
import com.bct.geodatafy.job.backup.RestoreJob;
import com.bct.geodatafy.job.backup.SolrBackupJob;
import com.bct.geodatafy.job.backup.SolrRestoreJob;
import com.bct.geodatafy.rest.service.WindowsService;
import com.bct.geodatafy.rest.service.exception.GeodatafyRestoreException;
import com.bct.geodatafy.util.EnvUtil;
import com.bct.geodatafy.util.GeoUtil;
import com.bct.geodatafy.util.JsonUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

public class RestoreUtil {
	static Logger logger = Logger.getLogger(RestoreUtil.class);
	public static final String JOB_TYPE = "SolrRestoreService";
	public static final int COMMIT_SIZE = 10;
	public static final String JOBS_COLLECTION = "jobs";
	public HashMap<String, String> collectionConfigMap = new HashMap<String, String>();
	public RestoreUtil() {
		
		
	}
	
	 public static int getRandom(int max){
	        return (int) (Math.random()*max);
	    }
	

	public String getBackJobList(String solrHost, String solrPort) throws Exception{		
		String str = getSolrBackupJobs(solrHost, solrPort);
		return str;		
	}
	
	
	public String startSolrRestoreJobService(String protocol, String solrHost, String solrPort) {		
				
		String returnMsg = null;					
		try {
			boolean response = UpdateRestoreStatus("true" ,protocol, solrHost, solrPort);
			logger.info("The response to Update Restore status to true(progess) is: " + response);		
	    	if(response){
	    		returnMsg ="success";	    		    		
	    	} else {
	    		returnMsg ="failure";
	    		throw new GeodatafyRestoreException(returnMsg);
	    	}			
		} catch (Exception e) {			
			returnMsg ="failure";	
			logger.error("Exception in start restore process", e);
			throw new GeodatafyRestoreException(returnMsg);			
		}		
		return returnMsg;
	}
	
	
	
	
	

	public String runSolrRestoreJobService(SolrRestoreJob restoreTask , GeodatafyJobLog jobLogger, String protocol
			
			) {		
				
		String returnMsg = null;
	
			
				
		try {
			//boolean response = UpdateRestoreStatus("true" ,protocol, restoreTask.getSolrHost(), restoreTask.getSolrPort());
			logger.info("The response to update restore status to true(progress) is: true"  );
		
	    	//if(response){
	    		jobLogger.info("The Restore Process started : " , " InProgress");
	    		returnMsg = SolrRestoreAll(restoreTask, jobLogger);
				boolean response = UpdateRestoreStatus("false" ,protocol, restoreTask.getSolrHost(), restoreTask.getSolrPort());
	    		jobLogger.info("Restore process is completed: " , " " + response);
	    		try {
	    			jobLogger.info("Restore process is completed: " , " Restarting the service " );
					WindowsService wServ = new WindowsService();
					wServ.restartService();
					jobLogger.info("Restart of GD service completed" ," " );
				} catch(Exception e1) {
					jobLogger.info("Exception occurred  during restart of Geodatafy service after successful restore" , e1.getMessage());
					throw new GeodatafyRestoreException("Exception occurred during restart of Geodatafy service after successful restore");
				}
	    		
	    	/*} else {
	    		jobLogger.info("Not Able to update sole restore status as running. " , " Restore Process not started");
	    		throw new GeodatafyRestoreException("Not Able to update sole restore status as running. Restore Process not started");
	    	}*/
	    	
		
			
		} catch (Exception e) {			
			String errMsg = "Exception occurred during Restore";
			logger.error(errMsg, e);
			logger.error("The Error is " + e.getMessage());
			jobLogger.info(errMsg, e.getMessage());
			e.printStackTrace();
		
			UpdateRestoreStatus("false" ,protocol, restoreTask.getSolrHost(), restoreTask.getSolrPort());
			
			jobLogger.info("The Restore Process  is completed with error: " , " " );
			try {
				jobLogger.info("Restarting  the GD Service " , "  " );
				WindowsService wServ = new WindowsService();
				wServ.restartService();
				jobLogger.info("Restart of GD service completed" ," " );
			} catch(Exception e1) {
				jobLogger.info("Exception occurred during restart of Geodatafy service during restore error" , e1.getMessage());
			}
			
			//returnMsg =  errMsg;
			throw new GeodatafyRestoreException(e.getLocalizedMessage());
			
		}
		
		return returnMsg;
	}
	
	


	public String runSolrRestoreJob(String solrHost,  String solrPort,  String collectionName,  String backupPath, String backupName)
			 throws Exception{		
						
		SolrRestoreJob restoreTask = new SolrRestoreJob();
		restoreTask.setBkupRunsFolder(backupPath);
		restoreTask.setSolrCollectionName(collectionName);
		restoreTask.setSolrHost(solrHost);;
		restoreTask.setSolrPort(solrPort);
		restoreTask.setSolrPort(solrPort);
		restoreTask.setBackupName(backupName);
		String returnMsg = null;
		String solrDocID = "Restore" + "_" + Long.toString(System.currentTimeMillis());
		//indexJob.setSolrDocID(solrDocID);
		String logFileName = "logs\\" + solrDocID + ".log";
		
		//String programDataDir = System.getenv("GD_LOG_PATH"); 
		String programDataDir = EnvUtil.getGDLogPath();
		logger.info("ProgramData dir received from environment variable ProgramData is: " + programDataDir);
		
		if(programDataDir != null && !programDataDir.isEmpty()){				
				String logDir = programDataDir + "\\logs\\restore\\";
				logFileName = logDir + solrDocID + ".log";
				File dir = new File(logDir);
				if(dir == null || !dir.isDirectory()){ 
					dir.mkdir();
				}
		}		
		String logLevel = GeodatafyJobLog.INFO;			
		GeodatafyJobLog jobLogger = new GeodatafyJobLog(logFileName, logLevel);		
		
		try {			
			jobLogger.info("The Restore Process started : " , " InProgress");	    		
			returnMsg = SolrRestoreAll(restoreTask, jobLogger);	
			System.out.println(" Please check the log for details at " + logFileName);
			jobLogger.info("The Restore Process  is completed: " , " " );			
		} catch (Exception e) {			
			String errMsg = "Exeception occured during Restore  ";
			logger.error(errMsg, e);
			logger.error("The Error is " + e.getMessage());
			jobLogger.info(errMsg, e.getMessage());
			e.printStackTrace();			
			returnMsg =  errMsg;			
		}		
		return returnMsg;
	}	
	
	private boolean UpdateRestoreStatus(String status, String protocol, String host, String port)  {
		
	
		CloseableHttpClient httpClient = WinHttpClients.createDefault();

		String solrUrl = protocol + "://" + host + ":" + port + "/solr/metadata";
		HttpPost post = new HttpPost(solrUrl + "/update/json?wt=json&commitWithin=1&overwrite=true");
		String rid = "Restore";
		String rDataType = "geodatafyRestore";
		 StringBuilder sb = new StringBuilder();
		    sb.append("{");
		    sb.append("\"id\":\"" + rid + "\", ");
		    sb.append("\"datatype\":\"" + rDataType + "\", ");
		    sb.append("\"status\":\"" + status + "\", ");
		    sb.append("}");
		
		try {
			String content = sb.toString();
			content = "{\"add\": { \"doc\": " + content + "}}";
			StringEntity entity  = new StringEntity(content, "UTF-8");
			entity.setContentType("application/json");
			post.setEntity(entity);	
		
	    	CloseableHttpResponse response = httpClient.execute(post);	
	    	return true;
	    	
		} catch (ClientProtocolException e) {			
			logger.error(e.getMessage());
			logger.error("ClientProtocolException in UpdateRestoreStatus", e);
			logger.error(e.getStackTrace().toString());
			return false;
			
		} catch (IOException e) {
			logger.error(e.getMessage());
			logger.error("IOException in UpdateRestoreStatus", e);
			logger.error(e.getStackTrace().toString());
			return false;
			
		}	catch (Exception e) {
			logger.error("Exception in UpdateRestoreStatus", e);
			logger.error(e.getMessage());
			logger.error(e.getStackTrace().toString());
			return false;
			
		}	  
		
	}
	
	
	
	private String getRestoreDirPath(boolean AllCollection, String collectionName) {
		DateFormat dateFormat = new SimpleDateFormat("ddMMyyyy_HHmmss");
		Date date = new Date();
		String currentDate = dateFormat.format(date);	
		//String programDataDir = System.getenv("GD_DATA_PATH");
		String programDataDir = EnvUtil.getGDDataPath();
		String targetFolder = "";
		if (AllCollection) {
			 targetFolder = programDataDir + "\\restore\\" + currentDate + "\\";
		} else {
			 targetFolder = programDataDir + "\\restore\\" + currentDate + "\\" + collectionName
						+ "\\";
		}	
		return targetFolder;
		
	}
	

	private String SolrBackup( String solrHost, String solrPort, String collectionName, String targetFolder, GeodatafyJobLog jobLogger) throws Exception {
		boolean isDirectoryCreated = true;
		try {

			StringBuilder sb1 = new StringBuilder();	
			//jobLogger.info("Preparing for Current backup for Collection before restore ", collectionName);			
			//String targetFolder = getRestoreDirPath(false, collectionName);			
			File file = new File(targetFolder);
			if (!file.exists() && !file.isDirectory()) {
				 isDirectoryCreated = file.mkdirs();
			}			
			String url = "http://" + solrHost + ":" + solrPort
					+ "/solr/admin/collections?action=BACKUP&name=";
			//jobLogger.info("Going to request Current backup for Collection  before restore  ", collectionName);
			
			if (isDirectoryCreated) {
				File targetfile = new File(targetFolder);
				URI uri = targetfile.toURI();
				int bkststatusid = getRandom(1000);
				String posturl = sb1.append(url).append(collectionName)
						.append("&collection=").append(collectionName)
						.append("&location=").append(BackupUtil.replaceSpzCharacter(targetfile.getCanonicalPath()))
						.append("&async=").append(bkststatusid)
						.toString();
				jobLogger.info("Requesting current backup for Collection " + collectionName + " before starting restore via   ", posturl);
				boolean isSuccess = postSolr( solrHost,  solrPort, bkststatusid, targetFolder.replace("\\", "/"), posturl, collectionName, jobLogger);
				if(isSuccess) {
					jobLogger.info("Success in taking current backup for Collection  " + collectionName + " before starting restore  ", collectionName );
					return targetFolder;					
				} else {
					jobLogger.info("Failed in taking current backup for Collection before starting restore ", collectionName );
					return "error";
				}
				
			} else {
				jobLogger.info("Failed to create the Target Path in and hence failed to take current backup ", targetFolder);
				System.out.println(" Failed to create the Target Path in " + targetFolder);
				return "error";
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception occurred  ", e);
			jobLogger.error("Exception occurred  ", e.getMessage());
			if (e.getMessage().contains("Connection refused")) {
				jobLogger.error("Connection refused ", "Given Port Number is Wrong...");
				System.out.println("Given Port Number is Wrong...");
			}
			return "error";
		}
	}
	private boolean CheckFolderExist(String[] collectionArr, String targetFolder ) {
		boolean isResDirExist = false;
		
			for (int i = 0; i < collectionArr.length; i++) {
				String collection =   collectionArr[i].trim();							
				logger.info(" SolrRestoreAll targetFolder " + targetFolder );				
				File file = new File(targetFolder);
				if (file.exists() && file.isDirectory()) {
					File resFile = new File(targetFolder.concat("\\" + collection +"\\"));
					File res2File = new File(targetFolder.concat("\\" + collection +"\\backup.properties"));
					//File res1File = new File(targetFolder.concat("\\" + collection +"\\" + "zk_backup" + "\\"));
					File res1File = new File(targetFolder.concat("\\" + collection +"\\" + "zk_backup\\configs\\"));
					if (resFile.exists() && resFile.isDirectory() && resFile.list().length > 0) {
					    if(res2File.exists()) {
					    	if (res1File.exists() && res1File.isDirectory() && res1File.list().length > 0) {
					    		isResDirExist = true;
					    	} else {
					    		isResDirExist = false;
								break;
					    	}
						} else {
							isResDirExist = false;
							break;
						}
					} else {
						isResDirExist = false;
						break;
					}					
				}
			
			}	
		 return isResDirExist;
		
	}
	private String  SolrRestoreAll( SolrRestoreJob restoreTask , GeodatafyJobLog jobLogger) throws Exception {
		logger.info("*************** SolrRestoreAll **********************   " );
		
		String returnMsg = null;
		boolean isResDirExist = false;
				
		String host = restoreTask.getSolrHost();
		String portNo = restoreTask.getSolrPort();
		
		
		String url = "http://" + host + ":" + portNo + "/solr/";	
		
		try {			

			//sonArray collectionArr = getSolrCollectionList(host,portNo );
			collectionConfigMap = getSolrCollectionConfig(restoreTask.getSolrHost(), restoreTask.getSolrPort());
			String[] collectionArr = restoreTask.getSolrCollectionName().split(",");
			String targetFolder = restoreTask.getBkupRunsFolder();				
			String baseSolrUrl = url.concat("admin/collections?action=RESTORE&name=");
			isResDirExist = CheckFolderExist(collectionArr, targetFolder);
			
			String bkTargetFolder = getRestoreDirPath(true, "All");	
			if (isResDirExist) {
				boolean isRestoreAllSuccess = false;
				ArrayList<String> collecList = getSolrCollectionList(host, portNo);
				for (int i = 0; i < collectionArr.length; i++) {
					String collection = collectionArr[i].trim();	
					//String backupTargetFolder =  bkTargetFolder + collection + "\\";
					//jobLogger.info("Going to request Current backup for Collection  before restore  ", collection);
					String currentCollectionBkupPath = "error";					
					if(collecList.contains(collection)) {
						currentCollectionBkupPath = SolrBackup(host, portNo, collection, bkTargetFolder, jobLogger);
						jobLogger.info("Path of Current backup for Collection " + collection + " before starting restore  ", currentCollectionBkupPath);
						if(currentCollectionBkupPath.equalsIgnoreCase("error")) {
							throw new Exception("Error in taking backup before restoring");
						}
					} else {
						jobLogger.info("Collection not available in solr so not taking backup before starting restore " ,  collection);
						System.out.println("Collection not available in solr so not taking backup before starting restore "+   collection);
					}
					
				}
				System.out.println(" Backup completed before starting restore");
				jobLogger.info("Preparing Restore for collection ",  restoreTask.getSolrCollectionName() );		
				ArrayList<String> configSetList = getSolrConfigList(host, portNo);
						
				for (int i = 0; i < collectionArr.length; i++) {
					 	String collection = collectionArr[i].trim();					 	
						logger.info("targetFolder " + targetFolder );
						logger.info("COLLECTION  " + collection );
						jobLogger.info(" Restore process started for collection ", collection);			
						StringBuilder sbDelete = new StringBuilder();
						String collDeleteUrl = sbDelete.append(url).append("admin/collections?action=DELETE&name=")
								.append(collection).toString();
						jobLogger.info("Requesting Solr to delete existing Collection before starting restore via   ", collDeleteUrl);
						boolean deleteCollection =  true ;
						if(collecList.contains(collection)) {
							deleteCollection = postSolr( collDeleteUrl,  jobLogger);
						} 
						if (deleteCollection) {
							StringBuilder sbDeleteConfig = new StringBuilder();
							String configSet = collectionConfigMap.get(collection);
							String collDeleteConfigUrl = sbDeleteConfig.append(url).append("admin/configs?action=DELETE&name=")
									.append(configSet).toString();
							boolean deleteConfigSet =  true ;
							if(configSetList.contains(configSet)) {
								deleteCollection = postSolr( collDeleteConfigUrl,  jobLogger);
							} 
							 
							if(deleteConfigSet) {
								StringBuilder sb1 = new StringBuilder();
								File targetfile = new File(targetFolder);
									
								logger.info(" SolrRestoreAll targetFolder " + targetFolder );		
								int  restoreStatusId = getRandom(10000);
								 String posturl = sb1.append(baseSolrUrl).append(collection)
											.append("&collection=").append(collection)
											.append("&location=").append(BackupUtil.replaceSpzCharacter(targetfile.getCanonicalPath()))	
											.append("&async=").append(restoreStatusId)
											.toString();
								 jobLogger.info("Requesting Solr to restore for Collection via   ", posturl);
								 logger.info(" Requesting Solr to restore for Collection via   " + posturl);
							
								// boolean isSuccess = postSolr( posturl,  jobLogger);
								 boolean isSuccess = postSolr( host,  portNo, restoreStatusId, targetFolder.replace("\\", "/"), posturl, collection, jobLogger);
								 StringBuilder sbClearStaus = new StringBuilder();
								 String clearStatuseUrl = sbClearStaus.append(url).append("admin/collections?action=DELETESTATUS&requestid=")
									.append(restoreStatusId).toString();
								 jobLogger.info("Requesting Solr to delete the request id  via   ", clearStatuseUrl);
								 logger.info(" Requesting Solr to delete the request id via   " + clearStatuseUrl);
							
								 postSolr( clearStatuseUrl,  jobLogger);
							
								 if (isSuccess) {	
									 System.out.println("  Successfully restore process completed for collection " + collection);
									 jobLogger.info("   Successfully restore process completed for collection ", collection);	
									 returnMsg = "done";	
									 isRestoreAllSuccess = true;
								 } else { 
									 System.out.println(" Restore process completed with error for collection " + collection);
									 jobLogger.info(" Restore process completed with error for collection ", collection);
									 returnMsg = "Error in Restoring the collection" + collection;
									 isRestoreAllSuccess = false;
									 break;									
								 }
							} else {
								jobLogger.info(" Error in deleting the configset for the collection. Restore is aborted ", collection);
								isRestoreAllSuccess = false;
								break;	
								
							}
							
						} else {	
							jobLogger.info(" Error in deleting the current collection. Restore is aborted ", collection);
							isRestoreAllSuccess = false;
							break;						
						}
						
				}
				 
				if (isRestoreAllSuccess) {
					jobLogger.info(" Update backup details with restore status as success and last restored date", "");
					updateBackupRestoreStatus(restoreTask.getBackupName(), "Success", host, portNo);
					jobLogger.info(" Delete the current backup taken before restore ", "");
					
					FileUtils.deleteDirectory(new File( bkTargetFolder));
					return "done";			 
				 }	else {
					 jobLogger.info("Error in Restoring the collection ", "");
					 //JsonArray collectionArray = getSolrCollectionList(host,portNo );
					 jobLogger.info(" Update backup details with restore status as fail and last restored date", "");
					 updateBackupRestoreStatus(restoreTask.getBackupName(), "Failed", host, portNo);
					 jobLogger.info("Error in Restoring ", "Delete the Invalid collection if exist before restoring the current backup");
					collecList = getSolrCollectionList(host, portNo);
					 for (int i = 0; i < collectionArr.length; i++) {
						 StringBuilder sbDelete = new StringBuilder();
						 String collection = collectionArr[i].trim();		
						 String collDeleteUrl = sbDelete.append(url).append("admin/collections?action=DELETE&name=")
									.append(collection).toString();		
						 //boolean deleteCollection = true;
						 if(collecList.contains(collection)) {
							 boolean deleteCollection = postSolr( collDeleteUrl,  jobLogger);
							 if(!deleteCollection) {
								 jobLogger.info("Error in Restoring ", "Error in Delete the Invalid collection"); 
								 FileUtils.deleteDirectory(new File( bkTargetFolder));
								 String msg =  "Error in Restoring the current Backup. Please check the log";
								 throw new Exception(msg);
							 } 
						 }
					 }
					 jobLogger.info("Error in Restoring ", " restore the current backup taken before restore started");
					 boolean isCurBkUprestore = false;
					 for (int i = 0; i < collectionArr.length; i++) {
						 StringBuffer sb1 = new StringBuffer();
						String collection =  collectionArr[i].trim();	
						//String backupTargetFolder =  bkTargetFolder + collection + "\\";	
						File tgfile = new File(bkTargetFolder);
						URI tguri = tgfile.toURI();
						StringBuilder sbDeleteConfig = new StringBuilder();
						String collDeleteConfigUrl = sbDeleteConfig.append(url).append("admin/configs?action=DELETE&name=")
								.append(collectionConfigMap.get(collection)).toString();
						boolean deleteConfigSet  = postSolr( collDeleteConfigUrl,  jobLogger);
						jobLogger.info("Error in Restoring deleteConfigSet : ", " " + deleteConfigSet); 
						String posturl =sb1.append(url).append("admin/collections?action=RESTORE&name=")
									.append(collection)
									.append("&collection=").append(collection)
									.append("&location=").append(tguri.toString())
									.toString();
						logger.info(" posturl   " + posturl );
						jobLogger.info("Requesting Solr restore for Collection via   ", posturl);
						boolean isSuccess = postSolr( posturl,  jobLogger);				
						if(isSuccess) {
							jobLogger.info("Successfully restored the current backup for collection   ", collection);
							isCurBkUprestore= true;
						} else {
							jobLogger.info("Failed to restore the current backup for collection   ", collection);
							isCurBkUprestore = false;
						}							
					}
					 if(isCurBkUprestore) {
						 jobLogger.info("Successfully restored and hence deleting the current backup files  ", bkTargetFolder);
						 FileUtils.deleteDirectory(new File( bkTargetFolder));
					 } else {
						 jobLogger.info("Failed to restore the current backup. Please check the log. The current backup is available in the path ", bkTargetFolder);
					 }
					 
						String msg =  "Error in Restoring the backup. Please check the log";
						throw new Exception(msg);
				}
			} else {
				returnMsg= " Backup files not available in the Target Path to restore " + targetFolder;
				logger.error(returnMsg);
				logger.error(returnMsg);
				jobLogger.info("Backup files not available in the Target Path to restore " , targetFolder);
				throw new Exception(returnMsg);
			}
			
			
		} catch (Exception e) {
			logger.error("Exception  in  SolrRestoreAll   " + e.getMessage() );
						e.printStackTrace();
						logger.error("Exception in SolrRestoreAll", e);
			if (e.getMessage().contains("Connection refused")) {
				logger.error("Given Port Number is Wrong...");
			}
			returnMsg = "Exception  in solr    " + e.getMessage();
			throw new Exception(e.getLocalizedMessage());
			//return returnMsg;
		}
		

	}
	
	private void updateBackupRestoreStatus(String backupName, String rStatus, String solarHost, String solarPort) throws SolrServerException, IOException {	
		// get existing project doc's id
		SolrQuery query = new SolrQuery();
		query.set("q","*:*" );		
		query.addFilterQuery("datatype:backupDetails");
		query.addFilterQuery("Name:\"" + GeoUtil.escapeQueryParams(backupName) + "\"");
		query.set("wt","json");
		try {
			CloseableHttpClient httpClient = WinHttpClients.createDefault();
			HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
					"http://" + solarHost + ":" + solarPort + "/solr/metadata" )).withHttpClient(httpClient).build();

			QueryResponse resp = client.query(query);
			int status = resp.getStatus();
			if ( status==0 ) {
				SolrDocumentList docs = resp.getResults();
				// update the project doc's Last_Scored field with current UTC datetime 
				for(SolrDocument doc : docs) {
					String id = (String) doc.getFieldValue("id");
					
					String restoreStatus = (String) doc.getFieldValue("restoreStatus");
					System.out.println("status1 : " + restoreStatus);
					SolrInputDocument projDoc = new SolrInputDocument();
					Map<String, String> partialUpdate = new HashMap<String, String>();
					partialUpdate.put("set", Instant.now().toString()  );	
					projDoc.addField("id",  id);
					//projDoc.addField("id", id.replace("\\", "\\\\"));
					
					projDoc.addField("Last_Modified_DateTime", partialUpdate);
					projDoc.addField("Last_Restored_DateTime", partialUpdate);	
					Map<String, String> partialUpdate1 = new HashMap<String, String>();
					if(restoreStatus!=null && restoreStatus.length() > 0) {
						partialUpdate1.put("set", rStatus  );
					} else {
						partialUpdate1.put("add", rStatus );
					}
					
					projDoc.addField("restoreStatus", partialUpdate1);
					logger.info(projDoc.toString());
					
					client.add(projDoc);	
					client.commit();
				}						
			}
			else {
				logger.info("  Status: " + status);
			}

		} catch (Exception e ) {	
			logger.error(" updateProject  Status: FAILED");
			logger.error("updateProject " + e.getMessage(), e);	
			e.printStackTrace();
			throw e;
		}				
		
	}

	
	private boolean postSolr(String url, GeodatafyJobLog jobLogger) throws Exception {
		
		logger.info("*************** postSolr **********************   " );
		HttpClient httpClient = HttpClientBuilder.create().build();	
		logger.info("postSolr URl to be posted  "  + url );
		HttpGet httpGet = new HttpGet(url);
		HttpResponse response = httpClient.execute(httpGet);
		System.out.println(response.toString());
		try {
			if (response.getStatusLine().getStatusCode() != 200) {
				logger.error("  Failed : HTTP error code : " + response.getStatusLine().getStatusCode() + "::"
						+ response.getStatusLine().getReasonPhrase());
				logger.error("  Failed : HTTP error code : " + response.getStatusLine().getStatusCode() + "::"
						+ response.getStatusLine().getReasonPhrase());
				jobLogger.info("post request failed : HTTP error code :   ", ":" + response.getStatusLine().getStatusCode());
				jobLogger.info("post request failed : HTTP Reason :   ", ":" + response.getStatusLine().getReasonPhrase()  );
				return false;
			} else {
				//logger.info("Successfully backed up for :" + collectionName + " at: " + targetFolder);				
				//jobLogger.info("Successfully restore up for :  ", collectionName);
				return true;
			}

		} catch (Exception e) {
			logger.error(" postSolr Exception  in solr postSolr   " + e.getMessage() );
			logger.error("Exception in solr postSolr", e);
			jobLogger.error("Exception occurred  in postSolr and the error message  :  ", e.getMessage());
			e.printStackTrace();	
			if (e.getMessage().contains("Connection refused")) {
				jobLogger.info("\"Given Port Number is Wrong... or Solr is not running..   ", e.getMessage());
				logger.error("Given Port Number is Wrong... or Solr is not running..");
				logger.error("\"Given Port Number is Wrong... or Solr is not running..   " + e.getMessage());
			}
			return false;
		} finally {
			//response.close();
			//httpClient.close();
		}
		

	}
	

	private boolean postSolr(String solrHost, String solrPort, int asyncId, String targetFolder, String url, String collectionName,   GeodatafyJobLog jobLogger) throws Exception {
	
		logger.info("*************** postSolr **********************   " );
		HttpClient httpClient = HttpClientBuilder.create().build();	
		logger.info("postSolr URl to be posted  "  + url );
		HttpGet httpGet = new HttpGet(url);
		HttpResponse response = httpClient.execute(httpGet);
		System.out.println("Async " + response.toString());
		try {
			if (response.getStatusLine().getStatusCode() != 200) {
				logger.error("  Failed : HTTP error code : " + response.getStatusLine().getStatusCode() + "::"
						+ response.getStatusLine().getReasonPhrase());
				logger.error("  Failed : HTTP error code : " + response.getStatusLine().getStatusCode() + "::"
						+ response.getStatusLine().getReasonPhrase());
				jobLogger.info("post request failed : HTTP error code :   ", ":" + response.getStatusLine().getStatusCode());
				jobLogger.info("post request failed : HTTP Reason :   ", ":" + response.getStatusLine().getReasonPhrase()  );
				return false;
			} else {
				//logger.info("Successfully backed up for :" + collectionName + " at: " + targetFolder);				
				//jobLogger.info("Successfully restore up for :  ", collectionName);
				int status = checkBackUpStatus(asyncId, solrHost, solrPort,jobLogger);
				for(; ;) {
					Thread.sleep(30000); //sleep for 30 second
					status = checkBackUpStatus(asyncId, solrHost,solrPort, jobLogger);
					if(status==1 || status==3) {
						break;						
					} else {
						continue;
					}
				}
				if(status==1) {
				//	logger.info("Successfully backed up for :" + collectionName + " at: " + targetFolder);
				//	jobLogger.info("Successfully backed up for :  ", collectionName);
				//	jobLogger.info("Successfully backed up at :  ", targetFolder);				
					return true;
				} else {
				//	jobLogger.info("Solr backup Failed : HTTP error code :   ", ":" + response.getStatusLine().getStatusCode());
				//	jobLogger.info("Solr backup Failed : HTTP Reason :   ", ":" + response.getStatusLine().getReasonPhrase()  );
					return false;
				}
			}

		} catch (Exception e) {
			logger.error(" postSolr Exception  in solr postSolr   " + e.getMessage() );
			logger.error("Exception in solr postSolr", e);
			jobLogger.error("Exception occurred in postSolr and the error message  :  ", e.getMessage());
			e.printStackTrace();	
			if (e.getMessage().contains("Connection refused")) {
				jobLogger.info("\"Given Port Number is Wrong... or Solr is not running..   ", e.getMessage());
				logger.error("Given Port Number is Wrong... or Solr is not running..");
				logger.error("\"Given Port Number is Wrong... or Solr is not running..   " + e.getMessage());
			}
			return false;
		} finally {
			//response.close();
			//httpClient.close();
		}
		

	}
	
	private int checkBackUpStatus(int asyncId, String solrHost, String solrPort,  GeodatafyJobLog jobLogger) throws Exception {
		CloseableHttpClient httpClient = WinHttpClients.createDefault();
		String statusUrl = "http://" + solrHost + ":" +   solrPort
				+ "/solr/admin/collections?action=REQUESTSTATUS&requestid=" + asyncId ;
		HttpGet httpGet = new HttpGet(statusUrl);
		HttpResponse response = httpClient.execute(httpGet);
		if (response.getStatusLine().getStatusCode() != 200) {
			throw new Exception("Exception occured in getting the backup staus request API");
		} else {
		 StringBuffer strBuffer = new StringBuffer();
		 BufferedReader rd = new BufferedReader(new InputStreamReader(
                    response.getEntity().getContent()));
            String line = "";
            while ((line = rd.readLine()) != null) {
            	strBuffer.append(line);
            }
            logger.info(strBuffer.toString());
            jobLogger.info("Response from Solr : " ,  strBuffer.toString());
            JSONObject json = new JSONObject(strBuffer.toString());
            
            Iterator it = json.keys();
            while(it.hasNext()) {
            	 String key = (String)it.next();
            	 if ( json.get(key) instanceof JSONObject ) {
            		 JSONObject jsonKeyObj = new JSONObject(json.get(key).toString());
            		 if(jsonKeyObj.has("STATUS")) {
            			 String bkupState = (String) jsonKeyObj.get("STATUS");
            			 if(bkupState.equalsIgnoreCase("failed")) {
            				 jobLogger.info("Backup status Failed " , "");
            				 String responseFromsolr = (String) jsonKeyObj.get("Response");
            				 jobLogger.info("Reason For backup failure " , responseFromsolr);
            				 return 3;
            			 }
 
            		 }
            			 
            	 }
            }

            
            if (json.has("status")) {
            	JSONObject jsonObj = json.getJSONObject("status");
            	String bkupState = (String) jsonObj.get("state");
            	
            	if(bkupState.equalsIgnoreCase("completed")) {
            		return 1;	            		
            	} else if(bkupState.equalsIgnoreCase("running")) {
            		return 2;            		
            	} else if(bkupState.equalsIgnoreCase("submitted")) {
            		return 2;
            	} else {
            		return 3;
            	}
            	
            } else {
            	jobLogger.info("checkRestoreStatus : json has no status in response.", "");
            	//return 2;
            	throw new Exception("Exception occurred in getting the backup/restore staus request API");
            }	
		}
		
		
	}
	
	
	public static void main(String args[]) throws Exception {
		RestoreUtil restoreObj = new RestoreUtil();
		// declare a variable that will store the user input
		if (args.length != 3) {
			System.out.println("Requires 3 arguments: Host, Port number, Backup Folder. ");
		} else {
			String host = args[0].trim();
			//System.out.println("host:" + host);
			String portNo = args[1].trim();
			//System.out.println(" portNo" + portNo);
			String backupFolder = args[2].trim();
			//System.out.println("backupFolder :" + backupFolder);	
			String userInput;
			
			ArrayList<BackupActiveJob> list = restoreObj.getBkupListFromDir(host, backupFolder);
			
			int i = 1;
			for (BackupActiveJob backupJobObj1 : list) {
				System.out.println(i++ + ":\t" + backupJobObj1.getBackupDate()
						+ "\t" + backupJobObj1.getBackupTime() + "\t"
						+ backupJobObj1.getCollection() + "\t"
						+ backupJobObj1.getBackupFolder());
			}
			int j=0;
			System.out.println(j + ":\t" + "Exit");
			// declate a scanner object to read the command line input by user
			Scanner sn = new Scanner(System.in);

			if (list.size() > 0) {
				
				System.out.println("*****Available Options*****");
				System.out.println("*. Press option from the list above");
				System.out.println("Enter your choice:");
				userInput = sn.next();
				// Check the user input
				int input = new Integer(userInput).intValue();
				if (input == 0) {
					System.exit(0);
				}
				if (input > 0 && input <= list.size()) {
				
					BackupActiveJob backupJobObj1 = list.get(input - 1);
					System.out.println(backupJobObj1.getBackupDate() + "\t"
							+ backupJobObj1.getBackupTime() + "\t"
							+ backupJobObj1.getCollection() + "\t"
							+ backupJobObj1.getBackupFolder());
					String arg[] = { "192.168.2.231", "8983",
							backupJobObj1.getCollection(),
							backupJobObj1.getBackupFolder() };
					//RestoreUtil.main(arg);
					String msg = restoreObj.runSolrRestoreJob(host, portNo, backupJobObj1.getCollection(), backupJobObj1.getBackupFolder(), backupJobObj1.getName());
					System.out.println(msg);
					System.out.println("Restore Process Completed.");

				} else {
					System.out.println("Invalid choice. Read the options carefully...");
				}
			} else {
				System.out.println("No Backup available in the given path "
						+ backupFolder + "\\" + host);
			}

			
			
		}
		
	}
	
	private ArrayList<BackupActiveJob> getBkupListFromDir(String host, String backupFolder) throws Exception {
		ArrayList<BackupActiveJob> list = new ArrayList<BackupActiveJob>();
		File[] directories = new File(backupFolder +"\\" + host).listFiles(File::isDirectory);
		if(directories == null || directories.length <=0) {
			System.out.println("No Backup available in the given path "
					+backupFolder +"\\" + host );
			System.exit(1);
		}
		for (int i = 0; i < directories.length; i++) {
			File f = directories[i];
			System.out.println("bkupJobName : " + f.getName());

			File[] bkupJobNames = new File(f.getCanonicalPath()).listFiles(File::isDirectory);
			if(bkupJobNames == null || bkupJobNames.length <=0) {
				System.out.println("No Backup available in the given path "
						+ f.getCanonicalPath());
				//System.exit(1);
				continue;
			}
			
			for (int j = 0; j < bkupJobNames.length; j++) {
				File bkupJobName = bkupJobNames[j];
				
				File[] bkupNameList = new File(bkupJobName.getCanonicalPath())	.listFiles(File::isDirectory);
				StringBuilder sbList = new StringBuilder();
				if(bkupNameList == null || bkupNameList.length <=0) {
					System.out.println("No Backup available in the given path "
							+ bkupJobName.getCanonicalPath());
					continue;
				}
				
				for (int k = 0; k < bkupNameList.length; k++) {
					File subdir = bkupNameList[k];
					sbList.append(subdir.getName()).append(",");
				}
				String collectionNames = sbList.toString().substring(0,sbList.toString().length() - 1);
				//System.out.println(collectionNames);
				BackupActiveJob backupJobObj = new BackupActiveJob();
				backupJobObj.setName(f.getName());
				backupJobObj.setBackupFolder(bkupJobName.getCanonicalPath());
				backupJobObj.setCollection(collectionNames);
				String DateTime = bkupJobName.getName();
				try {
					String strDate = DateTime.substring(0,DateTime.lastIndexOf("_"));
					String strTime = DateTime.substring(DateTime.lastIndexOf("_") + 1);
					SimpleDateFormat fromUser = new SimpleDateFormat("ddMMyyyy");
					SimpleDateFormat myFormat = new SimpleDateFormat("dd/MMM/yyyy");

					String reformattedStr = myFormat.format(fromUser.parse(strDate));
					SimpleDateFormat fromTimePattr = new SimpleDateFormat("HHmmss");
					SimpleDateFormat toTimePattr = new SimpleDateFormat("HH:mm:ss");
					String formattedTime = toTimePattr.format(fromTimePattr.parse(strTime));
					backupJobObj.setBackupDate(reformattedStr);
					backupJobObj.setBackupTime(formattedTime);
					list.add(backupJobObj);
				} catch (Exception e) {
					// e.printStackTrace();
				}

			}
		}
		return list;
		
	}
	
	private ArrayList<String> getSolrCollectionList(String solrHost, String solrPort) {
		StringBuilder stringBuilder = new StringBuilder();
		BufferedReader reader = null;
		HttpURLConnection connection = null;
		//StringBuilder sb = new StringBuilder();
		String collectionurl = "http://" + solrHost + ":" + solrPort + "/solr/admin/collections?action=LIST&wt=json";
		try {

			URL tempUrl = new URL(collectionurl);
			connection = (HttpURLConnection) tempUrl.openConnection();
			connection.connect();
			reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String line = null;
			while ((line = reader.readLine()) != null) {
				stringBuilder.append(line + "\n");

			}

		} catch (Exception e) {
			e.printStackTrace();
			if (e.getMessage().contains("Connection refused")) {
				System.out.println("Given Port Number is Wrong... or Solr is not running..");
			}

		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
			if (connection != null) {
				connection.disconnect();
			}
		}
		JsonElement jsenelemRes = JsonUtil.getJsonElement(stringBuilder.toString());
		JsonElement jsenelemCollRes = JsonUtil.getSubElement(jsenelemRes, "collections");
		JsonArray collectionArr = JsonUtil.convertToJsonArray(jsenelemCollRes);
		ArrayList<String> collectionList = new ArrayList<String>();
		for(JsonElement element : collectionArr) {
			collectionList.add(element.getAsString().trim());
		}
		return collectionList;
	}
	private ArrayList<String> getSolrConfigList(String solrHost, String solrPort) {
		StringBuilder stringBuilder = new StringBuilder();
		BufferedReader reader = null;
		HttpURLConnection connection = null;
		//StringBuilder sb = new StringBuilder();
		String collectionurl = "http://" + solrHost + ":" + solrPort + "/solr/admin/configs?action=LIST&wt=json";
		try {

			URL tempUrl = new URL(collectionurl);
			connection = (HttpURLConnection) tempUrl.openConnection();
			connection.connect();
			reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String line = null;
			while ((line = reader.readLine()) != null) {
				stringBuilder.append(line + "\n");

			}

		} catch (Exception e) {
			e.printStackTrace();
			if (e.getMessage().contains("Connection refused")) {
				System.out.println("Given Port Number is Wrong... or Solr is not running..");
			}

		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
			if (connection != null) {
				connection.disconnect();
			}
		}
		JsonElement jsenelemRes = JsonUtil.getJsonElement(stringBuilder.toString());
		JsonElement jsenelemConfigRes = JsonUtil.getSubElement(jsenelemRes, "configSets");
		JsonArray cnfigSetArr = JsonUtil.convertToJsonArray(jsenelemConfigRes);
		ArrayList<String> configSetList = new ArrayList<String>();
		for(JsonElement element : cnfigSetArr) {
			configSetList.add(element.getAsString().trim());
		}
		return configSetList;
	}

	
	
	private HashMap<String, String> getSolrCollectionConfig(String solrHost, String solrPort) throws Exception{
		StringBuilder stringBuilder = new StringBuilder();
		BufferedReader reader = null;
		HttpURLConnection connection = null;
		//StringBuilder sb = new StringBuilder();
		String collectionurl = "http://" + solrHost + ":" + solrPort + "/solr/admin/collections?action=CLUSTERSTATUS&wt=json";
		try {

			URL tempUrl = new URL(collectionurl);
			connection = (HttpURLConnection) tempUrl.openConnection();
			connection.connect();
			reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String line = null;
			while ((line = reader.readLine()) != null) {
				stringBuilder.append(line + "\n");

			}

		} catch (Exception e) {
			e.printStackTrace();
			if (e.getMessage().contains("Connection refused")) {
				System.out.println("Given Port Number is Wrong... or Solr is not running..");
			}

		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
			if (connection != null) {
				connection.disconnect();
			}
		}
		System.out.println(stringBuilder.toString());
		JsonElement jsenelemRes = JsonUtil.getJsonElement(stringBuilder.toString());
		JsonElement jsenelemClusterRes = JsonUtil.getSubElement(jsenelemRes, "cluster");
		JsonElement jsenelemColl = JsonUtil.getSubElement(jsenelemClusterRes, "collections");
		JSONObject json = new JSONObject(jsenelemColl.toString());
		Iterator<String> keys = json.keys();
		HashMap<String, String> collecConfigMap = new HashMap<String, String>();
		while(keys.hasNext()) {
		    String key = keys.next();
		    if (json.get(key) instanceof JSONObject) {
		    	JSONObject jsonColl = (JSONObject) json.get(key);
		    	System.out.println(jsonColl.get("configName"));
		    	collecConfigMap.put(key, (String)jsonColl.get("configName"));
		    }
		}
	
		//System.out.println(jsenelemColl.toString());
		/*JsonArray collectionArr = JsonUtil.convertToJsonArray(jsenelemCollRes);
		ArrayList<String> collectionList = new ArrayList<String>();
		for(JsonElement element : collectionArr) {
			collectionList.add(element.getAsString().trim());
		}*/
		return collecConfigMap;
	}
	
	
	
	
	

	
	
	
	public String getSolrBackupJobs( String solarHost, String solarPort)  {
		ArrayList<BackupActiveJob> bkupJobList = new ArrayList<BackupActiveJob>();
		try {
			CloseableHttpClient httpClient = WinHttpClients.createDefault();
			HttpSolrClient client = (new org.apache.solr.client.solrj.impl.HttpSolrClient.Builder(
					"http://" + solarHost + ":" + solarPort + "/solr/metadata" )).withHttpClient(httpClient).build();

			SolrQuery query = new SolrQuery();

			query.setQuery("*:*"); // main query
			query.set("wt", "json");
			query.setRows(2147483647);		
			
			String strQryByBackupdet = "datatype:backupDetails";
			logger.info("strQryBy for backupdetails ----> " +   strQryByBackupdet);
			//System.out.println("strQryBy for backupdetails ----> " +   strQryByBackupdet);
			query.addFilterQuery(strQryByBackupdet);
			//logger.info(query.toQueryString());			
			QueryResponse resp = client.query(query);
			logger.info("backupdetails  QueryResponse: " + resp.getResponse().toString());
			//System.out.println("backupdetails  QueryResponse: " + resp.getResponse().toString());
			SolrDocumentList docList = resp.getResults();
			logger.info(" backupdetails QueryResponse Num : " + docList.getNumFound());
			//System.out.println(" backupdetails QueryResponse Num : " + docList.getNumFound());
			if (docList.getNumFound() > 0 ) {	
				
				for (Map singleDoc : docList) {
					//Gson gson = new Gson();		
					Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'hh:mm:ss.sss'Z'").create();
					System.out.println(gson.toJson(singleDoc));
					RestoreJob restoreJob = gson.fromJson(gson.toJson(singleDoc), RestoreJob.class);
					//bkupJobList = gson.fromJson("[" + gson.toJson(singleDoc) + "]", new TypeToken<List<RestoreJob>>(){}.getType());
					for (String bkuppath : restoreJob.getBackupRetainedDetails()) {
						BackupActiveJob backupJobObj = new BackupActiveJob();
						backupJobObj.setId(restoreJob.getId());
						//System.out.println(" restoreJob.getName() : " + restoreJob.getName());
						backupJobObj.setName(restoreJob.getName());		
						String DateTime = bkuppath.substring(bkuppath.lastIndexOf("\\")+1);
						String strDate = DateTime.substring(0, DateTime.lastIndexOf("_"));
						String strTime = DateTime.substring(DateTime.lastIndexOf("_")+1);	
						SimpleDateFormat fromUser = new SimpleDateFormat("ddMMyyyy");
						SimpleDateFormat myFormat = new SimpleDateFormat("dd/MMM/yyyy");
						
						String reformattedStr = myFormat.format(fromUser.parse(strDate));
						System.out.println(" reformattedStr : " + reformattedStr);
					
						SimpleDateFormat fromTimePattr = new SimpleDateFormat("HHmmss");
						SimpleDateFormat toTimePattr = new SimpleDateFormat("HH:mm:ss");
						
						String formattedTime = toTimePattr.format(fromTimePattr.parse(strTime));
						System.out.println(" formattedTime : " + formattedTime);
						
						backupJobObj.setBackupDate(reformattedStr);
						backupJobObj.setBackupTime(formattedTime);
						String bkupDate = reformattedStr + formattedTime;
						backupJobObj.setBkupDateTime(getFormatedUTCTime(bkupDate));
						System.out.println(" bkupDate : " + bkupDate);
						backupJobObj.setBackupFolder(bkuppath);
						String collectionNames = restoreJob.getCollection();
						backupJobObj.setCollection(collectionNames);
						backupJobObj.setRestoreStatus(restoreJob.getRestoreStatus());
						backupJobObj.setLast_Restored_DateTime(restoreJob.getLast_Restored_DateTime());
						File file = new File(bkuppath);
						String[] collectionList = collectionNames.split(",");
						boolean isResDirExist = CheckFolderExist(collectionList, bkuppath);
						if (isResDirExist) {
							//System.out.println(" isResDirExist.status : All" +  isResDirExist);
							bkupJobList.add(backupJobObj);
						}
								
					} 
				}
							
			} else {
				String msg="No data found  ";
				logger.info("Backup not available to restore");
				throw new RuntimeException(msg);
			}
		} catch (Exception e) {
			logger.info("Backup not available to restore");
			//logger.error(e.getStackTrace().toString());
			//logger.info("Exception during execution of Solar Query for getSolrBackupJobs   ------>: " ,  e);
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
			//return null;
		} finally {

		}	
		Gson gsonBuilder = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'hh:mm:ss.sss'Z'").create();
		String jsonFromJavaArrayList = gsonBuilder.toJson(bkupJobList);
		System.out.println(bkupJobList.size());
		System.out.println("Returned File List  ------>: " + jsonFromJavaArrayList);
		return jsonFromJavaArrayList;		
		
		
	}	
	
	  public String getFormatedUTCTime(String strDate) throws Exception{
			
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.sss'Z'");
			df.setTimeZone(TimeZone.getTimeZone("UTC"));	
			  ZonedDateTime zdt = ZonedDateTime.now(ZoneOffset.UTC);
			DateFormat formatter = new SimpleDateFormat("dd/MMM/yyyyHH:mm:ss");
			formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
			Date dateObj=null;
			try {
				dateObj = (Date)formatter.parse(strDate);
			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception(e.getMessage());
			}
			String retStrDate = df.format(new Date(dateObj.getTime())).toString();
			return retStrDate;
		}
	  
	  private String getUTCTime(String strDate) throws Exception{
			
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.sss'Z'");
			df.setTimeZone(TimeZone.getTimeZone("UTC"));	
			  ZonedDateTime zdt = ZonedDateTime.now(ZoneOffset.UTC);
			DateFormat formatter = new SimpleDateFormat("MMM dd yyyy HH:mm:ss Z ");
			Date dateObj=null;
			try {
				dateObj = (Date)formatter.parse(strDate);
			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception(e.getMessage());
			}
			String retStrDate = df.format(new Date(dateObj.getTime())).toString();
			return retStrDate;
		}
	  

	
	
	
	

	

	
	



	

}
